var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../lime", "../core"], function (require, exports, lm, c) {
    var Widget = (function (_super) {
        __extends(Widget, _super);
        function Widget(parentContext, data, isNew, byRef) {
            _super.call(this, "[Widget] ");
            this.parentContext = parentContext;
            this.data = data;
            this.isNew = isNew;
            this.addedEvent = new c.InstanceEvent();
            this.changedEvent = new c.InstanceEvent();
            this.destroyedEvent = new c.InstanceEvent();
            this.removedEvent = new c.InstanceEvent();
            this.restoredEvent = new c.InstanceEvent();
            this.updatedEvent = new c.InstanceEvent();
            this.enableSettingsCurrent = false;
            this.enableTitleEditDef = true;
            this.enableSettingsMenu = true;
            this.byRef = false;
            this.externalUrl = null;
            if (byRef) {
                this.byRef = byRef;
            }
            this.state = lm.WidgetState.running;
            this.instance = {};
            if (isNew) {
                data.instanceId = lm.CommonUtil.random();
            }
        }
        Widget.prototype.isPublished = function () {
            var def = this.definition;
            return def && !!def.standardWidgetId;
        };
        Widget.prototype.isSettingsEnabled = function () {
            return (this.enableSettings || this.enableSettingsCurrent) && this.enableSettingsDef;
        };
        Widget.prototype.isCatalogTitle = function () {
            var customWidget = this.definition.custom;
            if (customWidget) {
                return customWidget.isCatalogTitle === true;
            }
            var customItem = this.data.custom;
            if (customItem && customItem.definition) {
                return customItem.definition.isCatalogTitle === true;
            }
            return false;
        };
        Widget.prototype.isSettingsMenuEnabled = function () {
            return (this.enableSettingsMenu || this.enableSettingsCurrent) && this.enableSettingsDef;
        };
        Widget.prototype.setSettingsMenuEnabled = function (enabled) {
            if (this.enableSettingsMenu !== enabled) {
                this.enableSettingsMenu = enabled;
                this.raiseUpdated();
            }
        };
        Widget.prototype.isEnableSettingsTemporary = function () {
            return this.enableSettingsCurrent;
        };
        Widget.prototype.enableSettingsTemporary = function (enable) {
            if (this.enableSettingsDef) {
                this.enableSettingsCurrent = enable;
            }
        };
        Widget.prototype.copyFrom = function (source) {
            this.enableSettings = source.enableSettings;
            this.enableSettingsMenu = source.enableSettingsMenu;
            this.enableSettingsCurrent = source.enableSettingsCurrent;
            this.enableSettingsDef = source.enableSettingsDef;
            this.enableTitleEditDef = source.enableTitleEditDef;
        };
        Widget.prototype.hasVisibleActions = function () {
            var actions = this.instance.actions;
            if (actions) {
                for (var _i = 0; _i < actions.length; _i++) {
                    var action = actions[_i];
                    if (action.isVisible !== false) {
                        return true;
                    }
                }
            }
            return false;
        };
        Widget.prototype.calculateTitle = function (isTitleLocked) {
            var isCatalogTitle = this.isCatalogTitle();
            var data = this.data;
            var title;
            if (!isCatalogTitle && isTitleLocked) {
                title = this.titleApi || data.titleApi;
                if (title) {
                    return title;
                }
                return this.definition.standardTitle;
            }
            if (isCatalogTitle) {
                isTitleLocked = true;
            }
            var custom = data.custom;
            if (custom) {
                var definition = custom.definition;
                if (definition && isCatalogTitle) {
                    var localization = custom.localization;
                    if (localization) {
                        var lang = localization[infor.lime.language];
                        if (lang) {
                            title = lang.title;
                            if (title) {
                                return title;
                            }
                        }
                    }
                    return definition.title || this.definition.standardTitle;
                }
            }
            var publishedCustom = this.definition.custom;
            if (publishedCustom) {
                if (isCatalogTitle) {
                    title = this.definition.title;
                    return title || this.definition.standardTitle;
                }
                if (!isTitleLocked) {
                    if ((this.enableSettingsCurrent || this.isTitleEditEnabled) && data.title) {
                        return data.title;
                    }
                    if (publishedCustom.title) {
                        return publishedCustom.title;
                    }
                }
            }
            if (!isTitleLocked) {
                title = data.title;
                if (title) {
                    return title;
                }
            }
            return this.definition.standardTitle;
        };
        Widget.prototype.updateTitle = function () {
            this.title = this.calculateTitle(this.data.isTitleLocked);
        };
        Widget.prototype.setTitleInternal = function (title) {
            this.data.title = title;
            this.updateTitle();
        };
        Widget.prototype.getDefaultTitle = function () {
            return this.definition.standardTitle;
        };
        Widget.prototype.setDefinition = function (sourceDefinition, addWidgetInfo) {
            var customWidget = null;
            var widgetData = this.data;
            if (addWidgetInfo) {
                customWidget = addWidgetInfo.customWidget;
            }
            var definition = angular.copy(sourceDefinition);
            definition.original = sourceDefinition;
            this.definition = definition;
            this.id = definition.widgetId;
            this.externalUrl = definition.url;
            this.widgetType = definition.type;
            this.accessLevel = definition.accessLevel;
            this.standardAccessLevel = definition.standardAccessLevel;
            var enableSettings = !(definition.enableSettings === false);
            this.enableSettingsDef = definition.enableSettingsDef !== false;
            var enableTitleEdit = !(definition.enableTitleEdit === false);
            this.enableTitleEditDef = definition.enableTitleEditDef !== false;
            var settingsDefinition = definition.settings;
            var byCopy = !this.byRef;
            var byRef = this.byRef;
            var isPublished = definition.isPublished;
            var isParentPublished = this.parentContext.isPublished;
            var hasDefinitionMetadata = settingsDefinition ? true : false;
            var settingsValues = widgetData.settings || {};
            widgetData.settings = settingsValues;
            var userSettingsValues = null;
            if (isParentPublished || isPublished) {
                userSettingsValues = this.parentContext.userSettings;
            }
            var editableSettings = [];
            var customMetadata;
            if (customWidget) {
                settingsValues = customWidget.settings;
                if (customWidget.title) {
                    widgetData.title = customWidget.title;
                }
                widgetData.isTitleLocked = customWidget.isTitleLocked === true;
                widgetData.logicalId = customWidget.logicalId;
                widgetData.titleApi = customWidget.titleApi;
            }
            if (isPublished) {
                var custom = definition.custom;
                if (custom) {
                    customMetadata = custom.metadata;
                    settingsValues = custom.settings || {};
                    widgetData.isTitleLocked = custom.isTitleLocked === true;
                    widgetData.logicalId = custom.logicalId;
                    widgetData.titleApi = custom.titleApi;
                }
            }
            else if (byCopy) {
                if (widgetData.custom) {
                    var customDefinition = widgetData.custom.definition;
                    if (customDefinition) {
                        customMetadata = customDefinition.settings;
                        if (enableSettings && customDefinition.enableSettings === false) {
                            enableSettings = false;
                        }
                        if (enableTitleEdit && customDefinition.enableTitleEdit === false) {
                            enableTitleEdit = false;
                        }
                    }
                }
                else if (isParentPublished) {
                    enableSettings = false;
                    enableTitleEdit = false;
                }
            }
            var hasCustomMetadata = lm.CommonUtil.hasValue(customMetadata);
            if (hasCustomMetadata) {
                definition.customMetadata = angular.copy(customMetadata);
            }
            var baseMetadata = [];
            if (hasDefinitionMetadata) {
                baseMetadata = definition.settings || [];
                if (hasCustomMetadata) {
                    baseMetadata = WidgetUtil.applyRestrictions(baseMetadata, customMetadata);
                }
            }
            else {
                if (hasCustomMetadata) {
                    baseMetadata = customMetadata;
                }
            }
            var name = null;
            var resultMetadata = [];
            for (var j = 0; j < baseMetadata.length; j++) {
                var metadata = baseMetadata[j];
                if (!metadata) {
                    continue;
                }
                name = metadata.name;
                var isEnabled = metadata.isEnabled !== false;
                if (isEnabled) {
                    editableSettings.push(name);
                }
                var value = this.getDefaultSettingsValue(name, isEnabled, settingsValues, userSettingsValues, settingsDefinition);
                settingsValues[name] = value;
                resultMetadata.push(metadata);
            }
            if (this.isNew || byRef) {
                widgetData.settings = settingsValues;
            }
            if (userSettingsValues && enableTitleEdit) {
                if (userSettingsValues["isTitleLocked"]) {
                    widgetData.isTitleLocked = true;
                }
                else {
                    widgetData.isTitleLocked = false;
                    var title = userSettingsValues[lm.WidgetConstants.widgetTitle];
                    if (title) {
                        widgetData.title = title;
                    }
                }
            }
            this.isTitleEditEnabled = enableTitleEdit;
            this.enableSettings = enableSettings;
            this.updateTitle();
            if (this.isNew && byCopy) {
                if (!definition.standardWidgetId) {
                    if (definition.enableSettingsDef === true && this.standardAccessLevel === c.WidgetAccessLevel.Configure) {
                        this.enableSettings = true;
                    }
                    if (definition.enableTitleEditDef === true) {
                        this.isTitleEditEnabled = true;
                    }
                    widgetData.id = definition.widgetId;
                }
                return;
            }
            definition.settings = resultMetadata;
        };
        Widget.prototype.getDefaultSettingsValue = function (name, isEnabled, widgetSettings, userSettings, definitionMetaData) {
            var value = null;
            if (isEnabled) {
                if (userSettings) {
                    value = userSettings[name];
                }
                if (lm.CommonUtil.hasValue(value)) {
                    return value;
                }
            }
            if (widgetSettings) {
                value = widgetSettings[name];
                if (lm.CommonUtil.hasValue(value)) {
                    return value;
                }
            }
            if (definitionMetaData) {
                var metadata = lm.ArrayUtil.itemByProperty(definitionMetaData, "name", name);
                if (metadata) {
                    return angular.copy(metadata.defaultValue);
                }
            }
            return null;
        };
        Widget.prototype.getUserData = function () {
            var definition = this.definition;
            var isSettingsEnabled = this.enableSettings && this.enableSettingsDef;
            if (!this.context || !definition || !isSettingsEnabled) {
                return null;
            }
            var data = null;
            var settings = this.context.getSettings();
            var settingsMetadata = definition.settings;
            if (settingsMetadata) {
                for (var _i = 0; _i < settingsMetadata.length; _i++) {
                    var setting = settingsMetadata[_i];
                    if (setting.isEnabled !== false) {
                        if (!data) {
                            data = {};
                        }
                        var name_1 = setting.name;
                        data[name_1] = settings.get(name_1);
                    }
                }
            }
            if (this.isTitleEditEnabled) {
                if (!data) {
                    data = {};
                }
                var isTitleLocked = this.data.isTitleLocked;
                if (!isTitleLocked) {
                    data[lm.WidgetConstants.widgetTitle] = this.data.title;
                }
                data["isTitleLocked"] = isTitleLocked;
            }
            return data;
        };
        Widget.prototype.updateSettings = function (triggerChanged) {
            if (triggerChanged === void 0) { triggerChanged = true; }
            var instance = this.instance;
            if (instance && instance.settingsSaved) {
                try {
                    instance.settingsSaved({ settings: this.context.getSettings() });
                }
                catch (e) {
                    this.error("Failed to invoke the settingsSaved event handler", e);
                }
            }
            if (triggerChanged) {
                this.raiseChanged();
            }
        };
        Widget.prototype.changed = function () {
            return this.changedEvent;
        };
        Widget.prototype.raiseChanged = function () {
            this.changedEvent.raise(this);
        };
        Widget.prototype.remove = function () {
            this.removedEvent.raise(this);
        };
        Widget.prototype.removed = function () {
            return this.removedEvent;
        };
        Widget.prototype.raiseAdded = function () {
            this.addedEvent.raise(this);
        };
        Widget.prototype.added = function () {
            return this.addedEvent;
        };
        Widget.prototype.restored = function () {
            return this.restoredEvent;
        };
        Widget.prototype.updated = function () {
            return this.updatedEvent;
        };
        Widget.prototype.raiseUpdated = function () {
            this.updatedEvent.raise(this);
        };
        Widget.prototype.destroyed = function () {
            return this.destroyedEvent;
        };
        Widget.prototype.destroy = function () {
            this.destroyedEvent.raise(this);
            this.addedEvent.clear();
            this.changedEvent.clear();
            this.destroyedEvent.clear();
            this.removedEvent.clear();
            this.restoredEvent.clear();
            this.updatedEvent.clear();
            var instance = this.instance;
            instance.activated = null;
            instance.deactivated = null;
            instance.settingsOpening = null;
            instance.settingsSaved = null;
            instance.getMetadata = null;
            instance.editing = null;
            instance.edited = null;
            instance.publishing = null;
            if (instance.actions) {
                for (var _i = 0, _a = instance.actions; _i < _a.length; _i++) {
                    var action = _a[_i];
                    action.execute = null;
                }
            }
        };
        Widget.prototype.getMetadata = function () {
            var f = this.instance.getMetadata;
            return f ? f() : this.definition.settings;
        };
        Widget.prototype.restore = function () {
            var settings = {};
            var metadata = this.getMetadata();
            if (metadata) {
                for (var _i = 0; _i < metadata.length; _i++) {
                    var item = metadata[_i];
                    var value = item.defaultValue;
                    if (lm.CommonUtil.hasValue(value)) {
                        settings[item.name] = angular.copy(value);
                    }
                }
            }
            this.data.settings = settings;
            this.raiseChanged();
            this.restoredEvent.raise(this);
        };
        return Widget;
    })(c.CoreBase);
    exports.Widget = Widget;
    var WidgetUtil = (function () {
        function WidgetUtil() {
        }
        WidgetUtil.getUrl = function (definition, path) {
            var widgetPath;
            var devPath = definition.devPath;
            if (devPath) {
                widgetPath = devPath;
            }
            else {
                var id = definition.isPublished ? definition.standardWidgetId : definition.widgetId;
                widgetPath = "widgets/" + id + "/" + definition.version;
            }
            if (path && path.length > 0) {
                widgetPath = widgetPath + (path.charAt(0) !== "/" ? "/" : "") + path;
            }
            return widgetPath;
        };
        WidgetUtil.cacheTemplates = function (templateCache, config) {
            var items = config.templates;
            if (items) {
                for (var _i = 0; _i < items.length; _i++) {
                    var item = items[_i];
                    var key = item.key;
                    if (!templateCache.get(key)) {
                        templateCache.put(key, item.value);
                    }
                }
            }
        };
        WidgetUtil.addAngularContent = function (scope, compile, element, config, definition) {
            var template = config.template;
            if (!template) {
                var templateUrl = config.cachedTemplateUrl;
                if (!templateUrl) {
                    templateUrl = config.relativeTemplateUrl;
                    if (templateUrl) {
                        var devPath = definition.devPath;
                        if (devPath) {
                            templateUrl = devPath + "/" + templateUrl;
                        }
                        else {
                            templateUrl = WidgetUtil.getUrl(definition, templateUrl);
                        }
                    }
                }
                if (templateUrl) {
                    template = "<div ng-include=\"'" + templateUrl + "'\" class=\"lm-size-full\"></div>";
                }
            }
            var scopeValue = config.scopeValue;
            if (scopeValue) {
                scope[scopeValue.name] = scopeValue.value;
            }
            if (template) {
                element.append(compile($(template))(scope));
                return;
            }
        };
        WidgetUtil.getLayoutClasses = function (layout) {
            var str = "";
            if (layout.columnSpan === 2) {
                str += "double-width";
            }
            else if (layout.columnSpan === 3) {
                str += "triple-width";
            }
            else if (layout.columnSpan === 4) {
                str += "quad-width";
            }
            if (layout.rowSpan === 2) {
                str += " double-height";
            }
            return str;
        };
        WidgetUtil.applySettingsValues = function (metadataArray, valuesMap) {
            if (!valuesMap) {
                return;
            }
            for (var _i = 0; _i < metadataArray.length; _i++) {
                var metadata = metadataArray[_i];
                var value = valuesMap[metadata.name];
                if (value) {
                    metadata.defaultValue = value;
                }
            }
        };
        WidgetUtil.getTranslation = function (key, lang) {
            if (!lang) {
                return key;
            }
            if (lang.hasOwnProperty(key)) {
                var value = lang[key];
                if (value && value.length > 0) {
                    return value;
                }
            }
            return key;
        };
        WidgetUtil.copySettings = function (settings, instanceSettings, lang) {
            var settingsCopy = [];
            for (var _i = 0; _i < settings.length; _i++) {
                var setting = settings[_i];
                var instanceValue = instanceSettings[setting.name];
                var copy = angular.copy(setting);
                if (instanceValue) {
                    copy.defaultValue = instanceValue;
                }
                copy[WidgetUtil.labelProperty] = WidgetUtil.getTranslation(copy.labelId, lang);
                settingsCopy.push(copy);
            }
            ;
            return settingsCopy;
        };
        WidgetUtil.applyRestrictions = function (currentMetadata, restrictingMetadata) {
            if (!currentMetadata || !restrictingMetadata) {
                return currentMetadata;
            }
            currentMetadata = angular.copy(currentMetadata);
            for (var _i = 0; _i < restrictingMetadata.length; _i++) {
                var restricting = restrictingMetadata[_i];
                var isEnabled = restricting.isEnabled !== false;
                var isVisible = restricting.isVisible !== false;
                var current = lm.ArrayUtil.itemByProperty(currentMetadata, "name", restricting.name);
                if (current) {
                    if (!isEnabled) {
                        current.isEnabled = false;
                    }
                    if (!isVisible) {
                        current.isVisible = false;
                    }
                }
            }
            return currentMetadata;
        };
        WidgetUtil.getSettingsFromMetadata = function (metadata, values, lang) {
            var settings = [];
            for (var _i = 0; _i < metadata.length; _i++) {
                var settingMetadata = metadata[_i];
                settingMetadata.isVisible = settingMetadata.isVisible !== false;
                settingMetadata.isEnabled = settingMetadata.isEnabled !== false;
                var name_2 = settingMetadata.name;
                var label = WidgetUtil.getTranslation(settingMetadata.labelId, lang);
                var value = null;
                if (values) {
                    value = values[name_2];
                }
                var type = settingMetadata.type;
                var setting = {
                    definition: settingMetadata,
                    id: lm.CommonUtil.random(),
                    label: label,
                    name: name_2,
                    type: type,
                    value: value
                };
                if (type === lm.WidgetSettingsType.selectorType) {
                    var items = settingMetadata.values;
                    for (var j = 0; j < items.length; j++) {
                        var item = items[j];
                        if (item.textId) {
                            item.text = WidgetUtil.getTranslation(item.textId, lang);
                        }
                        if (item.value == value) {
                            setting.value = item;
                        }
                    }
                    setting.values = items;
                }
                settings.push(setting);
            }
            return settings;
        };
        WidgetUtil.updateSettingsValues = function (items, isTitleLocked, widget) {
            var data = widget.data;
            data.isTitleLocked = isTitleLocked;
            var context = widget.context;
            var values = data.settings;
            for (var _i = 0; _i < items.length; _i++) {
                var item = items[_i];
                var name_3 = item.name;
                if (name_3 === "lmWidgetTitle") {
                    if (isTitleLocked) {
                        widget.setTitleInternal(null);
                    }
                    else {
                        widget.setTitleInternal(item.value);
                    }
                }
                else if (name_3 === "lmLogicalId") {
                    context.setLogicalId(item.value.value || null);
                }
                else {
                    var value = void 0;
                    if (item.type === lm.WidgetSettingsType.selectorType) {
                        value = item.value.value;
                    }
                    else {
                        value = item.value;
                    }
                    values[name_3] = value;
                }
            }
        };
        WidgetUtil.updateMetadata = function (widget) {
            var instance = widget.instance;
            var getMetadata = instance.getMetadata;
            if (getMetadata) {
                var metadata = getMetadata();
                if (metadata) {
                    widget.context.getSettings().setMetadata(metadata);
                }
            }
        };
        WidgetUtil.labelProperty = "label";
        return WidgetUtil;
    })();
    exports.WidgetUtil = WidgetUtil;
    var WidgetService = (function (_super) {
        __extends(WidgetService, _super);
        function WidgetService(rootScope, q, dataService, dialogService, languageService, editModeService, contextService, cacheService, progressService) {
            _super.call(this, "[WidgetService] ");
            this.rootScope = rootScope;
            this.q = q;
            this.dataService = dataService;
            this.dialogService = dialogService;
            this.editModeService = editModeService;
            this.contextService = contextService;
            this.cacheService = cacheService;
            this.progressService = progressService;
            this.definitions = {};
            this.loadedModules = {};
            this.isCatalogOpen = false;
            this.lang = languageService.getLanguage();
            this.widgetListCache = this.cacheService.createCache(c.Constants.clientCacheWidgets);
        }
        WidgetService.add = function (m) {
            m.service("lmWidgetService", WidgetService);
        };
        WidgetService.prototype.getDefinition = function (id) {
            var _this = this;
            var deferred = this.q.defer();
            var cachedDef = this.definitions[id];
            if (cachedDef) {
                deferred.resolve(cachedDef);
            }
            else {
                this.dataService.executePost("/widget/definition", { content: id }).then(function (response) {
                    var item = response.content;
                    if (item) {
                        _this.addDefinitionItem(item);
                        var definition = _this.getCachedDefinition(id);
                        deferred.resolve(definition);
                    }
                    else {
                        deferred.reject();
                    }
                }, function (error) {
                    lm.Log.error("Failed to load WidgetDefinition for id: " + id + " " + error);
                    deferred.reject();
                });
            }
            return deferred.promise;
        };
        WidgetService.prototype.loadWidget = function (widget) {
            var _this = this;
            var deferred = this.q.defer();
            if (widget.definition || widget.data.isBroken) {
                deferred.resolve(widget);
            }
            else {
                var id = widget.data.id;
                this.getDefinition(id).then(function (definition) {
                    if (!definition) {
                        deferred.reject();
                    }
                    var isCopyOfPublished = false;
                    if (definition.standardWidgetId) {
                        if (widget.addWidgetInfo) {
                            var addInfo = widget.addWidgetInfo;
                            if (addInfo.byRef === false) {
                                isCopyOfPublished = true;
                                if (!addInfo.customWidget) {
                                    addInfo.customWidget = definition.custom;
                                }
                            }
                        }
                    }
                    if (isCopyOfPublished) {
                        _this.getDefinition(definition.standardWidgetId).then(function (standardDefinition) {
                            if (!standardDefinition) {
                                deferred.reject();
                            }
                            _this.initializeWidget(standardDefinition, widget, deferred);
                        }, function (error) { deferred.reject(error); });
                    }
                    else {
                        _this.initializeWidget(definition, widget, deferred);
                    }
                }, function (error) { deferred.reject(error); });
            }
            return deferred.promise;
        };
        WidgetService.prototype.closeCatalog = function (dialog) {
            dialog.destroy();
            this.isCatalogOpen = false;
        };
        WidgetService.prototype.initializeWidget = function (definition, widget, deferred) {
            widget.setDefinition(definition, widget.addWidgetInfo);
            this.loadImplementation(widget, definition, deferred);
        };
        WidgetService.prototype.onLoadDefinition = function (item, widget, deferred) {
            this.addDefinitionItem(item);
            var definition = this.getCachedDefinition(item.definition.widgetId);
            this.initializeWidget(definition, widget, deferred);
        };
        WidgetService.prototype.addSharedModules = function (definition) {
            var modules = definition.sharedModules;
            if (!modules) {
                return;
            }
            var config = infor.lime.requireConfig;
            var starMap = config.map["*"];
            var isChanged = false;
            for (var _i = 0; _i < modules.length; _i++) {
                var m = modules[_i];
                var name_4 = m.name;
                var path = m.path || name_4;
                if (!starMap[name_4]) {
                    isChanged = true;
                    var modulePath = WidgetUtil.getUrl(definition, path);
                    starMap[name_4] = modulePath;
                }
            }
            if (isChanged) {
                infor.lime.requireFunction.config(config);
            }
        };
        WidgetService.prototype.loadImplementation = function (widget, definition, deferred) {
            var _this = this;
            var widgetType = !definition.type ? c.WidgetType.Inline : definition.type;
            widgetType = widgetType.toLowerCase();
            if (widgetType === c.WidgetType.Inline && !this.rootScope[c.Constants.safeMode]) {
                var name = !definition.moduleName ? c.Constants.widgetModuleDefaultName : definition.moduleName;
                var id = definition.isPublished ? definition.standardWidgetId : definition.widgetId;
                var cachedModule = this.loadedModules[id];
                if (cachedModule) {
                    widget.widgetModule = cachedModule;
                }
                else {
                    this.addSharedModules(definition);
                    var fullName = WidgetUtil.getUrl(definition, name);
                    this.debug("Loading inline widget module " + fullName);
                    require([fullName], function (widgetModule) {
                        if (widgetModule) {
                            _this.loadedModules[id] = widgetModule;
                            widget.widgetModule = widgetModule;
                            deferred.resolve(widget);
                        }
                        else {
                            require([name], function (widgetModule) {
                                if (widgetModule) {
                                    _this.loadedModules[id] = widgetModule;
                                    widget.widgetModule = widgetModule;
                                    deferred.resolve(widget);
                                }
                                else {
                                    var message = "Widget module not found: " + name + "(" + fullName + ")";
                                    _this.error(message);
                                    deferred.reject(message);
                                }
                            }, function (err) {
                                var message = name + "(" + fullName + ")";
                                _this.error(err);
                                deferred.reject(message);
                            });
                        }
                    }, function (err) {
                        var message = fullName;
                        _this.error(err);
                        deferred.reject(message);
                    });
                    return;
                }
            }
            deferred.resolve(widget);
        };
        WidgetService.prototype.getAddWidgetInfo = function (widget) {
            var data = widget.data;
            var isTitleLocked = data.isTitleLocked;
            if (widget.isCatalogTitle()) {
                isTitleLocked = false;
            }
            var customWidget = {
                settings: angular.copy(data.settings),
                title: widget.title,
                isTitleLocked: isTitleLocked,
                logicalId: data.logicalId,
                titleApi: data.titleApi
            };
            var definition = widget.definition;
            var id = definition.standardWidgetId || definition.widgetId;
            var widgetInfo = { widgetId: id, title: data.title, type: definition.type };
            var addWidgetInfo = { byRef: false, customWidget: customWidget, widgetInfo: widgetInfo };
            return addWidgetInfo;
        };
        WidgetService.prototype.addWidgetCopyToPage = function (context, addWidgetInfo) {
            var deferred = this.q.defer();
            this.preAddWidget(context, addWidgetInfo).then(function (widget) {
                context.addWidget(widget);
                deferred.resolve(widget);
            }, function (r) {
                deferred.reject(r);
            });
            return deferred.promise;
        };
        WidgetService.prototype.preAddWidget = function (context, addWidgetInfo, busyCallback) {
            var deferred = this.q.defer();
            this.preLoadWidget(deferred, context, addWidgetInfo, busyCallback);
            return deferred.promise;
        };
        WidgetService.prototype.preLoadWidget = function (deferred, context, addWidgetInfo, busyCallback) {
            var _this = this;
            if (!busyCallback) {
                this.progressService.setBusy(true);
            }
            var widgetInfo = addWidgetInfo.widgetInfo;
            var id = widgetInfo.widgetId;
            var data = {
                id: id, isTitleLocked: true
            };
            var widget = new Widget(context, data, true, addWidgetInfo.byRef);
            if (addWidgetInfo) {
                widget.addWidgetInfo = addWidgetInfo;
            }
            this.loadWidget(widget).then(function (w) {
                busyCallback ? busyCallback() : _this.progressService.setBusy(false);
                deferred.resolve(w);
            }, function (response) {
                lm.Log.error(_this.logPrefix + "Failed to load widget " + response);
                busyCallback ? busyCallback() : _this.progressService.setBusy(false);
                deferred.reject(response);
            });
        };
        WidgetService.prototype.getCachedDefinition = function (id) {
            var def = this.definitions[id];
            return lm.CommonUtil.hasValue(def) ? def : null;
        };
        WidgetService.prototype.addDefinitions = function (list) {
            for (var i = 0; i < list.length; i++) {
                this.addDefinition(list[i]);
            }
        };
        WidgetService.prototype.addDefinitionItem = function (item) {
            var definition = item.definition;
            definition.lang = item.localization;
            definition.standardTitle = item.standardTitle;
            definition.title = item.catalogTitle || item.standardTitle;
            definition.isCatalog = item.isCatalog;
            definition.accessLevel = item.accessLevel;
            definition.standardAccessLevel = item.standardAccessLevel;
            this.addDefinition(definition);
            var applications = item.applications;
            if (applications) {
                if (this.contextService) {
                    var context = this.contextService.getContext();
                    var configuration = context.getConfiguration();
                    if (configuration) {
                        configuration.addApplications(applications);
                    }
                }
            }
            return definition;
        };
        WidgetService.prototype.removeDefinition = function (widgetId) {
            lm.CommonUtil.deleteProperty(this.definitions, widgetId);
        };
        WidgetService.prototype.addDefinition = function (definition) {
            if (definition.standardWidgetId) {
                definition.isPublished = true;
            }
            this.definitions[definition.widgetId] = definition;
        };
        WidgetService.prototype.listWidgets = function (reload) {
            var _this = this;
            var deferred = this.q.defer();
            if (!this.widgetListCache.isValid || reload) {
                this.dataService.executePost("/widget/list", {}).then(function (response) {
                    _this.cacheService.updateCache(_this.widgetListCache, response, deferred);
                }, function (response) {
                    _this.widgetListCache.isValid = false;
                    deferred.reject(response);
                });
            }
            else {
                deferred.resolve(this.widgetListCache.cachedResponse);
            }
            return deferred.promise;
        };
        WidgetService.prototype.showCatalog = function (context, callback) {
            var _this = this;
            var deferred = this.q.defer();
            if (!this.isCatalogOpen) {
                this.isCatalogOpen = true;
                var template = "<div class=\"contextual-action-panel modal lm-catalog-dialog\" ng-include=\"'scripts/lime/templates/widget-library.html'\"></div>";
                this.dialogService.showContextualActionPanel(template, callback).then(function () {
                    _this.isCatalogOpen = false;
                    deferred.resolve();
                }, function () {
                    _this.isCatalogOpen = false;
                    deferred.reject();
                });
            }
            else {
                deferred.reject();
            }
            return deferred.promise;
        };
        WidgetService.prototype.showSettings = function (widget, data, isWidgetUnlocked) {
            var deferred = this.q.defer();
            var parameter = new WidgetSettingsParameter();
            parameter.widget = widget;
            parameter.isEditMode = this.editModeService.isActive();
            var options = {
                title: this.lang.widgetSettings,
                templateUrl: "scripts/lime/templates/widget-settings.html",
                parameter: parameter
            };
            var settings = widget.context.getSettings();
            var isCancelled = false;
            var instance = widget.instance;
            if (instance.settingsOpening) {
                var openingOptions = { settings: settings, data: data };
                try {
                    widget.instance.settingsOpening(openingOptions);
                    if (openingOptions.cancel) {
                        isCancelled = true;
                    }
                }
                catch (e) {
                    this.error("Failed to call settingsOpening for widget " + widget.id, e);
                }
            }
            if (isCancelled) {
                this.debug("Settings dialog cancelled by widget with id" + widget.id);
                var dialogResult = { button: lm.DialogButtonType.Cancel };
                deferred.resolve(dialogResult);
                return deferred.promise;
            }
            try {
                WidgetUtil.updateMetadata(widget);
            }
            catch (e) {
                this.error("Failed get metadata for widget " + widget.id, e);
            }
            if (instance.widgetSettingsFactory) {
                parameter.widgetSettingsFactory = function (context) { return instance.widgetSettingsFactory(context); };
                options.templateUrl = "scripts/lime/templates/widget-settings-custom.html";
            }
            widget.isSettings = true;
            var deactivated = instance.deactivated;
            if (deactivated) {
                deactivated({ type: lm.WidgetActivationType.settings });
            }
            this.dialogService.show(options).then(function (r) {
                if (r && r.value) {
                    widget.updateSettings(!isWidgetUnlocked);
                }
                widget.isSettings = false;
                var activated = instance.activated;
                if (activated) {
                    activated({ type: lm.WidgetActivationType.settings });
                }
                deferred.resolve(r);
            });
            return deferred.promise;
        };
        WidgetService.prototype.getPublished = function (id) {
            var deferred = this.q.defer();
            this.dataService.executePost("/widget/published", { content: id }).then(function (response) {
                deferred.resolve(response.content);
            }, function (r) { deferred.reject(r); });
            return deferred.promise;
        };
        WidgetService.prototype.publish = function (item) {
            var _this = this;
            var deferred = this.q.defer();
            this.dataService.executePost("/widget/published/create", { content: item }).then(function (response) {
                _this.widgetListCache.isValid = false;
                deferred.resolve(response);
            }, function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        };
        WidgetService.prototype.updatePublished = function (item) {
            var _this = this;
            var deferred = this.q.defer();
            this.dataService.executePost("/widget/published/update", { content: item }).then(function (response) {
                _this.widgetListCache.isValid = false;
                deferred.resolve(response);
            }, function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        };
        WidgetService.prototype.updatePublishedOwner = function (widgetId, ownerId) {
            var deferred = this.q.defer();
            var widget = { widgetId: widgetId, ownerId: ownerId };
            this.dataService.executePost("/widget/published/owner/update", widget).then(function (response) {
                deferred.resolve(response);
            }, function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        };
        WidgetService.prototype.deletePublished = function (widgets) {
            var _this = this;
            var deferred = this.q.defer();
            this.dataService.executePost("/widget/published/delete", { content: widgets }).then(function (response) {
                _this.widgetListCache.isValid = false;
                deferred.resolve(response);
            }, function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        };
        WidgetService.prototype.exportWidget = function (widgetData) {
            throw "Not implemented";
        };
        WidgetService.prototype.handleError = function (response, message) {
            this.dataService.handleError(response, message);
        };
        WidgetService.prototype.createImagePath = function (widget) {
            var path = "";
            var icon = widget.iconFile;
            if (icon) {
                var id = widget.standardWidgetId || widget.widgetId;
                if (c.ClientConfiguration.isLocal()) {
                    path = "/widgets/" + id + "/" + widget.version + "/" + icon;
                }
                else if (c.ClientConfiguration.isDev()) {
                    path = c.ClientConfiguration.dev.devData.widgetId + "/" + icon;
                }
                else {
                    path = "widgets/" + id + "/" + widget.version + "/" + icon;
                }
            }
            else {
                var basePath = "scripts/lime/resources/widget-category-icons/";
                switch (widget.category) {
                    case "businessprocess":
                        path = basePath + "ic-business-process.png";
                        break;
                    case "application":
                        path = basePath + "ic-application.png";
                        break;
                    case "social":
                        path = basePath + "ic-social.png";
                        break;
                    case "utilities":
                        path = basePath + "ic-utilites.png";
                        break;
                    case "businessintelligence":
                        path = basePath + "ic-business-intelligence.png";
                        break;
                    default:
                        lm.Log.error("No icon path could be set for widget with id: " + widget.widgetId + ", since it has an incorrect category.");
                        break;
                }
            }
            return path;
        };
        WidgetService.prototype.invalidateWidgetCache = function () {
            this.definitions = {};
            if (this.widgetListCache) {
                this.widgetListCache.isValid = false;
            }
        };
        WidgetService.$inject = ["$rootScope", "$q", "lmDataService", "lmDialogService", "lmLanguageService", "lmEditModeService", "lmContextService", "lmCacheService", "lmProgressService"];
        return WidgetService;
    })(c.CoreBase);
    var WidgetSettingsParameter = (function () {
        function WidgetSettingsParameter() {
        }
        return WidgetSettingsParameter;
    })();
    var CustomWidgetSettingsCtrl = (function (_super) {
        __extends(CustomWidgetSettingsCtrl, _super);
        function CustomWidgetSettingsCtrl(scope, widgetService) {
            _super.call(this, "[CustomWidgetSettingsCtrl] ");
            this.scope = scope;
            this.widgetService = widgetService;
            this.settingsInstance = null;
            this.dialog = scope["lmDialog"];
            var parameter = this.dialog.parameter;
            if (parameter) {
                this.widget = parameter.widget;
            }
            var self = this;
            scope.$watch("lmSettingsInstance", function (newValue, oldValue, watchScope) {
                if (newValue) {
                    self.settingsInstance = newValue;
                }
            });
        }
        CustomWidgetSettingsCtrl.add = function (m) {
            m.controller("lmCustomWidgetSettingsCtrl", CustomWidgetSettingsCtrl);
        };
        CustomWidgetSettingsCtrl.prototype.beforeClose = function (isSave) {
            try {
                if (this.settingsInstance) {
                    if (this.settingsInstance.closing) {
                        var arg = { isSave: isSave };
                        this.settingsInstance.closing(arg);
                    }
                }
            }
            catch (e) {
                this.error("Exception in settingsInstance.closing", e);
            }
        };
        CustomWidgetSettingsCtrl.prototype.onSave = function () {
            this.beforeClose(true);
            var result = { value: this.widget };
            this.dialog.close(result);
        };
        CustomWidgetSettingsCtrl.prototype.onCancel = function () {
            this.beforeClose(false);
            this.dialog.close();
        };
        CustomWidgetSettingsCtrl.$inject = ["$scope", "lmWidgetService"];
        return CustomWidgetSettingsCtrl;
    })(c.CoreBase);
    var WidgetSettingsCtrl = (function () {
        function WidgetSettingsCtrl(scope, widgetService, languageService) {
            this.scope = scope;
            this.widgetService = widgetService;
            this.isCatalogTitle = false;
            this.dialog = scope["lmDialog"];
            this.lang = languageService.getLanguage();
            this.webWidgetId = c.Constants.mingleWebWidgetID;
            var parameter = this.dialog.parameter;
            if (parameter && parameter.widget) {
                var widget = parameter.widget;
                var isEdit = parameter.isEditMode;
                this.isEditMode = isEdit;
                var definition = widget.definition;
                var lang = definition.lang;
                var widgetTitleLocked = widget.data.isTitleLocked === true;
                var values = widget.data.settings;
                var settings = [];
                var metadata = widget.context.getSettings().getMetadata();
                if (metadata) {
                    settings = WidgetUtil.getSettingsFromMetadata(metadata, values, lang);
                }
                if (isEdit || !definition.isPublished) {
                    var setting = this.createSelector(widget);
                    if (setting) {
                        settings.unshift(setting);
                    }
                }
                var isTitleEdit = widget.isTitleEditEnabled !== false;
                if (isEdit || isTitleEdit) {
                    var title = widget.title;
                    this.originalTitle = title;
                    settings.unshift({
                        id: lm.CommonUtil.random(),
                        name: c.Constants.settingsNameWidgetTitle,
                        value: title,
                        definition: {},
                        label: this.lang.title
                    });
                    this.isCatalogTitle = widget.isCatalogTitle();
                }
                this.isTitleLocked = widgetTitleLocked || this.isCatalogTitle;
                this.isSaveEnabled = isEdit || isTitleEdit || lm.ArrayUtil.find(settings, function (item) {
                    var def = item.definition;
                    return (def.isVisible && def.isEnabled);
                });
                this.widget = widget;
                this.settings = settings;
                scope["settings"] = settings;
                scope["widgetTitleMaxLength"] = c.Constants.widgetTitleLength;
            }
        }
        WidgetSettingsCtrl.prototype.createSelector = function (widget) {
            var context = widget.context;
            var applications = context.getApplications();
            if (!applications || applications.length < 2) {
                return null;
            }
            var logicalId = widget.data.logicalId || "";
            var values = [];
            var defaultApplication = context.getApplication();
            var defaultText = this.lang.defaultSelection + " (" + defaultApplication.logicalId + ")";
            var defaultItem = { text: defaultText, value: "" };
            var selectedItem = defaultItem;
            values.push(defaultItem);
            for (var i = 0; i < applications.length; i++) {
                var application = applications[i];
                var value = application.logicalId;
                var text = application.productName + " (" + value + ")";
                var item = { text: text, value: value };
                values.push(item);
                if (logicalId === value) {
                    selectedItem = item;
                }
            }
            var setting = {
                type: "selector",
                id: lm.CommonUtil.random(),
                name: "lmLogicalId",
                value: selectedItem,
                values: values,
                definition: {},
                label: this.lang.application
            };
            return setting;
        };
        WidgetSettingsCtrl.add = function (m) {
            m.controller("lmWidgetSettingsCtrl", WidgetSettingsCtrl);
        };
        WidgetSettingsCtrl.prototype.onClickIsLocked = function () {
            var isLocked = this.isTitleLocked;
            this.isTitleLocked = !isLocked;
            var metadata = this.settings[0];
            if (metadata.name === c.Constants.settingsNameWidgetTitle) {
                if (this.isTitleLocked) {
                    metadata.value = this.widget.calculateTitle(true);
                }
            }
        };
        WidgetSettingsCtrl.prototype.onSave = function () {
            if ((this.isEditMode || this.widget.isTitleEditEnabled) && this.settings[0].value === this.originalTitle) {
                this.settings.shift();
            }
            WidgetUtil.updateSettingsValues(this.settings, this.isTitleLocked, this.widget);
            var result = { value: this.widget };
            this.dialog.close(result);
        };
        WidgetSettingsCtrl.prototype.onCancel = function () {
            var result = { button: lm.DialogButtonType.Cancel };
            this.dialog.close(result);
        };
        WidgetSettingsCtrl.$inject = ["$scope", "lmWidgetService", "lmLanguageService"];
        return WidgetSettingsCtrl;
    })();
    var WidgetCustomizationCtrl = (function (_super) {
        __extends(WidgetCustomizationCtrl, _super);
        function WidgetCustomizationCtrl(scope, widgetService, dialogService, languageService, editModeService, contextService) {
            _super.call(this, "[WidgetCustomizationCtrl] ");
            this.scope = scope;
            this.widgetService = widgetService;
            this.dialogService = dialogService;
            this.editModeService = editModeService;
            this.contextService = contextService;
            this.customized = {};
            this.openTab = "basic";
            this.dialog = scope["lmDialog"];
            this.lang = languageService.getLanguage();
            this.tabOptions = { modalId: c.Constants.modalWidgetCustomize };
            var translationsEnabled = this.contextService.getContext().settings.isContentTranslationEnabled();
            this.translationEnabled = translationsEnabled;
            this.widgetTitleLength = c.Constants.widgetTitleLength;
            this.widgetDescriptionLength = c.Constants.widgetDescriptionLength;
            this.tagHolder = "#" + new Date().getFullYear().toString();
            var parameter = this.dialog.parameter;
            var item = parameter.item;
            var definition = item.definition;
            if (definition != null) {
                this.customized = definition;
                var localizationMap = item.localization || {};
                this.localization = { defaultLocalization: { title: definition.title, description: definition.description || "" }, localizationMap: localizationMap, isWidget: true };
                scope.localization = this.localization;
                this.initialize(definition, parameter.definition);
            }
        }
        WidgetCustomizationCtrl.prototype.enableItem = function (item, name, definition) {
            var isEnabled = true;
            var isVisible = true;
            var isHidden = false;
            if (definition) {
                definition = definition.original;
                var settings = definition.settings;
                if (settings) {
                    var current = lm.ArrayUtil.itemByProperty(settings, "name", name);
                    if (current) {
                        if (current.isHidden === true) {
                            isHidden = true;
                        }
                        if (current.isEnabled === false) {
                            isEnabled = false;
                        }
                        if (current.isVisible === false) {
                            isVisible = false;
                        }
                    }
                }
            }
            item["isEnabled"] = isEnabled;
            item["isVisible"] = isVisible;
            item["isHidden"] = isHidden;
        };
        WidgetCustomizationCtrl.prototype.initialize = function (definition, sourceDefinition) {
            var settings = definition.settings;
            var language = sourceDefinition.lang;
            var items = [];
            this.enableSettings = sourceDefinition.enableSettingsDef;
            items.push({
                label: this.lang.title,
                setting: {
                    name: c.Constants.settingsNameWidgetTitle,
                    isEnabled: definition.enableTitleEdit
                },
                isEnabled: true,
                isVisible: true
            });
            if (settings) {
                var enableSettings = definition.enableSettings;
                for (var _i = 0; _i < settings.length; _i++) {
                    var setting = settings[_i];
                    if (!enableSettings) {
                        setting.isEnabled = false;
                        setting.isVisible = false;
                    }
                    var isHidden = false;
                    if (setting.isHidden) {
                        setting.isVisible = false;
                        isHidden = true;
                    }
                    var item = { setting: setting };
                    item["isHidden"] = isHidden;
                    item[WidgetUtil.labelProperty] = WidgetUtil.getTranslation(setting.labelId, language);
                    items.push(item);
                }
            }
            this.settingsItems = items;
        };
        WidgetCustomizationCtrl.prototype.onClickTab = function (tabName) {
            this.openTab = tabName;
            if (tabName === "translations") {
                var widget = this.customized;
                this.scope.localization.defaultLocalization = { title: widget.title, description: widget.description };
            }
        };
        WidgetCustomizationCtrl.prototype.onClickApply = function () {
            var definition = this.customized;
            var items = this.settingsItems;
            var titleSetting = items.shift();
            definition.enableTitleEdit = titleSetting.setting.isEnabled;
            var info = {
                publishedItem: {
                    definition: definition,
                    localization: this.localization.localizationMap
                },
                isLocalizationChanged: this.isLocalizationsChanged(),
                isPublish: false
            };
            this.dialog.result = {
                value: info
            };
            this.dialog.close();
        };
        WidgetCustomizationCtrl.prototype.isLocalizationsChanged = function () {
            return true;
        };
        WidgetCustomizationCtrl.prototype.cancel = function () {
            this.dialog.close();
        };
        WidgetCustomizationCtrl.add = function (m) {
            m.controller("lmWidgetCustomizationCtrl", WidgetCustomizationCtrl);
        };
        WidgetCustomizationCtrl.$inject = ["$scope", "lmWidgetService", "lmDialogService", "lmLanguageService", "lmEditModeService", "lmContextService"];
        return WidgetCustomizationCtrl;
    })(c.CoreBase);
    var WidgetContainerCtrl = (function (_super) {
        __extends(WidgetContainerCtrl, _super);
        function WidgetContainerCtrl(rootScope, scope, widgetService, dialogService, contextService, languageService, containerService, editModeService, progressService) {
            _super.call(this, "[WidgetContainerCtrl] ");
            this.rootScope = rootScope;
            this.scope = scope;
            this.widgetService = widgetService;
            this.dialogService = dialogService;
            this.contextService = contextService;
            this.containerService = containerService;
            this.editModeService = editModeService;
            this.progressService = progressService;
            this.unsubscribers = [];
            this.showPublishItem = false;
            this.showPublishCopyItem = false;
            this.showEditPublishItem = false;
            this.showDuplicateItem = false;
            this.showAdvancedItem = false;
            this.showRestoreItem = false;
            this.showCopyItem = false;
            this.lang = languageService.getLanguage();
            var self = this;
            var unregister = scope.$watch("lmWidget", function (widget) {
                if (widget) {
                    unregister();
                    self.init(widget);
                }
            });
        }
        WidgetContainerCtrl.prototype.destroy = function () {
            angular.forEach(this.unsubscribers, function (unsubscribe) {
                unsubscribe();
            });
        };
        WidgetContainerCtrl.prototype.loadExternal = function (widget, iframe) {
            this.widget = widget;
            this.iframe = iframe;
            this.isExternal = true;
            this.updateUrl();
        };
        WidgetContainerCtrl.prototype.setUrl = function (url) {
            this.url = url;
        };
        WidgetContainerCtrl.prototype.applyUrl = function (newUrl) {
            if (newUrl && newUrl !== this.url) {
                this.url = newUrl;
                this.iframe.attr("src", newUrl);
            }
        };
        WidgetContainerCtrl.prototype.getLayoutClasses = function () {
            return this.widget ? WidgetUtil.getLayoutClasses(this.widget.data.layout) : "";
        };
        WidgetContainerCtrl.prototype.updateUrl = function () {
            var _this = this;
            var widget = this.widget;
            var iframe = this.iframe;
            if (widget && iframe) {
                var newUrl = widget.externalUrl;
                if (newUrl && newUrl.indexOf("{") >= 0) {
                    newUrl = this.widget.context.resolveAndReplace(newUrl);
                    this.widget.context.resolveAndReplaceAsync(newUrl, null).then(function (s) {
                        _this.applyUrl(s);
                    });
                }
                else {
                    this.applyUrl(newUrl);
                }
            }
        };
        WidgetContainerCtrl.prototype.init = function (widget) {
            this.widget = widget;
            var self = this;
            if (!widget.data.isBroken) {
                self.context = self.contextService.getContext();
                self.isMyWidget = widget.definition.owner && self.context.isCurrentUser(widget.definition.owner);
                if (widget.instance.actions) {
                    this.setPrimaryAction();
                }
                self.isPreviewMode = self.editModeService.isActive() && self.editModeService.getCurrent().mode === c.EditModes.preview;
                if (!self.isPreviewMode) {
                    self.updateMenu();
                }
                widget.updated().on(function () {
                    if (!self.isPreviewMode) {
                        self.updateMenu();
                    }
                });
                var editModeService = self.editModeService;
                this.unsubscribers.push(editModeService.changed().on(function (e) {
                    if (!self.isPreviewMode) {
                        self.updateMenu();
                    }
                }));
                this.unsubscribers.push(editModeService.started().on(function (e) {
                    var param = e.parameter;
                    if (param && param !== self.widget.elementId) {
                        self.isInactive = true;
                    }
                }));
            }
            widget.destroyed().on(function () {
                self.destroy();
            });
            self.widget.raiseAdded();
        };
        WidgetContainerCtrl.prototype.updateMenu = function () {
            var widget = this.widget;
            if (widget && !widget.data.isBroken) {
                var isSettingsEnabled = widget.isSettingsEnabled();
                if (widget.accessLevel === c.WidgetAccessLevel.View || widget.accessLevel === c.WidgetAccessLevel.Disabled) {
                    this.showSettingsItem = false;
                }
                else {
                    this.showSettingsItem = isSettingsEnabled && widget.isSettingsMenuEnabled();
                }
                var editMode = this.editModeService.getCurrent();
                var isEditMode = !!editMode && editMode.isActive;
                var isWidgetEditMode = isEditMode && editMode.mode === c.EditModes.widget;
                var isPagePublished = this.containerService.getContainer().selectedPage.isPublished();
                var isPageEditMode = isEditMode && editMode.mode === c.EditModes.page;
                if (this.hasEditRights()) {
                    var isPublishEnabled = this.context.settings.isWidgetPublishEnabled();
                    var isPublished = widget.isPublished();
                    var isEditPublish = isWidgetEditMode || (!isPublished && (!isPagePublished || isPageEditMode));
                    this.showPublishItem = isPublishEnabled && !isEditMode;
                    this.showPublishCopyItem = isPublishEnabled && !isEditMode && !isPublished;
                    this.showEditPublishItem = isEditPublish && (isPublishEnabled || this.context.settings.isPagePublishEnabled());
                    this.showRestoreItem = isSettingsEnabled && isEditPublish;
                }
                var canCopy = widget.definition.standardAccessLevel === c.WidgetAccessLevel.Configure;
                this.showDuplicateItem = canCopy && (isPageEditMode || (!isEditMode && !isPagePublished));
                this.showCopyItem = canCopy;
                this.showAdvancedItem = this.showPublishItem || this.showPublishCopyItem || this.showEditPublishItem || this.showDuplicateItem || this.showRestoreItem || this.showCopyItem;
            }
        };
        WidgetContainerCtrl.prototype.setPrimaryAction = function () {
            var actions = this.widget.instance.actions;
            for (var _i = 0; _i < actions.length; _i++) {
                var action = actions[_i];
                if (action.isPrimary && (action.standardIconName || action.customIconName)) {
                    this.primaryAction = action;
                    return;
                }
            }
        };
        WidgetContainerCtrl.prototype.hasEditRights = function () {
            return this.context && this.context.isAdministrator || !this.widget.definition.owner || this.widget.definition.owner === this.context.getUserId();
        };
        WidgetContainerCtrl.prototype.isEditModeActive = function () {
            return this.editModeService.isActive();
        };
        WidgetContainerCtrl.prototype.showSettings = function () {
            var _this = this;
            this.widgetService.showSettings(this.widget, null, this.isCustomizedUnlocked).then(function (r) {
                if (r && r.value) {
                    if (_this.isExternal) {
                        _this.updateUrl();
                    }
                }
            }, function (r) { _this.widgetService.handleError(r); });
        };
        WidgetContainerCtrl.prototype.onPublishWidget = function () {
            var editMode = this.editModeService.getCurrent();
            var isUpdate = editMode.submode === c.EditSubmodes.republish;
            var item = this.getPublishItem(!isUpdate);
            if (!item.definition.description || !item.definition.title) {
                this.showMissingInfoMessage();
                return;
            }
            if (editMode.submode === c.EditSubmodes.publish || editMode.submode === c.EditSubmodes.publishCopy) {
                this.publishWidget(item);
            }
            else {
                this.republishWidget(item);
            }
            this.publishedItem = null;
            this.publishInfo = null;
            this.editModeService.stop({ isSave: true });
        };
        WidgetContainerCtrl.prototype.startEditModeInternal = function () {
            var lang = this.lang;
            var widget = this.widget;
            var title;
            var commandText;
            if (!widget.definition.owner) {
                title = this.isPublishCopy ? lang.publishWidgetCopy : lang.publishWidget;
                commandText = lang.publish;
            }
            else {
                title = lang.republishWidget;
                commandText = lang.republish;
            }
            try {
                widget.enableSettingsTemporary(true);
                var publishing = widget.instance.publishing;
                if (publishing) {
                    publishing();
                }
            }
            catch (ex) {
                this.error("Failed to call publishing event function", ex);
            }
            var self = this;
            this.editModeService.start({
                mode: c.EditModes.widget,
                title: title,
                parameter: widget.elementId,
                submode: this.isPublishCopy ? c.EditSubmodes.publishCopy : lm.CommonUtil.isUndefined(widget.definition.owner) ? c.EditSubmodes.publish : c.EditSubmodes.republish,
                actions: [
                    { text: this.lang.cancel, execute: function () { self.onCancelPublish(); } },
                    { text: commandText, execute: function () { self.onPublishWidget(); } }],
                secondaryActions: [
                    { text: this.lang.editPublishConfiguration, execute: function () { self.showPublishConfiguration(); } }]
            });
            this.showPublishConfiguration();
        };
        WidgetContainerCtrl.prototype.onCancelPublish = function () {
            var _this = this;
            this.dialogService.showMessage({ standardButtons: lm.StandardDialogButtons.YesNo, message: this.lang.confirmCancelMessage, title: this.lang.confirmCancel }).then(function (r) {
                if (r.button === lm.DialogButtonType.Yes) {
                    _this.editModeService.stop({ isSave: false });
                }
            });
        };
        WidgetContainerCtrl.prototype.startEditMode = function (isCopy) {
            var _this = this;
            this.isPublishCopy = isCopy === true;
            if (this.widget.definition.isPublished) {
                this.progressService.setBusy(true);
                this.widgetService.getPublished(this.widget.id).then(function (item) {
                    var definition = item.definition;
                    if (definition.custom) {
                        definition.settings = WidgetUtil.applyRestrictions(definition.settings, definition.custom.metadata);
                    }
                    _this.publishedItem = item;
                    _this.progressService.setBusy(false);
                    _this.startEditModeInternal();
                }, function (r) {
                    _this.widgetService.handleError(r);
                    _this.progressService.setBusy(false);
                });
            }
            else {
                this.startEditModeInternal();
            }
        };
        WidgetContainerCtrl.prototype.copyPublishSettings = function (source, target) {
            target.settings = source.settings;
            target.title = source.title;
            target.description = source.description;
            target.tags = source.tags;
            target.enableSettings = source.enableSettings;
            target.enableTitleEdit = source.enableTitleEdit;
        };
        WidgetContainerCtrl.prototype.getPublishSettings = function (source) {
            var target = [];
            if (source) {
                for (var i = 0; i < source.length; i++) {
                    var setting = source[i];
                    target.push({
                        name: setting.name,
                        isEnabled: setting.isEnabled,
                        isVisible: setting.isVisible
                    });
                }
            }
            return target;
        };
        WidgetContainerCtrl.prototype.getPublishItem = function (isNew) {
            var sourceDefinition = this.widget.definition;
            var widgetData = this.widget.data;
            var info = this.publishInfo;
            var publishedItem = this.publishedItem;
            var settingsValues = widgetData.settings || {};
            var definition;
            var item;
            var sourceMetadata;
            if (info) {
                item = info.publishedItem;
                if (!info.isLocalizationChanged) {
                    item.localization = null;
                }
            }
            else if (publishedItem) {
                item = publishedItem;
            }
            else if (widgetData.custom) {
                item = widgetData.custom;
            }
            if (item) {
                definition = item.definition;
                sourceMetadata = definition.settings;
                if (!sourceMetadata && definition.custom) {
                    sourceMetadata = definition.custom.metadata;
                }
            }
            else {
                definition = {};
                this.copyPublishSettings(sourceDefinition, definition);
                sourceMetadata = definition.settings;
                item = { definition: definition };
                if (this.publishedItem) {
                    item.localization = this.publishedItem.localization;
                }
            }
            var title = widgetData.title;
            if (!title) {
                title = definition.title || sourceDefinition.standardTitle;
            }
            var metadata = this.getPublishSettings(sourceMetadata);
            var custom = {
                settings: settingsValues,
                metadata: metadata,
                title: title,
                isCatalogTitle: this.widget.isCatalogTitle(),
                isTitleLocked: widgetData.isTitleLocked
            };
            if (widgetData.logicalId) {
                custom.logicalId = widgetData.logicalId;
            }
            if (widgetData.titleApi) {
                custom.titleApi = widgetData.titleApi;
            }
            definition.custom = custom;
            widgetData.custom = null;
            definition.settings = null;
            if (!definition.standardWidgetId) {
                definition.standardWidgetId = sourceDefinition.standardWidgetId || sourceDefinition.widgetId;
            }
            if (!isNew) {
                definition.widgetId = widgetData.id;
            }
            return item;
        };
        WidgetContainerCtrl.prototype.toCustom = function (widget, customId) {
            widget.byRef = true;
            var data = widget.data;
            data.id = customId;
            data.settings = null;
        };
        WidgetContainerCtrl.prototype.publishWidget = function (item) {
            var _this = this;
            var isCopy = this.isPublishCopy;
            this.widgetService.publish(item).then(function (response) {
                var container = _this.containerService.getContainer();
                if (isCopy) {
                    container.refresh();
                }
                else {
                    var id = response.content;
                    _this.toCustom(_this.widget, id);
                    container.saveAndRefreshCurrent();
                }
            }, function (r) {
                _this.widgetService.handleError(r);
            });
        };
        WidgetContainerCtrl.prototype.republishWidget = function (item) {
            var _this = this;
            this.widgetService.updatePublished(item).then(function (response) {
                _this.containerService.getContainer().saveAndRefreshCurrent();
            }, function (r) {
                _this.widgetService.handleError(r);
            });
        };
        WidgetContainerCtrl.prototype.showMissingInfoMessage = function () {
            var _this = this;
            this.dialogService.showMessage({ title: this.lang.missingInformation, message: this.lang.noTitleOrDescription }).then(function () {
                _this.showPublishConfiguration();
            });
        };
        WidgetContainerCtrl.prototype.reset = function () {
            var _this = this;
            var options = {
                title: this.lang.confirmReset,
                message: this.lang.confirmResetMessage,
                standardButtons: lm.StandardDialogButtons.YesNo
            };
            this.dialogService.showMessage(options).then(function (result) {
                if (result.button === lm.DialogButtonType.Yes) {
                    _this.widget.restore();
                    if (_this.widget.instance.actions) {
                        _this.setPrimaryAction();
                    }
                }
            });
        };
        WidgetContainerCtrl.prototype.duplicate = function () {
            var _this = this;
            this.progressService.setBusy(true);
            var addWidgetInfo = this.widgetService.getAddWidgetInfo(this.widget);
            var context = this.widget.parentContext;
            this.widgetService.addWidgetCopyToPage(context, addWidgetInfo).then(function () {
                _this.progressService.setBusy(false);
            }, function (error) {
                _this.widgetService.handleError(error);
            });
        };
        WidgetContainerCtrl.prototype.copy = function () {
            this.rootScope["clipboardWidget"] = {};
            $.extend(true, this.rootScope["clipboardWidget"], this.widget);
        };
        WidgetContainerCtrl.prototype.showPublishConfiguration = function () {
            var widget = this.widget;
            try {
                WidgetUtil.updateMetadata(widget);
            }
            catch (e) {
                this.error("Failed get metadata for widget " + widget.id, e);
            }
            var editableItem = this.createEditableItem(widget);
            var definition = widget.definition;
            var parameter = {
                item: editableItem,
                definition: definition
            };
            var options = {
                title: this.lang.editPublishConfiguration,
                templateUrl: "scripts/lime/templates/widget-customize.html",
                parameter: parameter,
                style: "width:640px;",
                id: c.Constants.modalWidgetCustomize
            };
            var self = this;
            this.dialogService.show(options).then(function (r) {
                self.onClosePublishConfiguration(r);
            });
        };
        WidgetContainerCtrl.prototype.onClosePublishConfiguration = function (r) {
            var info = r.value;
            if (!info) {
                return;
            }
            this.publishInfo = info;
            var item = info.publishedItem;
            var definition = item.definition;
            var widget = this.widget;
            var sourceDefinition = widget.definition;
            var isPublished = sourceDefinition.isPublished;
            var isEditMode = this.editModeService.isActive();
            var widgetData = widget.data;
            var localization = null;
            var isCatalogTitle = definition.isCatalogTitle;
            var customWidget = sourceDefinition.custom;
            if (info.isLocalizationChanged) {
                localization = info.publishedItem.localization;
            }
            var customItem = widgetData.custom;
            if (!isPublished) {
                definition.settings = this.getPublishSettings(definition.settings);
                if (!customItem) {
                    customItem = {};
                    widgetData.custom = customItem;
                }
                customItem.definition = definition;
                customItem.localization = localization;
            }
            if (sourceDefinition.enableTitleEditDef !== false) {
                if (isCatalogTitle) {
                    if (customItem) {
                        customItem.definition.isCatalogTitle = true;
                    }
                    else if (customWidget) {
                        customWidget.isCatalogTitle = true;
                    }
                    if (isPublished) {
                        widget.definition.title = definition.title;
                    }
                    widget.setTitleInternal(null);
                }
                else {
                    if (customItem) {
                        customItem.definition.isCatalogTitle = false;
                    }
                    else if (customWidget) {
                        customWidget.isCatalogTitle = false;
                    }
                    widget.updateTitle();
                }
            }
            if (!isEditMode) {
                this.containerService.getContainer().saveAndRefreshCurrent();
            }
        };
        WidgetContainerCtrl.prototype.showAbout = function () {
            var options = {
                title: this.lang.about,
                templateUrl: "scripts/lime/templates/widget-about.html",
                parameter: { widget: this.widget },
                style: "width:356px;"
            };
            this.dialogService.show(options);
        };
        WidgetContainerCtrl.prototype.exportWidget = function () {
            var url = this.widgetService.exportWidget(this.widget.data);
        };
        WidgetContainerCtrl.prototype.openWidgetExport = function (url, data) {
            var form = document.createElement("form");
            form.action = url;
            form.method = "POST";
            form.target = "_blank";
            if (data) {
                for (var key in data) {
                    var input = document.createElement("textarea");
                    input.name = key;
                    input.value = typeof data[key] === "object" ? JSON.stringify(data[key]) : data[key];
                    form.appendChild(input);
                }
            }
            form.style.display = "none";
            document.body.appendChild(form);
            form.submit();
        };
        WidgetContainerCtrl.prototype.getTitle = function (widget) {
            return widget.title;
        };
        WidgetContainerCtrl.prototype.applyEnabled = function (source, target) {
            if (source && target) {
                for (var i = 0; i < source.length; i++) {
                    var sourceSetting = source[i];
                    var targetSetting = lm.ArrayUtil.itemByProperty(target, "name", sourceSetting.name);
                    if (targetSetting) {
                        targetSetting.isEnabled = sourceSetting.isEnabled;
                        targetSetting.isVisible = sourceSetting.isVisible;
                    }
                }
            }
        };
        WidgetContainerCtrl.prototype.createEditableItem = function (widget) {
            var definition = widget.definition;
            var settings = definition.settings ? angular.copy(definition.settings) : null;
            var sourceDefinition;
            var title = null;
            var enableSettings = false;
            var enableTitleEdit = false;
            var enableFromDefinition = true;
            var localization = null;
            var isTitleEditEnabled = widget.definition.enableTitleEditDef !== false;
            var info = this.publishInfo;
            var item = this.publishedItem;
            if (info) {
                var infoItem = info.publishedItem;
                sourceDefinition = infoItem.definition;
                localization = infoItem.localization;
            }
            else if (item) {
                sourceDefinition = item.definition;
                localization = item.localization;
            }
            else {
                var customItem = widget.data.custom;
                if (customItem && customItem.definition) {
                    sourceDefinition = customItem.definition;
                    localization = customItem.localization;
                    this.publishInfo = { publishedItem: { localization: localization, definition: sourceDefinition }, isLocalizationChanged: true };
                }
                else {
                    sourceDefinition = widget.definition;
                    title = widget.title;
                    enableFromDefinition = false;
                }
            }
            if (!title) {
                title = sourceDefinition.title || definition.standardTitle;
            }
            var description = sourceDefinition.description;
            var tags = sourceDefinition.tags;
            var isCatalogTitle = widget.isCatalogTitle();
            if (enableFromDefinition) {
                enableSettings = !!sourceDefinition.enableSettings;
                enableTitleEdit = !!sourceDefinition.enableTitleEdit;
                this.applyEnabled(sourceDefinition.settings, settings);
            }
            var editableDefinition = {
                settings: settings,
                enableSettings: enableSettings,
                enableTitleEdit: enableTitleEdit,
                title: title,
                description: description,
                tags: tags,
                isCatalogTitle: isCatalogTitle
            };
            var publishItem = {
                definition: editableDefinition,
                localization: localization ? angular.copy(localization) : null
            };
            return publishItem;
        };
        WidgetContainerCtrl.add = function (m) {
            m.controller("lmWidgetContainerCtrl", WidgetContainerCtrl);
        };
        WidgetContainerCtrl.$inject = ["$rootScope", "$scope", "lmWidgetService", "lmDialogService", "lmContextService", "lmLanguageService", "lmContainerService", "lmEditModeService", "lmProgressService"];
        return WidgetContainerCtrl;
    })(c.CoreBase);
    var WidgetResizeCtrl = (function (_super) {
        __extends(WidgetResizeCtrl, _super);
        function WidgetResizeCtrl(scope, pageService, contextService) {
            _super.call(this, "[AddPageCtrl] ");
            this.scope = scope;
            this.pageService = pageService;
            this.contextService = contextService;
            this.dialog = null;
            this.context = contextService.getContext();
            var dialog = scope["lmDialog"];
            if (!dialog) {
                this.error("lmDialog is not found in scope when opening add page dialog");
                return;
            }
            this.dialog = dialog;
            dialog.result = {};
            scope["layout"] = dialog.parameter;
            dialog.result.value = dialog.parameter;
        }
        WidgetResizeCtrl.add = function (m) {
            m.controller("lmResizeWidgetCtrl", WidgetResizeCtrl);
        };
        WidgetResizeCtrl.$inject = ["$scope", "lmPageService", "lmContextService"];
        return WidgetResizeCtrl;
    })(c.CoreBase);
    var WidgetSettingsContext = (function () {
        function WidgetSettingsContext(widget, element, dialog) {
            this.widget = widget;
            this.element = element;
            this.dialog = dialog;
            this.isSaveEnabledInternal = true;
            this.angularConfig = null;
        }
        WidgetSettingsContext.prototype.getWidgetContext = function () {
            return this.widget.context;
        };
        WidgetSettingsContext.prototype.getElement = function () {
            return this.element;
        };
        WidgetSettingsContext.prototype.enableSave = function (isEnabled) {
            this.isSaveEnabledInternal = isEnabled;
        };
        WidgetSettingsContext.prototype.isSaveEnabled = function () {
            return this.isSaveEnabledInternal;
        };
        WidgetSettingsContext.prototype.close = function (isSave) {
            var result = {};
            result.button = isSave ? lm.DialogButtonType.Ok : lm.DialogButtonType.Cancel;
            this.dialog.close(result);
        };
        return WidgetSettingsContext;
    })();
    exports.WidgetSettingsContext = WidgetSettingsContext;
    var WidgetContext = (function (_super) {
        __extends(WidgetContext, _super);
        function WidgetContext(q, timeout, widgetService, widget, settings, element, angularContext, context, languageService) {
            _super.call(this, "[WidgetContext] ");
            this.q = q;
            this.timeout = timeout;
            this.widgetService = widgetService;
            this.settings = settings;
            this.element = element;
            this.angularContext = angularContext;
            this.context = context;
            this.visible = false;
            this.config = null;
            this.widget = widget;
            this.config = context.getConfiguration();
            var language = (widget.definition.lang || {});
            language.get = function (id) {
                var text = language[id];
                return text || null;
            };
            var limeLanguage = languageService.getLanguage();
            for (var i = 0; i < c.Constants.sharedLimeLanguageConstants.length; i++) {
                if (!language.hasOwnProperty(c.Constants.sharedLimeLanguageConstants[i])) {
                    language[c.Constants.sharedLimeLanguageConstants[i]] = limeLanguage[c.Constants.sharedLimeLanguageConstants[i]];
                }
            }
            this.language = language;
            this.initializeApplication();
        }
        WidgetContext.prototype.isValidLogicalId = function (logicalId) {
            var logicalIdPrefix = this.getLogicalIdPrefix();
            return logicalIdPrefix && logicalId && logicalId.indexOf(logicalIdPrefix) == 0;
        };
        WidgetContext.prototype.initializeApplication = function () {
            var logicalIdPrefix = this.getLogicalIdPrefix();
            if (!logicalIdPrefix) {
                return;
            }
            var data = this.widget.data;
            var logicalId = data.logicalId;
            if (logicalId) {
                if (!this.isValidLogicalId(logicalId)) {
                    logicalId = null;
                    delete data.logicalId;
                }
            }
            this.setApplication(logicalId || logicalIdPrefix);
        };
        WidgetContext.prototype.setApplication = function (logicalId) {
            if (logicalId) {
                this.applications = this.config.getApplicationsCached(logicalId);
                this.application = this.config.getApplicationCached(logicalId);
            }
            else {
                this.applications = null;
                this.application = null;
            }
        };
        WidgetContext.prototype.getId = function () {
            return this.widget.id;
        };
        WidgetContext.prototype.getSettings = function () {
            return this.settings;
        };
        WidgetContext.prototype.getLanguage = function () {
            return this.language;
        };
        WidgetContext.prototype.getElement = function () {
            return this.element;
        };
        WidgetContext.prototype.getUrl = function (path) {
            return WidgetUtil.getUrl(this.widget.definition, path);
        };
        WidgetContext.prototype.getAngularContext = function () {
            return this.angularContext;
        };
        WidgetContext.prototype.isPublished = function () {
            var widget = this.widget;
            return widget.definition.isPublished || widget.parentContext.isPublished;
        };
        WidgetContext.prototype.isDev = function () {
            return c.ClientConfiguration.isDev();
        };
        WidgetContext.prototype.save = function () {
            this.widget.raiseChanged();
        };
        WidgetContext.prototype.isActive = function () {
            var widget = this.widget;
            return widget.isVisible && widget.state === lm.WidgetState.running && !widget.isEdit && !widget.isSettings;
        };
        WidgetContext.prototype.isVisible = function () {
            return this.widget.isVisible;
        };
        WidgetContext.prototype.setState = function (state) {
            var widget = this.widget;
            if (widget.state !== state) {
                widget.state = state;
                this.timeout(function () {
                });
            }
        };
        WidgetContext.prototype.getState = function () {
            return this.widget.state;
        };
        WidgetContext.prototype.getTitle = function () {
            return this.widget.data.title;
        };
        WidgetContext.prototype.getStandardTitle = function () {
            return this.widget.definition.standardTitle;
        };
        WidgetContext.prototype.setTitle = function (title) {
            try {
                var widget = this.widget;
                widget.titleApi = title;
                widget.data.titleApi = title;
                if (widget.isCatalogTitle() || !widget.data.isTitleLocked) {
                    if (this.isDebug()) {
                        this.debug("Ignoring setTitle call from implementation becuase widget is configured to use catalog title or the title is unlocked");
                    }
                    return;
                }
                widget.setTitleInternal(title);
            }
            catch (ex) {
                this.error("Failed to setTitle " + ex);
            }
        };
        WidgetContext.prototype.enableTitleEdit = function (isEnabled) {
            this.widget.isTitleEditEnabled = isEnabled;
        };
        WidgetContext.prototype.isTitleEditEnabled = function () {
            return this.widget.isTitleEditEnabled;
        };
        WidgetContext.prototype.getPageId = function () {
            try {
                return this.widget.parentContext.id;
            }
            catch (ex) {
                return null;
            }
        };
        WidgetContext.prototype.getStandardWidgetId = function () {
            return this.widget.definition.standardWidgetId || this.widget.id;
        };
        WidgetContext.prototype.getWidgetInstanceId = function () {
            return this.widget.data.instanceId;
        };
        WidgetContext.prototype.getService = function (name) {
            var element = this.widget.element;
            if (element) {
                var injector = element.injector();
                if (injector) {
                    try {
                        return injector.get(name);
                    }
                    catch (ex) {
                        this.error("Failed to get service " + name, ex);
                    }
                }
            }
            return null;
        };
        WidgetContext.prototype.getApplication = function () {
            return this.application;
        };
        WidgetContext.prototype.getApplications = function () {
            return this.applications || [];
        };
        WidgetContext.prototype.getLogicalId = function () {
            var application = this.application;
            return application ? application.logicalId : null;
        };
        WidgetContext.prototype.setLogicalId = function (logicalId) {
            var data = this.widget.data;
            if (logicalId) {
                if (!this.isValidLogicalId(logicalId)) {
                    throw "Invalid logical ID";
                }
                data.logicalId = logicalId;
            }
            else {
                delete data.logicalId;
            }
            this.initializeApplication();
        };
        WidgetContext.prototype.isCloud = function () {
            return this.context.isCloud();
        };
        WidgetContext.prototype.getContainerUrl = function () {
            return this.context.getContainerUrl();
        };
        WidgetContext.prototype.getApplicationAsync = function (logicalId) {
            return this.config.getApplication(logicalId);
        };
        WidgetContext.prototype.getApplicationsAsync = function (logicalId) {
            return this.config.getApplications(logicalId);
        };
        WidgetContext.prototype.getIonApiCustomerContext = function () {
            return this.config.ionApiCustomerContext;
        };
        WidgetContext.prototype.getIonApiContextAsync = function (options) {
            return this.config.getIonApiContextAsync(options);
        };
        WidgetContext.prototype.executeIonApiAsync = function (options) {
            return this.config.executeIonApiAsync(options);
        };
        WidgetContext.prototype.resolveAndReplaceAsync = function (template, logicalId) {
            var deferred = this.q.defer();
            this.resolveAndReplaceInternalAsync(template, logicalId || this.getLogicalId(), deferred, true, false);
            return deferred.promise;
        };
        WidgetContext.prototype.getViewTemplate = function (views, viewId) {
            var view = lm.ArrayUtil.itemByProperty(views, "viewId", viewId);
            return view ? view.urlTemplate : null;
        };
        WidgetContext.prototype.resolveViewUrl = function (options, application, deferred) {
            var views = application.views;
            if (views) {
                var template = this.getViewTemplate(views, options.viewId);
                if (template) {
                    if (options.resolve === false) {
                        deferred.resolve(template);
                        return;
                    }
                    this.resolveAndReplaceInternalAsync(template, application.logicalId, deferred, true, true);
                    return;
                }
            }
            deferred.reject("View not found");
        };
        WidgetContext.prototype.getViewUrlAsync = function (options) {
            var _this = this;
            var deferred = this.q.defer();
            var logicalId = options.logicalId || this.getLogicalId();
            this.config.getApplication(logicalId).then(function (application) {
                _this.resolveViewUrl(options, application, deferred);
            }, function (e) {
                deferred.reject(e);
            });
            return deferred.promise;
        };
        WidgetContext.prototype.getAbsoluteUrl = function (url, useHttps) {
            if (url.indexOf("http://") != 0 && url.indexOf("https://") != 0) {
                url = this.getScheme(useHttps) + "://" + url;
            }
            return url;
        };
        WidgetContext.prototype.resolveAndReplaceInternalAsync = function (template, logicalId, deferred, isFirst, isUrl) {
            var _this = this;
            if (template.indexOf("{lid://") == 0) {
                var end = template.indexOf("}");
                if (end > 0) {
                    logicalId = template.substring(1, end);
                    template = template.substring(end + 1);
                }
            }
            if (!logicalId) {
                deferred.resolve(this.resolveAndReplace(template));
                return;
            }
            this.config.getApplication(logicalId).then(function (application) {
                template = _this.resolveAndReplaceInternal(template, logicalId);
                if (isFirst && template && template.indexOf("{") >= 0) {
                    _this.resolveAndReplaceInternalAsync(template, logicalId, deferred, false, isUrl);
                }
                else {
                    if (isUrl) {
                        template = _this.getAbsoluteUrl(template, application.useHttps);
                    }
                    deferred.resolve(template);
                }
            }, function () {
                deferred.reject();
            });
        };
        WidgetContext.prototype.getLogicalIdPrefix = function () {
            return this.widget.definition.applicationLogicalId;
        };
        WidgetContext.prototype.resolve = function (key) {
            return this.resolveValue(key, this.getLogicalId());
        };
        WidgetContext.prototype.resolveValue = function (key, logicalId) {
            if (!key) {
                return key;
            }
            var i = key.indexOf(".");
            var prefix = null;
            if (i > 1) {
                prefix = key.substring(0, i);
                prefix = prefix.toLowerCase();
            }
            var cst = c.Constants;
            var widget = this.widget;
            var config = this.config;
            if (prefix && (c.Constants.configurationPrefixes.indexOf(prefix) >= 0)) {
                var name = key.substring(i + 1, key.length);
                var resolvedValue = null;
                if (name.toLowerCase() === c.Constants.scheme && prefix === cst.configurationApplicationPrefix) {
                    var schema = this.resolveScheme(logicalId, config, prefix);
                    if (schema) {
                        return schema;
                    }
                }
                if (prefix === cst.configurationWidgetPrefix) {
                    resolvedValue = this.resolveFromSource(widget.data, logicalId, cst.configurationSettings, name);
                }
                else if (prefix === cst.configurationLocalizationPrefix) {
                    resolvedValue = this.resolveFromSource(widget.context.getLanguage(), logicalId, null, name);
                }
                else if (prefix === cst.configurationViewPrefix) {
                    var application = this.config.getApplicationCached(logicalId);
                    if (application) {
                        resolvedValue = this.getViewTemplate(application.views, name);
                        if (resolvedValue && resolvedValue.indexOf("http") !== 0) {
                            resolvedValue = this.getScheme(application.useHttps) + "://" + resolvedValue;
                        }
                    }
                }
                else if (prefix === cst.configurationFrameworkPrefix) {
                    resolvedValue = this.resolveFramework(name);
                }
                else {
                    resolvedValue = this.resolveFromSource(config, logicalId, prefix, name);
                }
                return resolvedValue;
            }
            var value = this.resolveFromSource(widget.data, logicalId, cst.configurationSettings, key);
            if (value != null) {
                return value.toString();
            }
            value = this.resolveFromSource(config, logicalId, cst.configurationProperties, key);
            if (value != null) {
                return value;
            }
            var keyLowerCase = key.toLocaleLowerCase();
            if (keyLowerCase === c.Constants.tenantId) {
                return this.context.getTenantId();
            }
            if (keyLowerCase === c.Constants.userid) {
                return this.context.getUserId();
            }
            if (keyLowerCase === c.Constants.language) {
                return this.context.getLanguage();
            }
            value = this.resolveFromSource(config, logicalId, cst.configurationApplication, key);
            if (value != null) {
                return value;
            }
            if (keyLowerCase === c.Constants.scheme) {
                return this.resolveScheme(logicalId, config, cst.configurationApplication);
            }
            return null;
        };
        WidgetContext.prototype.getScheme = function (useHttps) {
            return useHttps === true || useHttps === "true" || useHttps === "1" ? "https" : "http";
        };
        WidgetContext.prototype.resolveFramework = function (name) {
            var widget = this.widget;
            name = name.toLowerCase();
            if ("pageid" === name) {
                return widget.parentContext.id;
            }
            if ("widgetid" === name) {
                return widget.id;
            }
            if ("standardwidgetid" === name) {
                return widget.definition.standardWidgetId || widget.id;
            }
            if ("widgetinstanceid" === name) {
                return widget.data.instanceId;
            }
            if ("containerurl" === name) {
                return widget.context.getContainerUrl();
            }
            return null;
        };
        WidgetContext.prototype.resolveScheme = function (logicalId, container, prefix) {
            var useHttps = this.resolveFromSource(container, logicalId, prefix, c.Constants.useHttps);
            if (useHttps) {
                useHttps = useHttps.toLowerCase();
                return this.getScheme(useHttps);
            }
            return null;
        };
        WidgetContext.prototype.resolveFromSource = function (container, logicalId, propertyName, key) {
            if (!container) {
                return null;
            }
            var mapObject;
            var cst = c.Constants;
            if (!propertyName) {
                mapObject = container;
            }
            else if (propertyName === cst.configurationApplication) {
                mapObject = container.getApplicationCached(logicalId);
            }
            else if (propertyName === cst.configurationPropertyPrefix) {
                mapObject = container[cst.configurationProperties];
            }
            else {
                mapObject = container[propertyName];
            }
            if (!mapObject) {
                if (this.isDebug()) {
                    this.debug("[resolveFromSource] " + propertyName + " " + key + ", no such configuration.");
                }
                return null;
            }
            var stringValue;
            var value = mapObject[key];
            if (lm.CommonUtil.hasValue(value)) {
                stringValue = value.toString();
                if (this.isDebug()) {
                    this.debug("[resolveFromSource] Resolved " + key + " to: " + stringValue);
                }
                return stringValue;
            }
            var keyUpper = key.toUpperCase();
            for (var name in mapObject) {
                if (keyUpper === name.toUpperCase()) {
                    value = mapObject[name];
                    if (lm.CommonUtil.hasValue(value)) {
                        stringValue = value.toString();
                        if (this.isDebug()) {
                            this.debug("[resolveFromSource] Resolved " + keyUpper + " to: " + stringValue);
                        }
                        return stringValue;
                    }
                    else {
                        return null;
                    }
                }
            }
            if (this.isDebug()) {
                this.debug("[resolve] " + propertyName + " has no value for " + key + ".");
            }
            return null;
        };
        WidgetContext.prototype.resolveAndReplace = function (template) {
            return this.resolveAndReplaceInternal(template, this.getLogicalId());
        };
        WidgetContext.prototype.resolveAndReplaceInternal = function (template, logicalId) {
            var _this = this;
            template = this.replaceSpecialCases(template, logicalId);
            var resolveFunction = function (key) {
                var value = _this.resolveInternal(key, logicalId);
                return value;
            };
            return lm.StringUtil.replaceParameters(template, resolveFunction);
        };
        WidgetContext.prototype.replaceSpecialCases = function (template, logicalId) {
            template = this.replaceSpecialVariable(template, logicalId, ":{Port}", "Port", ":", "");
            template = this.replaceSpecialVariable(template, logicalId, ":{Application.Port}", "Application.Port", ":", "");
            template = this.replaceSpecialVariable(template, logicalId, "/{Context}", "Context", "/", "");
            template = this.replaceSpecialVariable(template, logicalId, "/{Application.Context}", "Application.Context", "/", "");
            return template;
        };
        WidgetContext.prototype.replaceSpecialVariable = function (template, logicalId, searchText, variableName, resolvedPrefix, defaultText) {
            if (template && template.indexOf(searchText) > -1) {
                var resolved = this.resolveInternal(variableName, logicalId);
                if (!resolved || resolved == "0") {
                    template = template.replace(searchText, defaultText);
                }
                else {
                    if (resolvedPrefix) {
                        resolved = resolvedPrefix + resolved;
                    }
                    template = template.replace(searchText, resolved);
                }
            }
            return template;
        };
        WidgetContext.prototype.resolveInternal = function (key, logicalId) {
            var name = key;
            var index = key.indexOf("|");
            var encode = true;
            var defaultValue = "";
            var useUriEncode = true;
            if (index > 0) {
                name = key.substring(0, index);
                var filter = key.substring(index + 1, key.length);
                filter.trim();
                if (filter && filter.length > 1) {
                    filter = filter.toLowerCase();
                    var ruleIndex = filter.indexOf(":");
                    var filterParam = null;
                    if (ruleIndex > 0) {
                        filterParam = filter.substring(ruleIndex + 1, filter.length);
                        filterParam.trim();
                        filterParam = filterParam.toLowerCase();
                        filter = filter.substring(0, ruleIndex);
                    }
                    if (filter === "encode") {
                        if (filterParam === "none") {
                            encode = false;
                        }
                        else if (filterParam === "uri") {
                            useUriEncode = true;
                        }
                        else if (filterParam === "component") {
                            useUriEncode = false;
                        }
                    }
                    else if (filter === "default") {
                        defaultValue = filterParam;
                    }
                }
            }
            name = name.trim();
            var value = this.resolveValue(name, logicalId);
            if (value) {
                if (encode) {
                    if (useUriEncode) {
                        return encodeURI(value);
                    }
                    else {
                        return encodeURIComponent(value);
                    }
                }
                return value;
            }
            return defaultValue;
        };
        WidgetContext.prototype.launch = function (launchOptions) {
            var _this = this;
            if (!launchOptions) {
                throw "launchOptions is not set";
            }
            if (!launchOptions.url) {
                throw "url is not set";
            }
            var url = launchOptions.url;
            if (lm.CommonUtil.isUndefined(launchOptions.resolve)) {
                launchOptions.resolve = true;
            }
            if (launchOptions.resolve === true && url.indexOf("{") >= 0) {
                this.debug("About to resolve launch of: " + url);
                this.resolveAndReplaceAsync(url, null).then(function (result) {
                    _this.launchInternal(result);
                }, function (err) {
                    if (c.ClientConfiguration.isDev()) {
                        alert("Not supported in test mode unless configration is provided and dev-configration attribute set on test widget. Please see Homepages developers guide");
                    }
                    _this.error("Failed to resolve " + url + " " + err);
                });
            }
            else {
                this.launchInternal(url);
            }
        };
        WidgetContext.prototype.launchInternal = function (url) {
            if (url.indexOf("http") === 0 || url.indexOf("/") === 0) {
                this.debug("Launching URL in tab " + url);
                window.open(url);
            }
            else {
                this.debug("Launching URL in Ming.le " + url);
                var isFavorite = url.indexOf("?favoriteContext") === 0;
                var client = infor.companyon.client;
                if (isFavorite) {
                    client.sendPrepareFavoritesMessage(url);
                }
                else {
                    client.sendPrepareDrillbackMessage(url);
                }
            }
        };
        WidgetContext.prototype.showWidgetMessage = function (message) {
            this.widget.message = message;
        };
        WidgetContext.prototype.removeWidgetMessage = function () {
            delete this.widget.message;
        };
        return WidgetContext;
    })(c.CoreBase);
    exports.WidgetContext = WidgetContext;
    var WidgetSettings = (function () {
        function WidgetSettings(widgetService, widget, values) {
            this.widgetService = widgetService;
            this.widget = widget;
            this.values = values;
        }
        WidgetSettings.prototype.getSetting = function (name) {
            return lm.ArrayUtil.itemByProperty(this.getMetadata(), "name", name);
        };
        WidgetSettings.prototype.getValues = function () {
            return this.values;
        };
        WidgetSettings.prototype.setValues = function (values) {
            this.values = values;
            this.widget.data.settings = this.values;
        };
        WidgetSettings.prototype.get = function (name, defaultValue) {
            var value = this.values[name];
            return !lm.CommonUtil.isUndefined(value) ? value : defaultValue;
        };
        WidgetSettings.prototype.set = function (name, value) {
            this.values[name] = value;
        };
        WidgetSettings.prototype.getString = function (name, defaultValue) {
            var value = this.values[name];
            return value ? value.toString() : defaultValue;
        };
        WidgetSettings.prototype.showSettings = function (options) {
            var data = options ? options.data : null;
            this.widgetService.showSettings(this.widget, data);
        };
        WidgetSettings.prototype.getMetadata = function () {
            return this.widget.definition.settings;
        };
        WidgetSettings.prototype.setMetadata = function (metadata) {
            var definition = this.widget.definition;
            if (metadata) {
                var customMetadata = definition.customMetadata;
                if (customMetadata) {
                    metadata = WidgetUtil.applyRestrictions(metadata, customMetadata);
                }
            }
            definition.settings = metadata;
        };
        WidgetSettings.prototype.isSettingsEnabled = function () {
            return this.widget.isSettingsEnabled();
        };
        WidgetSettings.prototype.getCustomSetting = function (name) {
            var metadata = this.widget.definition.customMetadata;
            if (metadata) {
                return lm.ArrayUtil.itemByProperty(metadata, "name", name);
            }
            return null;
        };
        WidgetSettings.prototype.isSettingEnabled = function (name) {
            if (!this.isSettingsEnabled()) {
                return false;
            }
            var setting = this.getCustomSetting(name);
            if (setting && setting.isEnabled === false) {
                return false;
            }
            setting = this.getSetting(name);
            return setting && setting.isEnabled == false ? false : true;
        };
        WidgetSettings.prototype.isSettingVisible = function (name) {
            var setting = this.getCustomSetting(name);
            if (setting && setting.isVisible === false) {
                return false;
            }
            setting = this.getSetting(name);
            return setting && setting.isVisible == false ? false : true;
        };
        WidgetSettings.prototype.enableSettingsMenu = function (enabled) {
            this.widget.setSettingsMenuEnabled(enabled);
        };
        return WidgetSettings;
    })();
    var WidgetContainerDirective = (function (_super) {
        __extends(WidgetContainerDirective, _super);
        function WidgetContainerDirective(rootScope, q, timeout, compile, templateCache, widgetService, contextService, languageService) {
            _super.call(this, "[WidgetContainerDirective] ");
            this.rootScope = rootScope;
            this.q = q;
            this.timeout = timeout;
            this.compile = compile;
            this.templateCache = templateCache;
            this.widgetService = widgetService;
            this.contextService = contextService;
            this.languageService = languageService;
        }
        WidgetContainerDirective.prototype.createContext = function (scope, widget, element, definition) {
            var values = widget.data.settings;
            if (!values) {
                widget.data.settings = values = {};
            }
            var angularContext = scope != null ? {
                module: WidgetContainerDirective.externalModule,
                scope: scope,
                compile: this.compile,
                getTemplateUrl: function (relativeUrl) {
                    return WidgetUtil.getUrl(definition, relativeUrl);
                }
            } : null;
            var settings = new WidgetSettings(this.widgetService, widget, values);
            var context = this.contextService.getContext();
            return new WidgetContext(this.q, this.timeout, this.widgetService, widget, settings, element, angularContext, context, this.languageService);
        };
        WidgetContainerDirective.prototype.attach = function (scope, controller, widget, element) {
            var _this = this;
            var unregister = widget.restored().on(function () {
                if (controller) {
                    controller.setUrl("");
                }
                unregister();
                element.empty();
                _this.addWidget(scope, controller, widget, element);
            });
        };
        WidgetContainerDirective.prototype.addInline = function (scope, widget, element) {
            var factory = widget.widgetModule.widgetFactory;
            if (!factory) {
                this.error("The widget module for widget with id " + widget.data.id + " does not export a factory function for widget.");
                return;
            }
            var definition = this.widgetService.getCachedDefinition(widget.id);
            if (!definition) {
                this.error("Definition for id " + widget.id + " is not in the cache.");
                return;
            }
            var context = this.createContext(scope, widget, element, definition);
            widget.context = context;
            scope[lm.WidgetConstants.widgetContextKey] = context;
            var instance = factory(context);
            scope[lm.WidgetConstants.widgetInstanceKey] = instance;
            widget.instance = instance;
            this.widgetInstance = instance;
            var config = this.widgetInstance.angularConfig;
            if (config) {
                WidgetUtil.cacheTemplates(this.templateCache, config);
                WidgetUtil.addAngularContent(scope, this.compile, element, config, definition);
            }
            this.attach(scope, null, widget, element);
        };
        WidgetContainerDirective.prototype.addExternal = function (scope, controller, widget, element) {
            var iframe = lm.HtmlUtil.iframe(null, widget.data.instanceId);
            element.addClass("lm-position-r");
            element.append(iframe);
            var definition = this.widgetService.getCachedDefinition(widget.id);
            var context = this.createContext(null, widget, element, definition);
            widget.context = context;
            controller.loadExternal(widget, iframe);
            this.attach(scope, controller, widget, element);
        };
        WidgetContainerDirective.prototype.addWidget = function (scope, controller, widget, element) {
            scope["lmWidget"] = widget;
            if (widget.data.isBroken || this.rootScope[c.Constants.safeMode]) {
                return;
            }
            var type = widget.widgetType.toLowerCase();
            if (type === c.WidgetType.Inline) {
                this.addInline(scope, widget, element);
            }
            else if (type === c.WidgetType.External) {
                this.addExternal(scope, controller, widget, element);
            }
            else {
                this.error("Widget type " + type + " is not supported.");
            }
        };
        WidgetContainerDirective.prototype.link = function (scope, element, attributes, controller, transclude) {
            var _this = this;
            var widget = scope.$parent["lmWidget"];
            var content = element.find(".widget-content");
            this.widgetService.loadWidget(widget).then(function (w) { return _this.addWidget(scope, controller, w, content); });
        };
        WidgetContainerDirective.add = function (externalModule, internalModule) {
            WidgetContainerDirective.externalModule = externalModule;
            internalModule.directive("lmWidgetContainer", ["$rootScope", "$q", "$timeout", "$compile", "$templateCache", "lmWidgetService", "lmContextService", "lmLanguageService", function ($rootScope, $q, $timeout, $compile, $templateCache, widgetService, contextService, languageService) {
                    var directive = new WidgetContainerDirective($rootScope, $q, $timeout, $compile, $templateCache, widgetService, contextService, languageService);
                    return {
                        scope: {},
                        restrict: "E",
                        controller: WidgetContainerCtrl,
                        controllerAs: "ctrl",
                        replace: true,
                        templateUrl: "scripts/lime/templates/widget.html",
                        link: function (s, e, a, c, t) { return directive.link(s, e, a, c, t); }
                    };
                }]);
        };
        return WidgetContainerDirective;
    })(c.CoreBase);
    var CustomWidgetSettingsDirective = (function (_super) {
        __extends(CustomWidgetSettingsDirective, _super);
        function CustomWidgetSettingsDirective(compile, widgetService) {
            _super.call(this, "[CustomWidgetSettingsDirective] ");
            this.compile = compile;
            this.widgetService = widgetService;
        }
        CustomWidgetSettingsDirective.add = function (m) {
            m.directive("lmCustomWidgetSettings", ["$compile", "lmWidgetService", function ($compile, templateCache, widgetService) {
                    var directive = new CustomWidgetSettingsDirective($compile, widgetService);
                    return {
                        scope: {},
                        restrict: "E",
                        link: function (s, e, a, c, t) { return directive.link(s, e, a, c, t); }
                    };
                }]);
        };
        CustomWidgetSettingsDirective.prototype.link = function (scope, element, attributes, controller, transclude) {
            var dialog = scope.$parent["lmDialog"];
            var parameter = dialog.parameter;
            if (!parameter) {
                this.error("Parameter property not set on IDialog");
                return;
            }
            var content = element.find(".lm-widget-settings-content");
            if (!content) {
                content = null;
                this.error("Missing lm-widget-settings-content div");
            }
            try {
                var widget = parameter.widget;
                var context = new WidgetSettingsContext(widget, content, dialog);
                var settingsInstance = parameter.widgetSettingsFactory(context);
                scope.$parent["lmSettingsInstance"] = settingsInstance;
                var config = settingsInstance.angularConfig;
                if (config) {
                    WidgetUtil.addAngularContent(scope, this.compile, element, config, widget.definition);
                }
            }
            catch (e) {
                this.error("Failed to create custom settings with factory ", e);
            }
        };
        return CustomWidgetSettingsDirective;
    })(c.CoreBase);
    var WidgetAboutCtrl = (function () {
        function WidgetAboutCtrl(scope, widgetService, languageService, progressService, dialogService) {
            this.scope = scope;
            this.widgetService = widgetService;
            this.progressService = progressService;
            this.dialogService = dialogService;
            this.dialog = scope["lmDialog"];
            this.lang = languageService.getLanguage();
            var parameter = this.dialog.parameter;
            if (parameter) {
                this.widget = parameter.widget;
                if (this.widget.data.isBroken) {
                    return;
                }
                var id = this.widget.id;
                var definition = widgetService.getCachedDefinition(id);
                this.widgetDefinition = definition;
                var title = this.widget.title;
                scope["title"] = title;
                scope["name"] = definition.title;
                if (definition.isPublished && !this.widget.isDev) {
                    scope["titleBasedOn"] = definition.standardTitle;
                }
            }
        }
        WidgetAboutCtrl.prototype.getTitle = function (definition) {
            var title;
            var lang = definition.lang;
            if (lang) {
                title = lang[lm.WidgetConstants.widgetTitle];
            }
            return title || definition.standardTitle;
        };
        WidgetAboutCtrl.prototype.onClose = function () {
            this.dialog.close();
        };
        WidgetAboutCtrl.prototype.copyToClipboard = function () {
            var basedOn = this.scope["titleBasedOn"] ? 'Based on: ' + this.scope["titleBasedOn"] + ", \n" : "";
            var basedOnID = this.widgetDefinition.standardWidgetId ? 'Based on (ID): ' + this.widgetDefinition.standardWidgetId + ", \n" : "";
            var ownerName = this.widgetDefinition.ownerName ? ', \nOwner Name: ' + this.widgetDefinition.ownerName : "";
            var ownerId = this.widgetDefinition.owner ? ', \nOwner ID: ' + this.widgetDefinition.owner : "";
            var data = 'Title: ' + this.widget.title + ", \n" +
                'Name: ' + this.scope["name"] + ", \n" +
                'ID: ' + this.widget.data.id + ", \n" +
                basedOn +
                basedOnID +
                'Version: ' + this.widgetDefinition.version +
                ownerName +
                ownerId;
            this.dialogService.copyToClipboard({ copyData: data });
        };
        WidgetAboutCtrl.add = function (m) {
            m.controller("lmWidgetAboutCtrl", WidgetAboutCtrl);
        };
        WidgetAboutCtrl.$inject = ["$scope", "lmWidgetService", "lmLanguageService", "lmProgressService", "lmDialogService"];
        return WidgetAboutCtrl;
    })();
    exports.init = function (externalModule, internalModule) {
        WidgetService.add(internalModule);
        WidgetSettingsCtrl.add(internalModule);
        CustomWidgetSettingsCtrl.add(internalModule);
        CustomWidgetSettingsDirective.add(internalModule);
        WidgetContainerCtrl.add(internalModule);
        WidgetContainerDirective.add(externalModule, internalModule);
        WidgetResizeCtrl.add(internalModule);
        WidgetCustomizationCtrl.add(internalModule);
        WidgetAboutCtrl.add(internalModule);
    };
});
//# sourceMappingURL=widget.js.map