define(["require", "exports", "lime"], function (require, exports, lm) {
    var W2WReceiverCtrl = (function () {
        function W2WReceiverCtrl(scope) {
            var _this = this;
            this.scope = scope;
            // Get the widget context and instance from the scope
            var widgetContext = scope[lm.WidgetConstants.widgetContextKey];
            var widgetInstance = scope[lm.WidgetConstants.widgetInstanceKey];
            this.widgetContext = widgetContext;
            this.language = widgetContext.getLanguage();
            this.instanceId = widgetContext.getWidgetInstanceId();
            var pageId = widgetContext.getPageId();
            this.pageId = pageId;
            this.logPrefix = "[" + widgetContext.getId() + "] ";
            // Subscribe to the event that is triggered when settings are saved to be able to update the message type
            widgetInstance.settingsSaved = function () {
                _this.updateMessageType();
            };
            // Set initial message type used for communication
            this.updateMessageType();
        }
        W2WReceiverCtrl.prototype.registerHandler = function (messageType) {
            var _this = this;
            var callback = function (args) { _this.handleMessage(args); };
            infor.companyon.client.registerMessageHandler(messageType, callback);
            this.messageType = messageType;
            this.isHandlerRegistered = true;
            lm.Log.debug(this.logPrefix + "Message handler registered for message type: " + messageType);
        };
        W2WReceiverCtrl.prototype.unregisterHandler = function (messageType) {
            infor.companyon.client.unRegisterMessageHandler(messageType);
            lm.Log.debug(this.logPrefix + "Message handler unregistered for message type: " + messageType);
        };
        W2WReceiverCtrl.prototype.updateMessageType = function () {
            var messageType = this.widgetContext.getSettings().get("MessageType");
            var newMessageType = messageType + this.pageId;
            var original = this.messageType;
            if (!lm.StringUtil.isNullOrWhitespace(messageType) && newMessageType !== original) {
                if (this.isHandlerRegistered) {
                    this.unregisterHandler(original);
                }
                this.registerHandler(newMessageType);
            }
        };
        W2WReceiverCtrl.prototype.handleMessage = function (person) {
            if (person) {
                this.person = person;
                this.scope.$apply("ctrl.person");
            }
            lm.Log.debug(this.logPrefix + "Received message from sender widget: " + JSON.stringify(person));
        };
        W2WReceiverCtrl.add = function (m) {
            m.controller("W2WReceiverCtrl", W2WReceiverCtrl);
        };
        W2WReceiverCtrl.$inject = ["$scope"];
        return W2WReceiverCtrl;
    })();
    exports.widgetFactory = function (context) {
        var m = context.getAngularContext().module;
        W2WReceiverCtrl.add(m);
        return {
            angularConfig: {
                relativeTemplateUrl: "widget.html"
            }
        };
    };
});
//# sourceMappingURL=widget.js.map