﻿import lm = require("../../lime");
import c = require("../../core");
import s = require("../service");

class AdminPublishedPagesCtrl extends c.CoreBase {
	public publishedPages: c.IPage[] = [];
	public accessCopy: c.IPageAccess;
	public noOfSelected: number;
	public pagesGridOptions: any;
	public refreshText = "Refresh";
	public isSearchActive: boolean;

	private accessCopyPageId: string;

	static $inject = ["$scope", "lmAdminService", "lmAdminContext", "lmDialogService", "lmPageService", "lmCommonDataService", "uiGridConstants"];

	constructor(public scope: ng.IScope, private adminService: s.IAdminService, private adminContext: s.IAdminContext, private dialogService: lm.IDialogService, private pageService: c.IPageService,
		private commonDataService: c.ICommonDataService, private uiGridConstants: any) {
		super("[AdminPublishedPagesCtrl] ");

		this.initGrid();

		const adminConstants = s.AdminConstants;
		// Watch to see if this tab is selected
		const self = this;
		scope.$watch(adminConstants.openTab, (tab) => {
			if (tab === adminConstants.publishedPagesTab && !this.isSearchActive) {
				self.listPublishedPages(false);
			}
		});
	}

	public searchPage(id: string): void {
		if (!lm.StringUtil.isNullOrWhitespace(id)) {
			id = id.trim();
			const result = lm.ArrayUtil.find(this.publishedPages, (item: c.IPage) => {
				const data = item.data;
				return (data.id === id);
			});

			this.clearSelection();
			this.pagesGridOptions.data = result ? [result] : [];
			this.isSearchActive = true;
		}
	}

	public showGuidSearchDialog(): void {
		const options = <lm.IDialogOptions>{
			title: "Search",
			templateUrl: "scripts/lime/admin/templates/guid-search-dialog.html"
		};

		this.dialogService.show(options).then((r: lm.IDialogResult) => {
			if (!lm.CommonUtil.isUndefined(r.value) && r.button === lm.DialogButtonType.Ok) {
				const query = <string>r.value;
				if (query) {
					this.searchPage(query);
				}
			}
		});
	}

	private getSelectedRows(): c.IPage[] {
		return this.scope["pagesGridApi"].selection.getSelectedRows();
	}

	private clearSelection(): void {
		this.noOfSelected = 0;
		const grid = this.scope["pagesGridApi"];
		if (grid) {
			grid.selection.clearSelectedRows();
		}
	}

	/**
	* List Published Pages
	*
	* Lists published pages from cache or server.
	*
	* @params reload Boolean - True: load from server. False: load from cache.
	* @params callback Function to call on successful load from cache/server.
	*/
	public listPublishedPages(reload: boolean, callback?: Function): void {
		const self = this;
		const adminService = self.adminService;
		this.scope["searchIdString"] = "";
		this.isSearchActive = false;

		if (reload) {
			this.clearSelection();
		}

		adminService.setBusy(true);
		adminService.listPublishedPages(reload).then((r: c.IPageListResponse) => {
			const publishedPages = r.content;
			self.publishedPages = publishedPages;
			self.pagesGridOptions.data = publishedPages;
			adminService.setBusy(false);
			if (callback) {
				callback();
			}
		}, (r: c.IOperationResponse) => {
			adminService.setBusy(false);
			adminService.handleError(r);
			if (callback) {
				callback();
			}
		});
	}

	/**
	* Import
	*
	* Opens dialog for importing published pages.
	*/
	public import(): void {
		const dialogTitle = "Import Published Pages";
		const adminService = this.adminService;
		const options: c.IImportOptions = {
			title: dialogTitle,
			operation: c.EntityCategory.publishedPage.toString()
		};

		const self = this;
		adminService.openImportFilesDialog(options).then((r: lm.IDialogResult) => {
			const value = r.value;
			if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Success) {
				this.adminService.showUploadCompleteDialog(dialogTitle, value.message).then((result: lm.IDialogResult) => {
					if (result.button === lm.DialogButtonType.Ok) {
						self.listPublishedPages(true);
					}
				});
			} else if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Fail) {
				adminService.showUploadCompleteDialog(dialogTitle, value.message, true);
			}
		});
	}

	/**
	* Export
	*
	* Exports selected published pages.
	*/
	public export(): void {
		if (this.noOfSelected === this.publishedPages.length) {
			this.exportAll();
		} else {
			const pagesToExport = this.getSelectedRows();
			this.adminService.exportPublishedPages(pagesToExport);
		}
	}

	/**
	* Export All
	*
	* Exports all published pages.
	*/
	public exportAll(): void {
		this.adminService.exportPublishedPages();
	}

	/**
	* Delete
	*
	* Deletes the provided page or selected pages in the grid.
	*
	* @param page Page to delete (if single page).
	*/
	public delete(page?: c.IPage): void {
		const pagesToDelete = page ? [page] : this.getSelectedRows();
        var options = this.adminService.getDeletePageOptions(pagesToDelete, false);
        this.dialogService.showMessage(options).then((result: lm.IDialogResult) => {
            if (result.button === lm.DialogButtonType.Yes) {
                this.deletePublishedPage(pagesToDelete);
            }
        });
	}

	private setBusy(isBusy: boolean): void {
		this.adminService.setBusy(isBusy);
	}

	private onError(error: any): void {
		this.adminService.handleError(error);
		this.setBusy(false);
	}

	private updateOwner(existing: c.IPageData, updated: c.IPageData): void {
		existing.ownerId = updated.ownerId;
		existing.ownerName = updated.ownerName;
		existing.changedByName = updated.changedByName;
		existing.changeDate = updated.changeDate;
	}

	/**
	 * Changes the owner of the selected page to the current user.
	 */
	public takeOwnership(page: c.IPage): void {
		var self = this;
		this.setBusy(true);
		this.adminService.updatePageOwner({ id: page.data.id }).then((response) => {
			self.updateOwner(page.data, response.content);
			self.setBusy(false);
		}, (e) => {
			self.onError(e);
		});
	}

	public changeOwnership(page: c.IPage): void {
		var self = this;
		this.adminService.openChangeOwnerDialog(page.data.title, page.data.ownerId, (newOwner: lm.IAutocompleteEntity) => {
			if (page.data.ownerId !== newOwner.value) {
				self.setBusy(true);
				self.adminService.updatePageOwner({ id: page.data.id, ownerId: newOwner.value }).then((response) => {
					self.updateOwner(page.data, response.content);
					self.setBusy(false);
				}, (e) => {
					self.onError(e);
				});
			}
		});
	}

	/**
	* Edit Page Access
	*
	* Edit page access for a published page.
	*
	* @param page Page to edit.
	*/
	public editPageAccess(page: c.IPage): void {
		this.adminService.openPageAccessDialog(page, () => {
			this.listPublishedPages(true);
		});
	}
	
	/**
	* Copy page access.
	*
	* Copy access rights of a page.
	*
	* @params page to copy access from.
	*/
	public copyAccess(page: c.IPage): void {
		const self = this;
		const adminService = self.adminService;

		adminService.setBusy(true);
		adminService.getPageAccess(page.data.id).then((r: c.IPageAccessResponse) => {
			self.accessCopy = r.content;
			self.accessCopyPageId = page.data.id;
			adminService.setBusy(false);
		}, (r: c.IPageAccessResponse) => {
			adminService.handleError(r);
			adminService.setBusy(false);
		});
	}

	/**
	* Apply Access Copy
	*
	* Apply copied acces rights to selected widget(s).
	*
	* @params widget to edit. Otherwise use selected widgets in grid.
	*/
	public applyAccessCopy(page?: c.IPage): void {
		const pagesToUpdate = page ? [page] : this.getSelectedRows();
		this.adminService.applyPageAccess(pagesToUpdate, this.accessCopy, () => {
			this.listPublishedPages(true);
		});
	}

	/**
	* Clear Or Replace With Access Copy
	*
	* If indicated with "isReplace", replaces access rights.
	* Otherwise clear access rights of selected pages.
	*
	* @params isReplace Boolean, true: replace, false: clear.
	*/
	public clearOrReplaceWithAccessCopy(isReplace?: boolean, page?: c.IPage): void {
		const pagesToUpdate = page ? [page] : this.getSelectedRows();
		this.adminService.clearOrReplacePageAccess(pagesToUpdate, isReplace, () => {
			this.listPublishedPages(true);
		}, this.accessCopy);
	}

	/**
	* Init Grid
	*
	* Initializes the grid.
	*/
	private initGrid(): void {
		const gridConstants = this.uiGridConstants;
		const adminConstants = s.AdminConstants;
		const pageActionTemplate = '<div class="ui-grid-cell-contents lm-center-text"><button type="button" ng-click="$event.stopPropagation();" class="btn-actions lm-transparent" xi-popupmenu="grid.appScope.ctrl.menuOptions">' +
			'<span class="audible">Actions</span><svg class="icon" focusable="false" aria-hidden="false"><use xlink:href="#icon-more"/></svg></button><ul class="popupmenu actions top"><li><a ng-click="grid.appScope.ctrl.editPageAccess(row.entity)">Edit Permissions</a></li>' +
			'<li ng-show="row.entity.data.hasAccess"><a ng-click="grid.appScope.ctrl.copyAccess(row.entity)">Copy Permissions</a></li><li ng-show="grid.appScope.ctrl.accessCopy && grid.appScope.ctrl.accessCopyPageId !== row.entity.data.id" class="separator"></li>' +
			'<li ng-show="grid.appScope.ctrl.accessCopy && grid.appScope.ctrl.accessCopyPageId !== row.entity.data.id"><a ng-click="grid.appScope.ctrl.applyAccessCopy(row.entity)">Apply Copied Permissions</a></li><li ng-show="grid.appScope.ctrl.accessCopy && grid.appScope.ctrl.accessCopyPageId !== row.entity.data.id && row.entity.data.hasAccess">' +
			'<a ng-click="grid.appScope.ctrl.clearOrReplaceWithAccessCopy(true, row.entity)">Replace Copied Permissions</a></li><li class="separator"></li><li><a ng-click="grid.appScope.ctrl.takeOwnership(row.entity)">Take Ownership</a></li><li><a ng-click="grid.appScope.ctrl.changeOwnership(row.entity)">Change Ownership</a></li><li class="separator"></li>' +
			'<li ng-show="row.entity.data.hasAccess"><a ng-click="grid.appScope.ctrl.clearOrReplaceWithAccessCopy(false, row.entity)">Clear Permissions</a></li><li><a ng-click="grid.appScope.ctrl.delete(row.entity)">Delete</a></li></ul></div>';

		const self = this;
		this.pagesGridOptions = {
			paginationPageSizes: [adminConstants.gridPageSize],
			paginationPageSize: adminConstants.gridPageSize,
			columnDefs: [
				{
					field: "data.title",
					name: "Title",
					sort: { direction: gridConstants.ASC, priority: 1 },
					filter: { condition: gridConstants.filter.CONTAINS },
					minWidth: 50, maxWidth: 600
				},
				{ field: "data.description", name: "Description", minWidth: 50, maxWidth: 600 },
				{ field: "data.tags", name: "Tags", minWidth: 50, maxWidth: 600 },
				{ field: "data.ownerName", name: "Owner", minWidth: 50, maxWidth: 600 },
				{
					field: "data.changeDate",
					name: "ChangeDate",
					displayName: "Change date",
					cellTemplate: "<div class='ui-grid-cell-contents'>{{COL_FIELD | lmLocaleDate}}</div>",
					minWidth: 50,
					maxWidth: 600
				},
				{ field: "data.changedByName", name: "ChangedBy", displayName: "Changed by", minWidth: 50, maxWidth: 600 },
				{ field: "data.popularity", name: "UsedBy", displayName: "Used by", enableColumnResizing: false, maxWidth: 110 },
				{
					field: "data.hasAccess",
					name: "Permissions",
					enableFiltering: false,
					enableColumnResizing: false,
					maxWidth: 140,
					cellTemplate: "<div class='ui-grid-cell-contents'>{{COL_FIELD ? 'Restricted' : ''}}</div>"
				},
				{ field: "actions", name: "Actions", maxWidth: 110, cellTemplate: pageActionTemplate, enableFiltering: false, enableSorting: false, enableColumnResizing: false }
			],
			data: [],
			rowHeight: 48,
			enableFiltering: true,
			enableSorting: true,
			enableColumnMenus: false,
			onRegisterApi: (gridApi) => {
				self.scope["pagesGridApi"] = gridApi;
				self.noOfSelected = 0;
				const gridSelection = gridApi.selection;
				const onSelection = gridSelection.on;

				onSelection.rowSelectionChanged(this.scope, () => {
					self.noOfSelected = gridSelection.getSelectedRows().length;
				});
				onSelection.rowSelectionChangedBatch(this.scope, () => {
					self.noOfSelected = gridSelection.getSelectedRows().length;
				});
			}
		}
	}	

	/**
	* Delete Published Page
	*
	* Calls rest api to delete provided page IDs.
	*
	* @param pages IDs of pages to be deleted.
	*/
	private deletePublishedPage(pages: any[]): void {
		const adminService = this.adminService;
		adminService.setBusy(true);
        var self = this;
        var pageList = pages.map((page) => {
            return page.data.id;
        });
		this.pageService.deletePublished(pageList).then((r: c.IIntegerResponse) => {
			if (r.content > 0) {
                for (var page of pages) {
                    this.adminService.unselectGridItem(lm.ArrayUtil.itemByPredicate(self.publishedPages, (item) => item.data.id === page.data.id), this.scope["pagesGridApi"]);
                    lm.ArrayUtil.removeByPredicate(self.publishedPages, (item) => item.data.id === page.data.id);
				}
			}
			adminService.setBusy(false);
		}, (r: c.IOperationResponse) => {
			adminService.setBusy(false);
			adminService.handleError(r, r.errorText);
		});
	}

	static add(m: ng.IModule) {
		m.controller("lmAdminPublishedPagesCtrl", AdminPublishedPagesCtrl);
	}
}

export var init = (m: ng.IModule) => {
	AdminPublishedPagesCtrl.add(m);
}