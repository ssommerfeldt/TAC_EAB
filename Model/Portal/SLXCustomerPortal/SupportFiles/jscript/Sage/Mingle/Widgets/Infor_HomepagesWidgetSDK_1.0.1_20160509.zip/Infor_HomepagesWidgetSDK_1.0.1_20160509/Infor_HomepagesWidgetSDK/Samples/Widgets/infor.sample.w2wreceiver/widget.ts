﻿import lm = require("lime");

interface IPerson {
	id: number;
	lastName: string;
	firstName: string;
	title: string;
	status: string;
	anniversary: string;
}

class W2WReceiverCtrl implements lm.IWidgetInstance {
	public person: IPerson;

	private widgetContext: lm.IWidgetContext;
	private instanceId: string;
	private pageId: string;
	private language: lm.ILanguage;
	private messageType: string;
	private isHandlerRegistered: boolean;
	private logPrefix: string;

	static $inject = ["$scope"];

	constructor(public scope: ng.IScope) {
		// Get the widget context and instance from the scope
		const widgetContext = scope[lm.WidgetConstants.widgetContextKey];
		const widgetInstance = scope[lm.WidgetConstants.widgetInstanceKey];

		this.widgetContext = widgetContext;
		this.language = widgetContext.getLanguage();
		this.instanceId = widgetContext.getWidgetInstanceId();
		const pageId = widgetContext.getPageId();
		this.pageId = pageId;
		this.logPrefix = "[" + widgetContext.getId() + "] ";

		// Subscribe to the event that is triggered when settings are saved to be able to update the message type
		widgetInstance.settingsSaved = () => {
			this.updateMessageType();
		};

		// Set initial message type used for communication
		this.updateMessageType();
	}

	private registerHandler(messageType: string): void {
		const callback = (args: IPerson) => { this.handleMessage(args) };
		infor.companyon.client.registerMessageHandler(messageType, callback);
		this.messageType = messageType;
		this.isHandlerRegistered = true;

		lm.Log.debug(this.logPrefix + "Message handler registered for message type: " + messageType);
	}

	private unregisterHandler(messageType: string): void {
		infor.companyon.client.unRegisterMessageHandler(messageType);

		lm.Log.debug(this.logPrefix + "Message handler unregistered for message type: " + messageType);
	}

	private updateMessageType(): void {
		const messageType = this.widgetContext.getSettings().get<string>("MessageType");
		const newMessageType = messageType + this.pageId;
		const original = this.messageType;
		if (!lm.StringUtil.isNullOrWhitespace(messageType) && newMessageType !== original) {
			if (this.isHandlerRegistered) {
				this.unregisterHandler(original);
			}
			this.registerHandler(newMessageType);
		}
	}

	private handleMessage(person: IPerson): void {
		if (person) {
			this.person = person;
			this.scope.$apply("ctrl.person");
		}

		lm.Log.debug(this.logPrefix + "Received message from sender widget: " + JSON.stringify(person));
	}

	public static add(m: ng.IModule): void {
		m.controller("W2WReceiverCtrl", W2WReceiverCtrl);
	}
}

export var widgetFactory = (context: lm.IWidgetContext): lm.IWidgetInstance => {
	const m = context.getAngularContext().module;
	W2WReceiverCtrl.add(m);

	return {
		angularConfig: {
			relativeTemplateUrl: "widget.html"
		}
	};
};