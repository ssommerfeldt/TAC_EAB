var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../lime", "../core", "./service"], function (require, exports, lm, c, s) {
    var AdminOperationBase = (function (_super) {
        __extends(AdminOperationBase, _super);
        function AdminOperationBase(logPrefix, scope, timeout, adminService, dialogService) {
            var _this = this;
            _super.call(this, logPrefix);
            this.logPrefix = logPrefix;
            this.scope = scope;
            this.timeout = timeout;
            this.adminService = adminService;
            this.dialogService = dialogService;
            this.includeOptions = {};
            this.unsubscribers = [];
            this.initDefaults();
            var includeOptions = this.includeOptions;
            var adminConstants = s.AdminConstants;
            scope["includeOptions"] = includeOptions;
            this.unsubscribers.push(scope.$watch('includeOptions["includesettings"]', function (value) {
                if (value === false) {
                    includeOptions[adminConstants.parameterIncludeSettingsRules] = false;
                }
            }));
            this.unsubscribers.push(scope.$watch('includeOptions["includepublishedwidgets"]', function (value) {
                if (value === false) {
                    includeOptions[adminConstants.parameterIncludePublishedWidgetAccess] = false;
                }
            }));
            this.unsubscribers.push(scope.$watch('includeOptions["includepublishedpages"]', function (value) {
                if (value === false) {
                    includeOptions[adminConstants.parameterIncludePublishedPageConnections] = false;
                    includeOptions[adminConstants.parameterIncludePublishedPageAccess] = false;
                }
            }));
            scope.$on("$destroy", function () {
                angular.forEach(_this.unsubscribers, function (unsubscribe) {
                    unsubscribe();
                });
            });
        }
        AdminOperationBase.prototype.checkStatus = function (scope, callback) {
            var self = scope;
            self.adminService.getOperationStatus().then(function (r) {
                var content = r.content;
                if (content.messageList) {
                    self.statusMessageList = content.messageList;
                }
                if (content.isRunning) {
                    self.timeout(function () { return self.checkStatus(self, callback); }, s.AdminConstants.checkStatusInterval);
                }
                else {
                    self.setBusy(false);
                    if (callback) {
                        callback();
                    }
                }
            }, function (r) {
                var content = r.content;
                if (content.messageList) {
                    self.statusMessageList = content.messageList;
                }
                if (content.isRunning) {
                    self.timeout(function () { return self.checkStatus(self, callback); }, s.AdminConstants.checkStatusInterval);
                }
                else {
                    self.setBusy(false);
                    if (callback) {
                        callback();
                    }
                    if (r.hasError()) {
                        self.adminService.showUploadCompleteDialog("Error", r.toErrorLog(), true);
                    }
                }
            });
        };
        AdminOperationBase.prototype.cancel = function (scope) {
            var self = scope || this;
            self.adminService.cancelOperation().then(function (r) {
                var content = r.content;
                if (content.isRunning) {
                    self.checkStatus(self);
                }
                else {
                    self.setBusy(false);
                }
                if (content.messageList) {
                    self.statusMessageList = content.messageList;
                }
            }, function (r) {
                self.setBusy(false);
                self.adminService.showUploadCompleteDialog("Error", r.toErrorLog(), true);
            });
        };
        AdminOperationBase.prototype.initDefaults = function () {
            var includeOptions = this.includeOptions;
            var adminConstants = s.AdminConstants;
            includeOptions[adminConstants.parameterIncludeSettings] = true;
            includeOptions[adminConstants.parameterIncludeSettingsRules] = true;
            includeOptions[adminConstants.parameterIncludeUserSettings] = true;
            includeOptions[adminConstants.parameterIncludeProperties] = true;
            includeOptions[adminConstants.parameterIncludePublishedWidgets] = true;
            includeOptions[adminConstants.parameterIncludePublishedWidgetAccess] = true;
            includeOptions[adminConstants.parameterIncludePublishedPages] = true;
            includeOptions[adminConstants.parameterIncludePublishedPageConnections] = true;
            includeOptions[adminConstants.parameterIncludePublishedPageAccess] = true;
            includeOptions[adminConstants.parameterIncludePrivatePages] = true;
        };
        return AdminOperationBase;
    })(c.CoreBase);
    var AdminExportCtrl = (function (_super) {
        __extends(AdminExportCtrl, _super);
        function AdminExportCtrl(scope, timeout, adminService, dialogService) {
            _super.call(this, "[AdminExportCtrl] ", scope, timeout, adminService, dialogService);
            this.scope = scope;
            this.timeout = timeout;
            this.adminService = adminService;
            this.dialogService = dialogService;
        }
        AdminExportCtrl.prototype.export = function () {
            var _this = this;
            this.setBusy(true);
            this.adminService.startExportOperation(this.includeOptions).then(function (r) {
                if (r.content.isRunning) {
                    _this.checkStatus(_this);
                }
                else {
                    _this.setBusy(false);
                }
            }, function (r) {
                _this.setBusy(false);
                _this.adminService.showUploadCompleteDialog("Export Error", r.toErrorLog(), true);
            });
        };
        AdminExportCtrl.prototype.download = function () {
            this.adminService.downloadExportFile();
        };
        AdminExportCtrl.prototype.setBusy = function (isBusy) {
            this.scope["lmExportBusy"] = isBusy;
        };
        AdminExportCtrl.add = function (m) {
            m.controller("lmAdminExportCtrl", AdminExportCtrl);
        };
        AdminExportCtrl.$inject = ["$scope", "$timeout", "lmAdminService", "lmDialogService"];
        return AdminExportCtrl;
    })(AdminOperationBase);
    var AdminImportCtrl = (function (_super) {
        __extends(AdminImportCtrl, _super);
        function AdminImportCtrl(scope, timeout, adminService, dialogService) {
            _super.call(this, "[AdminImportCtrl] ", scope, timeout, adminService, dialogService);
            this.scope = scope;
            this.timeout = timeout;
            this.adminService = adminService;
            this.dialogService = dialogService;
        }
        AdminImportCtrl.prototype.upload = function () {
            var dialogTitle = "Upload Homepage Data";
            var adminService = this.adminService;
            var options = {
                title: dialogTitle,
                operation: s.AdminOperations.importData,
                buttonText: "Upload"
            };
            adminService.openImportFilesDialog(options).then(function (r) {
                var value = r.value;
                if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Success) {
                    var message = value.message ? value.message : "The file was successfully uploaded to the server.";
                    adminService.showUploadCompleteDialog(dialogTitle, message);
                }
                else if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Fail) {
                    adminService.showUploadCompleteDialog(dialogTitle, value.message, true);
                }
            });
        };
        AdminImportCtrl.prototype.import = function () {
            var _this = this;
            var self = this;
            var options = {
                title: "Import Homepage Data",
                message: "Are you sure you want to start an import operation?",
                standardButtons: lm.StandardDialogButtons.YesNo
            };
            this.dialogService.showMessage(options).then(function (result) {
                if (result.button === lm.DialogButtonType.Yes) {
                    var includeOptions = self.includeOptions;
                    self.setBusy(true);
                    self.adminService.startImportOperation(includeOptions).then(function (r) {
                        if (r.content.isRunning) {
                            var callback = function () { _this.onImported(includeOptions); };
                            self.checkStatus(self, callback);
                        }
                        else {
                            self.setBusy(false);
                        }
                    }, function (r) {
                        self.setBusy(false);
                        self.adminService.showUploadCompleteDialog("Import Error", r.toErrorLog(), true);
                    });
                }
            });
        };
        AdminImportCtrl.prototype.setBusy = function (isBusy) {
            this.scope["lmImportBusy"] = isBusy;
        };
        AdminImportCtrl.prototype.onImported = function (options) {
            this.adminService.invalidateCaches(options);
        };
        AdminImportCtrl.add = function (m) {
            m.controller("lmAdminImportCtrl", AdminImportCtrl);
        };
        AdminImportCtrl.$inject = ["$scope", "$timeout", "lmAdminService", "lmDialogService"];
        return AdminImportCtrl;
    })(AdminOperationBase);
    exports.init = function (m) {
        AdminExportCtrl.add(m);
        AdminImportCtrl.add(m);
    };
});
//# sourceMappingURL=import-export.js.map