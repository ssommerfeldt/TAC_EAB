﻿import c = require("../core");
import lm = require("../lime");

export class AdminOperations {
	public static updateRules: string = "updateRules";
	public static importData: string = "import";
	public static exportData: string = "export";
}

export class AdminConstants {
	public static openTab = "openTab";
	public static settingsTab = "settings";
	public static propertiesTab = "properties";
	public static privatePagesTab = "privatePages";
	public static publishedPagesTab = "publishedPages";
	public static publishedWidgetsTab = "publishedWidgets";
	public static standardWidgetsTab = "standardWidgets";
	public static errorsTab = "errors";

	public static gridPageSize = 15;

	// Import & Export
	public static checkStatusInterval = 2000;
	public static parameterIncludeSettings = "includesettings";
	public static parameterIncludeUserSettings = "includeusersettings";
	public static parameterIncludeSettingsRules = "includesettingsrules";
	public static parameterIncludeProperties = "includeproperties";
	public static parameterIncludePrivatePages = "includeprivatepages";
	public static parameterIncludePublishedPages = "includepublishedpages";
	public static parameterIncludePublishedPageConnections = "includepublishedpageconnections";
	public static parameterIncludePublishedPageAccess = "includepublishedpageaccess";
	public static parameterIncludePublishedWidgets = "includepublishedwidgets";
	public static parameterIncludePublishedWidgetAccess = "includepublishedwidgetaccess";
	public static parameterIncludeRoles = "includeroles";

	public static parameterUserSettingsFilter = "usersettingsfilter";
	public static parameterPublishedWidgetsFilter = "publishedwidgetsfilter";
	public static parameterPublishedPagesFilter = "publishedpagesfilter";
	public static parameterPrivatePagesFilter = "privatepagesfilter";
}

export class SettingValueInfo {
	value: string;
	label: string;
}

export class AppInfo {
	public name: string;
}

export interface IAdminTool {
	isAdministrator: boolean;
	settings: c.ISetting[];
	translations: SettingTitles[];
	isProvisioner: boolean;
	userName: string;
	userId: string;
	tenantId: string;
}

export interface SettingTitles {
	[id: string]: string;
}

export interface IAdminOperationInfo {
	id: string;
	isRunning: boolean;
	messageList: c.MessageInfo[];
}

export interface IAdminToolResponse extends c.IOperationResponse {
	content: IAdminTool;
}

export interface IAdminOperationResponse extends c.IOperationResponse {
	content: IAdminOperationInfo;
}

export interface IAdminOperationRequest extends c.IOperationRequest {
	parameters: c.IStringMap;
}

export interface IPropertyInfoListResponse extends c.IOperationResponse {
	content: IPropertyInfo[];
}

export interface IPropertyInfoResponse extends c.IOperationResponse {
	content: IPropertyInfo;
}

export interface IPropertyInfo {
	propertyId: string;
	propertyValue: string;
	description?: string;
	area?: string;
}


export interface IWidgetAccess {
	/**
	* Gets or sets the widget ID.
	*/
	id: string;

	/**
	* Gets or sets the widget access level.
	* See [[WidgetAccessLevel]]
	*/
	accessLevel: c.WidgetAccessLevel;

	/**
	* Gets or sets the group, role or user that the access level applies to.
	*/
	principal: string;

	/**
	* Gets or sets the name of the group, role or user that the access level applies to.
	*/
	principalName?: string;

	/**
	* Gets or sets a value that indicates if the principal is a user or a group / role.
	*/
	isUser?: boolean;

	/**
	* Gets or sets a value that indicates if widget is a published widget or a standard widget.
	*/
	isPublished?: boolean;

	/**
	* Gets or sets a value that indicates if the widget should be shown in the widget library or not.
	*/
	isCatalog?: boolean;

	changedBy?: string;
	changedByName?: string;
	changeDate?: string;
}

export interface IWidgetAccessInfo {
	/**
	* Gets or sets the widget ID.
	*/
	id: string;

	accessList: IWidgetAccess[];
}

export interface IAdminContext {
	initialize(): ng.IPromise<IAdminToolResponse>;
	get(): IAdminTool;
}

export interface IAdminService {
	invalidateCaches(options: c.IStringToAnyMap): void;
	onCachesInvalidated(): c.IInstanceEvent<c.IStringToAnyMap>;

	publishedPages: c.IPage[];
	allWidgets: c.IWidgetInfo[];

	searchRoles(query: string): ng.IPromise<lm.IAutocompleteEntity[]>;

	getTool(): ng.IPromise<IAdminToolResponse>;
	updateTool(adminTool: IAdminTool): ng.IPromise<c.IOperationResponse>;

	updateSettingRules(setting: c.ISetting): ng.IPromise<c.IOperationResponse>;

	listProperties(reload: boolean): ng.IPromise<IPropertyInfoListResponse>;
	createProperty(property: IPropertyInfo): ng.IPromise<IPropertyInfoResponse>;
	updateProperty(property: IPropertyInfo): ng.IPromise<IPropertyInfoResponse>;
	deleteProperty(propertyId: string): ng.IPromise<c.IOperationResponse>;
	exportProperties(properties?: IPropertyInfo[]): void;

	listPrivatePages(userId: string, reload: boolean): ng.IPromise<c.IPageListResponse>;
	listPublishedPages(reload: boolean): ng.IPromise<c.IPageListResponse>;
	getPageDisplayTitle(value: string, pages?: c.IPage[]): string;
	deletePrivatePages(pages: string[]): ng.IPromise<c.IIntegerResponse>;
	exportPublishedPages(pages?: c.IPage[]): void;
	exportPrivatePages(userId: string, pages?: c.IPage[]): void;

	listStandardWidgets(reload: boolean): ng.IPromise<c.IWidgetListResponse>;
	listPublishedWidgets(reload: boolean): ng.IPromise<c.IWidgetListResponse>;
	exportPublishedWidgets(widgets?: c.IWidgetInfo[]): void;

	getWidgetAccess(options: IWidgetAccessInfo): ng.IPromise<c.IOperationResponse>;
	updateWidgetAccess(options: IWidgetAccessInfo): ng.IPromise<c.IOperationResponse>;

	getPageAccess(pageId: string): ng.IPromise<c.IPageAccessResponse>;
	updatePageAccess(pageAccess: c.IPageAccess): ng.IPromise<c.IPageAccessResponse>;

	openImportFilesDialog(options: c.IImportOptions): ng.IPromise<lm.IDialogResult>;
	getError(): ng.IPromise<c.IOperationResponse>;

	startExportOperation(parameters: c.IStringMap): ng.IPromise<c.IOperationResponse>;
	startImportOperation(parameters: c.IStringMap): ng.IPromise<c.IOperationResponse>;
	cancelOperation(): ng.IPromise<IAdminOperationResponse>;
	getOperationStatus(): ng.IPromise<IAdminOperationResponse>;

	downloadExportFile(): void;

	/*
	* Forwards error to Data Service.
	*/
	handleError(response: c.IOperationResponse, message?: string): void;

	/*
	* Set UI busy status.
	*/
	setBusy(isBusy: boolean): void;

	isBusy(): boolean;

	/**
	* Returns a callback for showing a dialog.
	*/
	showUploadCompleteDialog(title: string, message: string, isError?: boolean): ng.IPromise<lm.IDialogResult>;

	updatePageOwner(pageData: c.IPageData): ng.IPromise<c.IPageDataResponse>;

	openChangeOwnerDialog(title: string, currentOwnerId: string, callback: Function): void;

	/**
	* Clears or replaces acces for widgets.
	*/
	clearOrReplaceWidgetAccess(widgets: c.IWidgetInfo[], isReplace: boolean, callback: Function, accessCopy?: IWidgetAccess[]): void;

	/**
	* Opens Widget Acces Dialog
	*/
	openWidgetAccessDialog(widget: c.IWidgetInfo, callback: Function): void;

	/**
	* Applies Widget Access
	*/
	applyWidgetAccess(widgets: c.IWidgetInfo[], accessCopy: IWidgetAccess[], callback: Function): void;

	/**
	* Clears or replaces acces for pages.
	*/
	clearOrReplacePageAccess(pages: c.IPage[], isReplace: boolean, callback: Function, accessCopy?: c.IPageAccess): void;

	/**
	* Opens Pages Acces Dialog
	*/
	openPageAccessDialog(page: c.IPage, callback: Function): void;

	/**
	* Applies Page Access
	*/
	applyPageAccess(pages: c.IPage[], accessCopy: c.IPageAccess, callback: Function): void;
    
	/**
	 * Unselects grid item and returns nr of selected items.
	 */
	unselectGridItem(item, gridApi): number;

	/**
	 * Returns options object for the delete page dialog.
	 */
	getDeletePageOptions(pages: c.IPage[], isPrivate: boolean): lm.IMessageDialogOptions;
}

class AdminService extends c.CoreBase implements IAdminService {
	public publishedPages: c.IPage[] = null;
	public allWidgets: c.IWidgetInfo[] = null;
	private roles: c.IGroupInfo[] = null;

	private invalidatedCachesEvent = new c.InstanceEvent<c.IStringToAnyMap>();
	private standardWidgetsCache: c.IDataListCache;
	private publishedWidgetsCache: c.IDataListCache;
	private publishedPagesCache: c.IDataListCache;
	private propertiesCache: c.IDataListCache;
	private privatePagesCache: c.IDataListCache;
	private rolesCache: c.IDataListCache;

	static $inject = ["$rootScope", "$q", "lmDataService", "lmProgressService", "lmDialogService", "lmCacheService"];

	constructor(private rootScope: ng.IRootScopeService, private q: ng.IQService, private dataService: c.IDataService, private progressService: c.IProgressService,
		private dialogService: lm.IDialogService, private cacheService: c.ICacheService) {
		super("[AdminService] ");

		var createCache = cacheService.createCache;
		var constants = c.Constants;
		this.standardWidgetsCache = createCache(constants.adminCacheStandardWidgets);
		this.publishedWidgetsCache = createCache(constants.adminCachePublishedWidgets);
		this.publishedPagesCache = createCache(constants.adminCachePublishedPages);
		this.propertiesCache = createCache(constants.adminCacheProperties);
		this.privatePagesCache = createCache(constants.adminCachePrivatePages);
		this.rolesCache = createCache(constants.adminCacheRoles);
	}

	public getTool(): ng.IPromise<IAdminToolResponse> {
		return this.dataService.executePost("/admin/tool");
	}

	public updateTool(adminTool: IAdminTool): ng.IPromise<c.IOperationResponse> {
		var request = { content: adminTool };
		return this.dataService.executePost("/admin/tool/update", request);
	}

	public updateSettingRules(setting: c.ISetting): ng.IPromise<c.IOperationResponse> {
		var request = { content: setting };
		return this.dataService.executePost("/admin/setting/rule/update", request);
	}

	public listProperties(reload: boolean): ng.IPromise<IPropertyInfoListResponse> {
		var deferred: ng.IDeferred<c.IWidgetListResponse> = this.q.defer();
		if (!this.propertiesCache.isValid || reload) {
			this.dataService.executePost("/admin/property/list", {}).then((response: c.IOperationResponse) => {
				this.cacheService.updateCache(this.propertiesCache, response, deferred);
			}, (response: c.IOperationResponse) => {
				this.propertiesCache.isValid = false;
				deferred.reject(response);
			});
		} else {
			deferred.resolve(this.propertiesCache.cachedResponse);
		}
		return deferred.promise;
	}

	public searchRoles(query: string): ng.IPromise<lm.IAutocompleteEntity[]> {
		var deferred: ng.IDeferred<lm.IAutocompleteEntity[]> = this.q.defer();
		this.getRoles(false).then((response: c.IGroupInfoListResponse) => {
			if (response.content) {
				var queryLower = query.toLowerCase();
				// Search for the query among all roles
				var matches: c.IGroupInfo[] = lm.ArrayUtil.findAll(response.content, (item: c.IGroupInfo) => {
					try {
						if (item) {
							if (item.id && item.id.toLowerCase().indexOf(queryLower) !== -1) {
								return true;
							}
							// Autocomplete does not support finding hits in what will be the info field
							return false;
						}
						return false;
					} catch (error) {
						lm.Log.error(this.logPrefix + "Failed to filter " + error);
					}
				});

				// Should we return all hits or filter out the first x set
				// For now returning the first 10 hits
				// Transform the groups to IAutocompleteEntity
				var result: lm.IAutocompleteEntity[] = [];
				if (matches) {
					for (var i = 0; i < 10; i++) {
						var item: c.IGroupInfo = matches[i];
						if (item) {
							var entity: lm.IAutocompleteEntity = {
								label: item.id || item.name,
								value: item.id,
								type: c.PrincipalType.Role
							};
							if (item.name) {
								entity.info = item.name;
							}
							result.push(entity);
						}
					}
				}
				deferred.resolve(result);

			} else {
				deferred.reject();
			}
		}, () => { deferred.reject(); });
		return deferred.promise;
	}

	private lastUsedListDeferred: ng.IDeferred<c.IGroupInfoListResponse>;
	private isRoleRequestPending = false;

	private getRoles(reload: boolean): ng.IPromise<c.IGroupInfoListResponse> {
		var deferred: ng.IDeferred<c.IGroupInfoListResponse> = this.q.defer();
		var self = this;
		if (!self.rolesCache.isValid || reload) {
			if (this.isRoleRequestPending) {
				return this.lastUsedListDeferred.promise;
			}
			this.isRoleRequestPending = true;
			this.lastUsedListDeferred = deferred;
			self.dataService.executePost("/admin/role/list", {}).then((response: c.IOperationResponse) => {
				this.isRoleRequestPending = false;
				lm.ArrayUtil.sortByProperty(response.content, "id");
				self.cacheService.updateCache(self.rolesCache, response, deferred);
			}, (response: c.IOperationResponse) => {
				this.isRoleRequestPending = false;
				self.rolesCache.isValid = false;
				deferred.reject(response);
			});
		} else {
			deferred.resolve(self.rolesCache.cachedResponse);
		}
		return deferred.promise;
	}

	public createProperty(property: IPropertyInfo): ng.IPromise<IPropertyInfoResponse> {
		var request = { content: property };
		return this.dataService.executePost("/admin/property/create", request);
	}

	public updateProperty(property: IPropertyInfo): ng.IPromise<IPropertyInfoResponse> {
		var request = { content: property };
		return this.dataService.executePost("/admin/property/update", request);
	}

	public deleteProperty(propertyId: string): ng.IPromise<c.IOperationResponse> {
		var request = { content: propertyId };
		return this.dataService.executePost("/admin/property/delete", request);
	}

	public exportProperties(properties?: IPropertyInfo[]): void {
		var query = "";
		if (properties) {
			for (var i = 0; i < properties.length; i++) {
				query += i == 0 ? "?keys=" + properties[i].propertyId : "&keys=" + properties[i].propertyId;
			}
		}

		var url = this.dataService.getUrl("admin/property/export/" + encodeURI("properties") + ".json") + query;
		if (this.isDebug()) {
			this.debug("Executing url " + url);
		}
		window.open(url, '_blank');
	}

	public listPrivatePages(userId: string, reload: boolean): ng.IPromise<c.IPageListResponse> {
		var request = { content: userId };
		var deferred: ng.IDeferred<c.IWidgetListResponse> = this.q.defer();
		if (!this.privatePagesCache.isValid || reload) {
			this.dataService.executePost("/admin/page/private/list", request).then((response: c.IOperationResponse) => {
				this.cacheService.updateCache(this.privatePagesCache, response, deferred);
			}, (response: c.IOperationResponse) => {
				this.privatePagesCache.isValid = false;
				deferred.reject(response);
			});
		} else {
			deferred.resolve(this.privatePagesCache.cachedResponse);
		}
		return deferred.promise;
	}

	public listPublishedPages(reload: boolean): ng.IPromise<c.IPageListResponse> {
		var deferred: ng.IDeferred<c.IWidgetListResponse> = this.q.defer();
		if (!this.publishedPagesCache.isValid || reload) {
			this.dataService.executePost("/admin/page/published/list", {}).then((response: c.IOperationResponse) => {
				response.content = this.sortPublishedPages(response.content);
				this.cacheService.updateCache(this.publishedPagesCache, response, deferred);
			}, (response: c.IOperationResponse) => {
				this.publishedPagesCache.isValid = false;
				deferred.reject(response);
			});
		} else {
			deferred.resolve(this.publishedPagesCache.cachedResponse);
		}
		return deferred.promise;
	}

	private sortPublishedPages(pages: c.IPage[]): c.IPage[] {
		return pages.sort((x, y) => {
			const xTitle = x["title"] ? x["title"] : x["data"]["title"];
			const yTitle = y["title"] ? y["title"] : y["data"]["title"];
			const a = xTitle.toLocaleLowerCase();
			const b = yTitle.toLocaleLowerCase();
			if (a > b) {
				return 1;
			} else if (a < b) {
				return -1;
			}
			return 0;
		});
	}

	public deletePrivatePages(pages: string[]): ng.IPromise<c.IIntegerResponse> {
		return this.dataService.executePost("/admin/page/private/delete", { content: pages });
	}

	public exportPublishedPages(pages?: c.IPage[]): void {
		var query = "";
		if (pages) {
			for (var i = 0; i < pages.length; i++) {
				query += i == 0 ? "?keys=" + pages[i].data.id : "&keys=" + pages[i].data.id;
			}
		}
		var url = this.dataService.getUrl("admin/page/published/export/" + encodeURI("pages") + ".zip") + query;
		if (this.isDebug()) {
			this.debug("Executing url " + url);
		}
		window.open(url, "_blank");
	}

	public exportPrivatePages(userId: string, pages?: c.IPage[]): void {
		var query = "";
		if (pages) {
			for (var i = 0; i < pages.length; i++) {
				query += i == 0 ? "?keys=" + pages[i].data.id : "&keys=" + pages[i].data.id;
			}
		}
		var url = this.dataService.getUrl("admin/page/private/export/" + userId + "/" + encodeURI("pages") + ".zip") + query;
		if (this.isDebug()) {
			this.debug("Executing url " + url);
		}
		window.open(url, "_blank");
	}

	public listStandardWidgets(reload: boolean): ng.IPromise<c.IWidgetListResponse> {
		var deferred: ng.IDeferred<c.IWidgetListResponse> = this.q.defer();
		if (!this.standardWidgetsCache.isValid || reload) {
			this.dataService.executePost("/admin/widget/standard/list", {}).then((response: c.IOperationResponse) => {
				this.cacheService.updateCache(this.standardWidgetsCache, response, deferred);
			}, (response: c.IOperationResponse) => {
				this.standardWidgetsCache.isValid = false;
				deferred.reject(response);
			});
		} else {
			deferred.resolve(this.standardWidgetsCache.cachedResponse);
		}
		return deferred.promise;
	}

	public listPublishedWidgets(reload: boolean): ng.IPromise<c.IWidgetListResponse> {
		var deferred: ng.IDeferred<c.IWidgetListResponse> = this.q.defer();
		var publishedWidgetsCache = this.publishedWidgetsCache;
		if (!publishedWidgetsCache.isValid || reload) {
			this.dataService.executePost("/admin/widget/published/list", {}).then((response: c.IOperationResponse) => {
				this.cacheService.updateCache(publishedWidgetsCache, response, deferred);
			}, (response: c.IOperationResponse) => {
				publishedWidgetsCache.isValid = false;
				deferred.reject(response);
			});
		} else {
			deferred.resolve(publishedWidgetsCache.cachedResponse);
		}
		return deferred.promise;
	}

	public exportPublishedWidgets(widgets?: c.IWidgetInfo[]): void {
		var query = "";
		if (widgets) {
			for (var i = 0; i < widgets.length; i++) {
				query += i == 0 ? "?keys=" + widgets[i].widgetId : "&keys=" + widgets[i].widgetId;
			}
		}

		var url = this.dataService.getUrl("admin/widget/published/export/" + encodeURI("widgets") + ".zip") + query;
		window.open(url, "_blank");
	}

	public getWidgetAccess(options: IWidgetAccessInfo): ng.IPromise<c.IOperationResponse> {
		var request = { content: options }
		return this.dataService.executePost("/admin/widget/access", request);
	}

	public updateWidgetAccess(options: IWidgetAccessInfo): ng.IPromise<c.IOperationResponse> {
		var request = { content: options }
		return this.dataService.executePost("/admin/widget/access/update", request);
	}

	public getPageAccess(pageId: string): ng.IPromise<c.IPageAccessResponse> {
		var request = { content: pageId };
		return this.dataService.executePost("/admin/page/access", request);
	}

	public updatePageAccess(pageAccess: c.IPageAccess): ng.IPromise<c.IPageAccessResponse> {
		var request = { content: pageAccess };
		return this.dataService.executePost("/admin/page/access/update", request);
	}

	public openImportFilesDialog(options: c.IImportOptions): ng.IPromise<lm.IDialogResult> {
		var dialogOptions = <lm.IDialogOptions>{
			title: options.title,
			templateUrl: "scripts/lime/admin/templates/import-dialog.html",
			style: "width:450px;",
			parameter: options
		};
		return this.dialogService.show(dialogOptions);
	}

	public startExportOperation(parameters: c.IStringMap): ng.IPromise<c.IOperationResponse> {
		return this.dataService.executePost("/admin/operation/export", { parameters: parameters });
	}

	public startImportOperation(parameters: c.IStringMap): ng.IPromise<c.IOperationResponse> {
		return this.dataService.executePost("/admin/operation/import", { parameters: parameters });
	}

	public cancelOperation(): ng.IPromise<IAdminOperationResponse> {
		return this.dataService.executePost("/admin/operation/cancel", {});
	}

	public getOperationStatus(): ng.IPromise<IAdminOperationResponse> {
		return this.dataService.executePost("/admin/operation/status", {});
	}

	public downloadExportFile(): void {
		var url = this.dataService.getUrl("admin/operation/export/download/" + encodeURI("LimeExport") + ".zip");
		if (this.isDebug()) {
			this.debug("Executing url " + url);
		}
		window.open(url, "_blank");
	}

	public onCachesInvalidated(): c.IInstanceEvent<c.IStringToAnyMap> {
		return this.invalidatedCachesEvent;
	}

	public invalidateCaches(options: c.IStringToAnyMap): void {
		// Set isValid false so that the next time the tab is selected the content is reloaded
		if (options[AdminConstants.parameterIncludeProperties] === true) {
			this.propertiesCache.isValid = false;
		}

		if (options[AdminConstants.parameterIncludePrivatePages] === true) {
			this.privatePagesCache.isValid = false;
		}

		if (options[AdminConstants.parameterIncludePublishedPages] === true) {
			this.publishedPagesCache.isValid = false;
		}

		if (options[AdminConstants.parameterIncludePublishedWidgets] === true) {
			this.publishedWidgetsCache.isValid = false;
		}

		if (options[AdminConstants.parameterIncludeRoles] === true) {
			this.rolesCache.isValid = false;
		}

		this.invalidatedCachesEvent.raise(options);
	}

	/**
	* Set UI busy status.
	*/
	public setBusy(isBusy: boolean): void {
		this.rootScope["lmBusy"] = isBusy;
	}

	public isBusy(): boolean {
		return this.rootScope["lmBusy"] ? true : false;
	}

	public getError(): ng.IPromise<c.IOperationResponse> {
		return this.dataService.executePost("/management/error/status/node", {});
	}

	/**
	* Forwards error to Data Service.
	*/
	public handleError(response: c.IOperationResponse, message?: string): void {
		this.dataService.handleError(response, message);
	}

	/**
	* Get Page Display Title
	*
	* Checks if a page title tranlations exists and returns the display value for pages.
	* @returns string Page display value
	*/
	public getPageDisplayTitle(value: any, pages?: c.IPage[]): string {
		var adminTool: IAdminTool = this.rootScope["lmAdminTool"];
		var translations = adminTool.translations;
		var displayValue: any = "";
		var values: string[] = null;

		if (value) {
			// If more than one value they are comma separated
			if (value.indexOf(",") !== -1) {
				values = value.split(",");
			}

			// Check for title translation. If a translation exists, use it
			// otherwise set the guid as value
			var publishedPages = this.publishedPages;
			if (values) {
				if (publishedPages) {
					// Get title from pages array
					angular.forEach(publishedPages, (page) => {
						if (page.data.id === values[0]) {
							displayValue = page.title || page.data.title;
						}
					});
				} else {
					// Get title from translations dictionary
					// Use the first value in the array
					if (values[0] in translations) {
						displayValue = translations[values[0]];
					} else {
						displayValue = values[0];
					}
				}

				// Show how many other pages are used by setting
				if (values.length > 1) {
					displayValue += " (+" + (values.length - 1) + " more)";
				}
			} else {
				// Use the one and only string value
				if (publishedPages) {
					// Get title from pages array
					angular.forEach(publishedPages, (page) => {
						if (page.data.id === value) {
							displayValue = page.title || page.data.title;
						}
					});
				} else {
					// Get title from translations dictionary
					if (translations && translations[value]) {
						displayValue = translations[value];
					} else {
						displayValue = value;
					}
				}
			}
		} else {
			displayValue = "";
		}
		return displayValue;
	}

	/**
	* Show Upload Complete Dialog
	*
	* Shows dialog that informs the user that a file upload was completed.
	* @param title Title of the dialog.
	* @param message Message to display.
	* @param isError Indicate whether its an error or not.
	*/
	public showUploadCompleteDialog(title: string, message: string, isError?: boolean): ng.IPromise<lm.IDialogResult> {
		return this.dialogService.showMessage({
			title: title,
			message: message,
			isError: isError
		});
	}

	public updatePageOwner(pageData: c.IPageData): ng.IPromise<c.IPageDataResponse> {
		return this.dataService.executePost("/page/owner/update", { content: pageData });
	}

	public openChangeOwnerDialog(title: string, currentOwnerId: string, callback: Function): void {
		const options = <lm.IDialogOptions>{
			title: "Change Owner - " + title,
			templateUrl: "scripts/lime/admin/templates/change-owner.html",
			style: "width: 100%; max-width: 500px;",
			parameter: currentOwnerId
		};

		this.dialogService.show(options).then((dialogResult: lm.IDialogResult) => {
			var value = dialogResult.value;
			if (dialogResult.button === lm.DialogButtonType.Ok && value) {
				callback(value);
			}
		});
	}

	/**
	* Clear Or Replace Widget Access
	*
	* Clears or replaces access of specifiec widget(s).
	*
	* @param widgets of which to edit access.
	* @param isReplace Replace, otherwise clear.
	* @param callback Function to call when access has been updated.
	*/
	public clearOrReplaceWidgetAccess(widgets: c.IWidgetInfo[], isReplace: boolean, callback: Function, accessCopy?: IWidgetAccess[]): void {
		this.progressService.setBusy(true);
		var nrOfWidgetsToUpdate = widgets.length;

		angular.forEach(widgets, (updateWidget) => {
			this.updateWidgetAccess({ id: updateWidget.widgetId, accessList: isReplace ? accessCopy : [] }).then(() => {
				nrOfWidgetsToUpdate -= 1;
				if (nrOfWidgetsToUpdate === 0) {
					callback();
				}
			}, (r: c.IOperationResponse) => {
				this.handleError(r);
				this.progressService.setBusy(false);
			});
		});
	}

	public openWidgetAccessDialog(widget: c.IWidgetInfo, callback: Function): void {
		var progressService = this.progressService;
		var options = <lm.IDialogOptions>{
			title: "Widget Permissions - " + widget.title,
			templateUrl: "scripts/lime/admin/templates/widget-access.html",
			style: "width: 100%; max-width: 600px;"
		};

		progressService.setBusy(true);
		this.getWidgetAccess({ id: widget.widgetId, accessList: [] }).then((r: c.IOperationResponse) => {
			options.parameter = { accessList: r.content.accessList, id: widget.widgetId };
			progressService.setBusy(false);
			this.dialogService.show(options).then((dialogResult: lm.IDialogResult) => {
				var value = dialogResult.value;
				if (dialogResult.button === lm.DialogButtonType.Ok && value) {
					progressService.setBusy(true);
					this.updateWidgetAccess({ id: widget.widgetId, accessList: value }).then((info: c.IWidgetInfo) => {
						callback(info);
					}, (result: c.IOperationResponse) => {
						this.handleError(result);
						progressService.setBusy(false);
					});
				}
			});
		}, (r: c.IOperationResponse) => {
			this.handleError(r);
			progressService.setBusy(false);
		});
	}

	public applyWidgetAccess(widgets: c.IWidgetInfo[], accessCopy: IWidgetAccess[], callback: Function): void {
		var progressService = this.progressService;
		var existingAccess: IWidgetAccess[];
		var nrOfWidgetsToUpdate = widgets.length;

		progressService.setBusy(true);
		angular.forEach(widgets, (updateWidget) => {
			this.getWidgetAccess({ id: updateWidget.widgetId, accessList: [] }).then((r: c.IOperationResponse) => {
				existingAccess = r.content.accessList;
				angular.forEach(accessCopy, (accessEntity) => {
					var accessUpdateIndex = lm.ArrayUtil.indexByProperty(existingAccess, "principal", accessEntity.principal);
					if (accessUpdateIndex !== -1) {
						existingAccess[accessUpdateIndex] = accessEntity;
					} else {
						existingAccess.push(accessEntity);
					}
				});
				this.updateWidgetAccess({ id: updateWidget.widgetId, accessList: existingAccess }).then(() => {
					nrOfWidgetsToUpdate -= 1;
					if (nrOfWidgetsToUpdate === 0) {
						callback();
					}
				}, (result: c.IOperationResponse) => {
					this.handleError(result);
					progressService.setBusy(false);
				});
			}, (r: c.IOperationResponse) => {
				this.handleError(r);
				progressService.setBusy(false);
			});
		});
	}

	/**
	* Edit Page Permissions
	*
	* Edit page permissions for a published page.
	*
	* @param page Page to edit.
	*/
	public openPageAccessDialog(page: c.IPage, callback: Function): void {
		var self = this;
		var progressService = self.progressService;

		progressService.setBusy(true);
		this.getPageAccess(page.data.id).then((r: c.IPageAccessResponse) => {
			if (r.content) {
				var options: lm.IDialogOptions = {
					title: "Page Permissions",
					templateUrl: "scripts/lime/admin/templates/page-access.html",
					parameter: r.content,
					style: "width: 100%; max-width: 600px;"
				};
				progressService.setBusy(false);
				self.dialogService.show(options).then((res: lm.IDialogResult) => {
					var value = res.value;
					if (res.button === lm.DialogButtonType.Ok && value) {
						progressService.setBusy(true);
						self.updatePageAccess(value).then((result: c.IPageAccessResponse) => {
							callback();
						}, (result: c.IOperationResponse) => {
							progressService.setBusy(false);
							self.handleError(result);
						});
					}
				});
			}
		}, (r: c.IOperationResponse) => {
			progressService.setBusy(false);
			self.handleError(r);
		});
	}

	/**
	* Clear Or Replace Page Access
	*
	* Clears or replaces access of specifiec page(s).
	*
	* @param pages of which to edit access.
	* @param isReplace Replace, otherwise clear.
	* @param callback Function to call when access has been updated.
	*/
	public clearOrReplacePageAccess(pages: c.IPage[], isReplace: boolean, callback: Function, accessCopy?: c.IPageAccess): void {
		var nrOfPagesToUpdate = pages.length;

		this.progressService.setBusy(true);
		angular.forEach(pages, (updatePage) => {
			this.updatePageAccess(isReplace ? { pageId: updatePage.data.id, roleAccess: accessCopy.roleAccess, userAccess: accessCopy.userAccess }
				: { pageId: updatePage.data.id, roleAccess: [], userAccess: {} }).then(() => {
					nrOfPagesToUpdate -= 1;
					if (nrOfPagesToUpdate === 0) {
						callback();
					}
				}, (r: c.IOperationResponse) => {
					this.handleError(r);
					this.progressService.setBusy(false);
				});
		});
	}

	public applyPageAccess(pages: c.IPage[], accessCopy: c.IPageAccess, callback: Function): void {
		var progressService = this.progressService;
		var existingAccess: c.IPageAccess;
		var existingRoleAccess: c.IEntityAccess[];
		var existingUserAccess: c.IStringToIEntityAccessMap;
		var nrOfPagesToUpdate = pages.length;

		progressService.setBusy(true);
		angular.forEach(pages, (updatePage) => {
			this.getPageAccess(updatePage.data.id).then((r: c.IPageAccessResponse) => {
				existingAccess = r.content;
				existingRoleAccess = existingAccess.roleAccess ? existingAccess.roleAccess : [];
				existingUserAccess = $.isEmptyObject(existingAccess.userAccess) ? {} : existingAccess.userAccess;
				
				// Apply role access (array)
				angular.forEach(accessCopy.roleAccess, (roleAccessEntity) => {
					var accessUpdateIndex = lm.ArrayUtil.indexByProperty(existingRoleAccess, "principal", roleAccessEntity.principal);
					if (accessUpdateIndex !== -1) {
						existingRoleAccess[accessUpdateIndex] = roleAccessEntity;
					} else {
						existingRoleAccess.push(roleAccessEntity);
					}
				});

				// Apply user access (map)
				for (var i in accessCopy.userAccess) {
					if (accessCopy.userAccess.hasOwnProperty(i)) {
						existingUserAccess[i] = accessCopy.userAccess[i];
					}
				}

				existingAccess.roleAccess = existingRoleAccess;
				existingAccess.userAccess = existingUserAccess;
				this.updatePageAccess(existingAccess).then((result: c.IPageAccessResponse) => {
					nrOfPagesToUpdate -= 1;
					if (nrOfPagesToUpdate === 0) {
						callback();
					}
				}, (result: c.IOperationResponse) => {
					this.handleError(result);
					progressService.setBusy(false);
				});
			}, (r: c.IOperationResponse) => {
				this.handleError(r);
				progressService.setBusy(false);
			});
		});
	}

	/**
	 * Unselects grid item and return nr of selected items.
	 * @param item 
	 * @param gridApi 
	 * @returns number of select items
	 */
	public unselectGridItem(item, gridApi): number {
		if (lm.ArrayUtil.containsByProperty(gridApi.selection.getSelectedRows(), '$$hashKey', item.$$hashKey)) {
			gridApi.selection.toggleRowSelection(item);
			gridApi.selection.getSelectedRows();
			return gridApi.selection.getSelectedRows().length;
		}
	}


	/**
	* Get Delete Page Options
	*
	* Creates and returns options for delete page dialog.
	*/
	public getDeletePageOptions(pages: c.IPage[], isPrivate: boolean): lm.IMessageDialogOptions {
		var pagesList = pages.map((page) => {
			return page.data.id;
		});
		var isMultiple = (pagesList.length > 1);
		var title = isMultiple ? "Delete Pages" : "Delete Page";
		var message = isMultiple ? "Are you sure that you want to delete the selected pages?" :
			"Are you sure that you want to delete the page?";
		if (!isPrivate) {
			message = message + (isMultiple ? " They will be deleted for all users." : " It will be deleted for all users.");
		}
		var options: lm.IMessageDialogOptions = {
			title: title,
			message: message,
			standardButtons: lm.StandardDialogButtons.YesNo
		};

		return options;
	}

	static add(m: ng.IModule) {
		m.service("lmAdminService", AdminService);
	}
}

class AdminContext implements IAdminContext {
	private adminTool: IAdminTool;

	static $inject = ["$q", "$location", "lmAdminService"];

	constructor(private q: ng.IQService, private location: ng.ILocationService, private adminService: IAdminService) {
		c.ClientConfiguration.initialize(location);
	}

	private isLocalhost(): boolean {
		return this.location.host() === "localhost";
	}

	public initialize(): ng.IPromise<IAdminToolResponse> {
		var deferred = this.q.defer();
		this.adminService.getTool().then((r) => {
			this.adminTool = r.content;
			deferred.resolve(r);
		}, (r: c.IOperationResponse) => {
			deferred.reject(r);
		});
		return deferred.promise;
	}

	public get(): IAdminTool {
		return this.adminTool;
	}

	static add(m: ng.IModule) {
		m.service("lmAdminContext", AdminContext);
	}
}

class AdminImportDialogCtrl extends c.CoreBase {
	public buttonText: string;
	public acceptFileExtension: string;

	private dialog: lm.IDialog = null;
	private options: c.IImportOptions;

	static $inject = ["$scope", "lmDataService"];

	constructor(public scope: any, private dataService: c.IDataService) {
		super("[AdminImportDialogCtrl] ");

		const dialog: lm.IDialog = scope["lmDialog"];
		if (!dialog) {
			this.error("lmDialog was not found in scope when opening import dialog.");
			return;
		}

		this.dialog = dialog;
		const dialogParam = dialog.parameter;
		this.options = dialogParam;
		this.acceptFileExtension = dialogParam.acceptFileExtension || ".zip";
		this.buttonText = dialogParam.buttonText || "Import";
	}

	static add(m: ng.IModule) {
		m.controller("lmAdminImportDialogCtrl", AdminImportDialogCtrl);
	}

	public close(): void {
		this.dialog.close({ button: lm.DialogButtonType.Cancel });
	}

	public import(files: any): void {
		if (!files) {
			this.debug("No file was selected.");
			return;
		}
		const dialog = this.dialog;
		const options = this.options;

		this.dataService.upload("/admin", options.operation, files, options.formFields).then((response: c.IOperationResponse) => {
			let message = "";
			const messageList = response.messageList;
			if (messageList) {
				angular.forEach(messageList, (msg) => {
					message += msg.message;
				});
			}
			dialog.close({ button: lm.DialogButtonType.Yes, value: { message: message, responseCode: c.DialogResponseCode.Success } });
		}, (response: c.IOperationResponse) => {
			let errorMsg = "";
			if (response.errorList) {
				angular.forEach(response.errorList, (error) => {
					errorMsg += error.message;
				});
			}
			dialog.close({ button: lm.DialogButtonType.Yes, value: { message: errorMsg, responseCode: c.DialogResponseCode.Fail } });
		});
	}
}

class GuidSearchDialogCtrl extends c.CoreBase {
	private dialog: lm.IDialog = null;

	static $inject = ["$scope"];

	constructor(public scope: ng.IScope) {
		super("[GuidSearchDialogCtrl] ");

		const dialog: lm.IDialog = scope["lmDialog"];
		if (!dialog) {
			this.error("lmDialog is not found in scope when opening guid search dialog.");
			return;
		}

		this.dialog = dialog;
	}

	public close(): void {
		this.dialog.close({ button: lm.DialogButtonType.Cancel });
	}

	public search(files: any): void {
		this.dialog.close({
			button: lm.DialogButtonType.Ok,
			value: this.scope["searchString"]
		});
	}

	static add(m: ng.IModule) {
		m.controller("lmGuidSearchDialogCtrl", GuidSearchDialogCtrl);
	}
}

class ChangeOwnerCtrl extends c.CoreBase {
	public autocompleteOptions: xi.IAutoCompleteOptions;
	public selectedOwner: lm.IAutocompleteEntity;

	private currentOwner: string;
	private dialog: lm.IDialog = null;
	private autocompleteElem: JQuery;

	static $inject = ["$scope", "lmCommonDataService"];

	constructor(public scope: ng.IScope, private commonDataService: c.ICommonDataService) {
		super("[ChangeOwnerCtrl] ");

		const dialog: lm.IDialog = scope["lmDialog"];
		if (!dialog) {
			this.error("lmDialog is not found in scope when opening change owner dialog.");
			return;
		}
		this.currentOwner = dialog.parameter;
		this.dialog = dialog;

		// Set source of autocomplete
		const self = this;
		this.autocompleteOptions = {
			source: (query, done) => {
				self.commonDataService.searchUsers(query).then((response: c.IUserListResponse) => {
					// Remove current owner from result
					lm.ArrayUtil.removeByProperty(response.content, "userName", self.currentOwner);
					done(query, lm.ArrayUtil.sortByProperty(c.CoreUtil.getEntityArray(response.content), "label"));
				});
			},
			template: c.Templates.autocompleteEntity
		}

		this.autocompleteElem = $("#autocomplete-change-owner");

		this.autocompleteElem.on("selected", (event, target, object: lm.IAutocompleteEntity) => {
			if (lm.CommonUtil.isUndefined(object) && self.currentOwner !== object.value) {
				return;
			}
			self.selectedOwner = object;
			self.scope.$apply("selectedOwner");
		});

		scope.$on("$destroy", () => {
			this.autocompleteElem.off();
		});
	}

	public onCancel(): void {
		this.dialog.close({ button: lm.DialogButtonType.Cancel });
	}

	public onOk(): void {
		this.dialog.close({
			button: lm.DialogButtonType.Ok,
			value: this.selectedOwner
		});
	}

	static add(m: ng.IModule) {
		m.controller("lmChangeOwnerCtrl", ChangeOwnerCtrl);
	}
}

export var init = (m: ng.IModule) => {
	AdminService.add(m);
	AdminContext.add(m);
	AdminImportDialogCtrl.add(m);
	GuidSearchDialogCtrl.add(m);
	ChangeOwnerCtrl.add(m);
}