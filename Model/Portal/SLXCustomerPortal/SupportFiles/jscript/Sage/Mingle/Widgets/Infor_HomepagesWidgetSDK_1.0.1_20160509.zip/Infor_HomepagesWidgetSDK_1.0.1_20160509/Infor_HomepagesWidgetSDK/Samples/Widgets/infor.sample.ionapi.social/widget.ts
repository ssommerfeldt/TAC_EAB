﻿/// <reference path="../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../scripts/typings/lime/lime.d.ts" />

import lm = require("lime");

// Prerequisites
// =============
// The following steps are required before testing this sample widget.
// - Aquire the server and port number for the ION API server to test with.
// - Configure and start a localhost proxy with the ION API server and port number.
// - Example: node proxy.js 8083 "mingledev01-ionapi.mingledev.infor.com" 443
// - Example: \Samples\StartIonApiProxy.cmd
//
// - Set the ionApiUrl property in the configuration.json file to the URL of the localhost proxy.
// - The configuration.json file is located in the root of the Widgets sample project by default.
// - The URL should include the tenant to test with.
// - Example: "ionApiUrl": "http://localhost:8083/ACME_TST"
//
// - Acquire an OAuth token string.
// - Log on to Ming.le.
// - Example: https://mingledev01-portal.mingledev.infor.com/ACME_TST/
// - Open a new tab in the same browser and navigate to the Grid SAML Session Provider OAuth resource
// - The Grid must be version 2.0 or later with a SAML Session Provider configured for the same IFS as Ming.le.
// - Example: https://mingledev01-grid-hp.mingledev.infor.com/grid/rest/security/sessions/oauth
// - Copy the the OAuth token string from the browser window.
//
// - If there are issues you can verify if your user has access to the grid by navigating to the Grid user page.
// - Note that you must be logged on to Ming.le before doing this.
// - Example: https://mingledev01-grid-hp.mingledev.infor.com:9544/grid/user
//
// - Set the ionApiToken property in the configuration.json file to the OAuth token string.
// - Example: "ionApiToken": "V9k5niTDR1kq6RuYlEq3N3HxGq8u"
//
// - Set the dev-configuration attribute on the lm-page-container to the name of the configuration.json file
// - Example: <lm-page-container dev-widget="infor.sample.ionapi.m3" dev-configuration="configuration.json"></lm-page-container>
//
//
// Developing and debugging
// ========================
// A widget using the ION API can be developed and debugged like any other widget.
// Just remember to start the proxy and configure the configuration.json file.
// The OAuth token will time out and when that happens you must acquire a new token and update the configuration.json file.

interface ISocialUser {
	FirstName: string;
	LastName: string;
	Email: string;
	Title: string;
	UserGUID: string;
}

interface IUserDetailResponse {
	UserDetailList: ISocialUser[];
	Status: number;
	ErrorList: any[];
}

class IonApiSocialCtrl {
	private widgetContext: lm.IWidgetContext;
	private instance: lm.IWidgetInstance;
	private ionApiContext: lm.IIonApiContext;
	private serviceUrl = "Mingle/SocialService.Svc";
	private retryAttempted = false;

	public fullName: string;
	public photoUrl: string;
	public user: ISocialUser;

	static $inject = ["$scope", "$http"];

	constructor(public scope: ng.IScope, private http: ng.IHttpService) {
		this.widgetContext = scope[lm.WidgetConstants.widgetContextKey];
		this.instance = scope[lm.WidgetConstants.widgetInstanceKey];

		this.setBusy(true);
		this.loadUser();
	}

	private setBusy(isBusy: boolean): void {
		// Show the indeterminate progress indicator when the widget is busy by changing the widget state.
		this.widgetContext.setState(isBusy ? lm.WidgetState.busy : lm.WidgetState.running);
	}

	private loadUser(): void {
		const request = this.createRequest("User/Detail");
		this.widgetContext.executeIonApiAsync(request).then(response => {
			this.updateUser(<IUserDetailResponse>response.data);
		}, (error) => {
			this.onRequestError(error);
		});
	}

	private updateUser(response: IUserDetailResponse): void {
		const user = response.UserDetailList[0];
		this.user = user;
		this.fullName = user.FirstName + " " + user.LastName;
		this.loadPhoto();
	}

	private loadPhoto(): void {
		const relativeUrl = "User/" + this.user.UserGUID + "/ProfilePhoto?thumbnailType=3";
		const request = this.createRequest(relativeUrl, { "Accept": "image/png, image/jpeg" });
		request.responseType = "blob";
		this.widgetContext.executeIonApiAsync(request).then(response => {
			this.updatePhoto(<IUserDetailResponse>response.data);
		}, (error) => {
			this.onRequestError(error);
		});
	}

	private updatePhoto(response: any): void {
		var reader = new FileReader();
		reader.onload = () => {
			this.photoUrl = reader.result;
			this.setBusy(false);
			this.scope.$apply();
		};
		reader.readAsDataURL(response);
	}

	private createRequest(relativeUrl: string, headers?: any): lm.IIonApiRequestOptions {
		if (!headers) {
			// Create default headers
			headers = { "Accept": "application/json" };
		}

		// Create the relative URL to the ION API
		const url = this.serviceUrl + "/" + relativeUrl;

		// Create HTTP GET request object
		const request: lm.IIonApiRequestOptions = {
			method: "GET",
			url: url,
			cache: false,
			headers: headers
		};

		return request;
	}

	private onRequestError(error: any): void {
		alert("Failed to call ION API: " + error);
		this.setBusy(false);
	}
}

export var widgetFactory = (context: lm.IWidgetContext): lm.IWidgetInstance => {
	var m = context.getAngularContext().module;
	m.controller("sample.IonApiSocialCtrl", IonApiSocialCtrl);
	return {
		angularConfig: {
			relativeTemplateUrl: "widget.html"
		}
	};
};