var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../lime", "../../core", "../service"], function (require, exports, lm, c, s) {
    var AdminStandardWidgetsCtrl = (function (_super) {
        __extends(AdminStandardWidgetsCtrl, _super);
        function AdminStandardWidgetsCtrl(scope, adminService, dialogService, widgetService, uiGridConstants) {
            _super.call(this, "[AdminStandardWidgetsCtrl] ");
            this.scope = scope;
            this.adminService = adminService;
            this.dialogService = dialogService;
            this.widgetService = widgetService;
            this.uiGridConstants = uiGridConstants;
            this.standardWidgets = [];
            this.refreshText = "Refresh";
            this.initGrid();
            var adminConstants = s.AdminConstants;
            var self = this;
            scope.$watch(adminConstants.openTab, function (tab) {
                if (tab === adminConstants.standardWidgetsTab) {
                    self.listStandardWidgets(false);
                }
            });
        }
        AdminStandardWidgetsCtrl.prototype.listStandardWidgets = function (reload) {
            var self = this;
            var adminService = self.adminService;
            if (reload) {
                this.noOfSelected = 0;
                if (this.scope["widgetsGridApi"]) {
                    this.scope["widgetsGridApi"].selection.clearSelectedRows();
                }
            }
            adminService.setBusy(true);
            adminService.listStandardWidgets(reload).then(function (r) {
                var standardWidgets = r.content;
                self.standardWidgets = standardWidgets;
                self.widgetsGridOptions.data = standardWidgets;
                adminService.setBusy(false);
            }, function (r) {
                adminService.handleError(r);
                adminService.setBusy(false);
            });
        };
        AdminStandardWidgetsCtrl.prototype.openWidgetAccessDialog = function (widget) {
            var _this = this;
            this.adminService.openWidgetAccessDialog(widget, function (resp) {
                if (resp && resp.content) {
                    _this.updateAfterWidgetAccessUpdate(resp.content);
                    _this.setBusy(false);
                }
                else {
                    _this.onError(resp);
                }
            });
        };
        AdminStandardWidgetsCtrl.prototype.updateAfterWidgetAccessUpdate = function (widgetInfo) {
            var existing = lm.ArrayUtil.find(this.standardWidgets, function (info) { return info.widgetId === widgetInfo.widgetId; });
            if (existing) {
                existing.hasAccess = widgetInfo.hasAccess;
                existing.hasRestrictions = widgetInfo.hasRestrictions;
            }
        };
        AdminStandardWidgetsCtrl.prototype.setBusy = function (isBusy) {
            this.adminService.setBusy(isBusy);
        };
        AdminStandardWidgetsCtrl.prototype.onError = function (error) {
            this.adminService.handleError(error);
            this.setBusy(false);
        };
        AdminStandardWidgetsCtrl.prototype.copyAccess = function (widget) {
            var self = this;
            var adminService = self.adminService;
            adminService.setBusy(true);
            adminService.getWidgetAccess({ id: widget.widgetId, accessList: [] }).then(function (r) {
                self.accessCopy = r.content.accessList;
                self.accessCopyWidgetId = widget.widgetId;
                adminService.setBusy(false);
            }, function (r) {
                self.adminService.handleError(r);
                adminService.setBusy(false);
            });
        };
        AdminStandardWidgetsCtrl.prototype.applyAccessCopy = function (widget) {
            var _this = this;
            var widgetsToUpdate = widget ? [widget] : this.getSelectedRows();
            this.adminService.applyWidgetAccess(widgetsToUpdate, this.accessCopy, function () { _this.listStandardWidgets(true); });
        };
        AdminStandardWidgetsCtrl.prototype.clearOrReplaceWithAccessCopy = function (isReplace, widget) {
            var _this = this;
            var widgetsToUpdate = widget ? [widget] : this.getSelectedRows();
            this.adminService.clearOrReplaceWidgetAccess(widgetsToUpdate, isReplace, function () { _this.listStandardWidgets(true); }, this.accessCopy);
        };
        AdminStandardWidgetsCtrl.prototype.initGrid = function () {
            var gridConstants = this.uiGridConstants;
            var adminConstants = s.AdminConstants;
            var widgetActionTemplate = '<div class="ui-grid-cell-contents lm-center-text"><button type="button" ng-click="$event.stopPropagation();" class="btn-actions lm-transparent" xi-popupmenu="grid.appScope.ctrl.menuOptions"><span class="audible">Actions</span>' +
                '<svg class="icon" focusable="false" aria-hidden="false"><use xlink:href="#icon-more"/></svg></button><ul class="popupmenu actions top"><li><a ng-click="grid.appScope.ctrl.openWidgetAccessDialog(row.entity)">Edit Permissions</a></li>' +
                '<li ng-show="row.entity.hasAccess"><a ng-click="grid.appScope.ctrl.copyAccess(row.entity)">Copy Permissions</a></li><li ng-show="grid.appScope.ctrl.accessCopy && grid.appScope.ctrl.accessCopyWidgetId !== row.entity.widgetId" class="separator"></li>' +
                '<li ng-show="grid.appScope.ctrl.accessCopy && grid.appScope.ctrl.accessCopyWidgetId !== row.entity.widgetId"><a ng-click="grid.appScope.ctrl.applyAccessCopy(row.entity)">Apply Copied Permissions</a></li><li ng-show="grid.appScope.ctrl.accessCopyWidgetId && grid.appScope.ctrl.accessCopyWidgetId !== row.entity.widgetId && row.entity.hasAccess">' +
                '<a ng-click="grid.appScope.ctrl.clearOrReplaceWithAccessCopy(true, row.entity)">Replace Copied Permissions</a></li><li ng-show="row.entity.hasAccess" class="separator"></li>' +
                '<li ng-show="row.entity.hasAccess"><a ng-click="grid.appScope.ctrl.clearOrReplaceWithAccessCopy(false, row.entity)">Clear Permissions</a></li></ul></div>';
            var self = this;
            this.widgetsGridOptions = {
                paginationPageSizes: [adminConstants.gridPageSize],
                paginationPageSize: adminConstants.gridPageSize,
                columnDefs: [{
                        field: "title",
                        name: "Title",
                        sort: { direction: gridConstants.ASC, priority: 1 },
                        filter: { condition: gridConstants.filter.CONTAINS },
                        minWidth: 50, maxWidth: 600
                    },
                    { field: "description", name: "Description", minWidth: 50, maxWidth: 600 },
                    { field: "widgetId", name: "WidgetId", displayName: "Widget id", minWidth: 50, maxWidth: 600 },
                    {
                        field: "changeDate", name: "ChangeDate", displayName: "Change date",
                        cellTemplate: "<div class='ui-grid-cell-contents'>{{COL_FIELD | lmLocaleDate}}</div>", minWidth: 50, maxWidth: 600
                    },
                    { field: "changedByName", name: "ChangeBy", displayName: "Changed by", minWidth: 50, maxWidth: 600 },
                    {
                        field: "hasRestrictions", name: "Permissions", enableFiltering: false, maxWidth: 140,
                        cellTemplate: "<div class='ui-grid-cell-contents'>{{COL_FIELD ? 'Restricted' : ''}}</div>",
                        enableColumnResizing: false
                    },
                    { field: "actions", name: "Actions", maxWidth: 110, cellTemplate: widgetActionTemplate, enableFiltering: false, enableSorting: false, enableColumnResizing: false }],
                data: [],
                rowHeight: 48,
                enableFiltering: true,
                enableSorting: true,
                enableColumnMenus: false,
                onRegisterApi: function (gridApi) {
                    self.scope["widgetsGridApi"] = gridApi;
                    self.noOfSelected = 0;
                    var gridSelection = gridApi.selection;
                    var onSelection = gridSelection.on;
                    onSelection.rowSelectionChanged(self.scope, function () {
                        self.noOfSelected = gridSelection.getSelectedRows().length;
                    });
                    onSelection.rowSelectionChangedBatch(self.scope, function () {
                        self.noOfSelected = gridSelection.getSelectedRows().length;
                    });
                }
            };
        };
        AdminStandardWidgetsCtrl.prototype.getSelectedRows = function () {
            return this.scope["widgetsGridApi"].selection.getSelectedRows();
        };
        AdminStandardWidgetsCtrl.add = function (m) {
            m.controller("lmAdminStandardWidgetsCtrl", AdminStandardWidgetsCtrl);
        };
        AdminStandardWidgetsCtrl.$inject = ["$scope", "lmAdminService", "lmDialogService", "lmWidgetService", "uiGridConstants"];
        return AdminStandardWidgetsCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        AdminStandardWidgetsCtrl.add(m);
    };
});
//# sourceMappingURL=standard-widgets.js.map