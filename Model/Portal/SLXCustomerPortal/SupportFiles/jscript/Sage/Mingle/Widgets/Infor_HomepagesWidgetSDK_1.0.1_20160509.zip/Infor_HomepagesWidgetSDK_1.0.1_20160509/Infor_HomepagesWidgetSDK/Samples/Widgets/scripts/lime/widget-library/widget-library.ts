﻿import lm = require("../lime");
import c = require("../core");

interface ICatalogWidget extends c.IWidgetInfo {
	isVisible?: boolean;
	searchableText?: string;
}

interface IWidgetCategory {
	id: string;
	name: string;
	filterHits: number;
	count: number;
}

interface IWidgetLibraryScope extends ng.IScope {
	widgets: ICatalogWidget[];
	selectedCategory: string;
	selectedCategoryName: string;
	lmWlBusy: boolean;
	descrCharLimit: number;
	searchInput: string;
	scrollPosBeforeExpand: number;
}

/**
 * Controller class for the widget library.
 */
class WidgetLibraryCtrl extends c.CoreBase {

	private dialog: c.IContextualActionPanel = null;
	private widgetCategories: c.IStringToAnyMap = {};
	private isSearchModeOn: boolean;
	private userId: string;
	private isUserAdmin: boolean;
	private isWidgetPublishEnabled: boolean;
	private showPublished: boolean;
	private lang: ILanguageLime;
	private context: c.IContext;
	private popupMenuOptions: xi.IPopupMenuOptions;
	private clearSelectionOnUpdate: boolean;

	private filteredWidgetsLength = 0;
	private visibleWidgets = 20;
	private widgetIncrement = 20;
	private preventWidgetIncrement: boolean;
	private scrollElement: JQuery;

	private activeWidget: ICatalogWidget;
	private previousWidget: ICatalogWidget;
	private nextSearchInstant: boolean;
	private unsubscribe: Function;

	private addCallback: Function;

	static $inject = ["$scope", "$timeout", "lmDataService", "lmDialogService", "lmWidgetService", "lmContextService", "lmTagService", "lmLanguageService"];

	constructor(public scope: IWidgetLibraryScope, private timeout: ng.ITimeoutService, private dataService: c.IDataService, private dialogService: lm.IDialogService,
		private widgetService: c.IWidgetService, private contextService: c.IContextService, private tagService: c.ITagService, languageService: c.ILanguageService) {
		super("[Widget Library] ");

		const lang = languageService.getLanguage();
		this.lang = lang;
		scope.lmWlBusy = true;

		const callback = <Function>scope["lmCallback"];
		if (callback) {
			this.addCallback = callback;
		}

		var once = scope.$watch("lmDialog", (dialog) => {
			if (!dialog) {
				return;
			}
			once();
			this.dialog = dialog.data("contextualactionpanel");
			// Timeout to let the DOM be ready
			setTimeout(() => {
				this.addScrollEvents();
				this.listWidgets();
				// Fix for missing actions in toolbar more pboberg
				$(".contextual-action-panel .toolbar").data("toolbar")["updated"]();
			}, 5);
		});


		this.widgetCategories[c.WidgetCategory.All] = <IWidgetCategory>{ name: lang.categoryAll, id: c.WidgetCategory.All, filterHits: 0 };
		this.widgetCategories[c.WidgetCategory.Application] = <IWidgetCategory>{ name: lang.categoryApplication, id: c.WidgetCategory.Application, filterHits: 0, count: 0 };
		this.widgetCategories[c.WidgetCategory.BusinessIntelligence] = <IWidgetCategory>{ name: lang.categoryBI, id: c.WidgetCategory.BusinessIntelligence, filterHits: 0, count: 0 };
		this.widgetCategories[c.WidgetCategory.BusinessProcess] = <IWidgetCategory>{ name: lang.categoryProcess, id: c.WidgetCategory.BusinessProcess, filterHits: 0, count: 0 };
		this.widgetCategories[c.WidgetCategory.Social] = <IWidgetCategory>{ name: lang.categorySocial, id: c.WidgetCategory.Social, filterHits: 0, count: 0 };
		this.widgetCategories[c.WidgetCategory.Utilities] = <IWidgetCategory>{ name: lang.categoryUtilities, id: c.WidgetCategory.Utilities, filterHits: 0, count: 0 };

		this.isSearchModeOn = false;
		this.clearSelectionOnUpdate = true;
		this.context = contextService.getContext();
		this.userId = this.context.getUserId();
		this.isUserAdmin = this.context.isAdministrator;
		this.isWidgetPublishEnabled = this.context.settings.isWidgetPublishEnabled();
		this.showPublished = true;
		scope.selectedCategoryName = lang.categoryAll;
		scope.descrCharLimit = 130;
		scope.selectedCategory = c.WidgetCategory.All;

		var self = this;
		var filterTimeout: ng.IPromise<any>;
		this.unsubscribe = scope.$watch("searchInput", (newValue: string) => {
			timeout.cancel(filterTimeout);
			if (!newValue) {
				// Instant action to clear old filter
				self.clearSearch();
			} else if (!self.nextSearchInstant) {
				// Delay search to await further input
				filterTimeout = timeout(() => {
					self.searchWidgets(newValue);
				}, 200, true);
			} else {
				self.searchWidgets(newValue);
				self.nextSearchInstant = false;
			}
		});
	}

	public static add(m: ng.IModule): void {
		m.controller("lmWidgetLibraryCtrl", WidgetLibraryCtrl);
	}

	private close(): void {
		this.unsubscribe();
		this.scrollElement.unbind("scroll");
		this.widgetService.closeCatalog(this.dialog);
	}

	public isLink(widget: c.IWidgetInfo): boolean {
		return widget.isLink === true;
	}

	public canDelete(widget: c.IWidgetInfo): boolean {
		// Published widgets can be deleted by the current user or an administrator with isWidgetPublishEnabled == true
		// TODO Check that the user still has publish rights
		const owner = widget.owner;
		return owner && (this.isUserAdmin || owner === this.userId) && this.isWidgetPublishEnabled;
	}

	private addInternal(widget: c.IWidgetInfo, byRef: boolean) {
		this.scope.lmWlBusy = true;
		const busyCallback = () => {
			this.scope.lmWlBusy = false;
		};
		const addWidgetInfo: c.IAddWidgetInfo = {
			widgetInfo: widget,
			byRef: byRef
		};
		this.addCallback(addWidgetInfo, busyCallback);
	}

	public copyWidget(widget: c.IWidgetInfo) {
		this.addInternal(widget, false);
	}

	public addWidget(widget: c.IWidgetInfo) {
		const byRef = widget.owner ? true : false;
		this.addInternal(widget, byRef);
	}

	/**
	 * On Tag Click
	 *
	 * Sets slsected tag as search input and closes detail window if open.
	 * THis function is used as a callback to the lm-tags directive.
	 */
	public onTagClick(tag: string) {
		const widget = this.activeWidget;
		if (widget) {
			this.closeWidgetDetails();
		}
		this.nextSearchInstant = true;
		this.scope.searchInput = tag;
	}

	private setCategorySizes(widgets: ICatalogWidget[]) {
		for (const widget of widgets) {
			this.widgetCategories[widget.category].count++;
		}
	}

	private updateWidgets(widgets: ICatalogWidget[]) {
		for (let i = 0; i < widgets.length; i++) {
			const widget = widgets[i];
			widget.displayCategory = this.translateCategory(widget.category);
			widget.displayIcon = this.createImagePath(widget);
			widget.isVisible = true;
			this.widgetCategories[widget.category].filterHits++;
		}
		widgets = lm.ArrayUtil.sortByProperty(widgets, "title", { ignoreCase: true });
		this.scope.widgets = widgets;
		this.filteredWidgetsLength = widgets.length;
		// Needed to calculate showCategory and this.scrollUp()
		this.searchWidgets("");
	}

	private addScrollEvents(): void {
		var element = $(".contextual-action-panel .modal-body-wrapper");
		var self = this;
		element.scroll(() => {
			var category = self.scope.selectedCategory;
			if (self.visibleWidgets >= (category === c.WidgetCategory.All ? self.filteredWidgetsLength : self.widgetCategories[category].filterHits)) {
				return;
			}
			var scrollTop = element.scrollTop();
			if (scrollTop + element[0].offsetHeight + 100 >= element[0].scrollHeight) {
				if (!this.preventWidgetIncrement) {
					self.visibleWidgets += self.widgetIncrement;
					self.preventWidgetIncrement = true;
					self.scope.$apply("ctrl.visibleWidgets");
					setTimeout(() => {
						element.scrollTop(scrollTop);
						self.preventWidgetIncrement = false;
					}, 100);
				}
			}
		});
		this.scrollElement = element;
	}

	private navigateToStandard(widget: ICatalogWidget): void {
		const widgets = this.scope.widgets;
		for (let i = 0; i < widgets.length; i++) {
			const w = widgets[i];
			if (w.widgetId === widget.standardWidgetId) {
				this.showWidgetDetails(w.widgetId, true);
				break;
			}
		}
	}

	private getStandardName(id: string): string {
		let str = "";
		const widgets = this.scope.widgets;
		if (!lm.CommonUtil.isUndefined(id) && !lm.CommonUtil.isUndefined(widgets) && widgets.length > 0) {
			for (let i = 0; i < widgets.length; i++) {
				const widget = widgets[i];
				if (id === widget.widgetId) {
					str = widget.title;
					break;
				}
			}
		}
		return str;
	}

	private listWidgets(): void {
		if (c.ClientConfiguration.isDev()) {
			const definition = c.ClientConfiguration.dev.definition;
			const localization = definition.localization;
			const id = definition.widgetId;
			const info = {
				widgetId: id,
				standardWidgetId: id,
				title: localization[lm.WidgetConstants.widgetTitle],
				description: localization[lm.WidgetConstants.widgetDescription],
				category: definition.category,
				owner: definition.owner,
				version: definition.version,
				iconFile: definition.iconFile
			} as c.IWidgetInfo;
			this.updateWidgets([info]);
			this.scope.lmWlBusy = false;
			this.scope.$apply("lmWlBusy");
			return;
		}
		this.scope.lmWlBusy = true;
		this.widgetService.listWidgets(false).then((r: c.IWidgetListResponse) => {
			this.debug("Listed widgets");

			if (r.content) { // TODO: If no content?
				this.setCategorySizes(r.content);
				this.updateWidgets(r.content);
				this.scope.lmWlBusy = false;
			}

		}, (r: c.IOperationResponse) => {
			this.dataService.handleError(r); // todo: custom error?
			this.scope.lmWlBusy = false;
		});
	}

	private clearCategoryCount(): void {
		angular.forEach(this.widgetCategories, (value: IWidgetCategory) => {
			value.filterHits = 0;
		});
	}

	private searchWidgets(query: string): void {
		const getLower = (s: string) => {
			return s ? s.toLocaleLowerCase() + ";" : "";
		};

		this.clearCategoryCount();
		query = query.toLowerCase();
		let visibleWidgets = 0;
		const widgets = this.scope.widgets;

		for (let i = 0; i < widgets.length; i++) {
			const widget = widgets[i];
			if (!widget.searchableText) {
				const tags = widget.tags;
				widget.searchableText = getLower(widget.title) + getLower(widget.description) + getLower(widget.ownerName) + getLower(tags);
			}
			const widgetCategory = widget.category;
			const isVisible = (!widget.owner || widget.owner && this.showPublished) && widget.searchableText.indexOf(query) !== -1;
			widget.isVisible = isVisible;
			if (isVisible) {
				visibleWidgets++;
				const category = this.widgetCategories[widgetCategory];
				category.filterHits++;
			}
		}
		this.filteredWidgetsLength = visibleWidgets;
		if (this.clearSelectionOnUpdate) {
			this.clearSelection();
			this.scrollUp();
		} else {
			this.clearSelectionOnUpdate = true;
		}
	}

	private clearSearch(): void {
		if (!this.scope.widgets) { return; }
		this.searchWidgets("");
	}

	/**
	 * Opens details of a widget.
	 * 
	 * isLink: If true, it opens the related standard widget of a published widget.
	 */
	private showWidgetDetails(id: string, isLink: boolean): void {
		const widget = this.getWidgetById(id);
		if (!isLink) {
			this.scope.scrollPosBeforeExpand = this.scrollElement.scrollTop();
		} else {
			this.previousWidget = angular.copy(this.activeWidget);
		}
		this.activeWidget = angular.copy(widget);
	}

	/**
	 * Closes the current open details view.
	 */
	private closeWidgetDetails(): void {
		if (lm.CommonUtil.isUndefined(this.previousWidget)) {
			delete this.activeWidget;
			// Go back to scroll position before collapse
			this.scrollElement.animate({
				scrollTop: this.scope.scrollPosBeforeExpand
			}, 1);
		} else {
			//If linked standard widgets is closing, show the previous widget.
			this.activeWidget = angular.copy(this.previousWidget);
			delete this.previousWidget;
		}
	}

	private getWidgetById(id: string): ICatalogWidget {
		return <ICatalogWidget>lm.ArrayUtil.itemByProperty(this.scope.widgets, "widgetId", id);
	}

	private clearSelection(): void {
		if (!lm.CommonUtil.isUndefined(this.activeWidget)) {
			delete this.activeWidget;
			delete this.previousWidget;
		}
	}

	private toggleShowPublished(): void {
		this.searchWidgets(this.scope.searchInput || "");
	}

	/**
	 * Select Category
	 *
	 * Changes the category to the chosen in menu,
	 */
	public selectCategory(category: IWidgetCategory, forceNameChange?: boolean): void {
		const selectedCategory = this.scope.selectedCategory;
		const categoryId = category.id;
		const searchInput = this.scope.searchInput;
		const isCategoryAll = categoryId === c.WidgetCategory.All;
		// do not perform if category is empty
		if (selectedCategory === categoryId || category.count === 0 || !isCategoryAll && searchInput && category.filterHits === 0) {
			if (forceNameChange) {
				this.scope.selectedCategory = categoryId;
				if (category.name) {
					this.scope.selectedCategoryName = category.name;
				}
			}
			return;
		}

		this.clearSelection();

		this.scope.selectedCategory = categoryId;
		if (category.name) {
			this.scope.selectedCategoryName = category.name;
		}
		if (isCategoryAll) {
			this.resetSort();
		} else {
			const categoryWidgets: ICatalogWidget[] = [];
			const widgets: ICatalogWidget[] = [];
			const scopeWidgets = this.scope.widgets;
			for (let i = 0; i < scopeWidgets.length; i++) {
				if (scopeWidgets[i].category === categoryId) {
					categoryWidgets.push(scopeWidgets[i]);
				} else {
					widgets.push(scopeWidgets[i]);
				}
			}
			this.scope.widgets = categoryWidgets.concat(widgets);
		}
		this.scrollUp();
	}

	private resetSort(): void {
		let widgets = this.scope.widgets;
		widgets = lm.ArrayUtil.sortByProperty(widgets, "title", { ignoreCase: true });
		this.scope.widgets = widgets;
	}

	/**
	 * Translate Category
	 *
	 * Used to display the proper category texts in the view
	 */
	public translateCategory(category: string): string {
		const lang = this.lang;
		if (category === c.WidgetCategory.BusinessIntelligence) {
			return lang.widgetCategoryBI;
		} else if (category === c.WidgetCategory.BusinessProcess) {
			return lang.widgetCategoryProcess;
		} else if (category === c.WidgetCategory.Social) {
			return lang.widgetCategorySocial;
		} else if (category === c.WidgetCategory.Utilities) {
			return lang.widgetCategoryUtility;
		}
		return lang.widgetCategoryApplication;
	}

	/**
	 * Delete Widget.
	 *
	 * Deletes a customized or standard widget depending on if
	 * an owner is set on the widget. If the owner is set the widget
	 * is custom.
	 *
	 * @ param widget Widget Info
	 */
	private deleteWidget(widget: c.IWidgetInfo): void {
		// Ask user if sure?
		const lang = this.lang;
		this.dialogService.showMessage({
			title: lang.deleteWidget,
			message: lang.format(lang.confirmDeleteCustomWidget, widget.title),
			standardButtons: lm.StandardDialogButtons.YesNo
		}).then((r: lm.IDialogResult) => {
			if (r.button === lm.DialogButtonType.Yes) {
				// Try to delete the widget
				if (widget.owner) {
					this.scope.lmWlBusy = true;
					this.debug("Attempting to delete customized widget.");
					this.widgetService.deletePublished([widget.widgetId]).then((r: c.IIntegerResponse) => {
						// Remove widget definition from cache
						this.widgetService.removeDefinition(widget.widgetId);
						// Remove widget from list
						lm.ArrayUtil.removeByProperty(this.scope.widgets, "widgetId", widget.widgetId);

						// If a search is active, search again to get correct results & hit counts
						// Else only clear the selection
						var searchText = this.scope.searchInput;
						if (searchText && searchText.length) {
							this.searchWidgets(searchText);
						} else {
							this.clearSelection();
						}

						// Go back to scroll position before collapse
						this.scrollElement.animate({
							scrollTop: this.scope.scrollPosBeforeExpand
						}, 1);
						this.debug("Customized widget deleted.");
						this.scope.lmWlBusy = false;
					}, (r: c.IOperationResponse) => {
						this.widgetService.handleError(r); // todo: custom error?
						this.scope.lmWlBusy = false;
					});
				}
			}
		});
	}

	/**
	 * Create Image Path
	 *
	 * Forwards widget info to service and returns icon path.
	 * 
	 * @ param widget Widget Info
	 * @ returns string Path to the icon.
	 */
	private createImagePath(widget: c.IWidgetInfo): string {
		return this.widgetService.createImagePath(widget);
	}

	private scrollUp(): void {
		this.scrollElement.scrollTop(0);
		this.visibleWidgets = this.widgetIncrement;
	}
}

export var init = (m: ng.IModule) => {
	WidgetLibraryCtrl.add(m);
};