var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../lime", "../core", "../app/page"], function (require, exports, lm, c, p) {
    var PageLibraryCtrl = (function (_super) {
        __extends(PageLibraryCtrl, _super);
        function PageLibraryCtrl(scope, timeout, pageService, contextService, containerService, dialogService, languageService) {
            var _this = this;
            _super.call(this, "[Page Library] ");
            this.scope = scope;
            this.timeout = timeout;
            this.pageService = pageService;
            this.contextService = contextService;
            this.containerService = containerService;
            this.dialogService = dialogService;
            this.languageService = languageService;
            this.pages = [];
            this.filteredPagesLength = 0;
            this.visiblePages = 30;
            this.pageIncrement = 30;
            var language = languageService.getLanguage();
            this.language = language;
            scope.lmPlBusy = true;
            var once = scope.$watch("lmDialog", function (dialog) {
                if (!dialog) {
                    return;
                }
                once();
                _this.dialog = dialog.data("contextualactionpanel");
                _this.container = containerService.getContainer();
                setTimeout(function () {
                    _this.addScrollEvents();
                    _this.listPages();
                    $(".contextual-action-panel .toolbar").data("toolbar")["updated"]();
                }, 5);
            });
            this.filters = [
                { "filter": "data.title", "name": language.sortTitleAsc },
                { "filter": "-data.title", "name": language.sortTitleDesc },
                { "filter": "-data.changeDate", "name": language.sortNewest },
                { "filter": "data.changeDate", "name": language.sortOldest },
                { "filter": "data.ownerName", "name": language.owner },
                { "filter": "-data.popularity", "name": language.usedbyHeader }
            ];
            scope.filter = this.filters[0];
            scope.filterName = language.sortTitleAsc;
            this.context = contextService.getContext();
            this.isUserAdmin = this.context.settings.isAdministrator();
            this.userId = this.context.getUserId();
            this.pageAddEnabled = this.context.settings.isPublicPageAddEnabled();
            this.pageCopyEnabled = this.context.settings.isPublicPageCopyEnabled();
            this.privatePagesEnabled = this.context.settings.isPrivatePagesEnabled();
            var self = this;
            var filterTimeout;
            this.unsubscribe = scope.$watch("searchInput", function (newValue, oldValue) {
                timeout.cancel(filterTimeout);
                if (!newValue) {
                    self.clearSearch();
                }
                else if (newValue !== oldValue) {
                    filterTimeout = timeout(function () {
                        self.searchPages(newValue);
                    }, 200, true);
                }
            });
        }
        PageLibraryCtrl.prototype.listPages = function () {
            var _this = this;
            this.scope.lmPlBusy = true;
            this.pageService.listPublished(false).then(function (r) {
                var pages = r.content;
                if (!r.hasError() && pages) {
                    for (var i = 0; i < pages.length; i++) {
                        var page = pages[i];
                        page.title = page.title || page.data.title;
                        page.description = page.description || page.data.description;
                        page.id = page.id || page.data.id;
                        page.isVisible = true;
                    }
                    _this.scope.lmPlBusy = false;
                    _this.filteredPagesLength = pages.length;
                    _this.pages = pages;
                }
            }, function (r) {
                _this.pageService.handleError(r);
                _this.scope.lmPlBusy = false;
            });
        };
        PageLibraryCtrl.prototype.addScrollEvents = function () {
            var _this = this;
            var element = $(".contextual-action-panel .modal-body-wrapper");
            element.scroll(function () {
                if (_this.visiblePages >= _this.filteredPagesLength) {
                    return;
                }
                var scrollTop = element.scrollTop();
                if (scrollTop + element[0].offsetHeight + 100 >= element[0].scrollHeight) {
                    if (!_this.preventPageIncrement) {
                        _this.visiblePages += _this.pageIncrement;
                        _this.preventPageIncrement = true;
                        _this.scope.$apply("ctrl.visiblePages");
                        setTimeout(function () {
                            element.scrollTop(scrollTop);
                            _this.preventPageIncrement = false;
                        }, 100);
                    }
                }
            });
            this.scrollElement = element;
        };
        PageLibraryCtrl.prototype.searchPages = function (query) {
            query = query.toLowerCase();
            var visiblePages = 0;
            var pages = this.pages;
            for (var i = 0; i < pages.length; i++) {
                var page = pages[i];
                var data = page.data;
                if (!page.searchableText) {
                    var tags = data.tags;
                    page.searchableText = page.title.toLowerCase() + ";" + page.description.toLowerCase() + ";" + data.ownerName.toLowerCase() + ";" + (tags ? tags.toLowerCase() : "");
                }
                var isVisible = page.searchableText.indexOf(query) !== -1;
                page.isVisible = isVisible;
                if (isVisible) {
                    visiblePages++;
                }
            }
            this.filteredPagesLength = visiblePages;
            this.scrollToTop();
        };
        PageLibraryCtrl.prototype.clearSearch = function () {
            var pages = this.pages;
            var pagesCount = pages.length;
            for (var i = 0; i < pagesCount; i++) {
                var page = pages[i];
                page.isVisible = true;
                this.filteredPagesLength = pagesCount;
            }
            this.scrollToTop();
        };
        PageLibraryCtrl.prototype.scrollToTop = function () {
            var element = this.scrollElement;
            if (element) {
                this.visiblePages = this.pageIncrement;
                element.scrollTop(0);
            }
        };
        PageLibraryCtrl.prototype.close = function () {
            var page = this.selectedPage;
            if (page) {
                this.toggleSelected(page);
            }
            this.unsubscribe();
            this.scrollElement.unbind("scroll");
            this.dialog.destroy();
        };
        PageLibraryCtrl.prototype.deletePage = function (page) {
            var _this = this;
            this.container.delete(page.data.id, page.title, true).then(function (r) {
                if (r.hasError()) {
                    _this.logResponse(r);
                    return;
                }
                lm.ArrayUtil.remove(_this.pages, page);
                delete _this.selectedPage;
            }, function (r) { _this.pageService.handleError(r); });
        };
        PageLibraryCtrl.prototype.previewPage = function (page) {
            var lang = this.language;
            var id = page.data.id;
            if (this.container.contains(id)) {
                this.dialogService.showMessage({ title: lang.pageExists, message: lang.format(lang.pageExistsMessage, page.title), standardButtons: lm.StandardDialogButtons.Ok });
                return;
            }
            this.container.previewPage(id, false);
            this.dialog.destroy();
        };
        PageLibraryCtrl.prototype.addPage = function (page) {
            var _this = this;
            this.scope.lmPlBusy = false;
            var busyCallback = function () {
                _this.scope.lmPlBusy = !_this.scope.lmPlBusy;
            };
            this.container.addExistingPage(page, true, false, null, busyCallback);
        };
        PageLibraryCtrl.prototype.copyPage = function (page) {
            var _this = this;
            this.scope.lmPlBusy = false;
            var busyCallback = function () {
                _this.scope.lmPlBusy = !_this.scope.lmPlBusy;
            };
            this.container.copyPage(page, true, false, busyCallback);
        };
        PageLibraryCtrl.prototype.toggleSelected = function (page) {
            var selectedPage = this.selectedPage;
            if (!selectedPage) {
                page.isSelected = true;
                this.selectedPage = page;
            }
            else {
                page.isSelected = true;
                selectedPage.isSelected = false;
                if (page.id === selectedPage.id) {
                    delete this.selectedPage;
                }
                else {
                    this.selectedPage = page;
                }
            }
        };
        PageLibraryCtrl.prototype.setFilter = function (filter) {
            if (!filter["filter"]) {
                return;
            }
            this.scope.filter = filter;
            this.scope.filterName = filter["name"];
            this.scrollToTop();
        };
        PageLibraryCtrl.prototype.canUserEditPage = function (page) {
            var isPagePrivate = p.PageUtil.isPagePrivate(page.data);
            return page.isEditable && !isPagePrivate;
        };
        PageLibraryCtrl.add = function (m) {
            m.controller("lmPageLibraryCtrl", PageLibraryCtrl);
        };
        PageLibraryCtrl.$inject = ["$scope", "$timeout", "lmPageService", "lmContextService", "lmContainerService", "lmDialogService", "lmLanguageService"];
        return PageLibraryCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        PageLibraryCtrl.add(m);
    };
});
//# sourceMappingURL=page-library.js.map