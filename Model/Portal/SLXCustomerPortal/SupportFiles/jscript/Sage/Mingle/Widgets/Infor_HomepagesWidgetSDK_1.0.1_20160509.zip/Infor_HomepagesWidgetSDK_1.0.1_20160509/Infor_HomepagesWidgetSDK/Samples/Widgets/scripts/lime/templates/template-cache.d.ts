/// <reference path="../../typings/angularjs/angular.d.ts" />
export declare class TemplateCacher {
    static cache(locationService: ng.ILocationService, templateCache: ng.ITemplateCacheService): void;
}
