var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../lime", "../core", "../app/page"], function (require, exports, lm, c, p) {
    var PageContainer = (function (_super) {
        __extends(PageContainer, _super);
        function PageContainer(context, data, pageService, dialogService, q, widgetService, lang, progressService, editModeService, loadStartPage) {
            _super.call(this, "[PageContainer] ");
            this.context = context;
            this.data = data;
            this.pageService = pageService;
            this.dialogService = dialogService;
            this.q = q;
            this.widgetService = widgetService;
            this.lang = lang;
            this.progressService = progressService;
            this.editModeService = editModeService;
            this.changedEvent = new c.InstanceEvent();
            this.refreshedEvent = new c.InstanceEvent();
            this.addedEvent = new c.InstanceEvent();
            this.selectedEvent = new c.InstanceEvent();
            this.pages = [];
            /**
             * The currently selected page or null if no page is selected.
             */
            this.selectedPage = null;
            if (data) {
                var pages = data.pages;
                if (pages) {
                    for (var i = 0; i < pages.length; i++) {
                        this.addLast(pages[i]);
                    }
                }
                if (loadStartPage) {
                    this.selectStartPage();
                }
            }
        }
        PageContainer.prototype.destroy = function () {
            try {
                var pages = this.pages;
                if (pages) {
                    for (var i = 0; i < pages.length; i++) {
                        pages[i].destroy();
                    }
                }
                this.addedEvent.clear();
                this.changedEvent.clear();
                this.refreshedEvent.clear();
                this.selectedEvent.clear();
            }
            catch (ex) {
                this.error("Failed to destroy", ex);
            }
        };
        PageContainer.prototype.selectStartPage = function () {
            var settings = this.context.settings;
            var startPage = settings.getStartPage();
            var selectedPage = this.getPage(startPage); // Check if it exists here or within select?
            if (!startPage || !selectedPage || !settings.isSelectHomepageEnabled()) {
                startPage = (this.pages[0] != null) ? this.pages[0].id : null;
            }
            this.select(startPage);
        };
        PageContainer.prototype.onCancelPublish = function () {
            var _this = this;
            this.dialogService.showMessage({ standardButtons: lm.StandardDialogButtons.YesNo, message: this.lang.confirmCancelMessage, title: this.lang.confirmCancel }).then(function (r) {
                if (r.button === lm.DialogButtonType.Yes) {
                    _this.editModeService.stop({ isSave: false });
                }
            });
        };
        PageContainer.prototype.notifyMingle = function () {
            var client = infor.companyon.client;
            var page = this.selectedPage;
            var name = page.title;
            var description = page.description;
            // Enable bookmarking of this page in Ming.le by sending the setShortcutContext message
            var context = {
                type: "page",
                id: page.id
            };
            var data = {
                name: name,
                description: description,
                absoluteURL: "false",
                shortcutContext: context
            };
            client.sendMessage("setShortcutContext", data);
            // Enable sharing of publishes pages in Ming.le by sending the inforBusinessContext message.
            // An empty entities array is used for private pages since those cannot currently be shared.
            var id = page.id;
            var logicalId = c.ClientConfiguration.getLogicalId();
            var entities;
            if (page.isPublished()) {
                var drillback = "?LogicalId=" + logicalId + "&page=" + id;
                entities = [{
                        entityType: "Homepage",
                        id1: name,
                        name: name,
                        description: description,
                        drillbackURL: drillback,
                    }];
            }
            else {
                entities = [];
            }
            var businessContext = {
                screenId: "homepages_Page",
                logicalId: logicalId,
                entities: entities,
                contextId: lm.CommonUtil.random(),
                originatingTime: new Date().getTime()
            };
            client.sendMessage("inforBusinessContext", businessContext);
        };
        PageContainer.prototype.select = function (pageId) {
            if (!pageId) {
                this.selectedPage = null;
                return;
            }
            var selectedPage = this.getPage(pageId);
            if (!selectedPage) {
                // This happens when the currently selected page has been deleted but the users UI hasn't been updated (see LIME-814).
                // In that case we set the selected pages to the first in the array if any pages exist.
                if (this.pages.length > 0) {
                    selectedPage = this.pages[0];
                }
                else {
                    return;
                }
            }
            var previousPage = this.selectedPage;
            if (previousPage) {
                previousPage.hide();
            }
            this.selectedPage = selectedPage;
            this.selectedEvent.raise(selectedPage);
            selectedPage.show();
            try {
                this.notifyMingle();
            }
            catch (ex) {
                this.error("Failed to notify Ming.le", ex);
            }
        };
        PageContainer.prototype.getNextSortOrder = function () {
            var sortOrder = 0;
            try {
                if (this.pages && this.pages.length > 0) {
                    var pageInstance = lm.ArrayUtil.last(this.pages);
                    var lastSortOrder = pageInstance.data.sortOrder;
                    sortOrder = lastSortOrder + 1;
                }
            }
            catch (ex) {
                lm.Log.error("Failed to get next sort order");
            }
            return sortOrder;
        };
        PageContainer.prototype.create = function (pageData) {
            var _this = this;
            pageData.sortOrder = this.getNextSortOrder();
            if (c.ClientConfiguration.isDev()) {
                var dev = c.ClientConfiguration.dev;
                dev.initPage(pageData);
                this.onPageCreated(new c.OperationResponse(pageData));
                dev.container.pages.push({ isEditable: true, data: pageData });
                dev.save();
                return;
            }
            var lang = this.lang;
            // Verify that this page isn't already loaded in that case show an error message
            if (lm.ArrayUtil.containsByProperty(this.pages, "id", pageData.id)) {
                this.dialogService.showMessage({ title: lang.pageExists, message: lang.format(lang.pageExistsMessage, pageData.title), standardButtons: lm.StandardDialogButtons.Ok });
                return;
            }
            var settings = this.context.settings;
            var userPageCount = this.getUserPageCount();
            var maxCount = settings.getMaxUserPageCount();
            if (userPageCount >= maxCount) {
                this.dialogService.showMessage({ title: lang.unableToAddPage, message: lang.format(lang.maxPageCountMessage, maxCount), standardButtons: lm.StandardDialogButtons.Ok });
                return;
            }
            this.context.setBusy(true);
            this.pageService.createPrivate(pageData).then(function (response) {
                _this.onPageCreated(response, true);
                _this.context.setBusy(false);
            }, function (response) {
                _this.handleCreatePageError(response);
                _this.context.setBusy(false);
            });
        };
        PageContainer.prototype.cacheApplicationsAndDefinitions = function (serverPage) {
            // Needed when adding a shared or copy.
            var definitions = serverPage.widgetDefinitions;
            if (definitions) {
                for (var i = 0; i < definitions.length; i++) {
                    this.widgetService.addDefinitionItem(definitions[i]);
                }
            }
            var applications = serverPage.applications;
            if (applications) {
                // Replacement configuration for a logicalId needs to be added to the container
                var config = this.context.getConfiguration();
                if (config) {
                    config.addApplicationMap(applications);
                }
            }
        };
        PageContainer.prototype.add = function (serverPage, showToastConfirmation) {
            this.cacheApplicationsAndDefinitions(serverPage);
            var page = this.addLast(serverPage);
            this.addedEvent.raise(page);
            this.select(page.id);
            this.raiseChanged();
            var lang = this.lang;
            if (showToastConfirmation) {
                this.dialogService.showToast({ title: lang.pageAdded, message: lang.format(lang.titleAddedMessage, page.title) });
            }
        };
        PageContainer.prototype.getUserPageCount = function () {
            var count = 0;
            for (var i = 0; i < this.pages.length; i++) {
                var page = this.pages[i];
                if (!page.isMandatory) {
                    count++;
                }
            }
            return count;
        };
        PageContainer.prototype.reorder = function (order) {
            var _this = this;
            var deferred = this.q.defer();
            this.pageService.reorderConnections(order).then(function (r) {
                if (r.hasError()) {
                    _this.logResponse(r);
                    deferred.reject(r);
                }
                else {
                    r.content = _this.pages;
                    deferred.resolve(r);
                    _this.raiseChanged();
                }
            }, function (r) {
                _this.logResponse(r);
                deferred.reject(r);
            });
            return deferred.promise;
        };
        PageContainer.prototype.contains = function (id) {
            return lm.ArrayUtil.containsByProperty(this.pages, "id", id);
        };
        PageContainer.prototype.publish = function (page, isUpdate) {
            var _this = this;
            var pageData = page.createSavePageData();
            var pageRequest = {
                data: pageData,
                roleAccess: page.roleAccess,
                userAccess: page.userAccess,
                localization: page.localization
            };
            var self = this;
            this.pageService.updatePublished(pageRequest).then(function (r) {
                _this.editModeService.stop({ isSave: true });
                _this.refresh();
            }, function (r) {
                _this.pageService.handleError(r);
                _this.editModeService.stop({ isSave: false });
            });
        };
        PageContainer.prototype.editPageConfiguration = function (isUpdate) {
            var page = this.selectedPage;
            var options = {
                title: this.lang.editPublishConfiguration,
                templateUrl: "scripts/lime/templates/page-customize.html",
                style: "width: 100%; max-width: 650px;",
                parameter: page,
                id: c.Constants.modalPagePublish
            };
            this.dialogService.show(options).then(function (r) {
                var updatedPage = r.value;
                if (!lm.CommonUtil.isUndefined(updatedPage)) {
                    // The data properties are manually copied instead of replacing the entire data object 
                    // since that caused issues that must be fixed before this can be done.
                    var pageData = page.data;
                    var updatedData = updatedPage.data;
                    pageData.title = updatedData.title;
                    pageData.description = updatedData.description;
                    pageData.tags = updatedData.tags;
                    page.roleAccess = updatedPage.roleAccess;
                    page.userAccess = updatedPage.userAccess;
                    page.localization = updatedPage.localization;
                }
            });
        };
        PageContainer.prototype.removeDev = function (deferred, page) {
            this.removeFromPages(page);
            c.ClientConfiguration.dev.save();
            deferred.resolve(new c.OperationResponse(page.id));
        };
        PageContainer.prototype.remove = function (page) {
            var _this = this;
            var deferred = this.q.defer();
            var lang = this.lang;
            var options = {
                title: lang.removePage,
                message: p.PageUtil.isPagePrivate(page.data) ? lang.format(lang.confirmRemovePage, page.title) : lang.format(lang.confirmRemovePublicPage, page.title),
                standardButtons: lm.StandardDialogButtons.YesNo,
                cssClass: "e2e-publRemove"
            };
            this.dialogService.showMessage(options).then(function (result) {
                if (result.button === lm.DialogButtonType.Yes) {
                    _this.context.setBusy(true);
                    if (c.ClientConfiguration.isDev()) {
                        _this.removeDev(deferred, page);
                        return deferred.promise;
                    }
                    _this.pageService.removeConnection(page.id).then(function (r) {
                        if (r.hasError()) {
                            deferred.reject(r);
                        }
                        _this.removeFromPages(page);
                        deferred.resolve(r);
                        _this.context.setBusy(false);
                    }, function (r) {
                        deferred.reject(r);
                        _this.logResponse(r);
                        _this.context.setBusy(false);
                    });
                }
            });
            return deferred.promise;
        };
        PageContainer.prototype.delete = function (pageId, name, isShared) {
            var _this = this;
            var lang = this.lang;
            var page = this.getPage(pageId);
            var isPageLoaded = lm.CommonUtil.hasValue(page);
            var deferred = this.q.defer();
            var message = isShared ? lang.format(lang.confirmDeletePublicPage, name) :
                lang.format(lang.confirmRemovePage, name);
            var options = {
                title: isShared ? this.lang.deletePage : this.lang.removePage,
                message: message,
                standardButtons: lm.StandardDialogButtons.YesNo,
                cssClass: "e2e-privRemove"
            };
            this.dialogService.showMessage(options).then(function (result) {
                if (result.button === lm.DialogButtonType.Yes) {
                    _this.context.setBusy(true);
                    if (c.ClientConfiguration.isDev()) {
                        _this.removeDev(deferred, page);
                        _this.context.setBusy(false);
                        return deferred.promise;
                    }
                    _this.pageService.delete(page === null ? pageId : page.id).then(function (r) {
                        if (r.hasError()) {
                            deferred.reject(r);
                        }
                        if (isPageLoaded) {
                            _this.removeFromPages(page);
                        }
                        deferred.resolve(r);
                        _this.context.setBusy(false);
                    }, function (r) {
                        deferred.reject(r);
                        _this.logResponse(r);
                        _this.context.setBusy(false);
                    });
                }
                return deferred.promise;
            });
            return deferred.promise;
        };
        PageContainer.prototype.removeAllPagesFromClient = function () {
            var _this = this;
            angular.forEach(this.pages, function (page) {
                _this.removeFromPages(page, true);
            });
        };
        PageContainer.prototype.removeFromPages = function (page, isRefresh) {
            var id = page.id;
            var selectedIndex;
            if (!isRefresh && this.selectedPage.id === page.id) {
                selectedIndex = lm.ArrayUtil.indexByProperty(this.pages, "id", id);
            }
            // Remove homepage element from DOM. This must be done before destroying the page and
            // removing the page data, otherwise a memory leak will occur.
            var element = $("#" + id + "").parent(".homepage");
            p.PageUtil.destroyHomepageControl(element);
            element.remove();
            // Destroy page and all its widgets
            page.destroy();
            lm.ArrayUtil.removeByProperty(this.pages, "id", id);
            for (var i = 0; i < this.data.pages.length; i++) {
                if (this.data.pages[i].data.id === id) {
                    this.data.pages.splice(i, 1);
                    break;
                }
            }
            if (!lm.CommonUtil.isUndefined(selectedIndex)) {
                this.selectOnRemove(selectedIndex);
            }
            if (this.isDebug()) {
                this.debug("Page " + page.data.title + " was removed");
            }
            this.raiseChanged();
        };
        PageContainer.prototype.added = function () {
            return this.addedEvent;
        };
        PageContainer.prototype.selected = function () {
            return this.selectedEvent;
        };
        PageContainer.prototype.changed = function () {
            return this.changedEvent;
        };
        PageContainer.prototype.refreshed = function () {
            return this.refreshedEvent;
        };
        PageContainer.prototype.showAddPage = function () {
            var _this = this;
            if (this.isPageAddPossible()) {
                var options = {
                    title: this.lang.newPage,
                    templateUrl: "scripts/lime/templates/add-page.html",
                    cssClass: "e2e-newPageDialog"
                };
                this.dialogService.show(options).then(function (r) {
                    _this.debug("Add page dialog closed");
                    if (!lm.CommonUtil.isUndefined(r.value) && r.button === lm.DialogButtonType.Ok) {
                        var newPage = r.value;
                        if (newPage.title) {
                            _this.create(newPage);
                        }
                        else {
                            _this.debug("Page not added since no title was specified");
                        }
                    }
                });
            }
        };
        PageContainer.prototype.loadPage = function (id) {
            var _this = this;
            var deferred = this.q.defer();
            var existingPage = lm.ArrayUtil.itemByProperty(this.pages, "id", id);
            //If page is not mine and ownerName is not set, fetch page
            if (lm.CommonUtil.hasValue(existingPage) && (existingPage.data.ownerId === this.context.getUserId() || !lm.CommonUtil.isUndefined(existingPage.data.ownerName))) {
                deferred.resolve(existingPage);
            }
            else {
                this.pageService.getPublished(id).then(function (resp) {
                    if (resp && resp.content) {
                        if (lm.CommonUtil.hasValue(existingPage)) {
                            //Replace pageData if existing page was fetched again to set userNames
                            existingPage.data = resp.content.data;
                        }
                        deferred.resolve(resp.content);
                    }
                    else {
                        _this.error("loadPage did not return the page. " + JSON.stringify(resp));
                        deferred.reject(resp);
                    }
                }, function (resp) {
                    _this.error("Failed to load page: " + JSON.stringify(resp));
                    deferred.reject(resp);
                });
            }
            return deferred.promise;
        };
        PageContainer.prototype.showPageInformation = function (id) {
            var _this = this;
            if (!id) {
                return;
            }
            // TODO: Do we need this page to update public or is it ok to just fetch it?
            //var page = lm.ArrayUtil.itemByProperty(this.pages, "id", id);
            //var isExisting = lm.CommonUtil.hasValue(page);
            this.context.setBusy(true);
            this.loadPage(id).then(function (page) {
                var isPrivate = page.data.viewAccess === c.AccessType.Owner;
                _this.context.setBusy(false);
                _this.showPageSettings(page);
            }, function (error) {
                _this.error("Unable to get Page " + error);
                _this.dialogService.showMessage({ title: _this.lang.pageSettings, message: _this.lang.unableOpenPageSettings, standardButtons: lm.StandardDialogButtons.Ok });
                _this.context.setBusy(false);
            });
        };
        PageContainer.prototype.showPageSettings = function (page) {
            var _this = this;
            var options = {
                title: this.lang.pageSettings,
                templateUrl: "scripts/lime/templates/page-settings.html",
                parameter: page
            };
            this.dialogService.show(options).then(function (r) {
                if (r.button == lm.DialogButtonType.Ok) {
                    page.data.title = page.title;
                    page.data.description = page.description;
                    page.data.changeDate = page.changeDate;
                    _this.raiseChangedId(page.data.id);
                }
            });
        };
        PageContainer.prototype.showAboutPage = function () {
            //TODO Type data
            var about = $("#xi-about-dialog-link").data("about");
            var modal = about.modal.data("modal");
            modal.open();
        };
        PageContainer.prototype.showPageLibrary = function () {
            var template = "<div class=\"contextual-action-panel modal lm-catalog-dialog\" ng-include=\"'scripts/lime/templates/page-library.html'\"></div>";
            this.dialogService.showContextualActionPanel(template);
        };
        PageContainer.prototype.addLast = function (serverPage) {
            var page = new p.Page(this.context, serverPage, this.widgetService, this.lang, this.progressService);
            this.addEventHandlers(page);
            this.pages.push(page);
            return page;
        };
        PageContainer.prototype.savePage = function (page, deferred) {
            var _this = this;
            var pageData = page.createSavePageData();
            this.pageService.update(pageData).then(function (r) {
                _this.debug("Page saved: " + pageData.title);
                if (deferred) {
                    deferred.resolve(r);
                }
            }, function (r) {
                _this.pageService.handleError(r);
                if (deferred) {
                    deferred.reject(r);
                }
            });
        };
        PageContainer.prototype.refresh = function () {
            this.refreshedEvent.raise(this);
        };
        PageContainer.prototype.saveAndRefreshCurrent = function () {
            var _this = this;
            if (this.selectedPage) {
                this.saveCurrent().then(function () {
                    _this.refresh();
                });
            }
        };
        PageContainer.prototype.saveCurrent = function () {
            var deferred = this.q.defer();
            var page = this.selectedPage;
            if (page) {
                this.savePage(page, deferred);
            }
            else {
                deferred.reject();
            }
            return deferred.promise;
        };
        PageContainer.prototype.addEventHandlers = function (page) {
            var _this = this;
            page.changed().on(function (p) {
                if (p) {
                    // Check edit modes where save should be skipped
                    var service = _this.editModeService;
                    if (service.containsMode(c.EditModes.page) || service.containsMode(c.EditModes.widget)) {
                        // Don't save anything here when in publish page / widdget mode for now. 
                        // The page will be saved if it is published.
                        // TODO How to handle user data in publish page mode?
                        return;
                    }
                    if (page.isPublished()) {
                        _this.saveUserData(page);
                    }
                    else {
                        _this.savePage(p, null);
                    }
                }
            });
        };
        PageContainer.prototype.getPage = function (id) {
            return lm.ArrayUtil.itemByProperty(this.pages, "id", id);
        };
        PageContainer.prototype.saveUserData = function (page) {
            var _this = this;
            var data = page.getWidgetUserSettings();
            // Save the widget user data in the settings object
            if (page.setWidgetUserSettings(data)) {
                this.pageService.updateConnectionSettings(page.data.id, page.settings).then(function (response) {
                    // Nothing to do for now
                }, function (r) { _this.widgetService.handleError(r); });
            }
        };
        /**
         * Selects the page with this index or one below if index is out of range
         */
        PageContainer.prototype.selectOnRemove = function (index) {
            if (this.pages.length == 0) {
                this.select(null);
            }
            else if (0 <= index && index < this.pages.length) {
                this.select(this.pages[index].id);
            }
            else {
                this.select(this.pages[index - 1].id);
            }
        };
        PageContainer.prototype.onPageCreated = function (response, startEditMode) {
            var pageData = response.content;
            var serverPage = { data: pageData, isEditable: true };
            this.add(serverPage, false);
            if (startEditMode) {
                this.editModeService.start({
                    mode: c.EditModes.layout, title: this.lang.editingPageLayout
                });
            }
            this.debug("Created page: " + pageData.title);
        };
        PageContainer.prototype.raiseChangedId = function (id) {
            this.debug("Page with id " + id + " changed");
            this.changedEvent.raise();
        };
        PageContainer.prototype.raiseChanged = function () {
            this.changedEvent.raise(this);
        };
        /**
         * Add Existing Page
         *
         * Add an existing published or private page.
         */
        PageContainer.prototype.addExistingPage = function (page, showToastConfirmation, isCopy, copyTitle, busyCallback) {
            var _this = this;
            if (!busyCallback) {
                this.progressService.setBusy(true);
            }
            else {
                busyCallback();
            }
            var pageToAdd = lm.ArrayUtil.itemByProperty(this.pages, "id", page.data.id);
            if (!pageToAdd || pageToAdd.isPublished()) {
                // Public page.
                // Verify that the page does not exist in My Pages already, in that case show an error message
                var lang = this.lang;
                if (!isCopy && lm.ArrayUtil.containsByProperty(this.pages, "id", page.data.id)) {
                    busyCallback ? busyCallback() : this.progressService.setBusy(true);
                    this.dialogService.showMessage({ title: lang.pageExists, message: lang.format(lang.pageExistsMessage, page.title), standardButtons: lm.StandardDialogButtons.Ok });
                    return;
                }
                // Add page if max pages not reached.
                if (this.isPageAddPossible()) {
                    var sortOrder = this.getNextSortOrder();
                    // Sortorder is set on server
                    this.pageService.addConnection(page.data.id, isCopy, sortOrder, copyTitle).then(function (r) {
                        _this.add(r.content, showToastConfirmation);
                        busyCallback ? busyCallback() : _this.progressService.setBusy(false);
                    }, function (r) {
                        _this.pageService.handleError(r);
                        busyCallback ? busyCallback() : _this.progressService.setBusy(false);
                    });
                }
                else {
                    busyCallback ? busyCallback() : this.progressService.setBusy(false);
                }
            }
            else {
                // Private page.
                this.duplicatePrivatePage(pageToAdd.createSavePageData(), copyTitle);
                if (busyCallback) {
                    busyCallback();
                }
            }
        };
        /**
         * Duplicate Private Page
         *
         * Duplicates a private page.
         */
        PageContainer.prototype.duplicatePrivatePage = function (pageData, copyTitle) {
            var _this = this;
            // Add page if max pages not reached.
            if (this.isPageAddPossible()) {
                // Strip ID and set new title.
                pageData.title = copyTitle;
                pageData.id = null;
                // Set next sort order
                pageData.sortOrder = this.getNextSortOrder();
                // Create new page.
                this.context.setBusy(true);
                this.pageService.createPrivate(pageData).then(function (response) {
                    _this.onPageCreated(response, false);
                    _this.context.setBusy(false);
                }, function (response) {
                    _this.handleCreatePageError(response);
                    _this.context.setBusy(false);
                });
            }
        };
        /**
         * Is Page Add Possible
         *
         * Returns false if the user has reached the max page count.
         * @ return boolean Max page count reached?
         */
        PageContainer.prototype.isPageAddPossible = function () {
            var lang = this.lang;
            var settings = this.context.settings;
            var userPageCount = this.getUserPageCount();
            // Fix for preview page since a page is temporarily added in that mode, causing misleading page count
            if (this.editModeService.isMode("preview")) {
                userPageCount--;
            }
            var maxCount = settings.getMaxUserPageCount();
            if (userPageCount >= maxCount) {
                this.dialogService.showMessage({ title: lang.unableToAddPage, message: lang.format(lang.maxPageCountMessage, maxCount), standardButtons: lm.StandardDialogButtons.Ok });
                return false;
            }
            return true;
        };
        PageContainer.prototype.copyPage = function (page, showToastConfirmation, fromPreview, busyCallback) {
            if (this.isPageAddPossible()) {
                var title;
                var pageTitle = page.title ? page.title : page.data.title;
                var pageTitleLength = pageTitle.length;
                var self = this;
                // Handle max-length
                var copySuffixLength = this.lang.format(this.lang.pageCopyTitle, pageTitle).length - pageTitleLength;
                if ((pageTitleLength + copySuffixLength) <= c.Constants.pageTitleLength) {
                    title = pageTitle;
                }
                else {
                    title = pageTitle.substr(0, (pageTitleLength + (c.Constants.pageTitleLength - pageTitleLength)) - (copySuffixLength + 3));
                    title += "...";
                }
                var options = {
                    title: this.lang.duplicatePage,
                    templateUrl: "scripts/lime/templates/copy-page.html",
                    parameter: { title: this.lang.format(this.lang.pageCopyTitle, title) },
                    controller: "lmCopyPageCtrl as ctrl",
                    cssClass: "e2e-copyPageModal"
                };
                this.dialogService.show(options).then(function (r) {
                    self.debug("Copy page dialog closed");
                    if (r.value && r.button === lm.DialogButtonType.Ok) {
                        var newPage = r.value;
                        if (fromPreview) {
                            // Remove then add to get correct behavior towards the server
                            self.removeFromPages(self.getPage(page.data.id));
                        }
                        self.addExistingPage(page, showToastConfirmation, true, newPage.title, busyCallback);
                        if (fromPreview) {
                            self.editModeService.stop({ isSave: true });
                        }
                    }
                });
            }
        };
        PageContainer.prototype.openImportPageDialog = function () {
            var settings = this.context.settings;
            var userPageCount = this.getUserPageCount();
            var maxCount = settings.getMaxUserPageCount();
            var lang = this.lang;
            if (userPageCount >= maxCount) {
                var messageOptions = {
                    title: lang.unableToAddPage,
                    message: lang.format(lang.maxPageCountMessage, maxCount),
                    standardButtons: lm.StandardDialogButtons.Ok
                };
                return this.dialogService.showMessage(messageOptions);
            }
            var importOptions = {
                url: "/user",
                title: this.lang.importPage,
                operation: c.EntityCategory.privatePage.toString(),
                acceptFileExtension: ".json"
            };
            var options = {
                title: this.lang.importPage,
                templateUrl: "scripts/lime/templates/import.html",
                style: "width:450px;",
                parameter: importOptions
            };
            return this.dialogService.show(options);
        };
        PageContainer.prototype.previewPage = function (pageId, isExternal) {
            var _this = this;
            this.progressService.setBusy(true);
            this.pageService.getPreview(pageId).then(function (response) {
                if (response.hasError() || !response.content.data) {
                    _this.progressService.setBusy(false);
                    _this.pageService.handleError(response);
                    if (!isExternal) {
                        // Catalog should not be opened for previews / shared links
                        _this.showPageLibrary();
                    }
                    return;
                }
                var page = response.content;
                var isAddEnabled = _this.context.settings.isPublicPageAddEnabled();
                var isDuplicateEnabled = _this.context.settings.isPublicPageCopyEnabled() && _this.context.settings.isPrivatePagesEnabled();
                // Register Applications and definitions so the preview will have enough data
                _this.cacheApplicationsAndDefinitions(page);
                var pageTitle = page.data.title;
                var isEditable = page.isEditable;
                // Edit is never allowed in preview - but remember to change it back is added
                page.isEditable = false;
                var self = _this;
                _this.editModeService.start({
                    mode: c.EditModes.preview,
                    title: _this.lang.format(_this.lang.previewingPage, "'" + pageTitle + "'"),
                    actions: [
                        {
                            text: _this.lang.cancel,
                            cssClass: "e2e-previewPageCancel",
                            execute: function () {
                                self.removeFromPages(self.getPage(page.data.id));
                                self.editModeService.stop({ isSave: false });
                                if (!isExternal) {
                                    // Catalog should not be opened for previews / shared links
                                    _this.showPageLibrary();
                                }
                            }
                        },
                        {
                            text: _this.lang.addPage,
                            cssClass: "e2e-previewPageAdd",
                            execute: function () {
                                if (_this.isPageAddPossible()) {
                                    // Remove then add to get correct behavior towards the server
                                    self.removeFromPages(self.getPage(page.data.id));
                                    // Set the server value for isEditable
                                    page.isEditable = isEditable;
                                    self.addExistingPage(page, false);
                                    self.editModeService.stop({ isSave: true });
                                }
                            },
                            isEnabled: isAddEnabled
                        }
                    ],
                    secondaryActions: [
                        {
                            text: _this.lang.duplicatePage,
                            execute: function () {
                                self.copyPage(page, false, true);
                            },
                            isEnabled: isDuplicateEnabled
                        }
                    ]
                });
                _this.add(page, false);
                _this.progressService.setBusy(false);
            }, function (response) {
                _this.pageService.handleError(response);
                _this.context.setBusy(false);
                if (!isExternal) {
                    // Catalog should not be opened for previews / shared links
                    _this.showPageLibrary();
                }
            });
        };
        PageContainer.prototype.handleCreatePageError = function (response) {
            var title = this.lang.unableToAddPage;
            var message = this.lang.unableToAddPageMesssage;
            // Check if this is a IOperationResponse or a http error
            if (response.errorList) {
                if (response.errorList[0].code === c.UniqueError.failedToAddMaxUserPagesReached) {
                    var maxUserPage = this.context.settings.getMaxUserPageCount();
                    message = this.lang.format(this.lang.maxPageCountMessage, maxUserPage);
                }
            }
            this.dialogService.showMessage({ title: title, message: message, standardButtons: lm.StandardDialogButtons.Ok });
            this.logResponse(response);
        };
        return PageContainer;
    })(c.CoreBase);
    var IonApiContext = (function () {
        function IonApiContext(url, token, customerContext) {
            this.url = url;
            this.token = token;
            this.customerContext = customerContext;
        }
        IonApiContext.prototype.getUrl = function () {
            return this.url;
        };
        IonApiContext.prototype.getToken = function () {
            return this.token;
        };
        IonApiContext.prototype.setToken = function (token) {
            this.token = token;
        };
        IonApiContext.prototype.getHeaderName = function () {
            return "Authorization";
        };
        IonApiContext.prototype.getHeaderValue = function () {
            return "Bearer " + this.token;
        };
        IonApiContext.prototype.getCustomerContext = function () {
            return this.customerContext;
        };
        return IonApiContext;
    })();
    var Configuration = (function () {
        function Configuration(q, http, commonDataService, applications, properties, ionApiCustomerContext, ionApiUrl, ionApiDevToken) {
            this.q = q;
            this.http = http;
            this.commonDataService = commonDataService;
            this.properties = properties;
            this.ionApiCustomerContext = ionApiCustomerContext;
            this.ionApiUrl = ionApiUrl;
            this.ionApiDevToken = ionApiDevToken;
            // A map of application instances keyed by logical ID
            this.instanceMap = {};
            // A map of application instance arrays keyed by logical ID prefix
            this.prefixMap = {};
            /**
             * Error message: No logical ID specified
             */
            this.errorNoId = "No logical ID specified";
            this.addApplicationMap(applications);
        }
        Configuration.prototype.getIonApiContextAsync = function (options) {
            var _this = this;
            var deferred = this.q.defer();
            var refresh = options && options.refresh === true;
            var context = this.ionApiContext;
            if (!c.ClientConfiguration.isDev()) {
                if (context && !refresh) {
                    deferred.resolve(context);
                }
                else {
                    var req = {
                        method: "GET",
                        url: "/grid/rest/security/sessions/oauth?forceRefresh=true",
                        cache: false
                    };
                    this.http(req).then(function (response) {
                        var token = response.data;
                        if (context) {
                            // Update the token in the exsting context
                            context.setToken(token);
                        }
                        else {
                            context = new IonApiContext(_this.ionApiUrl, token, _this.ionApiCustomerContext);
                            _this.ionApiContext = context;
                        }
                        deferred.resolve(context);
                    }, function (response) {
                        deferred.reject(response);
                    });
                }
            }
            else {
                // Use data from configuration file
                if (lm.CommonUtil.isUndefined(this.ionApiUrl) || lm.CommonUtil.isUndefined(this.ionApiDevToken)) {
                    deferred.reject();
                }
                else {
                    context = new IonApiContext(this.ionApiUrl, this.ionApiDevToken, this.ionApiCustomerContext);
                    deferred.resolve(context);
                }
            }
            return deferred.promise;
        };
        Configuration.prototype.executeIonApi = function (context, options, deferred, isRetry) {
            var _this = this;
            var url = options.url;
            if (url && url.indexOf("https://") !== 0) {
                // Prepend the ION API base URL to the relative URL
                options.url = c.HttpUtil.combine(context.getUrl(), url);
            }
            // Add the authorization header for ION API including the OAuth token.
            var headers = options.headers || {};
            headers[context.getHeaderName()] = context.getHeaderValue();
            options.headers = headers;
            this.http(options).then(function (r) {
                // Resolve successful request.
                deferred.resolve(r);
            }, function (error) {
                // Check if the failed request should be retried with a new ION API context.
                if (error.status === 401 && !isRetry && options.ionApiRetry !== false) {
                    _this.getIonApiContextAsync({ refresh: true }).then(function (retryContext) {
                        _this.executeIonApi(retryContext, options, deferred, true);
                    }, function (retryError) {
                        // Reject when a new context cannot be retrieved.
                        deferred.reject(retryError);
                    });
                }
                else {
                    // Reject failed retry attemtps or when retry is disabled.
                    deferred.reject(error);
                }
            });
        };
        Configuration.prototype.executeIonApiAsync = function (options) {
            var _this = this;
            var deferred = this.q.defer();
            this.getIonApiContextAsync().then(function (context) {
                _this.executeIonApi(context, options, deferred, false);
            }, function (r) {
                deferred.reject(r);
            });
            return deferred.promise;
        };
        Configuration.prototype.getApplicationOrDefault = function (applications, logicalId) {
            if (applications) {
                var defaultApplication;
                for (var i = 0; i < applications.length; i++) {
                    var application = applications[i];
                    if (application.logicalId === logicalId) {
                        // Return exact match
                        return application;
                    }
                    if (application.isDefault) {
                        defaultApplication = application;
                    }
                }
                // Return the application marked as default or the first in the list
                return defaultApplication || applications[0];
            }
            return null;
        };
        Configuration.prototype.getApplicationCached = function (logicalId) {
            var application = this.instanceMap[logicalId];
            if (application) {
                return application;
            }
            var applications = this.prefixMap[logicalId];
            return this.getApplicationOrDefault(applications, logicalId);
        };
        Configuration.prototype.getApplicationsCached = function (logicalId) {
            var logicalIdPrefix;
            var application = this.instanceMap[logicalId];
            if (application) {
                logicalIdPrefix = application.logicalIdPrefix;
            }
            else {
                logicalIdPrefix = logicalId;
            }
            var applications = logicalIdPrefix ? this.prefixMap[logicalIdPrefix] : null;
            return applications || null;
        };
        Configuration.prototype.add = function (items) {
            for (var i = 0; i < items.length; i++) {
                this.addApplication(items[i]);
            }
        };
        Configuration.prototype.addApplicationMap = function (applications) {
            for (var key in applications) {
                this.addApplications(applications[key]);
            }
        };
        Configuration.prototype.addApplications = function (applications) {
            for (var i = 0; i < applications.length; i++) {
                this.addApplication(applications[i]);
            }
        };
        Configuration.prototype.addApplication = function (application) {
            var logicalId = application.logicalId;
            var logicalIdPrefix = application.logicalIdPrefix;
            var instances = this.prefixMap[logicalIdPrefix];
            if (!instances) {
                instances = [];
                this.prefixMap[logicalIdPrefix] = instances;
            }
            var index = lm.ArrayUtil.indexByProperty(instances, "logicalId", logicalId);
            if (index >= 0) {
                // Overwrite exsting
                instances[index] = application;
            }
            else {
                // Add new
                instances.push(application);
            }
            this.instanceMap[logicalId] = application;
        };
        Configuration.prototype.getApplications = function (logicalId) {
            var _this = this;
            var deferred = this.q.defer();
            if (logicalId) {
                var applications = this.getApplicationsCached(logicalId);
                if (applications) {
                    deferred.resolve(applications);
                }
                else {
                    this.commonDataService.getApplication(logicalId).then(function (r) {
                        if (!r.hasError() && r.content) {
                            applications = r.content;
                            _this.add(applications);
                            deferred.resolve(applications);
                        }
                        else {
                            deferred.reject(r);
                        }
                    }, function (r) {
                        deferred.reject(r);
                    });
                }
            }
            else {
                deferred.reject(this.errorNoId);
            }
            return deferred.promise;
        };
        Configuration.prototype.getApplication = function (logicalId) {
            var _this = this;
            var deferred = this.q.defer();
            if (logicalId) {
                this.getApplications(logicalId).then(function (applications) {
                    var application = _this.getApplicationOrDefault(applications, logicalId);
                    if (application) {
                        deferred.resolve(application);
                    }
                    else {
                        deferred.reject(null);
                    }
                }, function (r) {
                    deferred.reject(r);
                });
            }
            else {
                deferred.reject(this.errorNoId);
            }
            return deferred.promise;
        };
        return Configuration;
    })();
    var Context = (function () {
        function Context(q, http, progressService, dataservice, commonDataService) {
            this.q = q;
            this.http = http;
            this.progressService = progressService;
            this.dataservice = dataservice;
            this.commonDataService = commonDataService;
            this.isAdministrator = false;
            this.isPageAdmininistrator = false;
            this.isDev = false;
        }
        Context.prototype.init = function (container, containerUrl) {
            // TODO Decide if we should keep both or just one. MT vs on-premise.
            this.isAdministrator = container.isAdministrator;
            this.isPageAdmininistrator = container.isPageAdministrator;
            this.container = container;
            this.userId = container.userId;
            this.tenantId = container.tenantId;
            this.version = container.version;
            this.containerUrl = containerUrl;
            this.settings = new ServerSettings(container.userSettings, container.applicationSettings, container.isAdministrator, container.isPageAdministrator, this.q, this.dataservice);
            this.configuration = this.createConfiguration(container.configuration);
        };
        Context.prototype.getTenantId = function () {
            return this.tenantId;
        };
        Context.prototype.getContainerUrl = function () {
            return this.containerUrl;
        };
        Context.prototype.isCloud = function () {
            return this.container.isCloud;
        };
        Context.prototype.isBusy = function () {
            return this.progressService.isBusy();
        };
        Context.prototype.setBusy = function (isBusy) {
            this.progressService.setBusy(isBusy);
        };
        Context.prototype.createConfiguration = function (config) {
            var applications = null, properties = null, ionApiCustomerContext = null, ionApiUrl = null, ionDevToken = null;
            if (config) {
                applications = config.applications;
                properties = config.properties;
                ionApiCustomerContext = config.ionApiCustomerContext;
                ionApiUrl = config.ionApiUrl;
                ionDevToken = config.ionApiToken;
            }
            return new Configuration(this.q, this.http, this.commonDataService, applications || {}, properties || {}, ionApiCustomerContext, ionApiUrl, ionDevToken);
        };
        Context.prototype.getConfiguration = function () {
            return this.configuration;
        };
        Context.prototype.getUserId = function () { return this.userId; };
        Context.prototype.getVersion = function () { return this.version; };
        Context.prototype.isCurrentUser = function (user) {
            return user && user.toLocaleLowerCase() === this.userId;
        };
        // TODO Change all security checks
        Context.prototype.isOperationEnabled = function (page, settingValue) {
            var isAdmin = this.isPageAdmininistrator;
            var isOwner = this.isCurrentUser(page.ownerId);
            var isShared = page.viewAccess !== c.AccessType.Owner;
            var isAllowed = isShared && settingValue;
            return isOwner || isAdmin || isAllowed;
        };
        Context.prototype.getLanguage = function () {
            if (lm.CommonUtil.isUndefined(this.language)) {
                this.language = infor.lime.language || "en-US";
            }
            return this.language;
        };
        return Context;
    })();
    var ServerSettings = (function (_super) {
        __extends(ServerSettings, _super);
        function ServerSettings(userSettings, applicationSettings, isAdmin, isPageAdmin, q, dataservice) {
            _super.call(this, "[ServerSettings] ");
            this.userSettings = userSettings;
            this.applicationSettings = applicationSettings;
            this.isAdmin = isAdmin;
            this.isPageAdmin = isPageAdmin;
            this.q = q;
            this.dataservice = dataservice;
            this.isDirty = false;
            this.user = this.toDictionary(userSettings);
            this.application = this.toDictionary(applicationSettings);
        }
        ServerSettings.prototype.toDictionary = function (source) {
            var dictionary = {};
            if (source != null) {
                for (var i = 0; i < source.length; i++) {
                    var item = source[i];
                    dictionary[item.name] = item;
                }
            }
            return dictionary;
        };
        ServerSettings.prototype.getString = function (dictionary, name, defaultValue) {
            if (defaultValue === void 0) { defaultValue = null; }
            var setting = dictionary[name];
            if (setting && setting.value) {
                return setting.value;
            }
            return defaultValue;
        };
        ServerSettings.prototype.setString = function (dictionary, name, value) {
            var setting = dictionary[name];
            if (setting && value) {
                if (setting.value !== value) {
                    setting.isChanged = true;
                    this.isDirty = true;
                }
                setting.value = value;
            }
        };
        ServerSettings.prototype.setStringAllowEmpty = function (dictionary, name, value) {
            var setting = dictionary[name];
            if (setting && value != null) {
                if (setting.value !== value) {
                    setting.isChanged = true;
                    this.isDirty = true;
                }
                setting.value = value;
            }
        };
        ServerSettings.prototype.getInt = function (dictionary, name, defaultValue) {
            if (defaultValue === void 0) { defaultValue = 0; }
            var setting = dictionary[name];
            if (setting) {
                return lm.NumUtil.getInt(setting.value, defaultValue);
            }
            return defaultValue;
        };
        ServerSettings.prototype.getBoolean = function (dictionary, name, defaultValue) {
            if (defaultValue === void 0) { defaultValue = false; }
            var setting = dictionary[name];
            if (setting) {
                return lm.CommonUtil.getBoolean(setting.value, defaultValue);
            }
            return defaultValue;
        };
        ServerSettings.prototype.getJSON = function (dictionary, name) {
            var setting = dictionary[name];
            if (setting) {
                var value = setting.value;
                try {
                    return JSON.parse(setting.value);
                }
                catch (e) {
                    this.error("Failed to parse to JSON " + value);
                }
            }
            return null;
        };
        ServerSettings.prototype.isAdministrator = function () {
            return this.isAdmin;
        };
        ServerSettings.prototype.isPageAdministrator = function () {
            return this.isAdmin || this.isPageAdmin;
        };
        ServerSettings.prototype.isPrivatePagesEnabled = function () {
            return this.getBoolean(this.application, c.SettingsNames.enablePrivatePages, false);
        };
        ServerSettings.prototype.isSelectHomepageEnabled = function () {
            return this.getBoolean(this.application, c.SettingsNames.enableSelectHomepage, false);
        };
        /**
        * Use getCanAddFavoritePage(currentCount).
        */
        ServerSettings.prototype.isPublicPageAddEnabled = function () {
            return this.getBoolean(this.application, c.SettingsNames.enableAddPublishedPage, false);
        };
        ServerSettings.prototype.isPublicPageCopyEnabled = function () {
            if (!this.isPrivatePagesEnabled) {
                return false;
            }
            return this.getBoolean(this.application, c.SettingsNames.enableDuplicatePublishedPage, false);
        };
        ServerSettings.prototype.isWidgetPublishEnabled = function () {
            return this.getBoolean(this.application, c.SettingsNames.enableWidgetPublish, false);
        };
        ServerSettings.prototype.isPageCatalogEnabled = function () {
            return this.getBoolean(this.application, c.SettingsNames.enablePageCatalog, false);
        };
        ServerSettings.prototype.isContentTranslationEnabled = function () {
            return this.getBoolean(this.application, c.SettingsNames.enableContentTranslation, true);
        };
        ServerSettings.prototype.getDefaultLanguage = function () {
            return this.getString(this.application, c.SettingsNames.defaultLanguage, "en-US");
        };
        ServerSettings.prototype.getCanAddPrivatePage = function (pageCount) {
            if (pageCount === void 0) { pageCount = -1; }
            // Only check pageCount if that value has been passed
            if (!this.getCanAddUserPage(pageCount)) {
                return false;
            }
            return this.isPrivatePagesEnabled();
        };
        ServerSettings.prototype.getCanAddUserPage = function (pageCount) {
            if (pageCount === void 0) { pageCount = -1; }
            if (pageCount >= 0) {
                if (pageCount >= this.getMaxUserPageCount()) {
                    return false;
                }
                else {
                    return true;
                }
            }
            return false;
        };
        ServerSettings.prototype.getCanAddFavoritePage = function (pageCount) {
            if (pageCount === void 0) { pageCount = -1; }
            if (!this.getCanAddUserPage(pageCount)) {
                return false;
            }
            return this.isPublicPageAddEnabled();
        };
        ServerSettings.prototype.getMaxUserPageCount = function () {
            return this.getInt(this.application, c.SettingsNames.maxUserPageCount, 0);
        };
        ServerSettings.prototype.getStartPage = function () {
            return this.getString(this.user, c.SettingsNames.startPage, "");
        };
        ServerSettings.prototype.setStartPage = function (value) {
            this.setStringAllowEmpty(this.user, c.SettingsNames.startPage, value);
        };
        ServerSettings.prototype.getLogLevel = function () {
            return this.getInt(this.user, c.SettingsNames.logLevel, lm.Log.levelInfo);
        };
        ServerSettings.prototype.saveUserSettings = function () {
            var deferred = this.q.defer();
            var array = this.toArray(this.user);
            var request = { content: JSON.stringify(array) };
            this.dataservice.executePost("/user/settings/update", request).then(function (response) {
                // TODO if ok then remove isChanged from all user settings?
                deferred.resolve(response);
            }, function (response) {
                deferred.reject(response);
            });
            return deferred.promise;
        };
        ServerSettings.prototype.toArray = function (dictionary) {
            var array = [];
            for (var key in dictionary) {
                if (dictionary.hasOwnProperty(key)) {
                    array.push(dictionary[key]);
                }
            }
            ;
            return array;
        };
        /**
         * Gets a valued that indicates if the user is allowed to publish a page (make it public).
         */
        ServerSettings.prototype.isPagePublishEnabled = function () {
            return this.getBoolean(this.application, "EnablePagePublish");
        };
        ServerSettings.prototype.isPageExportEnabled = function () {
            return this.getBoolean(this.application, "EnablePageExport");
        };
        ServerSettings.prototype.isPageImportEnabled = function () {
            return this.getBoolean(this.application, "EnablePageImport");
        };
        /**
         * Gets a value that indicates if a specific widget is enabled for the current user.
         */
        ServerSettings.prototype.isWidgetEnabled = function (type) {
            if (type == null) {
                return false;
            }
            if (this.enabledWidgets == null) {
                this.enabledWidgets = this.getString(this.application, "EnabledWidgets", "").trim().toLowerCase();
                this.disabledWidgets = this.getString(this.application, "DisabledWidgets", "").trim().toLowerCase();
            }
            type = type.toLowerCase();
            if (this.disabledWidgets.indexOf(type) >= 0) {
                return false;
            }
            if (this.enabledWidgets.length > 0 && this.enabledWidgets.indexOf(type) < 0) {
                return false;
            }
            return true;
        };
        return ServerSettings;
    })(c.CoreBase);
    // Temporary default settings if container isn't loaded
    var DefaultServerSettings = (function () {
        function DefaultServerSettings() {
        }
        DefaultServerSettings.prototype.isAdministrator = function () {
            return false;
        };
        DefaultServerSettings.prototype.isPageAdministrator = function () {
            return false;
        };
        DefaultServerSettings.prototype.isPrivatePagesEnabled = function () {
            return false;
        };
        DefaultServerSettings.prototype.isSelectHomepageEnabled = function () {
            return false;
        };
        DefaultServerSettings.prototype.isPublicPageAddEnabled = function () {
            return false;
        };
        DefaultServerSettings.prototype.isPublicPageCopyEnabled = function () {
            return false;
        };
        DefaultServerSettings.prototype.isPageCatalogEnabled = function () {
            return false;
        };
        DefaultServerSettings.prototype.isContentTranslationEnabled = function () {
            return true;
        };
        DefaultServerSettings.prototype.getCanAddPrivatePage = function (pageCount) {
            if (pageCount === void 0) { pageCount = -1; }
            return false;
        };
        DefaultServerSettings.prototype.getCanAddUserPage = function (pageCount) {
            if (pageCount === void 0) { pageCount = -1; }
            return false;
        };
        DefaultServerSettings.prototype.getCanAddFavoritePage = function (pageCount) {
            if (pageCount === void 0) { pageCount = -1; }
            return false;
        };
        DefaultServerSettings.prototype.getMaxUserPageCount = function () {
            return 0;
        };
        DefaultServerSettings.prototype.getStartPage = function () {
            return ""; // TODO?
        };
        DefaultServerSettings.prototype.setStartPage = function (value) {
            // TODO?
        };
        DefaultServerSettings.prototype.saveUserSettings = function () {
            // TODO?
            //var deferred = this.q.defer();
            return null;
        };
        DefaultServerSettings.prototype.getLogLevel = function () {
            return lm.Log.levelInfo;
        };
        /**
         * Gets a valued that indicates if the user is allowed to publish a page (make it public).
         */
        DefaultServerSettings.prototype.isPagePublishEnabled = function () {
            return false;
        };
        DefaultServerSettings.prototype.isPageExportEnabled = function () {
            return false;
        };
        DefaultServerSettings.prototype.isPageImportEnabled = function () {
            return false;
        };
        DefaultServerSettings.prototype.isWidgetEnabled = function (id) {
            return true;
        };
        DefaultServerSettings.prototype.isWidgetPublishEnabled = function () {
            return false;
        };
        DefaultServerSettings.prototype.getDefaultLanguage = function () {
            return "en-US";
        };
        return DefaultServerSettings;
    })();
    /**
     * Controller class for the page navigator.
     */
    var PageNavigatorCtrl = (function (_super) {
        __extends(PageNavigatorCtrl, _super);
        function PageNavigatorCtrl(scope, rootScope, containerService, dataService, dialogService, widgetService, contextService, languageService, editModeService, locationService, pageService) {
            var _this = this;
            _super.call(this, "[PageNavigatorCtrl] ");
            this.scope = scope;
            this.rootScope = rootScope;
            this.containerService = containerService;
            this.dataService = dataService;
            this.dialogService = dialogService;
            this.widgetService = widgetService;
            this.contextService = contextService;
            this.editModeService = editModeService;
            this.locationService = locationService;
            this.pageService = pageService;
            this.widgetToAdd = null;
            this.filenameExport = "Homepage";
            this.extensionExport = ".json";
            this.selectedPageIndex = 0;
            this.unsubscribers = [];
            var isDev = c.ClientConfiguration.isDev();
            // TODO Set default settings opbject with everything turned off
            this.settings = new DefaultServerSettings();
            // TODO Check security settings
            this.isSettingsEnabled = !isDev;
            this.isAdvancedEnabled = !isDev;
            this.lang = languageService.getLanguage();
            this.adminUrl = this.calculateAdminUrl();
            var unregister = scope.$watch("lmPageContainer", function (pc) {
                if (pc) {
                    _this.initialize(pc);
                    unregister();
                }
            });
            scope.$watch("lmPageContainer.selectedPage", function (page) {
                if (page) {
                    _this.selectedPageIndex = _this.pageContainer.pages.indexOf(page);
                }
            });
            this.unsubscribers.push(editModeService.stopped().on(function (editMode) {
                if ((editMode.mode === c.EditModes.page || editMode.mode === c.EditModes.widget) && editMode.isSave === false) {
                    _this.refreshCurrent();
                }
            }));
            scope.$on("$destroy", function () {
                angular.forEach(_this.unsubscribers, function (unsubscribe) {
                    unsubscribe();
                });
            });
        }
        PageNavigatorCtrl.add = function (m) {
            m.controller("lmPageNavigatorCtrl", PageNavigatorCtrl);
        };
        PageNavigatorCtrl.prototype.showPagesMenu = function () {
            if (this.pageContainer.pages.length > 1) {
                $("#lmPagesMenuBtn").click();
            }
        };
        PageNavigatorCtrl.prototype.initialize = function (pageContainer) {
            var _this = this;
            this.pageContainer = pageContainer;
            this.context = pageContainer.context;
            // Check for settings to make sure nor error occurs if server is unavailable (Lime-659)
            if (this.context.settings) {
                this.settings = pageContainer.context.settings;
            }
            this.isPublicPageCopyEnabled = this.settings.isPublicPageCopyEnabled();
            // Select the initial page if there is one
            if (pageContainer.selectedPage) {
                this.onSelected(pageContainer.selectedPage);
            }
            // Subscribe to events from the page container
            this.unsubscribers.push(pageContainer.selected().on(function (p) { return _this.onSelected(p); }));
            this.unsubscribers.push(pageContainer.refreshed().on(function () { return _this.refreshCurrent(); }));
            if (pageContainer.data) {
                var name = c.Product.productName;
                this.aboutDialogOptions = {
                    appName: name,
                    productName: name,
                    version: pageContainer.data.version,
                    useDefaultCopyright: true,
                    content: "<div ng-controller='lmPageAboutCtrl as ctrl' class='lm-padding-md-l'><a class='hyperlink e2e-showUserSettings' ng-click='ctrl.showUserSettings()'>" + this.lang.viewUserPermissions + "</a></div>"
                };
            }
        };
        PageNavigatorCtrl.prototype.addWidget = function (addWidgetInfo, busyCallback) {
            var _this = this;
            var page = this.currentPage;
            var lang = this.lang;
            this.widgetService.preAddWidget(page.getWidgetParentContext(), addWidgetInfo, busyCallback).then(function (widget) {
                page.add(widget);
                _this.dialogService.showToast({ title: lang.widgetAdded, message: lang.format(lang.titleAddedMessage, addWidgetInfo.widgetInfo.title) });
            }, function (err) {
                _this.dialogService.showMessage({ title: lang.unableToAddWidget, message: lang.brokenWidget, isError: true });
            });
        };
        PageNavigatorCtrl.prototype.pasteWidget = function () {
            var _this = this;
            this.context.setBusy(true);
            var widgetCopy = this.rootScope["clipboardWidget"];
            // Add to the current page context
            var context = this.currentPage.getWidgetParentContext();
            var addWidgetInfo = this.widgetService.getAddWidgetInfo(widgetCopy);
            this.widgetService.addWidgetCopyToPage(context, addWidgetInfo).then(function () {
                _this.context.setBusy(false);
            });
        };
        PageNavigatorCtrl.prototype.removePage = function () {
            var _this = this;
            //Delete if private, remove if public
            if (p.PageUtil.isPagePrivate(this.currentPage.data)) {
                this.pageContainer.delete(this.currentPage.id, this.currentPage.title, false).then(function (r) {
                    // For now the selected event from pageContainer handles selection
                }, function (r) { _this.dataService.handleError(r); });
            }
            else {
                this.pageContainer.remove(this.currentPage).then(function (r) {
                    // For now the selected event from pageContainer handles selection
                }, function (r) { _this.dataService.handleError(r); });
            }
        };
        PageNavigatorCtrl.prototype.deletePage = function () {
            var _this = this;
            var pageData = this.currentPage.data;
            if (this.currentPage.isEditable) {
                var self = this;
                this.pageContainer.delete(pageData.id, this.currentPage.title, pageData.viewAccess != c.AccessType.Owner).then(function (r) {
                    // For now the selected event from pageContainer handles delete
                }, function (r) { _this.dataService.handleError(r); });
            }
        };
        PageNavigatorCtrl.prototype.showWidgetCatalog = function () {
            var context = this.currentPage.getWidgetParentContext();
            var self = this;
            this.widgetService.showCatalog(context, function (w, c) { self.addWidget(w, c); }).then(function () {
                // Adding of widget handled by callback
            }, function () {
                lm.Log.error("Could not open Widget Catalog (via menu).");
            });
        };
        PageNavigatorCtrl.prototype.showAddPage = function () {
            this.pageContainer.showAddPage();
        };
        PageNavigatorCtrl.prototype.showMyPages = function () {
            this.scope["lmShowMyPages"] = true;
        };
        PageNavigatorCtrl.prototype.showPageSettings = function () {
            this.pageContainer.showPageInformation(this.pageContainer.selectedPage.id);
        };
        PageNavigatorCtrl.prototype.showRepublishPage = function () {
            var _this = this;
            var page = this.pageContainer.selectedPage;
            this.pageService.getPublishedExtended(page.data.id).then(function (r) {
                if (r.hasError()) {
                    _this.logResponse(r);
                }
                else {
                    page.localization = r.content.localization;
                    page.userAccess = r.content.userAccess;
                    page.roleAccess = r.content.roleAccess;
                    _this.showPublishPage();
                }
            }, function (r) {
                _this.logResponse(r);
                return;
            });
        };
        PageNavigatorCtrl.prototype.showPublishPage = function () {
            var lang = this.lang;
            var title;
            var commandText;
            if (this.isPagePrivate) {
                title = lang.publishPage;
                commandText = lang.publish;
            }
            else {
                title = lang.republishPage;
                commandText = lang.republish;
            }
            this.currentPage.notifyPublishingMode();
            var self = this;
            var cancelClass = "e2e-pubPageCancel";
            var publishClass = "e2e-pubPagePublish";
            var editLayoutClass = "e2e-pubPageEditLayout";
            var editPubConf = "e2e-pubPageEditPubConfig";
            if (!this.isPagePrivate) {
                cancelClass = "e2e-rePubPageCancel";
                publishClass = "e2e-rePubPagePublish";
                editLayoutClass = "e2e-rePubPageEditLayout";
                editPubConf = "e2e-rePubPageEditPubConfig";
            }
            this.editModeService.start({
                mode: c.EditModes.page,
                title: title,
                submode: this.isPagePrivate ? c.EditSubmodes.publish : c.EditSubmodes.republish,
                actions: [
                    { text: this.lang.cancel, cssClass: cancelClass, execute: function () { self.pageContainer.onCancelPublish(); } },
                    { text: commandText, cssClass: publishClass, execute: function () { self.pageContainer.publish(self.pageContainer.selectedPage, self.pageContainer.selectedPage.isPublished()); } }
                ],
                secondaryActions: [
                    { text: this.lang.editLayout, cssClass: editLayoutClass, execute: function () { self.showEditPageLayout(); } },
                    { text: this.lang.editPublishConfiguration, cssClass: editPubConf, execute: function () { self.pageContainer.editPageConfiguration(!self.isPagePrivate); } }
                ]
            });
            this.pageContainer.editPageConfiguration(!this.isPagePrivate);
        };
        PageNavigatorCtrl.prototype.exportPage = function () {
            if (!this.settings.isPageExportEnabled()) {
                this.debug("[ExportPage] Click on disabled context menu, should have been prevented by infor control");
                return;
            }
            var page = this.currentPage;
            var id = page.id;
            var name = page.data.title; // TODO: which title to use for export, default or translated?
            if (!name) {
                name = this.filenameExport;
            }
            name = encodeURI(name);
            var query = "?_=" + new Date().getTime(); // Add this to prevent browser caching
            var url = this.dataService.getUrl("page/export/" + id + "/" + name + this.extensionExport) + query;
            this.debug("[exportPage] " + url);
            window.open(url, "_blank");
        };
        PageNavigatorCtrl.prototype.importPage = function () {
            var _this = this;
            var self = this;
            this.pageContainer.openImportPageDialog().then(function (r) {
                var value = r.value;
                if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Success) {
                    var response = r.value.message;
                    self.refresh(response.content.id);
                }
                else if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Fail) {
                    self.dialogService.showMessage({
                        title: self.lang.importPage,
                        message: self.lang.errorGeneric,
                        isError: true
                    });
                }
            }, function (r) {
                _this.pageService.handleError(r);
            });
        };
        PageNavigatorCtrl.prototype.showPageLibrary = function () {
            this.pageContainer.showPageLibrary();
        };
        PageNavigatorCtrl.prototype.showEditPageLayout = function () {
            this.editModeService.start({
                mode: c.EditModes.layout,
                title: this.lang.editingPageLayout
            });
        };
        PageNavigatorCtrl.prototype.onClickSelectPage = function (page) {
            this.pageContainer.select(page.id);
        };
        PageNavigatorCtrl.prototype.onSelected = function (page) {
            if (page !== this.currentPage) {
                this.currentPage = page;
            }
            this.isPagePrivate = p.PageUtil.isPagePrivate(this.currentPage.data);
            this.isPageDeletable = this.currentPage.isEditable && !this.isPagePrivate;
            this.isRepublishEnabled = this.currentPage.isEditable && !this.isPagePrivate && this.context.settings.isPagePublishEnabled();
        };
        PageNavigatorCtrl.prototype.copyPage = function () {
            var page = this.currentPage;
            this.pageContainer.copyPage(page, false, false);
        };
        PageNavigatorCtrl.prototype.refreshCurrent = function () {
            this.pageContainer.removeAllPagesFromClient();
            this.widgetService.invalidateWidgetCache();
            this.pageService.invalidatePageCache();
            var page = this.pageContainer.selectedPage;
            if (page) {
                this.refresh(page.id);
            }
            else {
                // Case when no pages exist, but still need to fully refresh the container
                this.refresh();
            }
        };
        PageNavigatorCtrl.prototype.refresh = function (selectPageId) {
            var _this = this;
            // For case where when container failed to load and "Refresh" button appears, or when user has no pages, full refresh of startpage is needed
            var fullRefresh;
            if (this.pageContainer.errorMessage || !this.pageContainer.selectedPage) {
                fullRefresh = true;
            }
            else {
                fullRefresh = false;
            }
            this.scope["lmPageContainer"] = null;
            var unregister = this.scope.$watch("lmPageContainer", function (pc) {
                if (pc) {
                    _this.initialize(pc);
                    if (selectPageId) {
                        pc.select(selectPageId);
                    }
                    unregister();
                }
            });
            this.scope["lmRefresh"](fullRefresh);
        };
        /**
         * Shows the About Page dialog.
         */
        PageNavigatorCtrl.prototype.showAboutPage = function () {
            this.pageContainer.showAboutPage();
        };
        /**
         * Calculate Admin URL
         *
         * Returns url to admin tool with or without template cache flag.
         */
        PageNavigatorCtrl.prototype.calculateAdminUrl = function () {
            var urlParams = this.locationService.search();
            var url = c.ClientConfiguration.isLocal() ? "admin.html" : "admin";
            if (urlParams.templateCache && urlParams.templateCache === "true") {
                url += "?templateCache=true";
            }
            return url;
        };
        PageNavigatorCtrl.$inject = ["$scope", "$rootScope", "lmContainerService", "lmDataService", "lmDialogService", "lmWidgetService", "lmContextService", "lmLanguageService", "lmEditModeService", "$location", "lmPageService"];
        return PageNavigatorCtrl;
    })(c.CoreBase);
    var PageNavigatorDirective = (function () {
        function PageNavigatorDirective() {
        }
        PageNavigatorDirective.add = function (m) {
            m.directive("lmPageNavigator", ["$compile", function ($compile) {
                    return {
                        scope: false,
                        restrict: "E",
                        replace: true,
                        controller: PageNavigatorCtrl,
                        controllerAs: "lmPageNavigatorCtrl",
                        templateUrl: "scripts/lime/templates/navigator.html"
                    };
                }]);
        };
        return PageNavigatorDirective;
    })();
    var PageContainerCtrl = (function (_super) {
        __extends(PageContainerCtrl, _super);
        function PageContainerCtrl(rootScope, scope, compile, containerService, widgetService, location, mingleMessageBroker, dialogService, languageService) {
            _super.call(this, "[PageContainerCtrl] ");
            this.scope = scope;
            this.compile = compile;
            this.containerService = containerService;
            this.widgetService = widgetService;
            this.location = location;
            this.dialogService = dialogService;
            this.languageService = languageService;
            this.isDev = false;
            this.isSafeMode = false;
            this.isMingleInitialized = false;
            mingleMessageBroker.initialize();
            var self = this;
            // Delay initialization until the directive has completed initialization.
            var unregister = scope.$watch("lmContainerMode", function (mode) {
                var urlParams = location.search();
                rootScope[c.Constants.safeMode] = !lm.CommonUtil.isUndefined(urlParams) && !lm.CommonUtil.isUndefined(urlParams[c.Constants.safeMode]) && urlParams[c.Constants.safeMode] === "true";
                self.init(mode, true);
                unregister();
            });
        }
        PageContainerCtrl.prototype.init = function (mode, reloadStartPage) {
            var _this = this;
            var isDev = mode === "dev";
            if (isDev) {
                this.isDev = true;
                c.ClientConfiguration.initDevConfiguration(this.scope["lmDevData"]);
            }
            this.containerService.loadContainer(reloadStartPage).then(function (response) {
                _this.onResponse(response);
            }, function (r) { _this.widgetService.handleError(r); });
            this.scope["lmRefresh"] = function (fullRefresh) { _this.refresh(fullRefresh); };
        };
        PageContainerCtrl.prototype.refresh = function (fullRefresh) {
            var mode = this.scope["lmContainerMode"];
            // TODO Destroy in both cases or not?
            this.pageContainer.destroy();
            if (fullRefresh) {
                this.init(mode, true);
            }
            else {
                this.init(mode, false);
            }
        };
        PageContainerCtrl.prototype.showPageMissing = function () {
            var language = this.languageService.getLanguage();
            this.dialogService.showMessage({ title: c.Product.productName, message: language.pageNotExist, standardButtons: lm.StandardDialogButtons.Ok });
        };
        PageContainerCtrl.prototype.openPage = function (pageId, preview) {
            var container = this.pageContainer;
            if (container.contains(pageId)) {
                container.select(pageId);
                // Manually apply the scope since the source is from another frame.
                this.scope.$apply();
                return true;
            }
            if (preview) {
                container.previewPage(pageId, true);
                return true;
            }
            return false;
        };
        PageContainerCtrl.prototype.onShowPage = function (pageId) {
            if (pageId && this.openPage(pageId, true)) {
                return;
            }
            this.showPageMissing();
        };
        PageContainerCtrl.prototype.onDrillback = function (data) {
            try {
                if (!data) {
                    return;
                }
                this.debug("onDrillback: " + JSON.stringify(data));
                // Parse the drillback URL, for example:
                // "?LogicalId=lid://infor.homepages.1&page=asd45as54asd564asd564",
                var url = data.applicationDrillback;
                var pageId = c.HttpUtil.parseQuery(url)["page"];
                this.onShowPage(pageId);
            }
            catch (ex) {
                this.error("Failed to handle drillback " + JSON.stringify(data), ex);
            }
        };
        PageContainerCtrl.prototype.onBookmark = function (data) {
            try {
                this.debug("onBookmark: " + JSON.stringify(data));
                var context = JSON.parse(data.favoriteContext);
                this.onShowPage(context.id);
            }
            catch (ex) {
                this.error("Failed to handle bookmark " + JSON.stringify(data), ex);
            }
        };
        PageContainerCtrl.prototype.initMingleCallbacks = function () {
            if (this.isMingleInitialized) {
                return;
            }
            this.isMingleInitialized = true;
            var client = infor.companyon.client;
            var self = this;
            client.registerMessageHandler("showFavoriteContext", function (data) {
                self.onBookmark(data);
            });
            client.registerMessageHandler("applicationDrillback", function (data) {
                self.onDrillback(data);
            });
            // Use explicit initialization for Homepages
            client.sendMessage("appInitComplete", window.name);
        };
        PageContainerCtrl.prototype.onResponse = function (pageContainer) {
            this.debug("Received page container");
            this.pageContainer = pageContainer;
            this.scope["lmPageContainer"] = pageContainer;
            this.initMingleCallbacks();
        };
        PageContainerCtrl.add = function (m) {
            m.controller("lmPageContainerCtrl", PageContainerCtrl);
        };
        PageContainerCtrl.$inject = ["$rootScope", "$scope", "$compile", "lmContainerService", "lmWidgetService", "$location", "MingleMessageBroker", "lmDialogService", "lmLanguageService"];
        return PageContainerCtrl;
    })(c.CoreBase);
    var PageContainerDirective = (function () {
        function PageContainerDirective() {
        }
        PageContainerDirective.add = function (m) {
            m.directive("lmPageContainer", ["$compile", function ($compile) {
                    return {
                        scope: true,
                        restrict: "E",
                        replace: true,
                        controller: PageContainerCtrl,
                        templateUrl: "scripts/lime/templates/page-container.html",
                        link: function (scope, element, attributes, controller, transclude) {
                            var mode = "default";
                            var widgetId = attributes["devWidget"];
                            var config = attributes["devConfiguration"];
                            var settings = attributes["devSettings"];
                            var custom = attributes["devCustom"];
                            var devData = new c.DevConfigurationData();
                            // devWidget is mandatory and has to be set
                            if (widgetId) {
                                mode = "dev";
                                devData.widgetId = widgetId;
                                scope["lmDevData"] = devData;
                            }
                            if (config) {
                                devData.configurationPath = config;
                            }
                            if (settings) {
                                devData.settingsPath = settings;
                            }
                            if (custom) {
                                devData.customDefinitionPath = custom;
                            }
                            scope["lmContainerMode"] = mode;
                            lm.CommonUtil.detectBrowser();
                        }
                    };
                }]);
        };
        return PageContainerDirective;
    })();
    var PageDirective = (function () {
        function PageDirective(scope, element, $compile, timeout, editModeService) {
            var _this = this;
            this.scope = scope;
            this.element = element;
            this.$compile = $compile;
            this.timeout = timeout;
            this.editModeService = editModeService;
            this.unsubscribers = [];
            scope.$watch("lmPageContainer.selectedPage", function (page) {
                _this.update(page);
            });
            this.unsubscribers.push(editModeService.started().on(function (editMode) {
                if (editMode.mode == c.EditModes.layout && _this.page) {
                    _this.startEditLayout();
                    _this.page.toggleEditMode(true);
                }
            }));
            this.unsubscribers.push(editModeService.stopped().on(function (editMode) {
                if (editMode.mode == c.EditModes.layout && _this.page) {
                    _this.stopEditLayout(editMode);
                    _this.page.toggleEditMode(false);
                }
            }));
            scope.$on("$destroy", function () {
                angular.forEach(_this.unsubscribers, function (unsubscribe) {
                    unsubscribe();
                });
            });
        }
        PageDirective.prototype.startEditLayout = function () {
            var content = this.findContent(this.page.data);
            p.PageUtil.updateLayout(this.page.widgets);
            p.PageUtil.destroyHomepageControl(content.parent(".homepage"));
        };
        PageDirective.prototype.stopEditLayout = function (editMode) {
            var page = this.page;
            var content = this.findContent(page.data);
            p.PageUtil.addHomepageControl(content.parent(".homepage"));
            if (!editMode.isSave) {
                setTimeout(function () {
                    p.PageUtil.refreshHomepageLayout(content.parent(".homepage"));
                }, 1);
                return;
            }
            page.widgetsAddedCount = 0;
            this.updateContent(page);
            var currentMode = this.editModeService.getCurrent();
            var isPageEditActive = currentMode != null && currentMode.isActive && currentMode.mode === c.EditModes.page;
            page.updateWidgets(editMode.result, !isPageEditActive);
            if (isPageEditActive) {
                this.timeout(function () {
                    page.notifyPublishingMode();
                });
            }
        };
        PageDirective.prototype.remove = function (widget) {
            var element = widget.element;
            if (element) {
                try {
                    element.remove();
                }
                catch (e) {
                    lm.Log.error("Widget element with id '" + widget.id + "' could not be removed.");
                }
            }
        };
        PageDirective.prototype.addWidget = function (content, widget) {
            var element = this.createWidget(widget);
            content.append(element);
        };
        PageDirective.prototype.createWidget = function (widget) {
            var _this = this;
            var elementId = lm.CommonUtil.random();
            widget.elementId = elementId;
            var container = $("<lm-widget-container/>").attr("id", elementId);
            var newScope = this.scope.$new(true);
            widget.element = container;
            newScope["lmWidget"] = widget;
            if (widget.destroyed) {
                var unregisterDestroyed = widget.destroyed().on(function () {
                    unregisterDestroyed();
                    newScope.$destroy();
                    _this.remove(widget);
                });
            }
            if (widget.added) {
                var unregisterAdded = widget.added().on(function () {
                    unregisterAdded();
                    _this.onWidgetAdded();
                });
            }
            return this.$compile(container)(newScope);
        };
        PageDirective.prototype.onWidgetAdded = function () {
            this.page.widgetsAddedCount++;
            if (this.page.widgetsAddedCount === this.page.noOfWidgets()) {
                //Delay needed to place larger widgets correctly
                var self = this;
                setTimeout(function () {
                    var content = self.findContent(self.page.data);
                    p.PageUtil.refreshHomepageLayout(content.parent(".homepage"));
                    content.find(".chart-container").trigger("resize");
                }, 1);
            }
        };
        PageDirective.prototype.addWidgets = function (content, widgets) {
            this.page.widgetsAddedCount = 0;
            for (var i = 0; i < widgets.length; i++) {
                this.addWidget(content, widgets[i]);
            }
        };
        PageDirective.prototype.createContent = function (page) {
            // Attribute data-colums says that the Homepage supports 4 columns, othervise use 3.
            return $("<div/>").addClass("homepage").attr({ "role": "main", "data-columns": "4" }).append($("<div />").addClass("content").attr("id", page.id));
        };
        PageDirective.prototype.updateContent = function (page) {
            var content = this.findContent(page);
            if (content.length > 0) {
                content.empty();
            }
            else {
                content = this.createContent(page);
                this.element.append(content);
            }
            return content;
        };
        PageDirective.prototype.findContent = function (page) {
            return this.element.find("#" + page.id);
        };
        PageDirective.prototype.update = function (page) {
            var _this = this;
            if (!page) {
                if (this.page) {
                    // Remove homepage container
                    this.element.find(".homepage").remove();
                    this.page = null;
                }
                return;
            }
            this.page = page;
            var visibleHomePage = this.element.find(".homepage");
            if (visibleHomePage.length > 0) {
                visibleHomePage.hide();
                p.PageUtil.detachHomepageEvents(visibleHomePage);
            }
            var content = this.findContent(page);
            if (content.length > 0) {
                var hiddenHomepage = content.parent(".homepage");
                hiddenHomepage.show();
                p.PageUtil.attachHomepageEvents(hiddenHomepage, true);
                return;
            }
            this.updateContent(page);
            content = this.findContent(page);
            p.PageUtil.addHomepageControl(content.parent(".homepage"));
            this.unsubscribers.push(page.widgetAdded().on(function (w) {
                _this.addWidget(content, w);
            }));
            this.addWidgets(content, page.widgets);
        };
        PageDirective.add = function (m) {
            m.directive("lmPage", ["$compile", "$timeout", "lmEditModeService", function ($compile, $timeout, editModeService) {
                    return {
                        scope: false,
                        replace: true,
                        restrict: "E",
                        link: function (scope, element, attributes, controller, transclude) {
                            var directive = new PageDirective(scope, element, $compile, $timeout, editModeService);
                        }
                    };
                }]);
        };
        return PageDirective;
    })();
    var ContainerService = (function (_super) {
        __extends(ContainerService, _super);
        function ContainerService(location, q, contextService, dataservice, widgetService, pageService, dialogService, languageService, editModeService, progressService, http) {
            _super.call(this, "[ContainerService] ");
            this.location = location;
            this.q = q;
            this.contextService = contextService;
            this.dataservice = dataservice;
            this.widgetService = widgetService;
            this.pageService = pageService;
            this.dialogService = dialogService;
            this.languageService = languageService;
            this.editModeService = editModeService;
            this.progressService = progressService;
            this.http = http;
            this.isDev = false;
            this.context = contextService.getContext();
            this.language = languageService.getLanguage();
        }
        ContainerService.prototype.getContainer = function () {
            return this.pageContainer;
        };
        ContainerService.prototype.loadContainer = function (loadStartPage) {
            var _this = this;
            this.context.setBusy(true);
            var deferred = this.q.defer();
            // Get url parameters from mingle limeLanguage is a global javascript variable
            var language = this.context.getLanguage();
            lm.Log.debug("Parameter " + c.Constants.mingleLanguage + " set to :" + language);
            // Initialize language
            this.dataservice.setLanguage(language);
            if (c.ClientConfiguration.isDev()) {
                // Widget development mode
                this.isDev = true;
                this.initDev(deferred, loadStartPage);
                this.context.setBusy(false);
            }
            else {
                // Normal mode
                Locale.set(language).then(function (response) {
                    _this.info("Locale successfully set to: " + response);
                    //Class-based detection for IE
                    if (navigator.userAgent.match(/Trident/)) {
                        $('html').addClass('ie');
                    }
                    if (navigator.appVersion.indexOf('MSIE 9.0') > -1) {
                        $('html').addClass('ie9');
                    }
                    if (navigator.appVersion.indexOf('MSIE 10.0') > -1) {
                        $('html').addClass('ie10');
                    }
                    else {
                        if (navigator.userAgent.match(/Trident\/7\./)) {
                            $('html').addClass('ie11');
                        }
                    }
                }, function () {
                    _this.error("Failed to set Locale.");
                });
                c.ClientConfiguration.initialize(this.location);
                this.dataservice.executePost("/page/container", {}).then(function (response) {
                    _this.onResponse(response, loadStartPage);
                    _this.context.setBusy(false);
                    deferred.resolve(_this.pageContainer);
                }, function (response) {
                    _this.context.setBusy(false);
                    _this.error("Failed to load pages: " + response);
                    _this.createErrorContainer("Failed to load page container");
                    var errorTitle = _this.language.errorUnavailable;
                    var errorList = response.errorList;
                    if (errorList && errorList.length && errorList[0].code === c.ResponseErrorCodes.forbidden) {
                        errorTitle = _this.language.errorUnauthorizedPage + " (403)";
                    }
                    var message = _this.language.contactAdminRetry;
                    if (response.errorHttpCode === c.ResponseErrorCodes.undefined.toString()) {
                        message = _this.language.errorSignOut;
                    }
                    _this.dialogService.showMessage({ title: errorTitle, message: message });
                    deferred.resolve(_this.pageContainer);
                });
            }
            return deferred.promise;
        };
        ContainerService.prototype.loadDevContainer = function (devPath, devData) {
            // TODO Add support for widget layout and other things that might be required for testing.
            var definition = devData.widgetDefinition;
            var id = definition.widgetId;
            var dev = c.ClientConfiguration.dev;
            var container = dev.load(id);
            var enableSettings = definition.enableSettings !== false;
            var enableTitleEdit = definition.enableTitleEdit !== false;
            definition.enableSettings = enableSettings;
            definition.enableSettingsDef = enableSettings;
            definition.enableTitleEdit = enableTitleEdit;
            definition.enableTitleEditDef = enableTitleEdit;
            dev.definition = definition;
            // Add configuration
            var configuration = devData.configuration;
            if (configuration) {
                container.configuration = devData.configuration;
            }
            container["applicationSettings"] = [{ name: c.SettingsNames.enablePrivatePages, value: "true" },
                { name: c.SettingsNames.maxUserPageCount, value: "5" }];
            // Get the English description for now, consider using client language in dev mode
            var language = definition["localization"]["en-US"];
            var title = language[lm.WidgetConstants.widgetTitle];
            definition.localization = language;
            var page = null;
            var serverPage = null;
            if (container.pages) {
                // TODO Support more than one page
                serverPage = container.pages[0];
                serverPage.isEditable = true;
                page = serverPage.data;
            }
            if (page) {
                dev.initPage(page);
                var widgets = page.widgets;
                if (!widgets || widgets.length === 0) {
                    page.widgets = widgets = [{}];
                }
                var widgetData = widgets[0];
                var customDefinition = devData.customDefinition;
                var useCustom = !!customDefinition;
                if (!widgetData.title) {
                    widgetData.title = title;
                }
                widgetData.instanceId = lm.CommonUtil.random();
                if (widgetData.isTitleLocked !== false) {
                    widgetData.isTitleLocked = true;
                }
                if (useCustom) {
                    definition.isPublished = true;
                    definition.standardWidgetId = id;
                    id = lm.CommonUtil.random();
                    definition.widgetId = id;
                    definition.custom = customDefinition.custom;
                    if (customDefinition.enableSettings === false) {
                        definition.enableSettings = false;
                    }
                    if (customDefinition.enableTitleEdit === false) {
                        definition.enableTitleEdit = false;
                    }
                }
                else {
                    // If a settings and data file is configured those should be used instead of the saved values - but only if the widget isn't customized
                    if (devData.settings) {
                        var devSettings = devData.settings["settings"];
                        if (devSettings) {
                            this.info("Using settings from " + devData.settingsPath + ". The stored settings in isolated storage will not be used.");
                            widgetData.settings = devSettings;
                        }
                    }
                }
                // Set the widget ID which might have changed
                widgetData.id = id;
                if (!widgetData.layout) {
                    widgetData.layout = new c.WidgetLayout(0, 0);
                }
            }
            var finalDefinition = {};
            angular.copy(definition, finalDefinition);
            var item = {
                definition: finalDefinition, standardTitle: title, catalogTitle: title, localization: language
            };
            finalDefinition.widgetId = id;
            finalDefinition.settings = definition.settings;
            finalDefinition.devPath = devPath;
            finalDefinition.lang = language;
            container.widgetDefinitions = [item];
            page.widgetRefs = [{
                    id: id,
                    byRef: !!finalDefinition.isPublished
                }];
            var response = new c.OperationResponse();
            response.content = container;
            return response;
        };
        ContainerService.prototype.initDev = function (deferred, loadStartPage) {
            var _this = this;
            lm.Log.setDebug();
            // TODO Better solution for changing the context root in dev mode?
            c.Constants.restRoot = "";
            var devData = c.ClientConfiguration.dev.devData;
            var promises = [];
            var widgetId = devData.widgetId;
            if (widgetId) {
                var definitionPath = widgetId + "/widget.manifest";
                promises.push(this.downloadFile(definitionPath, devData.propWidgetDefinition, devData));
            }
            if (devData.settingsPath) {
                promises.push(this.downloadFile(devData.settingsPath, devData.propSettings, devData));
            }
            if (devData.customDefinitionPath) {
                promises.push(this.downloadFile(devData.customDefinitionPath, devData.propCustomDefinition, devData));
            }
            if (devData.configurationPath) {
                promises.push(this.downloadFile(devData.configurationPath, devData.propConfiguration, devData));
            }
            var promise = this.q.all(promises);
            promise.then(function (result) {
                _this.onResponse(_this.loadDevContainer(widgetId, devData), loadStartPage);
                deferred.resolve(_this.pageContainer);
            }, function (error) {
                _this.createErrorContainer("Failed to load page container of one of the configured attributes.");
                deferred.resolve(_this.pageContainer);
            });
        };
        ContainerService.prototype.downloadFile = function (path, propertyName, devObj) {
            var _this = this;
            var uri = path + "?rid=" + lm.CommonUtil.random();
            var deferred = this.q.defer();
            this.http.get(uri).then(function (response) {
                devObj[propertyName] = response.data;
                deferred.resolve();
            }, function () {
                _this.error("Failed to download " + uri);
                deferred.resolve();
            });
            return deferred.promise;
        };
        ContainerService.prototype.createErrorContainer = function (message) {
            this.pageContainer = new PageContainer(this.context, null, this.pageService, this.dialogService, this.q, this.widgetService, this.language, this.progressService);
            this.pageContainer.errorMessage = message;
        };
        ContainerService.prototype.onResponse = function (response, loadStartPage) {
            var _this = this;
            var containerData = response.content;
            if (containerData) {
                if (!this.isDev) {
                    lm.Log.level = lm.ArrayUtil.itemByProperty(containerData.userSettings, "name", "LogLevel").value;
                }
                this.info("Loaded page container");
                this.dataservice.startPing(containerData.pingInterval);
                var definitions = containerData.widgetDefinitions;
                if (definitions) {
                    for (var _i = 0; _i < definitions.length; _i++) {
                        var definition = definitions[_i];
                        this.widgetService.addDefinitionItem(definition);
                    }
                }
                // Set sort order from IPage to IPageData. 
                // This is a temporary change, the sortOrder property should be completely moved to IPage since IPageData is shared for published pages.
                var pages = containerData.pages;
                if (pages) {
                    for (var _a = 0; _a < pages.length; _a++) {
                        var page = pages[_a];
                        var data = page.data;
                        if (data) {
                            data.sortOrder = page.sortOrder;
                        }
                    }
                }
                // Initialize context
                this.context.init(containerData, this.getContainerUrl());
                var container = new PageContainer(this.context, containerData, this.pageService, this.dialogService, this.q, this.widgetService, this.language, this.progressService, this.editModeService, loadStartPage);
                container.context.isDev = this.isDev;
                container.changed().on(function () {
                    _this.onChanged();
                });
                this.pageContainer = container;
            }
            else {
                var message = "Received empty page container";
                this.createErrorContainer(message);
                this.error(message);
            }
        };
        ContainerService.prototype.getContainerUrl = function () {
            // Check the location for an xfo parameter from Ming.le
            // If that is set return it
            var xfoParameter = this.location.search().xfo;
            if (xfoParameter) {
                this.info("Using ContainerUrl " + xfoParameter);
                return xfoParameter;
            }
            // If no parameter is present use the homepages application
            var homepagesUrl = this.location.protocol() + "://" + this.location.host();
            // Not including port since I don't think that we will use it
            this.info("Using ContainerUrl" + homepagesUrl);
            return homepagesUrl;
        };
        ContainerService.prototype.onChanged = function () {
            this.debug("Change detected");
        };
        ContainerService.add = function (m) {
            m.service("lmContainerService", ContainerService);
        };
        ContainerService.$inject = ["$location", "$q", "lmContextService", "lmDataService", "lmWidgetService", "lmPageService", "lmDialogService", "lmLanguageService", "lmEditModeService", "lmProgressService", "$http"];
        return ContainerService;
    })(c.CoreBase);
    var PageService = (function (_super) {
        __extends(PageService, _super);
        function PageService(q, dataService, cacheService) {
            _super.call(this, "[PageService] ");
            this.q = q;
            this.dataService = dataService;
            this.cacheService = cacheService;
            this.pageListCache = this.cacheService.createCache(c.Constants.clientCachePages);
        }
        PageService.add = function (m) {
            m.service("lmPageService", PageService);
        };
        PageService.prototype.createPrivate = function (page) {
            var request = { content: page };
            return this.dataService.executePost("/page/private/create", request);
        };
        PageService.prototype.update = function (page) {
            if (c.ClientConfiguration.isDev()) {
                c.ClientConfiguration.dev.save();
                this.debug("Saved page in dev mode");
                return this.q.when({ content: "" });
            }
            var request = { content: page };
            return this.dataService.executePost("/page/update", request);
        };
        PageService.prototype.updateSettings = function (page) {
            var request = { content: page };
            return this.dataService.executePost("/page/settings/update", request);
        };
        PageService.prototype.delete = function (id) {
            this.pageListCache.isValid = false;
            var request = { content: id };
            return this.dataService.executePost("/page/delete", request);
        };
        PageService.prototype.getPublished = function (id) {
            return this.dataService.executePost("/page/published", { content: id });
        };
        PageService.prototype.getPublishedExtended = function (pageId) {
            return this.dataService.executePost("/page/published/extended", { content: pageId });
        };
        PageService.prototype.listPublished = function (reload) {
            var _this = this;
            var deferred = this.q.defer();
            if (!this.pageListCache.isValid || reload) {
                this.dataService.executePost("/page/published/list", {}).then(function (response) {
                    _this.cacheService.updateCache(_this.pageListCache, response, deferred);
                }, function (response) {
                    _this.pageListCache.isValid = false;
                    deferred.reject(response);
                });
            }
            else {
                deferred.resolve(this.pageListCache.cachedResponse);
            }
            return deferred.promise;
        };
        PageService.prototype.updatePublished = function (page) {
            this.pageListCache.isValid = false;
            return this.dataService.executePost("/page/published/update", { content: page });
        };
        PageService.prototype.deletePublished = function (pages) {
            return this.dataService.executePost("/page/published/delete", { content: pages });
        };
        PageService.prototype.addConnection = function (id, asTemplate, sortOrder, templateTitle) {
            var request = { pageId: id, asTemplate: asTemplate, templateTitle: templateTitle, sortOrder: sortOrder };
            return this.dataService.executePost("/page/connection/add", request);
        };
        PageService.prototype.reorderConnections = function (pages) {
            return this.dataService.executePost("/page/connection/reorder", { content: pages });
        };
        PageService.prototype.updateConnectionSettings = function (pageId, settings) {
            var request = { content: { pageId: pageId, settings: settings } };
            return this.dataService.executePost("/page/connection/settings/update", request);
        };
        PageService.prototype.removeConnection = function (id) {
            return this.dataService.executePost("/page/connection/remove", { content: id });
        };
        /*
         * Forwards errors to DataService error handler.
         */
        PageService.prototype.handleError = function (response, message) {
            this.dataService.handleError(response, message);
        };
        PageService.prototype.getPreview = function (pageId) {
            return this.dataService.executePost("/page/published/preview", { content: pageId });
        };
        /**
         * Invalidates the Page cache.
         */
        PageService.prototype.invalidatePageCache = function () {
            if (this.pageListCache) {
                this.pageListCache.isValid = false;
            }
        };
        PageService.$inject = ["$q", "lmDataService", "lmCacheService"];
        return PageService;
    })(c.CoreBase);
    var ContextService = (function () {
        function ContextService(q, http, progressService, dataservice, commonDataService) {
            this.progressService = progressService;
            this.context = new Context(q, http, progressService, dataservice, commonDataService);
        }
        ContextService.prototype.getContext = function () {
            return this.context;
        };
        ContextService.add = function (m) {
            m.service("lmContextService", ContextService);
        };
        ContextService.$inject = ["$q", "$http", "lmProgressService", "lmDataService", "lmCommonDataService"];
        return ContextService;
    })();
    var EditModeService = (function () {
        function EditModeService(rootScope) {
            this.rootScope = rootScope;
            this.startedEvent = new c.InstanceEvent();
            this.stoppedEvent = new c.InstanceEvent();
            this.changedEvent = new c.InstanceEvent();
            this.modes = [];
        }
        EditModeService.prototype.updateMode = function () {
            var mode = this.getCurrent();
            this.rootScope["lmEditMode"] = mode;
        };
        EditModeService.prototype.start = function (options) {
            var mode = options;
            mode.isActive = true;
            this.modes.push(mode);
            this.updateMode();
            this.startedEvent.raise(mode);
            this.changedEvent.raise(mode);
        };
        EditModeService.prototype.isActive = function () {
            var current = this.getCurrent();
            return (current && current.isActive) === true;
        };
        EditModeService.prototype.stop = function (options) {
            var mode = this.modes.pop();
            if (mode) {
                mode.isSave = options.isSave;
                mode.result = options.result;
                this.updateMode();
                this.stoppedEvent.raise(mode);
                this.changedEvent.raise(mode);
            }
        };
        EditModeService.prototype.isMode = function (mode) {
            var current = this.getCurrent();
            return (current && current.mode == mode) === true;
        };
        EditModeService.prototype.containsMode = function (mode) {
            // Check if the mode exists anywhere in the mode stack
            var modes = this.modes;
            for (var i = 0; i < modes.length; i++) {
                if (modes[i].mode == mode) {
                    return true;
                }
            }
            return false;
        };
        EditModeService.prototype.getCurrent = function () {
            return this.modes.length > 0 ? this.modes[this.modes.length - 1] : null;
        };
        EditModeService.prototype.started = function () {
            return this.startedEvent;
        };
        EditModeService.prototype.stopped = function () {
            return this.stoppedEvent;
        };
        EditModeService.prototype.changed = function () {
            return this.changedEvent;
        };
        EditModeService.add = function (m) {
            m.service("lmEditModeService", EditModeService);
        };
        EditModeService.$inject = ["$rootScope"];
        return EditModeService;
    })();
    var ContentImportCtrl = (function (_super) {
        __extends(ContentImportCtrl, _super);
        function ContentImportCtrl(scope, dataService) {
            _super.call(this, "[ContentImportCtrl] ");
            this.scope = scope;
            this.dataService = dataService;
            this.dialog = null;
            var dialog = scope["lmDialog"];
            if (!dialog) {
                this.error("lmDialog is not found in scope when opening admin import dialog");
                return;
            }
            var dialogParam = dialog.parameter;
            this.options = dialogParam;
            this.acceptFileExtension = dialogParam.acceptFileExtension || ".zip";
            this.dialog = dialog;
        }
        ContentImportCtrl.prototype.close = function () {
            this.dialog.close({ button: lm.DialogButtonType.Cancel });
        };
        ContentImportCtrl.prototype.import = function (files) {
            if (!files) {
                this.debug("No file was selected");
                return;
            }
            var dialog = this.dialog;
            this.dataService.upload(this.options.url, this.options.operation, files).then(function (response) {
                dialog.close({ button: lm.DialogButtonType.Yes, value: { message: response, responseCode: c.DialogResponseCode.Success } });
            }, function (r) {
                var errorMsg = "";
                if (r.errorList) {
                    angular.forEach(r.errorList, function (error) {
                        errorMsg += error.message;
                    });
                }
                dialog.close({ button: lm.DialogButtonType.Yes, value: { message: errorMsg, responseCode: c.DialogResponseCode.Fail } });
            });
        };
        ContentImportCtrl.add = function (m) {
            m.controller("lmContentImportCtrl", ContentImportCtrl);
        };
        ContentImportCtrl.$inject = ["$scope", "lmDataService"];
        return ContentImportCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        ContextService.add(m);
        PageService.add(m);
        ContainerService.add(m);
        PageNavigatorCtrl.add(m);
        PageContainerCtrl.add(m);
        PageNavigatorDirective.add(m);
        PageDirective.add(m);
        PageContainerDirective.add(m);
        ContentImportCtrl.add(m);
        EditModeService.add(m);
    };
});
//# sourceMappingURL=container.js.map