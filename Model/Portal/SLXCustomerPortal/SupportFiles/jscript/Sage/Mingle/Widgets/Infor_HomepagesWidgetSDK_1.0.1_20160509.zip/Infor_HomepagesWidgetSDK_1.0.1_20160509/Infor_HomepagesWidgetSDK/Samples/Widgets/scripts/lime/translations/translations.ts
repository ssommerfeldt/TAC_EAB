﻿import lm = require("../lime");
import c = require("../core");

interface ITranslationEntity {
	language?: string;
	title?: string;
	defaultTitle?: string;
	description?: string;
	defaultDescription?: string;
	isWidget?: boolean;
}

class TranslationsCtrl extends c.CoreBase {
	private localization: c.ILocalizationParameter;
	private hasTranslations: boolean;
	private languages: c.IStringMap;
	private langsLength: number;
	private addedLangsLength: number;
	private isEditDialogOpen: boolean;

	private lang: ILanguageLime;
	static $inject = ["$scope", "lmContextService", "lmDialogService", "lmLanguageService", "lmCommonDataService"];

	constructor(public scope: any, private contextService: c.IContextService, private dialogService: lm.IDialogService, languageService: c.ILanguageService, private commonDataService: c.ICommonDataService) {
		super("[TranslationsCtrl] ");
		this.lang = languageService.getLanguage();
		this.getLocalization();
	}

	public showAdd(translation?: ITranslationEntity) {
		this.getLocalization();
		if (!translation) {
			translation = {};
		}
		translation.isWidget = this.localization.isWidget;
		translation.defaultTitle = this.localization.defaultLocalization.title;
		translation.defaultDescription = this.localization.defaultLocalization.description;
		this.showDialog(translation);
	}

	private getLocalization(): void {
		var localization = <c.ILocalizationParameter>this.scope["localization"];
		if (!localization.localizationMap) {
			lm.Log.debug("localization is not set on scope");
		} else {
			this.hasTranslations = !$.isEmptyObject(localization.localizationMap);
		}
		this.localization = localization;
	}

	private getLanguages(translation: ITranslationEntity) {
		var self = this;
		this.commonDataService.listLanguages().then((response: c.ILanguagueResponse) => {
			self.languages = response.content;
			self.langsLength = Object.keys(self.languages).length;
			self.showDialog(translation);
		}, (r: c.IOperationResponse) => { this.commonDataService.handleError(r); });
	}

	private setDefault(languages: c.IStringMap): void {
		const defaultLanguage = this.contextService.getContext().settings.getDefaultLanguage();
		for (let language in languages) {
			if (language === defaultLanguage) {
				const name = languages[language];
				languages[language] = name + " *";
			}
		}
	}

	private showDialog(translation: ITranslationEntity) {
		if (lm.CommonUtil.isUndefined(this.languages)) {
			this.getLanguages(translation);
			return;
		}
		const langCopy = angular.copy(this.languages);
		this.setDefault(langCopy);
		if (lm.CommonUtil.isUndefined(translation.language)) {
			for (let lang in this.localization.localizationMap) {
				delete langCopy[lang];
			}
		}
		const options = <lm.IDialogOptions>{
			title: translation.language ? this.lang.editTranslation : this.lang.addTranslation,
			templateUrl: "scripts/lime/templates/add-translation.html",
			style: "width: 100%; max-width: 370px;",
			parameter: { translation: translation, languages: langCopy }
		};
		var self = this;
		this.dialogService.show(options).then((r: lm.IDialogResult) => {
			this.isEditDialogOpen = false;
			if (r.value) {
				const item = <ITranslationEntity>r.value;
				self.addOrUpdateTranslation(item, translation);
				self.hasTranslations = true;
			}
		});
	}

	public showEdit(language: string) {
		this.getLocalization();
		if (!this.isEditDialogOpen) {
			var translation = <ITranslationEntity>{
				defaultTitle: this.localization.defaultLocalization.title,
				defaultDescription: this.localization.defaultLocalization.description,
				isWidget: this.localization.isWidget
			};
			angular.extend(translation, this.localization.localizationMap[language]);
			if (translation.title) {
				translation.language = language;
				this.isEditDialogOpen = true;
				this.showDialog(translation);
			}
		}
	}

	public delete(language: string) {
		delete this.localization.localizationMap[language];
		this.hasTranslations = !$.isEmptyObject(this.localization.localizationMap);
		this.addedLangsLength = Object.keys(this.localization.localizationMap).length;
	}

	private addOrUpdateTranslation(newItem: ITranslationEntity, oldItem?: ITranslationEntity) {
		if (oldItem && newItem.language !== oldItem.language) {
			this.delete(oldItem.language);
		}
		this.localization.localizationMap[newItem.language] = { title: newItem.title, description: newItem.description };
		this.addedLangsLength = Object.keys(this.localization.localizationMap).length;
	}

	static add(m: ng.IModule) {
		m.controller("lmTranslationsCtrl", TranslationsCtrl);
	}
}

interface IAddTranslationScope extends ng.IScope {
	data: any;
	languages: c.IStringMap;
	translation: ITranslationEntity;
	buttonText: string;
}

class AddTranslationCtrl extends c.CoreBase {
	isAdd: boolean;
	private dialog: lm.IDialog = null;

	private titleLength;
	private descriptionLength;

	static $inject = ["$scope"];

	constructor(public scope: IAddTranslationScope) {
		super("[AddTranslationCtrl] ");
		var dialog: lm.IDialog = scope["lmDialog"];
		this.dialog = dialog;
		scope.data = { selectedLanguage: "" };
		var param = dialog.parameter;
		if (param) {
			var translation = <ITranslationEntity>angular.copy(param.translation);
			scope.translation = translation;
			var isAdd = lm.CommonUtil.isUndefined(translation.language);
			this.isAdd = isAdd;
			scope.buttonText = isAdd ? scope["lmLang"].add : scope["lmLang"].update;
			if (isAdd) {
				scope.data.selectedLanguage = translation.language;
			}
			this.loadLanguage(param.languages);

			var isWidget = translation.isWidget;
			this.titleLength = isWidget ? c.Constants.widgetTitleLength : c.Constants.pageTitleLength;
			this.descriptionLength = isWidget ? c.Constants.widgetDescriptionLength : c.Constants.pageDescriptionLength;
		}
	}

	private sortMapByValue(map: c.IStringMap): c.IStringMap {
		var array = [];
		for (var key in map) {
			array.push([key, map[key]]);
		}

		array.sort((a, b) => {
			a = a[1];
			b = b[1];

			return a < b ? -1 : (a > b ? 1 : 0);
		});

		var newMap: c.IStringMap = {};
		for (var i = 0; i < array.length; i++) {
			newMap[array[i][0]] = array[i][1];
		}
		return newMap;
	}

	private loadLanguage(map: c.IStringMap): void {
		var languages = this.sortMapByValue(map);
		var translationLanguage = this.scope.translation.language;
		var selectedLanguage = "";
		if (this.isAdd) {
			for (var lang in languages) {
				selectedLanguage = languages[lang];
				break;
			}
		} else {
			selectedLanguage = languages[translationLanguage] ? languages[translationLanguage] : translationLanguage;
		}
		this.scope.data.selectedLanguage = selectedLanguage;
		this.scope.languages = languages;
	}

	public add(): void {
		const translation = this.scope.translation;
		const selectedLanguage = this.scope.data.selectedLanguage;
		const languages = this.scope.languages;
		if (translation.title && selectedLanguage && translation.description) {
			if (this.isAdd) {
				for (var lang in languages) {
					if (selectedLanguage === languages[lang]) {
						translation.language = lang;
						break;
					}
				}
			}
			var result = { value: translation };
			this.dialog.close(result);
		}
	}

	public close(): void {
		this.dialog.close();
	}

	static add(m: ng.IModule): void {
		m.controller("lmAddTranslationCtrl", AddTranslationCtrl);
	}
}

export var init = (m: ng.IModule) => {
	TranslationsCtrl.add(m);
	AddTranslationCtrl.add(m);
};