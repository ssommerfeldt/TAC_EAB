﻿import lm = require("../lime");
import c = require("../core");
import s = require("./service");

class ErrorCtrl extends c.CoreBase {
	public errorList: any[];
	public refreshText = "Refresh";

	static $inject = ["$scope", "lmAdminContext", "lmAdminService", "lmDialogService", "lmProgressService"];

	constructor(private scope: ng.IScope, private adminContext: s.IAdminContext, private adminService: s.IAdminService,
		private dialogService: lm.IDialogService, private progressService: c.IProgressService) {
		super("[ErrorCtrl] ");

		const adminConstants = s.AdminConstants;
		const self = this;
		// Watch to see if this tab is selected
		scope.$watch(adminConstants.openTab, (tab) => {
			if (tab === adminConstants.errorsTab) {
				self.listErrors();
			}
		});
	}

	public listErrors(): void {
		const self = this;
		const adminService = self.adminService;

		adminService.setBusy(true);
		adminService.getError().then((r) => {
			const content = r.content;
			self.errorList = Object.keys(content).length > 0 ? content : [];
			adminService.setBusy(false);
		}, (r) => {
			adminService.setBusy(false);
			self.dialogService.showToast({ title: "Error", message: r.toErrorLog() });
		});
	}

	static add(m: ng.IModule) {
		m.controller("lmErrorCtrl", ErrorCtrl);
	}
}

export var init = (m: ng.IModule) => {
	ErrorCtrl.add(m);
}