﻿import lm = require("../lime");
import c = require("../core");
import s = require("./service");

class AdminContainerCtrl extends c.CoreBase {
	static $inject = ["$rootScope", "$scope", "lmAdminContext", "lmAdminService"];

	constructor(private rootScope: ng.IScope, private scope: ng.IScope, private adminContext: s.IAdminContext, private adminService: s.IAdminService) {
		super("[AdminContainerCtrl] ");

		Locale.set("en-US");

		adminService.setBusy(true);
		adminContext.initialize().then((r) => {
			this.onInitialized(r);
			adminService.setBusy(false);
		}, (r: c.IOperationResponse) => {
			adminService.setBusy(false);
			adminService.handleError(r);
		});
	}

	private onInitialized(r: s.IAdminToolResponse): void {
		this.rootScope["lmAdminTool"] = r.content;
	}
}

class AdminPageContainerDirective {
	static add(m: ng.IModule) {
		m.directive("lmAdminContainer", ["$compile", ($compile) => {
			return {
				scope: true,
				restrict: "E",
				replace: true,
				controller: AdminContainerCtrl,
				templateUrl: "scripts/lime/admin/templates/admin.html",
				link: (scope: ng.IScope, element: ng.IAugmentedJQuery, attributes: ng.IAttributes, controller: any, transclude: ng.ITranscludeFunction) => {
					lm.CommonUtil.detectBrowser();
				}
			};
		}]);
	}
}

export var init = (m: ng.IModule) => {
	AdminPageContainerDirective.add(m);
};