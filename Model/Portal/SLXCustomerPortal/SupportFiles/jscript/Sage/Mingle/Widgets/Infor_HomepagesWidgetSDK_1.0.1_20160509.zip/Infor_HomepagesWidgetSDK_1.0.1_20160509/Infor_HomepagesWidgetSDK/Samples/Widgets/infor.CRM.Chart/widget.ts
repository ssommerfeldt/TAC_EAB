﻿/**
 * NOTE:
 * A custom settings UI shall only be implemented if settings are dynamic, for instance based on data retrieved from a server.
 * Or if the settings structure is complicated, and not possible to handle using supported metadata setting types (string, boolean, number, selector).
 * For other cases, use metadata settings handled by the default settings UI.
**/
/// <reference path="../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../scripts/typings/lime/lime.d.ts" />

/// <reference path="../scripts/typings/sohoxi/sohoxi.d.ts" />
import lm = require("lime");
declare var $: any;
class inforCRMChartMainCtrl {
    private content: JQuery;
    private item: JQuery;
    private language: lm.ILanguage;
    private chartDiv;
    private widgetContext: lm.IWidgetContext;
    private widgetInstanceId: string;
    private chartOptions;
    private defText = false;
    private textValue: string;
    private dateTime: string;
    
    // Use the $inject array to avoid issues with minification
    static $inject = ["$scope"];

    public showSettingsDialog(): void {
        this.widgetContext.getSettings().showSettings();
    }
    constructor(public scope: ng.IScope) {
        // Get the widget context and the widget instance that are made available on the scope by the framework
        this.widgetContext = scope[lm.WidgetConstants.widgetContextKey];
        const widgetInstance: lm.IWidgetInstance = scope[lm.WidgetConstants.widgetInstanceKey];
        const settings = this.widgetContext.getSettings();
        this.widgetInstanceId = this.widgetContext.getWidgetInstanceId();
        console.log('widget Instance Id - Main: ' + this.widgetInstanceId);
        var date = new Date();
        this.dateTime = date.getTime().toString();
        
        // Callback triggered from Framework when settings are saved
        widgetInstance.settingsSaved = (saveArg: lm.IWidgetSettingsArg) => {
            this.setContent();
        }

        widgetInstance.widgetSettingsFactory = (settingsContext: lm.IWidgetSettingsContext): lm.IWidgetSettingsInstance => {
            var instance: lm.IWidgetSettingsInstance = {};

            instance.angularConfig = {
                relativeTemplateUrl: "settings.html",
                // Pass the settings instance to settings scope so that its closing() callback can be set from the Settings Controller (in which settings are persisted if called by Save button)
                // Pass the settings context to settings scope from which the widget context also can be retrieved
                scopeValue: { name: "settingsData", value: { settingsContext: settingsContext, settingsInstance: instance } }
            }

            return instance;
        }

        // Get the language object from the widget context.
        this.language = this.widgetContext.getLanguage();

        this.setContent();
    }

    private setContent() {
        var settings = this.widgetContext.getSettings();
        var entity = settings.get("entity");
        var group = settings.get("group");
        var filter = settings.get("filter");
        var metric = settings.get("metric");
        var chartType = settings.get<string>("chartType");
        var limitCount = settings.get("limitCount");
        if (entity && group && filter && metric && chartType && limitCount) {
            var context = this;
            this.setBusy(true);
            var analyticsUrl = '/CustomerApi/CRM/SDataMingle/slx/system/-/groups(name eq "{0}")/$queries/executeMetric?format=json&_filterName={1}&_metricName={2}&limit={3}&count={4}&_t={5}';
            analyticsUrl = this.format([analyticsUrl, group, filter, metric, limitCount, limitCount, this.dateTime]);
            const analyticsReq = this.createRequest(encodeURI(analyticsUrl));
            analyticsReq.withCredentials = true;
            this.widgetContext.executeIonApiAsync(analyticsReq).then((response) => {
                var data = response.data['$resources'];
                if (data.length == 0) {
                    context.textValue = context.language['noData'];
                    context.setBusy(false);
                }
                else {
                    var items = [];
                    for (var i = 0; i < data.length; i++) {
                        var item = { 'name': data[i].$descriptor, 'value': data[i].value };
                        items.push(item);
                    };
                    var info = [{
                        data: items
                    }];
                    context.chartOptions = {
                        type: chartType.charAt(0).toLowerCase() + chartType.slice(1),
                        dataset: info
                    }
                    context.defText = true;
                    context.setBusy(false);
                    //scope.$apply();
                }

            }, (error) => { this.onRequestError(error); });
        }
        else {
            this.textValue = this.language['notConfigured'];
        }
    }

    public static add(m: ng.IModule) {
        m.controller("inforCRMChartMainCtrl", inforCRMChartMainCtrl);
    }

    private format(args: any): string {
        var s = args[0];
        for (var i = 0; i < args.length - 1; i++) {
            var reg = new RegExp("\\{" + i + "\\}", "gm");
            s = s.replace(reg, args[i + 1]);
        }
        return s;
    }

    private setBusy(isBusy: boolean): void {
        this.widgetContext.setState(isBusy ? lm.WidgetState.busy : lm.WidgetState.running);
    }

    private onRequestError(error: any): void {
        this.textValue = this.language['errorOccured'];
        this.setBusy(false);

        console.log("Failed to call ION API: " + error);
    }

    private createRequest(url): lm.IIonApiRequestOptions {
        const request: lm.IIonApiRequestOptions = {
            method: "GET",
            url: url,
            cache: false,
            headers: {
                "Accept": "application/json"
            }
        }
        return request;
    }
}

class CustomSettingsCtrl {
    private widgetTitle: string;
    private titleEditEnabled: boolean;
    private repeatSelect: string;
    static $inject = ["$scope"];
    private widgetContext: any;
    private entityValue: string;
    private groupValue: string;
    private dimensionValue: string;
    private metricValue: string;
    private chartValue: string;
    private limitCount: string;
    private widgetInstanceId: string;
    private widgetSettings: lm.IWidgetSettings;
    private language: lm.ILanguage;
    private isEntityBusy: Boolean;
    private isGroupBusy: Boolean;
    private isFilterBusy: Boolean;
    private isMetricBusy: Boolean;

    //Dropdowns
    private dropdownOptions: xi.IDropDownOptions;
    private entityDropdownOptions: xi.IDropDownOptions;
    private groupDropdownOptions: xi.IDropDownOptions;
    private filterDropdownOptions: xi.IDropDownOptions;
    private metricDropdownOptions: xi.IDropDownOptions;

    private entityOptions: string[];
    private groupOptions: string[];
    private filterOptions: string[];
    private metricOptions: string[];
    private chartOptions: string[];
    private textValue: string;
    private dateTime: string;
    private textTitle: string;
    private textEntity: string;
    private textGroup: string;
    private textDimension: string;
    private textMetric: string;
    private textType: string;
    private textLimit: string;

    constructor(public scope: ng.IScope) {
        $('body').initialize('en-US');
        this.isEntityBusy = true;
        this.repeatSelect = null;

        // Get instance and context from the scope property defined in Settings factory
        const settingsInstance: lm.IWidgetSettingsInstance = scope["settingsData"].settingsInstance;
        const settingsContext: lm.IWidgetSettingsContext = scope["settingsData"].settingsContext;
        this.widgetContext = settingsContext.getWidgetContext();
        this.widgetInstanceId = this.widgetContext.getWidgetInstanceId();
        console.log('widget Instance Id - Settings: ' + this.widgetInstanceId);
        this.widgetSettings = this.widgetContext.getSettings();
        this.widgetTitle = this.widgetContext.getTitle() || this.widgetContext.getStandardTitle();
        this.titleEditEnabled = this.widgetContext.isTitleEditEnabled();
        var context = this;
        var date = new Date();
        this.dateTime = date.getTime().toString();
        this.language = this.widgetContext.getLanguage();

        //Labels text
        this.textTitle = this.language['titleText'] || "Title";
        this.textEntity = this.language['textEntity'] || "Entity";
        this.textGroup = this.language['textGroup'] || "Group";
        this.textDimension = this.language['textDimension'] || "Dimension";
        this.textMetric = this.language['textMetric'] || "Metric";
        this.textType = this.language['textType'] || "Type";
        this.textLimit = this.language['textLimit'] || "Limit";

        // Callback triggered from Framework when Configure dialog is about to be closed
        settingsInstance.closing = (closingArg: lm.IWidgetSettingsCloseArg) => {
            if (closingArg.isSave) {
                this.widgetContext.getSettings().set("entity", context.entityValue);
                this.widgetContext.getSettings().set("title", context.widgetTitle);
                this.widgetContext.setTitle(context.widgetTitle);
                this.widgetContext.getSettings().set("group", context.groupValue);
                this.widgetContext.getSettings().set("filter", context.dimensionValue);
                this.widgetContext.getSettings().set("metric", context.metricValue);
                this.widgetContext.getSettings().set("chartType", context.chartValue);
                this.widgetContext.getSettings().set("limitCount", context.limitCount);
            }
        }
        //Populate the dropdowns
        this.chartOptions = ["Bar", "Column", "Donut", "Line", "Pie"];
        var value = context.widgetContext.getSettings().get("chartType");
        if (value) {
            this.chartValue = value;
        }

        value = context.widgetContext.getSettings().get("limitCount");
        if (value) {
            this.limitCount = value;
        }

        //begin
        context.entityDropdownOptions = null;
        var entityUrl = '/CustomerApi/CRM/SDataMingle/slx/metadata/-/entities?startIndex=0&count=300&where=filters.analyticsAvailable eq true and filters.filterType eq \'analyticsMetric\'&select=name,displayName,tableName&orderBy=$descriptor&format=json&_t={0}';
        entityUrl = context.format([entityUrl, this.dateTime]);
        const entityReq = this.createRequest(encodeURI(entityUrl));
        entityReq.withCredentials = true;
        this.widgetContext.executeIonApiAsync(entityReq).then((response) => {
            var data = response.data.$resources;
            var options = [];
            for (var i = 0; i < data.length; i++) {
                options.push(data[i].$descriptor);
            };
            context.entityOptions = options;

            var value = context.widgetContext.getSettings().get("entity");
            if (value) {
                context.entityValue = value;
            }
            if (this.entityDropdownOptions) {
                this.entityDropdownOptions = null;
            } else {
                this.entityDropdownOptions = {};
            }
            context.isEntityBusy = false;
        }, (error) => { this.onRequestError(error); });


        
        this.entityChanged();

        //end

    }

    private onRequestError(error: any): void {
        this.textValue = this.language['errorOccured'];
        //this.setBusy(false);
        this.isEntityBusy = false;
        this.isGroupBusy = false;
        this.isFilterBusy = false;
        this.isMetricBusy = false;
        console.log("Failed to call ION API: " + error);
    }

    private createRequest(url): lm.IIonApiRequestOptions {
        const request: lm.IIonApiRequestOptions = {
            method: "GET",
            url: url,
            cache: false,
            headers: {
                "Accept": "application/json"
            }
        }
        return request;
    }

    private setBusy(isBusy: boolean): void {
        this.widgetContext.setState(isBusy ? lm.WidgetState.busy : lm.WidgetState.running);
    }

    public static add(m: ng.IModule) {
        m.controller("CustomSettingsCtrl", CustomSettingsCtrl);
    }

    private entityChanged = function () {
        console.log('entityChanged');
        var context = this;
        var dateTime = this.dateTime;
        var value = this.entityValue || this.widgetContext.getSettings().get("entity");
        if (!value) {
            console.log('entityValue is undefined');
            return;
        }
        context.isGroupBusy = true;
        context.isFilterBusy = true;
        context.isMetricBusy = true;

        context.groupDropdownOptions = null;
        context.filterDropdownOptions = null;
        context.metricDropdownOptions = null;

        var groupsUrl = '/CustomerApi/CRM/SDataMingle/slx/system/-/groups?startIndex=0&count=300&where=upper(family) eq upper(\'{0}\')&select=name,displayName&orderBy=name&format=json&_t={1}';
        groupsUrl = context.format([groupsUrl, value, dateTime]);
        const groupsReq = this.createRequest(encodeURI(groupsUrl));
        groupsReq.withCredentials = true;
        this.widgetContext.executeIonApiAsync(groupsReq).then((response) => {
            var data = response.data.$resources;
            var options = [];
            for (var i = 0; i < data.length; i++) {
                options.push(data[i].name);
            };
            context.groupOptions = options;//Options

            var value = context.widgetContext.getSettings().get("group");
            context.groupValue = value;//selected value

            if (context.groupDropdownOptions) {
                context.groupDropdownOptions = null;
            } else {
                context.groupDropdownOptions = {};
            }
            context.isGroupBusy = false;
        }, (error) => { this.onRequestError(error); });


        var filtersUrl = '/CustomerApi/CRM/SDataMingle/slx/metadata/-/entities("{0}")/filters?startIndex=0&count=300&where=analyticsAvailable and filterType ne \'analyticsMetric\'&select=filterName,displayName,analyticsDescription&orderBy=filterName&format=json&_t={1}';
        filtersUrl = context.format([filtersUrl, value, dateTime]);
        const filtersReq = this.createRequest(encodeURI(filtersUrl));
        filtersReq.withCredentials = true;
        this.widgetContext.executeIonApiAsync(filtersReq).then((response) => {
            var data = response.data.$resources;
            var options = [];
            for (var i = 0; i < data.length; i++) {
                options.push(data[i].filterName);
            };
            context.filterOptions = options;//Options

            var value = context.widgetContext.getSettings().get("filter");
            context.dimensionValue = value;//selected value

            if (context.filterDropdownOptions) {
                context.filterDropdownOptions = null;
            } else {
                context.filterDropdownOptions = {};
            }
            context.isFilterBusy = false;
        }, (error) => { this.onRequestError(error); });

        var metricsUrl = '/CustomerApi/CRM/SDataMingle/slx/metadata/-/entities("{0}")/filters?_compact=true&startIndex=0&count=300&where=analyticsAvailable and filterType eq \'analyticsMetric\'&select=filterName,displayName,analyticsDescription&orderBy=filterName&format=json&_t={1}';
        metricsUrl = context.format([metricsUrl, value, dateTime]);
        const metricsReq = this.createRequest(encodeURI(metricsUrl));
        metricsReq.withCredentials = true;
        this.widgetContext.executeIonApiAsync(metricsReq).then((response) => {
            var data = response.data.$resources;
            var options = [];
            for (var i = 0; i < data.length; i++) {
                options.push(data[i].filterName);
            };
            context.metricOptions = options;//Options

            var value = context.widgetContext.getSettings().get("metric");
            context.metricValue = value;//selected value

            if (context.metricDropdownOptions) {
                context.metricDropdownOptions = null;
            } else {
                context.metricDropdownOptions = {};
            }
            context.isMetricBusy = false;
        }, (error) => { this.onRequestError(error); });

        
    };

    private format(args: any): string {
        var s = args[0];
        for (var i = 0; i < args.length - 1; i++) {
            var reg = new RegExp("\\{" + i + "\\}", "gm");
            s = s.replace(reg, args[i + 1]);
        }
        return s;
    }
}

// Widget factory function
export var widgetFactory = (context: lm.IWidgetContext): lm.IWidgetInstance => {

    var m = context.getAngularContext().module;
    // Add controllers to the provided AngularJS module
    inforCRMChartMainCtrl.add(m);
    CustomSettingsCtrl.add(m);

    // Create and return the widget instance
    var instance: lm.IWidgetInstance = {
        angularConfig: <lm.IAngularWidgetConfig>{
            relativeTemplateUrl: "widget.html"
        }
    };
    return instance;
};