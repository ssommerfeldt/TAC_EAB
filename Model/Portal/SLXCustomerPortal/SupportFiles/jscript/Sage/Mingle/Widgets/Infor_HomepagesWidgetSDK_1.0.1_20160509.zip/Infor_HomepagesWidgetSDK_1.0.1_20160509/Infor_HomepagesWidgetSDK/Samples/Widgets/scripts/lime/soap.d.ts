export interface ISoapElement {
    getName(): string;
    getValue(): any;
    setValue(value: any): ISoapElement;
    getAttribute(name: string): string;
    setAttribute(name: string, value: string): void;
    getAttributes(): any;
    addNamespace(name: string, url: string): void;
    appendChild(obj: any): void;
    newChild(name: string): ISoapElement;
    addParameter(name: string, value: string): ISoapElement;
    getChildren(): any;
    hasChildren(): boolean;
    find(name: string): ISoapElement;
    toString(): string;
}
export interface ISoapEnvelope {
    addAttribute(name: string, value: any): void;
    addNamespace(name: string, uri: string): void;
    addHeader(element: ISoapElement): void;
    addBody(element: ISoapElement): void;
    toString(): string;
}
export interface ISoapRequest {
}
export interface ISoapResponse {
}
export interface ISoapService {
    execute(request: ISoapRequest): ng.IPromise<ISoapResponse>;
}
export interface ISoapVersion {
    contentType: string;
    namespaceUri: string;
}
export declare class SoapConstants {
    static xml: string;
    static xsi: string;
    static xsd: string;
    static soap11: ISoapVersion;
    static soap12: ISoapVersion;
    static entityMap: {
        "<": string;
        ">": string;
        "&": string;
        "\"": string;
        "'": string;
    };
}
export declare class SoapElement implements ISoapElement {
    private name;
    className: string;
    private parent;
    private attributes;
    private namespaces;
    private children;
    private value;
    constructor(name: string);
    getName(): string;
    getValue(): any;
    setValue(value: any): ISoapElement;
    getAttributes(): any;
    getAttribute(name: string): string;
    setAttribute(name: string, value: string): void;
    addNamespace(name: string, url: string): void;
    appendChild(child: any): void;
    newChild(name: string): ISoapElement;
    addParameter(name: string, value: any): ISoapElement;
    getChildren(): any;
    hasChildren(): boolean;
    find(name: string): ISoapElement;
    toString(): string;
}
export declare class SoapEnvelope implements ISoapEnvelope {
    className: string;
    private prefix;
    private soapVersion;
    private attributes;
    private headers;
    private bodies;
    constructor(element: ISoapElement);
    addAttribute(name: string, value: any): void;
    addNamespace(name: string, uri: string): void;
    addHeader(element: ISoapElement): void;
    addBody(element: ISoapElement): void;
    toString(): string;
}
