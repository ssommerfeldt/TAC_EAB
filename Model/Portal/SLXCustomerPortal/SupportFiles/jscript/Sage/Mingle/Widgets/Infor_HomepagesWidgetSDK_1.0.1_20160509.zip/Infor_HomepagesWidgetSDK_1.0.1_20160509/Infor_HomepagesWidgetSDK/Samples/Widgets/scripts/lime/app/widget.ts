﻿import lm = require("../lime");
import c = require("../core");
import container = require("../app/container");

export class Widget extends c.CoreBase implements c.IWidget {
	private addedEvent = new c.InstanceEvent<c.IWidget>();
	private changedEvent = new c.InstanceEvent<c.IWidget>();
	private destroyedEvent = new c.InstanceEvent<c.IWidget>();
	private removedEvent = new c.InstanceEvent<c.IWidget>();
	private restoredEvent = new c.InstanceEvent<c.IWidget>();
	private updatedEvent = new c.InstanceEvent<c.IWidget>();

	private enableSettings: boolean;
	private enableSettingsDef: boolean;
	private enableSettingsCurrent = false;
	private enableTitleEditDef = true;
	private enableSettingsMenu = true;

	id: string;

	public title;
	public definition: c.IWidgetDefinition;
	public instance: lm.IWidgetInstance;
	public widgetModule: any;
	public byRef = false;
	externalUrl: string = null;
	context: lm.IWidgetContext;
	widgetType; string;

	public elementId: string;
	public element: any;

	public state: string;
	public isVisible: boolean;
	public isEdit: boolean;
	public isSettings: boolean;

	public isTitleEditEnabled: boolean;
	public titleApi: string;
	public isDev: boolean;

	public accessLevel: c.WidgetAccessLevel;
	public standardAccessLevel: c.WidgetAccessLevel;

	/**
	* Extra information when adding a widget byRef / Copy / Duplicate etc.
	*/
	public addWidgetInfo: c.IAddWidgetInfo;

	constructor(public parentContext: c.IWidgetParentContext, public data: c.IWidgetData, private isNew: boolean, byRef: boolean) {
		super("[Widget] ");
		if (byRef) {
			this.byRef = byRef;
		}
		this.state = lm.WidgetState.running;
		this.instance = {};

		if (isNew) {
			data.instanceId = lm.CommonUtil.random();
		}
	}

	public isPublished(): boolean {
		// TODO Check why definition might not be set in some cases
		const def = this.definition;
		return def && !!def.standardWidgetId;
	}

	public isSettingsEnabled(): boolean {
		return (this.enableSettings || this.enableSettingsCurrent) && this.enableSettingsDef;
	}

	public isCatalogTitle(): boolean {
		const customWidget = this.definition.custom;
		if (customWidget) {
			return customWidget.isCatalogTitle === true;
		}
		const customItem = this.data.custom;
		if (customItem && customItem.definition) {
			return customItem.definition.isCatalogTitle === true;
		}
		return false;
	}

	public isSettingsMenuEnabled(): boolean {
		return (this.enableSettingsMenu || this.enableSettingsCurrent) && this.enableSettingsDef;
	}

	public setSettingsMenuEnabled(enabled: boolean): void {
		if (this.enableSettingsMenu !== enabled) {
			this.enableSettingsMenu = enabled;
			this.raiseUpdated();
		}
	}

	public isEnableSettingsTemporary(): boolean {
		return this.enableSettingsCurrent;
	}

	public enableSettingsTemporary(enable: boolean): void {
		if (this.enableSettingsDef) {
			this.enableSettingsCurrent = enable;
		}
	}

	public copyFrom(source: Widget): void {
		this.enableSettings = source.enableSettings;
		this.enableSettingsMenu = source.enableSettingsMenu;
		this.enableSettingsCurrent = source.enableSettingsCurrent;
		this.enableSettingsDef = source.enableSettingsDef;
		this.enableTitleEditDef = source.enableTitleEditDef;
	}

	public hasVisibleActions(): boolean {
		const actions = this.instance.actions;
		if (actions) {
			for (let action of actions) {
				if (action.isVisible !== false) {
					return true;
				}
			}
		}
		return false;
	}

	public calculateTitle(isTitleLocked: boolean): string {
		// TODO Refactor, reuse similar code if possible

		const isCatalogTitle = this.isCatalogTitle();
		const data = this.data;
		let title: string;

		if (!isCatalogTitle && isTitleLocked) {
			// A title set using the API in the current session that has the highest priority
			// A title set using the API in a previous session that has the next priority
			title = this.titleApi || data.titleApi;
			if (title) {
				return title;
			}
			return this.definition.standardTitle;
		}

		if (isCatalogTitle) {
			isTitleLocked = true;
		}


		const custom = data.custom;
		if (custom) {
			const definition = custom.definition;
			if (definition && isCatalogTitle) {
				const localization = custom.localization;
				if (localization) {
					const lang = localization[infor.lime.language];
					if (lang) {
						title = lang.title;
						if (title) {
							return title;
						}
					}
				}
				return definition.title || this.definition.standardTitle;
			}
		}

		const publishedCustom = this.definition.custom;
		if (publishedCustom) {
			if (isCatalogTitle) {
				title = this.definition.title;
				return title || this.definition.standardTitle;
			}
			if (!isTitleLocked) {
				if ((this.enableSettingsCurrent || this.isTitleEditEnabled) && data.title) {
					// Special cases when we are in Publish mode for a published widget
					// or when the user is allowed to change the title of a published widget.
					return data.title;
				}
				if (publishedCustom.title) {
					return publishedCustom.title;
				}
			}
		}

		if (!isTitleLocked) {
			title = data.title;
			if (title) {
				return title;
			}
		}

		return this.definition.standardTitle;
	}

	public updateTitle(): void {
		this.title = this.calculateTitle(this.data.isTitleLocked);
	}

	public setTitleInternal(title: string): void {
		this.data.title = title;
		this.updateTitle();
	}

	public getDefaultTitle(): string {
		return this.definition.standardTitle;
	}

	public setDefinition(sourceDefinition: c.IWidgetDefinition, addWidgetInfo: c.IAddWidgetInfo) {
		var customWidget: c.ICustomWidget = null;
		var widgetData = this.data;

		// addWidget info is extra info for adding the widget
		if (addWidgetInfo) {
			customWidget = addWidgetInfo.customWidget;
		}

		// customWidget is data and settings from duplicate widget action
		// TODO Handle settings configuration for private byCopy
		// TODO ByCopy && isNew copy settings but remove "security"

		// Copy the definition to allow local modification for the current widget
		var definition = angular.copy(sourceDefinition);
		definition.original = sourceDefinition;

		this.definition = definition;
		this.id = definition.widgetId;
		this.externalUrl = definition.url;
		this.widgetType = definition.type;

		this.accessLevel = definition.accessLevel;
		this.standardAccessLevel = definition.standardAccessLevel;

		var enableSettings = !(definition.enableSettings === false);
		this.enableSettingsDef = definition.enableSettingsDef !== false;

		var enableTitleEdit = !(definition.enableTitleEdit === false);
		this.enableTitleEditDef = definition.enableTitleEditDef !== false;

		var settingsDefinition = definition.settings;
		var byCopy = !this.byRef;
		var byRef = this.byRef;
		var isPublished = definition.isPublished;

		// For user data for published content
		var isParentPublished = this.parentContext.isPublished;
		var hasDefinitionMetadata = settingsDefinition ? true : false;

		var settingsValues = widgetData.settings || {};
		widgetData.settings = settingsValues;

		var userSettingsValues: c.IStringToAnyMap = null;
		if (isParentPublished || isPublished) {
			userSettingsValues = this.parentContext.userSettings;
		}

		// A dictionary with all editable setttings
		var editableSettings: string[] = [];

		var customMetadata: lm.IWidgetSettingMetadata[];
		if (customWidget) {
			// Set data from the passed in customWidget parameter. Used for copy.
			settingsValues = customWidget.settings;
			if (customWidget.title) {
				widgetData.title = customWidget.title;
			}
			widgetData.isTitleLocked = customWidget.isTitleLocked === true;
			widgetData.logicalId = customWidget.logicalId;
			widgetData.titleApi = customWidget.titleApi;
		}

		if (isPublished) {
			var custom = definition.custom;
			if (custom) {
				customMetadata = custom.metadata;
				settingsValues = custom.settings || {};
				widgetData.isTitleLocked = custom.isTitleLocked === true;
				widgetData.logicalId = custom.logicalId;
				widgetData.titleApi = custom.titleApi;
			}
		} else if (byCopy) {
			if (widgetData.custom) {
				var customDefinition = widgetData.custom.definition;
				if (customDefinition) {
					customMetadata = customDefinition.settings;
					if (enableSettings && customDefinition.enableSettings === false) {
						enableSettings = false;
					}
					if (enableTitleEdit && customDefinition.enableTitleEdit === false) {
						enableTitleEdit = false;
					}
				}
			} else if (isParentPublished) {
				// ByCopy widget on a published page without custom configuration -> disable settings by default.
				enableSettings = false;
				enableTitleEdit = false;
			}
		}

		var hasCustomMetadata = lm.CommonUtil.hasValue(customMetadata);
		if (hasCustomMetadata) {
			definition.customMetadata = angular.copy(customMetadata);
		}

		var baseMetadata: lm.IWidgetSettingMetadata[] = [];
		if (hasDefinitionMetadata) {
			baseMetadata = definition.settings || [];
			if (hasCustomMetadata) {
				baseMetadata = WidgetUtil.applyRestrictions(baseMetadata, customMetadata);
			}
		} else {
			if (hasCustomMetadata) {
				baseMetadata = customMetadata;
			}
		}

		var name: string = null;
		var resultMetadata: lm.IWidgetSettingMetadata[] = [];

		for (var j = 0; j < baseMetadata.length; j++) {
			var metadata = baseMetadata[j];
			if (!metadata) {
				continue;
			}
			name = metadata.name;
			var isEnabled = metadata.isEnabled !== false;
			if (isEnabled) {
				editableSettings.push(name);
			}

			var value = this.getDefaultSettingsValue(name, isEnabled, settingsValues, userSettingsValues, settingsDefinition);

			// Set the current setting by checking settingsdata, custom and definition
			settingsValues[name] = value;

			resultMetadata.push(metadata);
		}

		if (this.isNew || byRef) {
			widgetData.settings = settingsValues;
		}

		// Handle widget title for a published widget where the user is allowed to change the widget title.
		if (userSettingsValues && enableTitleEdit) {
			if (userSettingsValues["isTitleLocked"]) {
				widgetData.isTitleLocked = true;
			} else {
				widgetData.isTitleLocked = false;
				var title = userSettingsValues[lm.WidgetConstants.widgetTitle];
				if (title) {
					widgetData.title = title;
				}
			}
		}

		this.isTitleEditEnabled = enableTitleEdit;
		this.enableSettings = enableSettings;

		this.updateTitle();

		if (this.isNew && byCopy) {
			// Added by copy from widget library
			if (!definition.standardWidgetId) {
				if (definition.enableSettingsDef === true && this.standardAccessLevel === c.WidgetAccessLevel.Configure) {
					this.enableSettings = true;
				}
				if (definition.enableTitleEditDef === true) {
					this.isTitleEditEnabled = true;
				}

				// Reset the widget data id
				widgetData.id = definition.widgetId;

			}
			return;
		}

		definition.settings = resultMetadata;
	}

	private getDefaultSettingsValue(name: string, isEnabled: boolean, widgetSettings: c.IStringToAnyMap, userSettings: c.IStringToAnyMap, definitionMetaData: lm.IWidgetSettingMetadata[]): any {
		let value = null;
		if (isEnabled) {
			// Only allowed to get data from widget itself if it is enabled for editing
			if (userSettings) {
				value = userSettings[name];
			}
			if (lm.CommonUtil.hasValue(value)) {
				return value;
			}
		}

		if (widgetSettings) {
			value = widgetSettings[name];
			if (lm.CommonUtil.hasValue(value)) {
				return value;
			}
		}

		if (definitionMetaData) {
			const metadata: lm.IWidgetSettingMetadata = lm.ArrayUtil.itemByProperty(definitionMetaData, "name", name);
			if (metadata) {
				return angular.copy(metadata.defaultValue);
			}
		}
		return null;
	}

	public getUserData(): any {
		const definition = this.definition;
		const isSettingsEnabled = this.enableSettings && this.enableSettingsDef;
		if (!this.context || !definition || !isSettingsEnabled) {
			// TODO Something wrong the first time...
			return null;
		}

		let data: any = null;
		const settings = this.context.getSettings();
		const settingsMetadata = definition.settings;
		if (settingsMetadata) {
			for (let setting of settingsMetadata) {
				if (setting.isEnabled !== false) {
					if (!data) {
						data = {};
					}
					const name = setting.name;
					data[name] = settings.get(name);
				}
			}
		}

		// If title edit is enabled the widgetTitle and isTitleLocked values are stored in the user settings data object.
		if (this.isTitleEditEnabled) {
			if (!data) {
				data = {};
			}
			const isTitleLocked = this.data.isTitleLocked;
			if (!isTitleLocked) {
				data[lm.WidgetConstants.widgetTitle] = this.data.title;
			}
			data["isTitleLocked"] = isTitleLocked;
		}

		return data;
	}

	public updateSettings(triggerChanged: boolean = true) {
		const instance = this.instance;
		if (instance && instance.settingsSaved) {
			try {
				instance.settingsSaved({ settings: this.context.getSettings() });
			} catch (e) {
				this.error("Failed to invoke the settingsSaved event handler", e);
			}
		}

		if (triggerChanged) {
			this.raiseChanged();
		}
	}

	public changed(): c.InstanceEvent<c.IWidget> {
		return this.changedEvent;
	}

	public raiseChanged(): void {
		this.changedEvent.raise(this);
	}

	public remove(): void {
		this.removedEvent.raise(this);
	}

	public removed(): c.InstanceEvent<c.IWidget> {
		return this.removedEvent;
	}

	public raiseAdded() {
		this.addedEvent.raise(this);
	}

	public added(): c.InstanceEvent<c.IWidget> {
		return this.addedEvent;
	}

	public restored(): c.IInstanceEvent<c.IWidget> {
		return this.restoredEvent;
	}

	public updated(): c.IInstanceEvent<c.IWidget> {
		return this.updatedEvent;
	}

	private raiseUpdated(): void {
		this.updatedEvent.raise(this);
	}

	public destroyed(): c.IInstanceEvent<c.IWidget> {
		return this.destroyedEvent;
	}

	public destroy(): void {
		this.destroyedEvent.raise(this);

		this.addedEvent.clear();
		this.changedEvent.clear();
		this.destroyedEvent.clear();
		this.removedEvent.clear();
		this.restoredEvent.clear();
		this.updatedEvent.clear();

		const instance = this.instance;
		instance.activated = null;
		instance.deactivated = null;
		instance.settingsOpening = null;
		instance.settingsSaved = null;
		instance.getMetadata = null;
		instance.editing = null;
		instance.edited = null;
		instance.publishing = null;
		if (instance.actions) {
			for (let action of instance.actions) {
				action.execute = null;
			}
		}
	}

	private getMetadata(): lm.IWidgetSettingMetadata[] {
		const f = this.instance.getMetadata;
		return f ? f() : this.definition.settings;
	}

	public restore(): void {
		const settings: c.IStringToAnyMap = {};
		const metadata = this.getMetadata();
		if (metadata) {
			for (let item of metadata) {
				const value = item.defaultValue;
				if (lm.CommonUtil.hasValue(value)) {
					settings[item.name] = angular.copy(value);
				}
			}
		}
		this.data.settings = settings;

		this.raiseChanged();
		this.restoredEvent.raise(this);
	}
}

/**
* Utility methods related to widgets.
*/
export class WidgetUtil {
	public static labelProperty = "label";

	/**
	* Gets a URL to the widget folder or a resource in the wiget directory.
	* 
	* @param path An optional relative path that will be appended to the widget directory URL. If this parameter is omitted or is blank the URL to the widget directory will be returned.
	* @returns A URL to the widget directory or a resource in the wiget directory.
	*/
	public static getUrl(definition: c.IWidgetDefinition, path?: string): string {
		let widgetPath: string;

		const devPath = definition.devPath;
		if (devPath) {
			widgetPath = devPath;
		} else {
			const id = definition.isPublished ? definition.standardWidgetId : definition.widgetId;
			widgetPath = "widgets/" + id + "/" + definition.version;
		}

		if (path && path.length > 0) {
			widgetPath = widgetPath + (path.charAt(0) !== "/" ? "/" : "") + path;
		}

		return widgetPath;
	}

	public static cacheTemplates(templateCache: ng.ITemplateCacheService, config: lm.IAngularWidgetConfig): void {
		// Cache any templates provided by the widget that are not already cached
		const items = config.templates;
		if (items) {
			for (let item of items) {
				const key = item.key;
				if (!templateCache.get(key)) {
					templateCache.put(key, item.value);
				}
			}
		}
	}

	public static addAngularContent(scope: ng.IScope, compile: ng.ICompileService, element: JQuery, config: lm.IAngularWidgetConfig, definition: c.IWidgetDefinition): void {
		let template = config.template;
		if (!template) {
			// Check for a template URL.
			// When a cached template URL is set it is used "as is".
			// When a relative template URL is used the base path is added (which might be a development path).
			let templateUrl = config.cachedTemplateUrl;
			if (!templateUrl) {
				templateUrl = config.relativeTemplateUrl;
				if (templateUrl) {
					const devPath = definition.devPath;
					if (devPath) {
						templateUrl = devPath + "/" + templateUrl;
					} else {
						templateUrl = WidgetUtil.getUrl(definition, templateUrl);
					}
				}
			}
			if (templateUrl) {
				template = "<div ng-include=\"'" + templateUrl + "'\" class=\"lm-size-full\"></div>";
			}
		}

		const scopeValue = config.scopeValue;
		if (scopeValue) {
			scope[scopeValue.name] = scopeValue.value;
		}

		if (template) {
			element.append(compile($(template))(scope));
			return;
		}
	}

	public static getLayoutClasses(layout: c.WidgetLayout): string {
		let str = "";
		if (layout.columnSpan === 2) {
			str += "double-width";
		} else if (layout.columnSpan === 3) {
			str += "triple-width";
		} else if (layout.columnSpan === 4) {
			str += "quad-width";
		}

		// No support for triple-height atm
		if (layout.rowSpan === 2) {
			str += " double-height";
		}
		return str;
	}

	public static applySettingsValues(metadataArray: lm.IWidgetSettingMetadata[], valuesMap: c.IStringToAnyMap) {
		if (!valuesMap) {
			return;
		}
		for (let metadata of metadataArray) {
			const value = valuesMap[metadata.name];
			if (value) {
				metadata.defaultValue = value;
			}
		}
	}

	public static getTranslation(key: string, lang: ILanguageLime): string {
		if (!lang) {
			return key;
		}
		if (lang.hasOwnProperty(key)) {
			const value = lang[key];
			if (value && value.length > 0) {
				return value;
			}
		}
		return key;
	}

	public static copySettings(settings: lm.IWidgetSettingMetadata[], instanceSettings: any, lang: any): any[] {
		const settingsCopy = [];
		for (let setting of settings) {
			const instanceValue = instanceSettings[setting.name];
			const copy = angular.copy(setting);
			if (instanceValue) {
				copy.defaultValue = instanceValue;
			}
			copy[WidgetUtil.labelProperty] = WidgetUtil.getTranslation(copy.labelId, lang);
			settingsCopy.push(copy);
		};
		return settingsCopy;
	}

	public static applyRestrictions(currentMetadata: lm.IWidgetSettingMetadata[], restrictingMetadata: lm.IWidgetSettingMetadata[]): lm.IWidgetSettingMetadata[] {
		if (!currentMetadata || !restrictingMetadata) {
			return currentMetadata;
		}

		currentMetadata = angular.copy(currentMetadata);
		for (let restricting of restrictingMetadata) {
			const isEnabled = restricting.isEnabled !== false;
			const isVisible = restricting.isVisible !== false;
			const current = lm.ArrayUtil.itemByProperty(currentMetadata, "name", restricting.name);
			if (current) {
				if (!isEnabled) {
					current.isEnabled = false;
				}
				if (!isVisible) {
					current.isVisible = false;
				}
			}
		}
		return currentMetadata;
	}

	public static getSettingsFromMetadata(metadata: lm.IWidgetSettingMetadata[], values: c.IWidgetData, lang: any): IWidgetSettingMetadataEx[] {
		const settings: IWidgetSettingMetadataEx[] = [];
		for (let settingMetadata of metadata) {
			settingMetadata.isVisible = settingMetadata.isVisible !== false;
			settingMetadata.isEnabled = settingMetadata.isEnabled !== false;
			const name = settingMetadata.name;
			const label = WidgetUtil.getTranslation(settingMetadata.labelId, lang);
			let value = null;
			if (values) {
				value = values[name];
			}
			const type = settingMetadata.type;
			const setting = <IWidgetSettingMetadataEx><any>{
				definition: settingMetadata,
				id: lm.CommonUtil.random(),
				label: label,
				name: name,
				type: type,
				value: value
			};

			if (type === lm.WidgetSettingsType.selectorType) {
				const items = settingMetadata.values;
				for (let j = 0; j < items.length; j++) {
					const item = items[j];
					if (item.textId) {
						item.text = WidgetUtil.getTranslation(item.textId, lang);
					}
					if (item.value == value) {
						setting.value = item;
					}
				}
				setting.values = items;
			}
			settings.push(setting);
		}
		return settings;
	}

	public static updateSettingsValues(items: any[], isTitleLocked: boolean, widget: c.IWidget) {
		const data = widget.data;
		data.isTitleLocked = isTitleLocked;

		const context = widget.context;
		const values = data.settings;
		for (let item of items) {
			const name = item.name;
			if (name === "lmWidgetTitle") {
				if (isTitleLocked) {
					// Clear the title since it should fallback to the default
					widget.setTitleInternal(null);
				} else {
					widget.setTitleInternal(item.value);
				}
			} else if (name === "lmLogicalId") {
				context.setLogicalId(item.value.value || null);
			} else {
				let value;
				if (item.type === lm.WidgetSettingsType.selectorType) {
					value = item.value.value;
				} else {
					value = item.value;
				}
				values[name] = value;
			}
		}
	}

	public static updateMetadata(widget: c.IWidget) {
		const instance = widget.instance;
		const getMetadata = instance.getMetadata;
		if (getMetadata) {
			const metadata = getMetadata();
			if (metadata) {
				widget.context.getSettings().setMetadata(metadata);
			}
		}
	}
}

class WidgetService extends c.CoreBase implements c.IWidgetService {
	private definitions: c.IStringtoDefinitionMap = {};
	private loadedModules: any = {};
	private lang: ILanguageLime;
	private isCatalogOpen = false;
	private widgetListCache: c.IDataListCache;

	static $inject = ["$rootScope", "$q", "lmDataService", "lmDialogService", "lmLanguageService", "lmEditModeService", "lmContextService", "lmCacheService", "lmProgressService"];

	constructor(private rootScope: ng.IRootScopeService, private q: ng.IQService, private dataService: c.IDataService, private dialogService: lm.IDialogService,
		languageService: c.ILanguageService, private editModeService: c.IEditModeService, private contextService: c.IContextService, private cacheService: c.ICacheService, private progressService: c.IProgressService) {
		super("[WidgetService] ");
		this.lang = languageService.getLanguage();
		this.widgetListCache = this.cacheService.createCache(c.Constants.clientCacheWidgets);
	}

	static add(m: ng.IModule) {
		m.service("lmWidgetService", WidgetService);
	}

	public getDefinition(id: string): ng.IPromise<c.IWidgetDefinition> {
		var deferred: ng.IDeferred<c.IWidgetDefinition> = this.q.defer();
		var cachedDef = this.definitions[id];

		if (cachedDef) {
			deferred.resolve(cachedDef);
		} else {
			this.dataService.executePost("/widget/definition", { content: id }).then((response: IWidgetDefinitionItemResponse) => {
				var item = response.content;
				if (item) {
					this.addDefinitionItem(item);
					var definition = this.getCachedDefinition(id);
					deferred.resolve(definition);
				} else {
					deferred.reject();
				}
			}, (error) => {
				lm.Log.error("Failed to load WidgetDefinition for id: " + id + " " + error);
				deferred.reject();
			});
		}
		return deferred.promise;
	}

	public loadWidget(widget: c.IWidget): ng.IPromise<c.IWidget> {
		var deferred: ng.IDeferred<c.IWidget> = this.q.defer();

		// Skip widgets that have already been loaded and broken widgets.
		if (widget.definition || widget.data.isBroken) {
			deferred.resolve(widget);
		} else {
			const id = widget.data.id;

			// Load the first definition
			this.getDefinition(id).then((definition: c.IWidgetDefinition) => {

				if (!definition) {
					deferred.reject();
				}
				// Is this a copy of a published widget - then we need to load the standard widget as well
				var isCopyOfPublished = false;
				if (definition.standardWidgetId) {
					// Add of published widget or a copy of a published widget
					if (widget.addWidgetInfo) {
						const addInfo = widget.addWidgetInfo;
						if (addInfo.byRef === false) {
							isCopyOfPublished = true;
							if (!addInfo.customWidget) {
								addInfo.customWidget = definition.custom;
							}
						}
					}
				}

				if (isCopyOfPublished) {
					// Need to get standard widget and use that definition with the extra data in addWidgetInfo
					this.getDefinition(definition.standardWidgetId).then((standardDefinition: c.IWidgetDefinition) => {
						// Standard definition item
						if (!standardDefinition) {
							deferred.reject();
						}
						// Initialize - will resolve deferred
						this.initializeWidget(standardDefinition, widget, deferred);


					}, (error) => { deferred.reject(error); });
				} else {
					// Initialize - will resolve deferred
					this.initializeWidget(definition, widget, deferred);
				}

			}, (error) => { deferred.reject(error); });
		}
		return deferred.promise;
	}

	/**
	* Close and destroy the catalog.
	* @param dialog Xi dialog to destroy.
	* @returns {} 
	*/
	public closeCatalog(dialog: c.IContextualActionPanel): void {
		dialog.destroy();
		this.isCatalogOpen = false;
	}

	private initializeWidget(definition: c.IWidgetDefinition, widget: c.IWidget, deferred: ng.IDeferred<c.IWidget>) {
		// Add widget information
		widget.setDefinition(definition, widget.addWidgetInfo);
		this.loadImplementation(widget, definition, deferred);
	}

	private onLoadDefinition(item: c.IWidgetDefinitionItem, widget: c.IWidget, deferred: ng.IDeferred<c.IWidget>) {
		// TODO validate response
		this.addDefinitionItem(item);
		var definition = this.getCachedDefinition(item.definition.widgetId);
		this.initializeWidget(definition, widget, deferred);
	}

	private addSharedModules(definition: c.IWidgetDefinition): void {
		const modules = definition.sharedModules;
		if (!modules) { return; }

		const config = infor.lime.requireConfig;
		const starMap = config.map["*"];
		let isChanged = false;
		for (let m of modules) {
			const name = m.name;
			const path = m.path || name;
			if (!starMap[name]) {
				isChanged = true;
				const modulePath = WidgetUtil.getUrl(definition, path);
				starMap[name] = modulePath;
			}
		}

		if (isChanged) {
			infor.lime.requireFunction.config(config);
		}
	}

	private loadImplementation(widget: c.IWidget, definition: c.IWidgetDefinition, deferred: ng.IDeferred<c.IWidget>) {
		// Default type is inline
		let widgetType = !definition.type ? c.WidgetType.Inline : definition.type;
		widgetType = widgetType.toLowerCase();
		if (widgetType === c.WidgetType.Inline && !this.rootScope[c.Constants.safeMode]) {
			var name = !definition.moduleName ? c.Constants.widgetModuleDefaultName : definition.moduleName;
			var id = definition.isPublished ? definition.standardWidgetId : definition.widgetId;
			const cachedModule = this.loadedModules[id];
			if (cachedModule) {
				widget.widgetModule = cachedModule;
			} else {
				this.addSharedModules(definition);
				var fullName = WidgetUtil.getUrl(definition, name);
				this.debug("Loading inline widget module " + fullName);
				require([fullName], (widgetModule) => {
					if (widgetModule) {
						// Anonymous moudule file or an existing module
						this.loadedModules[id] = widgetModule;
						widget.widgetModule = widgetModule;
						deferred.resolve(widget);
					} else {
						// Multi module file or incorrect module
						require([name], (widgetModule) => {
							if (widgetModule) {
								this.loadedModules[id] = widgetModule;
								widget.widgetModule = widgetModule;
								deferred.resolve(widget);
							} else {
								const message = "Widget module not found: " + name + "(" + fullName + ")";
								this.error(message);
								deferred.reject(message);
							}
						}, (err) => {
							var message = name + "(" + fullName + ")";
							this.error(err);
							deferred.reject(message);
						});
					}
				}, (err) => {
					var message = fullName;
					this.error(err);
					deferred.reject(message);
				});
				return;
			}
		}
		deferred.resolve(widget);
	}

	public getAddWidgetInfo(widget: c.IWidget): c.IAddWidgetInfo {
		const data = widget.data;
		let isTitleLocked = data.isTitleLocked;
		if (widget.isCatalogTitle()) {
			isTitleLocked = false;
		}

		const customWidget: c.ICustomWidget = {
			settings: angular.copy(data.settings),
			title: widget.title,
			isTitleLocked: isTitleLocked,
			logicalId: data.logicalId,
			titleApi: data.titleApi
		};

		const definition = widget.definition;
		const id = definition.standardWidgetId || definition.widgetId;
		const widgetInfo: c.IWidgetInfo = { widgetId: id, title: data.title, type: definition.type };
		const addWidgetInfo: c.IAddWidgetInfo = { byRef: false, customWidget: customWidget, widgetInfo: widgetInfo }
		return addWidgetInfo;
	}

	// Used by duplicate widget on a page
	public addWidgetCopyToPage(context: c.IWidgetParentContext, addWidgetInfo: c.IAddWidgetInfo): ng.IPromise<c.IWidget> {
		var deferred = this.q.defer();
		this.preAddWidget(context, addWidgetInfo).then((widget: c.IWidget) => {
			// Add the widget to the parent page
			context.addWidget(widget);
			deferred.resolve(widget);
		}, (r) => {
			deferred.reject(r);
		});
		return deferred.promise;
	}

	public preAddWidget(context: c.IWidgetParentContext, addWidgetInfo: c.IAddWidgetInfo, busyCallback?: Function): ng.IPromise<c.IWidget> {
		const deferred = this.q.defer();
		this.preLoadWidget(deferred, context, addWidgetInfo, busyCallback);
		return deferred.promise;
	}

	public preLoadWidget(deferred: ng.IDeferred<c.IWidgetData>, context: c.IWidgetParentContext, addWidgetInfo: c.IAddWidgetInfo, busyCallback?: Function) {
		// Is a busyCallback exists, the widget has been added from the catalog
		if (!busyCallback) {
			this.progressService.setBusy(true);
		}
		var widgetInfo = addWidgetInfo.widgetInfo;
		var id = widgetInfo.widgetId;
		var data: c.IWidgetData = {
			id: id, isTitleLocked: true
		};
		var widget = new Widget(context, data, true, addWidgetInfo.byRef);
		if (addWidgetInfo) {
			// Store data to be used in load widget this is a newly added widget
			widget.addWidgetInfo = addWidgetInfo;
		}
		this.loadWidget(widget).then((w: c.IWidget) => {
			//TODO add information about the copy data that should be added to the IWidget
			busyCallback ? busyCallback() : this.progressService.setBusy(false);
			deferred.resolve(w);
		}, (response) => {
			lm.Log.error(this.logPrefix + "Failed to load widget " + response);
			busyCallback ? busyCallback() : this.progressService.setBusy(false);
			deferred.reject(response);
		});

		// TODO Resolve error case
	}

	getCachedDefinition(id: string) {
		var def = this.definitions[id];
		return lm.CommonUtil.hasValue(def) ? def : null;
	}

	addDefinitions(list: c.IWidgetDefinition[]) {
		for (var i = 0; i < list.length; i++) {
			this.addDefinition(list[i]);
		}
	}

	addDefinitionItem(item: c.IWidgetDefinitionItem): c.IWidgetDefinition {
		var definition = <c.IWidgetDefinition>item.definition;
		definition.lang = item.localization;
		definition.standardTitle = item.standardTitle;
		definition.title = item.catalogTitle || item.standardTitle;
		definition.isCatalog = item.isCatalog;
		definition.accessLevel = item.accessLevel;
		definition.standardAccessLevel = item.standardAccessLevel;

		this.addDefinition(definition);
		var applications = item.applications;
		// If the definition has application configuration add that as well
		if (applications) {
			if (this.contextService) {
				var context = this.contextService.getContext();
				var configuration = context.getConfiguration();
				if (configuration) {
					configuration.addApplications(applications);
				}
			}
		}
		return definition;
	}

	removeDefinition(widgetId: string) {
		lm.CommonUtil.deleteProperty(this.definitions, widgetId);
	}

	private addDefinition(definition: c.IWidgetDefinition) {
		if (definition.standardWidgetId) {
			definition.isPublished = true;
		}
		this.definitions[definition.widgetId] = definition;
	}

	listWidgets(reload: boolean): ng.IPromise<c.IWidgetListResponse> {
		var deferred: ng.IDeferred<c.IWidgetListResponse> = this.q.defer();
		if (!this.widgetListCache.isValid || reload) {
			this.dataService.executePost("/widget/list", {}).then((response: c.IWidgetListResponse) => {
				this.cacheService.updateCache(this.widgetListCache, response, deferred);
			}, (response: c.IWidgetListResponse) => {
				this.widgetListCache.isValid = false;
				deferred.reject(response);
			});
		} else {
			deferred.resolve(this.widgetListCache.cachedResponse);
		}
		return deferred.promise;
	}

	showCatalog(context: c.IWidgetParentContext, callback?: Function): ng.IPromise<c.IWidget> {
		var deferred = this.q.defer();

		// Open catalog only if it's not opened already.
		if (!this.isCatalogOpen) {
			this.isCatalogOpen = true;
			var template = "<div class=\"contextual-action-panel modal lm-catalog-dialog\" ng-include=\"'scripts/lime/templates/widget-library.html'\"></div>";
			this.dialogService.showContextualActionPanel(template, callback).then(() => {
				this.isCatalogOpen = false;
				deferred.resolve();
			}, () => {
				this.isCatalogOpen = false;
				deferred.reject();
			});
		} else {
			// Catalog already open.
			deferred.reject();
		}

		// TODO Resolve error case
		return deferred.promise;
	}



	showSettings(widget: c.IWidget, data?: any, isWidgetUnlocked?: boolean): ng.IPromise<lm.IDialogResult> {
		var deferred = this.q.defer();

		var parameter = new WidgetSettingsParameter();
		parameter.widget = widget;
		parameter.isEditMode = this.editModeService.isActive();

		var options = <lm.IDialogOptions>{
			title: this.lang.widgetSettings,
			templateUrl: "scripts/lime/templates/widget-settings.html",
			parameter: parameter
		};

		var settings = widget.context.getSettings();

		// TODO Clone settings definitions
		var isCancelled = false;
		var instance = widget.instance;
		if (instance.settingsOpening) {
			var openingOptions: lm.IWidgetSettingsArg = { settings: settings, data: data };
			try {
				widget.instance.settingsOpening(openingOptions);
				if (openingOptions.cancel) {
					isCancelled = true;
				}
			} catch (e) {
				this.error("Failed to call settingsOpening for widget " + widget.id, e);
			}
		}

		if (isCancelled) {
			// Cancel the dialog the widget can open it's own dialog if it likes
			this.debug("Settings dialog cancelled by widget with id" + widget.id);
			var dialogResult: lm.IDialogResult = { button: lm.DialogButtonType.Cancel };
			deferred.resolve(dialogResult);
			return deferred.promise;
		}

		try {
			WidgetUtil.updateMetadata(widget);
		} catch (e) {
			this.error("Failed get metadata for widget " + widget.id, e);
		}

		// Check if widget has custom UI
		if (instance.widgetSettingsFactory) {
			// Save the factory for later use
			parameter.widgetSettingsFactory = (context: lm.IWidgetSettingsContext) => { return instance.widgetSettingsFactory(context); };
			// Change the template to the custom settings UI
			options.templateUrl = "scripts/lime/templates/widget-settings-custom.html";
		}

		// Set that settings is open
		widget.isSettings = true;

		var deactivated = instance.deactivated;
		if (deactivated) {
			deactivated({ type: lm.WidgetActivationType.settings });
		}

		this.dialogService.show(options).then((r: lm.IDialogResult) => {
			if (r && r.value) {
				widget.updateSettings(!isWidgetUnlocked);
			}

			// Settings is no longer open
			widget.isSettings = false;

			var activated = instance.activated;
			if (activated) {
				activated({ type: lm.WidgetActivationType.settings });
			}

			deferred.resolve(r);
		});

		return deferred.promise;
	}

	public getPublished(id: string): ng.IPromise<c.IPublishedWidgetItem> {
		var deferred: ng.IDeferred<c.IPublishedWidgetItem> = this.q.defer();
		this.dataService.executePost("/widget/published", { content: id }).then((response: IPublishedWidgetItemResponse) => {
			deferred.resolve(response.content);
		}, (r: c.IOperationResponse) => { deferred.reject(r); });
		return deferred.promise;
	}

	public publish(item: c.IPublishedWidgetItem): ng.IPromise<c.IStringResponse> {
		var deferred: ng.IDeferred<c.IStringResponse> = this.q.defer();
		this.dataService.executePost("/widget/published/create", { content: item }).then((response: c.IStringResponse) => {
			this.widgetListCache.isValid = false;
			deferred.resolve(response);
		}, (response: c.IStringResponse) => {
			deferred.reject(response);
		});
		return deferred.promise;
	}

	public updatePublished(item: c.IPublishedWidgetItem): ng.IPromise<c.IStringResponse> {
		var deferred: ng.IDeferred<c.IStringResponse> = this.q.defer();
		// TODO Caching
		this.dataService.executePost("/widget/published/update", { content: item }).then((response: c.IStringResponse) => {
			this.widgetListCache.isValid = false;
			deferred.resolve(response);
		}, (response: c.IStringResponse) => {
			deferred.reject(response);
		});
		return deferred.promise;
	}

	public updatePublishedOwner(widgetId: string, ownerId: string): ng.IPromise<any> {
		var deferred: ng.IDeferred<any> = this.q.defer();
		const widget = { widgetId: widgetId, ownerId: ownerId };
		this.dataService.executePost("/widget/published/owner/update", widget).then((response) => {
			deferred.resolve(response);
		}, (response) => {
			deferred.reject(response);
		});
		return deferred.promise;
	}

	public deletePublished(widgets: string[]): ng.IPromise<c.IIntegerResponse> {
		var deferred: ng.IDeferred<c.IIntegerResponse> = this.q.defer();
		this.dataService.executePost("/widget/published/delete", { content: widgets }).then((response: c.IIntegerResponse) => {
			this.widgetListCache.isValid = false;
			deferred.resolve(response);
		}, (response: c.IIntegerResponse) => {
			deferred.reject(response);
		});
		return deferred.promise;
	}

	public exportWidget(widgetData: c.IWidgetData): string {
		throw "Not implemented";
		// TODO Not supported yet
		//var name = widgetData.title ? widgetData.title : "widget";
		//name = encodeURI(name);
		//var query = "?_=" + new Date().getTime(); // Add this to prevent browser caching
		//var extension = ".json"; // TODO executeget?
		//var url = this.dataService.getUrl("widgets/" + widgetData.id + "/" + name + extension);// + query;
		//this.debug("[exportWidget] " + url);
		//return url;
	}

	/*
	* Forwards errors to error handler in Data Service.
	*/
	public handleError(response: c.IOperationResponse, message?: string) {
		this.dataService.handleError(response, message);
	}

	/**
	* Create Image Path
	*
	* Creates an image path for custom widget icons.
	* 
	* @ param widget Widget Info
	* @ returns string Path to the icon.
	*/
	public createImagePath(widget: c.IWidgetInfo) {
		// Path to return.
		let path = "";

		// Create path to custom icon or set a generic icon depending on category.
		const icon = widget.iconFile;
		if (icon) {
			const id = widget.standardWidgetId || widget.widgetId;
			if (c.ClientConfiguration.isLocal()) {
				path = "/widgets/" + id + "/" + widget.version + "/" + icon;
			} else if (c.ClientConfiguration.isDev()) {
				// Note special case in dev where the widgetId is a path
				path = c.ClientConfiguration.dev.devData.widgetId + "/" + icon;
			} else {
				path = "widgets/" + id + "/" + widget.version + "/" + icon;
			}
		} else {
			// Base path to non custom icons.
			const basePath = "scripts/lime/resources/widget-category-icons/";
			switch (widget.category) {
				case "businessprocess":
					path = basePath + "ic-business-process.png";
					break;
				case "application":
					path = basePath + "ic-application.png";
					break;
				case "social":
					path = basePath + "ic-social.png";
					break;
				case "utilities":
					path = basePath + "ic-utilites.png";
					break;
				case "businessintelligence":
					path = basePath + "ic-business-intelligence.png";
					break;
				default:
					lm.Log.error("No icon path could be set for widget with id: " + widget.widgetId + ", since it has an incorrect category.");
					break;
			}
		}
		return path;
	}

	/**
	* Invalidates the Widget cache. 
	*/
	public invalidateWidgetCache(): void {
		this.definitions = {};
		if (this.widgetListCache) {
			this.widgetListCache.isValid = false;
		}
	}
}

export interface IWidgetSettingMetadataEx extends lm.IWidgetSettingMetadata {
	definition: lm.IWidgetSettingMetadata;
	id: string;
	label: string;
	value: any;
}

class WidgetSettingsParameter {
	widget: c.IWidget;
	/**
	* Gets or sets a value that indicates if the widget is in edit mode. 
	* The edit mode could be for either a published widget or a private widget on a published page.
	*/
	isEditMode: boolean;
	widgetSettingsFactory: (context: lm.IWidgetSettingsContext) => lm.IWidgetSettingsInstance;
}

class CustomWidgetSettingsCtrl extends c.CoreBase {
	private dialog: lm.IDialog;
	private widget: c.IWidget;
	private settings: any[]; // TODO Type
	private settingsInstance: lm.IWidgetSettingsInstance = null;
	static $inject = ["$scope", "lmWidgetService"];

	constructor(public scope: ng.IScope, private widgetService: c.IWidgetService) {
		super("[CustomWidgetSettingsCtrl] ");
		this.dialog = scope["lmDialog"];
		var parameter = <WidgetSettingsParameter>this.dialog.parameter;
		if (parameter) {
			this.widget = parameter.widget;
		}
		var self = this;
		scope.$watch("lmSettingsInstance", (newValue: any, oldValue: any, watchScope: ng.IScope) => {
			if (newValue) {
				// TODO Check type
				self.settingsInstance = newValue;
			}
		});
	}

	public static add(m: ng.IModule) {
		m.controller("lmCustomWidgetSettingsCtrl", CustomWidgetSettingsCtrl);
	}

	private beforeClose(isSave: boolean) {
		try {
			if (this.settingsInstance) {
				if (this.settingsInstance.closing) {
					var arg: lm.IWidgetSettingsCloseArg = { isSave: isSave };
					this.settingsInstance.closing(arg);
				}
			}
		} catch (e) {
			this.error("Exception in settingsInstance.closing", e);
		}
	}

	public onSave() {
		// TODO Should save be cancelled?
		this.beforeClose(true);

		// Close dialog
		var result = <lm.IDialogResult>{ value: this.widget };
		this.dialog.close(result);
	}

	public onCancel() {
		this.beforeClose(false);
		this.dialog.close();
	}
}

class WidgetSettingsCtrl {
	static $inject = ["$scope", "lmWidgetService", "lmLanguageService"];

	private dialog: lm.IDialog;
	private widget: c.IWidget;
	private settings: any[]; // TODO Type
	private lang: ILanguageLime;
	private originalTitle: string;
	private isEditMode: boolean;
	private webWidgetId: string;

	public isCatalogTitle = false;
	public isTitleLocked: boolean;

	public isSaveEnabled;

	constructor(public scope: ng.IScope, private widgetService: c.IWidgetService, languageService: c.ILanguageService) {
		this.dialog = scope["lmDialog"];
		this.lang = languageService.getLanguage();
		this.webWidgetId = c.Constants.mingleWebWidgetID;
		var parameter = <WidgetSettingsParameter>this.dialog.parameter;
		if (parameter && parameter.widget) {
			var widget = parameter.widget;
			var isEdit = parameter.isEditMode;
			this.isEditMode = isEdit;

			var definition = widget.definition;
			var lang = definition.lang;

			// ReSharper disable once RedundantComparisonWithBoolean
			var widgetTitleLocked = widget.data.isTitleLocked === true;

			// Create settings objects used by the HTML template
			var values = widget.data.settings;
			var settings: IWidgetSettingMetadataEx[] = [];

			var metadata = widget.context.getSettings().getMetadata();
			if (metadata) {
				settings = WidgetUtil.getSettingsFromMetadata(metadata, values, lang);
			}

			// Add the application selector if necessary for private widgets or published widgets in edit mode
			if (isEdit || !definition.isPublished) {
				var setting = this.createSelector(widget);
				if (setting) {
					settings.unshift(setting);
				}
			}

			const isTitleEdit = widget.isTitleEditEnabled !== false;
			if (isEdit || isTitleEdit) {
				const title = widget.title;
				this.originalTitle = title;
				settings.unshift(<IWidgetSettingMetadataEx>{
					id: lm.CommonUtil.random(),
					name: c.Constants.settingsNameWidgetTitle,
					value: title,
					definition: <lm.IWidgetSettingMetadata>{},
					label: this.lang.title
				});
				this.isCatalogTitle = widget.isCatalogTitle();
			}

			this.isTitleLocked = widgetTitleLocked || this.isCatalogTitle;

			// Everything is unlocked in edit mode for now.
			this.isSaveEnabled = isEdit || isTitleEdit || lm.ArrayUtil.find(settings, (item: IWidgetSettingMetadataEx) => {
				var def = item.definition;
				return (def.isVisible && def.isEnabled);
			});

			this.widget = widget;
			this.settings = settings;
			scope["settings"] = settings;
			scope["widgetTitleMaxLength"] = c.Constants.widgetTitleLength;
		}
	}

	private createSelector(widget: c.IWidget): IWidgetSettingMetadataEx {
		// Show application instance selector if there are more than one instance
		const context = widget.context;
		const applications = context.getApplications();
		if (!applications || applications.length < 2) {
			return null;
		}

		const logicalId = widget.data.logicalId || "";

		const values: lm.IValueItem[] = [];
		const defaultApplication = context.getApplication();
		const defaultText = this.lang.defaultSelection + " (" + defaultApplication.logicalId + ")";
		const defaultItem = { text: defaultText, value: "" };
		let selectedItem = defaultItem;
		values.push(defaultItem);
		for (let i = 0; i < applications.length; i++) {
			const application = applications[i];
			const value = application.logicalId;
			const text = application.productName + " (" + value + ")";
			const item = { text: text, value: value };
			values.push(item);
			if (logicalId === value) {
				selectedItem = item;
			}
		}

		const setting: IWidgetSettingMetadataEx = {
			type: "selector",
			id: lm.CommonUtil.random(),
			name: "lmLogicalId",
			value: selectedItem,
			values: values,
			definition: <lm.IWidgetSettingMetadata>{},
			label: this.lang.application
		};
		return setting;
	}

	public static add(m: ng.IModule) {
		m.controller("lmWidgetSettingsCtrl", WidgetSettingsCtrl);
	}

	public onClickIsLocked() {
		const isLocked = this.isTitleLocked;
		this.isTitleLocked = !isLocked;

		const metadata = <IWidgetSettingMetadataEx>this.settings[0];
		if (metadata.name === c.Constants.settingsNameWidgetTitle) {
			// Change the setting value for title if the title was locked and reset the title to the default widget title
			if (this.isTitleLocked) {
				metadata.value = this.widget.calculateTitle(true);
			}
		}
	}

	public onSave() {
		if ((this.isEditMode || this.widget.isTitleEditEnabled) && this.settings[0].value === this.originalTitle) {
			// If title edit is enabled but the title is unchanged, remove that setting to prevent setting it locally.
			this.settings.shift();
		}

		// Update settings
		WidgetUtil.updateSettingsValues(this.settings, this.isTitleLocked, this.widget);

		// Close dialog
		const result = <lm.IDialogResult>{ value: this.widget };
		this.dialog.close(result);
	}

	public onCancel() {
		const result = <lm.IDialogResult>{ button: lm.DialogButtonType.Cancel };
		this.dialog.close(result);
	}
}

interface IWidgetCustomizationScope extends ng.IScope {
	localization: c.ILocalizationParameter;
}

/**
* Controller for the dialog that is used to edit the publish configuration for a widget.
*/
class WidgetCustomizationCtrl extends c.CoreBase {
	private dialog: lm.IDialog;
	private customized: c.IWidgetDefinition = {};
	private localization: c.ILocalizationParameter;
	private widgetTitleLength;
	private widgetDescriptionLength;
	private lang: ILanguageLime;
	private tabOptions: Object;
	private translationEnabled: boolean;
	private openTab = "basic";
	private tagHolder: string;

	/**
	* Gets or sets a value that indicates if the widget supports settings or not.
	*/
	private enableSettings: boolean;

	// TODO Typing of the wrapper object 
	public settingsItems: any[];

	static $inject = ["$scope", "lmWidgetService", "lmDialogService", "lmLanguageService", "lmEditModeService", "lmContextService"];

	constructor(public scope: IWidgetCustomizationScope, private widgetService: c.IWidgetService, private dialogService: lm.IDialogService, languageService: c.ILanguageService,
		private editModeService: c.IEditModeService, private contextService: c.IContextService) {
		super("[WidgetCustomizationCtrl] ");
		this.dialog = scope["lmDialog"];
		this.lang = languageService.getLanguage();
		this.tabOptions = { modalId: c.Constants.modalWidgetCustomize };
		const translationsEnabled = this.contextService.getContext().settings.isContentTranslationEnabled();
		this.translationEnabled = translationsEnabled;
		this.widgetTitleLength = c.Constants.widgetTitleLength;
		this.widgetDescriptionLength = c.Constants.widgetDescriptionLength;
		this.tagHolder = "#" + new Date().getFullYear().toString();

		const parameter: c.IPublishWidgetOptions = this.dialog.parameter;
		const item = parameter.item;
		const definition = item.definition;
		if (definition != null) {
			this.customized = definition;
			const localizationMap = item.localization || {};
			this.localization = { defaultLocalization: { title: definition.title, description: definition.description || "" }, localizationMap: localizationMap, isWidget: true };
			scope.localization = this.localization;
			this.initialize(definition, parameter.definition);
		}
	}

	private enableItem(item: any, name: string, definition: c.IWidgetDefinition) {
		let isEnabled = true;
		let isVisible = true;
		let isHidden = false;
		if (definition) {
			definition = definition.original;
			const settings = definition.settings;
			if (settings) {
				const current = lm.ArrayUtil.itemByProperty(settings, "name", name);
				if (current) {
					if (current.isHidden === true) {
						isHidden = true;
					}
					if (current.isEnabled === false) {
						isEnabled = false;
					}
					if (current.isVisible === false) {
						isVisible = false;
					}
				}
			}
		}
		item["isEnabled"] = isEnabled;
		item["isVisible"] = isVisible;
		item["isHidden"] = isHidden;
	}

	private initialize(definition: c.IWidgetDefinition, sourceDefinition: c.IWidgetDefinition) {
		const settings = definition.settings;
		const language = sourceDefinition.lang;
		const items = [];

		this.enableSettings = sourceDefinition.enableSettingsDef;

		items.push({
			label: this.lang.title,
			setting: {
				name: c.Constants.settingsNameWidgetTitle,
				isEnabled: definition.enableTitleEdit
			},
			isEnabled: true,
			isVisible: true
		});

		if (settings) {
			const enableSettings = definition.enableSettings;
			for (let setting of settings) {
				if (!enableSettings) {
					setting.isEnabled = false;
					setting.isVisible = false;
				}

				let isHidden = false;
				if (setting.isHidden) {
					setting.isVisible = false;
					isHidden = true;
				}

				const item = { setting: setting };
				item["isHidden"] = isHidden;
				item[WidgetUtil.labelProperty] = WidgetUtil.getTranslation(setting.labelId, language);
				items.push(item);
			}
		}

		this.settingsItems = items;
	}

	private onClickTab(tabName: string): void {
		this.openTab = tabName;
		if (tabName === "translations") {
			const widget = this.customized;
			this.scope.localization.defaultLocalization = { title: widget.title, description: widget.description };
		}
	}

	private onClickApply() {
		const definition = this.customized;
		const items = this.settingsItems;
		const titleSetting = items.shift();
		definition.enableTitleEdit = titleSetting.setting.isEnabled;

		const info: c.IWidgetPublishInfo = {
			publishedItem: {
				definition: definition,
				localization: this.localization.localizationMap
			},
			isLocalizationChanged: this.isLocalizationsChanged(),
			isPublish: false
		};

		this.dialog.result = {
			value: info
		};
		this.dialog.close();
	}

	private isLocalizationsChanged() {
		// TODO Implement this to optimize updating of a published widget
		return true;
	}

	private cancel() {
		this.dialog.close();
	}

	public static add(m: ng.IModule) {
		m.controller("lmWidgetCustomizationCtrl", WidgetCustomizationCtrl);
	}
}

/**
* Controller for the Widget container.
* 
* Angular controller name: lmWidgetContainerCtrl
*/
class WidgetContainerCtrl extends c.CoreBase {
	private widget: c.IWidget;
	private iframe: JQuery;
	private url: string;
	private isExternal: boolean;
	private unsubscribers: Array<Function> = [];

	private isMyWidget: boolean;
	private isCustomizedUnlocked: boolean;
	private context: c.IContext;
	private lang: ILanguageLime;
	private primaryAction: lm.IWidgetAction;

	/**
	* Addtional data for a published widget in edit mode.
	*/
	private publishedItem: c.IPublishedWidgetItem;
	private publishInfo: c.IWidgetPublishInfo;
	private isPublishCopy: boolean;
	private isPreviewMode: boolean;
	private isInactive: boolean;

	private showSettingsItem: boolean;
	private menuOptions: xi.IPopupMenuOptions;
	public showPublishItem = false;
	public showPublishCopyItem = false;
	public showEditPublishItem = false;
	public showDuplicateItem = false;
	public showAdvancedItem = false;
	public showRestoreItem = false;
	public showCopyItem = false;

	public static $inject = ["$rootScope", "$scope", "lmWidgetService", "lmDialogService", "lmContextService", "lmLanguageService", "lmContainerService", "lmEditModeService", "lmProgressService"];

	constructor(private rootScope: ng.IRootScopeService, public scope: ng.IScope, private widgetService: c.IWidgetService, private dialogService: lm.IDialogService,
		private contextService: c.IContextService, languageService: c.ILanguageService, private containerService: container.IContainerService, private editModeService: c.IEditModeService, private progressService: c.IProgressService) {
		super("[WidgetContainerCtrl] ");
		this.lang = languageService.getLanguage();

		var self = this;
		var unregister = scope.$watch("lmWidget", (widget: c.IWidget) => {
			if (widget) {
				unregister();
				self.init(widget);
			}
		});
	}

	private destroy(): void {
		angular.forEach(this.unsubscribers, (unsubscribe) => {
			unsubscribe();
		});
	}

	public loadExternal(widget: c.IWidget, iframe: JQuery) {
		this.widget = widget;
		this.iframe = iframe;
		this.isExternal = true;
		this.updateUrl();
	}

	public setUrl(url: string): void {
		this.url = url;
	}

	private applyUrl(newUrl: string) {
		if (newUrl && newUrl !== this.url) {
			this.url = newUrl;
			this.iframe.attr("src", newUrl);
		}
	}

	private getLayoutClasses(): string {
		// TODO Temporary for broken test container
		return this.widget ? WidgetUtil.getLayoutClasses(this.widget.data.layout) : "";
	}

	private updateUrl() {
		var widget = this.widget;
		var iframe = this.iframe;
		if (widget && iframe) {
			var newUrl = widget.externalUrl;
			if (newUrl && newUrl.indexOf("{") >= 0) {
				// TODO Use the widgetContext instead of only data.settings
				newUrl = this.widget.context.resolveAndReplace(newUrl);
				this.widget.context.resolveAndReplaceAsync(newUrl, null).then((s: string) => {
					this.applyUrl(s);
				});
			} else {
				this.applyUrl(newUrl);
			}
		}
	}

	private init(widget: c.IWidget) {
		this.widget = widget;
		const self = this;
		if (!widget.data.isBroken) {
			self.context = self.contextService.getContext();
			self.isMyWidget = widget.definition.owner && self.context.isCurrentUser(widget.definition.owner);
			if (widget.instance.actions) {
				this.setPrimaryAction();
			}
			self.isPreviewMode = self.editModeService.isActive() && self.editModeService.getCurrent().mode === c.EditModes.preview;
			if (!self.isPreviewMode) {
				self.updateMenu();
			}

			widget.updated().on(() => {
				if (!self.isPreviewMode) {
					self.updateMenu();
				}
			});

			const editModeService = self.editModeService;
			this.unsubscribers.push(editModeService.changed().on((e: c.IEditMode) => {
				// Always update the menu when edit mode changes unless preview mode since entire menu is hidden
				if (!self.isPreviewMode) {
					self.updateMenu();
				}
			}));

			this.unsubscribers.push(editModeService.started().on((e: c.IEditMode) => {
				var param = e.parameter;
				if (param && param !== self.widget.elementId) {
					self.isInactive = true;
				}
			}));
		}
		widget.destroyed().on(() => {
			self.destroy();
		});
		self.widget.raiseAdded();
	}

	/**
	* Updates which items should be visible / enabled in the widget menu.
	*/
	private updateMenu(): void {
		const widget = this.widget;
		if (widget && !widget.data.isBroken) {
			const isSettingsEnabled = widget.isSettingsEnabled();

			if (widget.accessLevel === c.WidgetAccessLevel.View || widget.accessLevel === c.WidgetAccessLevel.Disabled) {
				this.showSettingsItem = false;
			} else {
				this.showSettingsItem = isSettingsEnabled && widget.isSettingsMenuEnabled();
			}

			const editMode = this.editModeService.getCurrent();
			const isEditMode = !!editMode && editMode.isActive;
			const isWidgetEditMode = isEditMode && editMode.mode === c.EditModes.widget;
			const isPagePublished = this.containerService.getContainer().selectedPage.isPublished();
			const isPageEditMode = isEditMode && editMode.mode === c.EditModes.page;

			if (this.hasEditRights()) {
				const isPublishEnabled = this.context.settings.isWidgetPublishEnabled();
				const isPublished = widget.isPublished();
				const isEditPublish = isWidgetEditMode || (!isPublished && (!isPagePublished || isPageEditMode));
				this.showPublishItem = isPublishEnabled && !isEditMode;
				this.showPublishCopyItem = isPublishEnabled && !isEditMode && !isPublished;
				this.showEditPublishItem = isEditPublish && (isPublishEnabled || this.context.settings.isPagePublishEnabled());
				this.showRestoreItem = isSettingsEnabled && isEditPublish;
			}

			const canCopy = widget.definition.standardAccessLevel === c.WidgetAccessLevel.Configure;
			this.showDuplicateItem = canCopy && (isPageEditMode || (!isEditMode && !isPagePublished));
			this.showCopyItem = canCopy;

			// Enable the advanced menu item if it has at least one visible item
			this.showAdvancedItem = this.showPublishItem || this.showPublishCopyItem || this.showEditPublishItem || this.showDuplicateItem || this.showRestoreItem || this.showCopyItem;
		}
	}

	/**
	* Find and set the primary action to be shown in title bar
	*/
	private setPrimaryAction() {
		const actions = this.widget.instance.actions;
		for (let action of actions) {
			if (action.isPrimary && (action.standardIconName || action.customIconName)) {
				this.primaryAction = action;
				return;
			}
		}
	}

	/**
	* Gets a value that indicates if the current user is allowed to edit the widget.
	*/
	private hasEditRights(): boolean {
		return this.context && this.context.isAdministrator || !this.widget.definition.owner || this.widget.definition.owner === this.context.getUserId();
	}

	private isEditModeActive(): boolean {
		return this.editModeService.isActive();
	}

	public showSettings() {
		this.widgetService.showSettings(this.widget, null, this.isCustomizedUnlocked).then((r: lm.IDialogResult) => {
			if (r && r.value) {
				if (this.isExternal) {
					this.updateUrl();
				}
			}
		}, (r: c.IOperationResponse) => { this.widgetService.handleError(r); });
	}

	private onPublishWidget() {
		const editMode = this.editModeService.getCurrent();
		const isUpdate = editMode.submode === c.EditSubmodes.republish;
		const item = this.getPublishItem(!isUpdate);

		// Verify mandatory values
		if (!item.definition.description || !item.definition.title) {
			this.showMissingInfoMessage();

			// TODO Verify if item is still valid the next time, seems to be issues when getPublishItem is called twice

			return;
		}

		if (editMode.submode === c.EditSubmodes.publish || editMode.submode === c.EditSubmodes.publishCopy) {
			this.publishWidget(item);
		} else {
			this.republishWidget(item);
		}
		this.publishedItem = null;
		this.publishInfo = null;
		this.editModeService.stop({ isSave: true });
	}

	private startEditModeInternal() {
		var lang = this.lang;
		var widget = this.widget;
		var title: string;
		var commandText: string;
		if (!widget.definition.owner) {
			title = this.isPublishCopy ? lang.publishWidgetCopy : lang.publishWidget;
			commandText = lang.publish;
		} else {
			title = lang.republishWidget;
			commandText = lang.republish;
		}

		try {
			widget.enableSettingsTemporary(true);
			var publishing = widget.instance.publishing;
			if (publishing) {
				publishing();
			}
		} catch (ex) {
			this.error("Failed to call publishing event function", ex);
		}

		var self = this;
		this.editModeService.start({
			mode: c.EditModes.widget,
			title: title,
			parameter: widget.elementId,
			submode: this.isPublishCopy ? c.EditSubmodes.publishCopy : lm.CommonUtil.isUndefined(widget.definition.owner) ? c.EditSubmodes.publish : c.EditSubmodes.republish,
			actions: [
				{ text: this.lang.cancel, execute: () => { self.onCancelPublish(); } },
				{ text: commandText, execute: () => { self.onPublishWidget(); } }],
			secondaryActions: [
				{ text: this.lang.editPublishConfiguration, execute: () => { self.showPublishConfiguration(); } }]
		});

		// Always show the dialog when edit mode starts
		this.showPublishConfiguration();
	}

	private onCancelPublish() {
		this.dialogService.showMessage({ standardButtons: lm.StandardDialogButtons.YesNo, message: this.lang.confirmCancelMessage, title: this.lang.confirmCancel }).then((r: lm.IDialogResult) => {
			if (r.button === lm.DialogButtonType.Yes) {
				this.editModeService.stop({ isSave: false });
			}
		});
	}

	public startEditMode(isCopy: boolean) {
		this.isPublishCopy = isCopy === true;
		if (this.widget.definition.isPublished) {
			// Load the custom definition data for a published widget before starting edit mode
			this.progressService.setBusy(true);
			this.widgetService.getPublished(this.widget.id).then((item: c.IPublishedWidgetItem) => {
				var definition = item.definition;
				if (definition.custom) {
					definition.settings = WidgetUtil.applyRestrictions(definition.settings, definition.custom.metadata);
				}
				this.publishedItem = item;
				this.progressService.setBusy(false);
				this.startEditModeInternal();
			}, (r: c.IOperationResponse) => {
				this.widgetService.handleError(r);
				this.progressService.setBusy(false);
			});
		} else {
			this.startEditModeInternal();
		}
	}

	private copyPublishSettings(source: c.IWidgetDefinition, target: c.IWidgetDefinition): void {
		target.settings = source.settings;
		target.title = source.title;
		target.description = source.description;
		target.tags = source.tags;
		target.enableSettings = source.enableSettings;
		target.enableTitleEdit = source.enableTitleEdit;
	}

	/**
	* Gets a subset of the settings metadata for publishing a widget.
	*/
	private getPublishSettings(source: lm.IWidgetSettingMetadata[]) {
		const target: lm.IWidgetSettingMetadata[] = [];
		if (source) {
			for (let i = 0; i < source.length; i++) {
				const setting = source[i];
				target.push({
					name: setting.name,
					isEnabled: setting.isEnabled,
					isVisible: setting.isVisible
				});
			}
		}
		return target;
	}

	private getPublishItem(isNew: boolean): c.IPublishedWidgetItem {
		const sourceDefinition = this.widget.definition;
		const widgetData = this.widget.data;
		const info = this.publishInfo;
		const publishedItem = this.publishedItem;
		const settingsValues = widgetData.settings || {};
		let definition: c.IWidgetDefinition;
		let item: c.IPublishedWidgetItem;
		let sourceMetadata: lm.IWidgetSettingMetadata[];

		if (info) {
			item = info.publishedItem;
			if (!info.isLocalizationChanged) {
				item.localization = null;
			}
		} else if (publishedItem) {
			item = publishedItem;
		} else if (widgetData.custom) {
			item = widgetData.custom;
		}

		if (item) {
			definition = item.definition;
			sourceMetadata = definition.settings;
			if (!sourceMetadata && definition.custom) {
				sourceMetadata = definition.custom.metadata;
			}
		} else {
			definition = {};
			this.copyPublishSettings(sourceDefinition, definition);
			sourceMetadata = definition.settings;
			item = { definition: definition };
			if (this.publishedItem) {
				item.localization = this.publishedItem.localization;
			}
		}

		// TODO Decide title priority (widget title vs publish configuration title etc).
		let title = widgetData.title;
		if (!title) {
			title = definition.title || sourceDefinition.standardTitle;
		}

		const metadata = this.getPublishSettings(sourceMetadata);
		const custom = {
			settings: settingsValues,
			metadata: metadata,
			title: title,
			isCatalogTitle: this.widget.isCatalogTitle(),
			isTitleLocked: widgetData.isTitleLocked
		} as c.ICustomWidget;

		if (widgetData.logicalId) {
			// Only set this when necessary
			custom.logicalId = widgetData.logicalId;
		}
		if (widgetData.titleApi) {
			custom.titleApi = widgetData.titleApi;
		}

		definition.custom = custom;

		// Reset properties that is not used for published widgets
		// TODO Remove isTitleLocked 
		widgetData.custom = null;
		definition.settings = null;

		// Verify mandatory properties for publish 
		if (!definition.standardWidgetId) {
			definition.standardWidgetId = sourceDefinition.standardWidgetId || sourceDefinition.widgetId;
		}

		if (!isNew) {
			definition.widgetId = widgetData.id;
		}

		return item;
	}

	private toCustom(widget: c.IWidget, customId: string): void {
		widget.byRef = true;

		const data = widget.data;
		data.id = customId;

		// Clear values that should not be saved for a published wiget
		data.settings = null;
	}

	private publishWidget(item: c.IPublishedWidgetItem) {
		var isCopy = this.isPublishCopy;
		this.widgetService.publish(item).then((response: c.IStringResponse) => {
			var container = this.containerService.getContainer();
			if (isCopy) {
				// When a copy of the widget is published we don't need to save but the page must still be refreshed to discard local changes to the widget.
				container.refresh();
			} else {
				const id = response.content;
				this.toCustom(this.widget, id);
				container.saveAndRefreshCurrent();
			}
		}, (r: c.IStringResponse) => {
			this.widgetService.handleError(r);
		});
	}

	private republishWidget(item: c.IPublishedWidgetItem) {
		this.widgetService.updatePublished(item).then((response: c.IStringResponse) => {
			this.containerService.getContainer().saveAndRefreshCurrent();
		}, (r: c.IStringResponse) => {
			this.widgetService.handleError(r);
		});
	}

	private showMissingInfoMessage() {
		this.dialogService.showMessage({ title: this.lang.missingInformation, message: this.lang.noTitleOrDescription }).then(() => {
			this.showPublishConfiguration();
		});
	}

	public reset() {
		const options: lm.IMessageDialogOptions = {
			title: this.lang.confirmReset,
			message: this.lang.confirmResetMessage,
			standardButtons: lm.StandardDialogButtons.YesNo
		};
		this.dialogService.showMessage(options).then((result: lm.IDialogResult) => {
			if (result.button === lm.DialogButtonType.Yes) {
				this.widget.restore();
				if (this.widget.instance.actions) {
					this.setPrimaryAction();
				}
			}
		});
	}

	/*
	* Copies the widget on the page using the standard widget - applying all settings form standard widget combined with the current settings
	*/
	public duplicate() {
		this.progressService.setBusy(true);
		const addWidgetInfo = this.widgetService.getAddWidgetInfo(this.widget);
		// Add to same page context
		const context = this.widget.parentContext;
		// Copy all the settings and apply it to the newly added widget
		this.widgetService.addWidgetCopyToPage(context, addWidgetInfo).then(() => {
			this.progressService.setBusy(false);
		}, (error: c.IOperationResponse) => {
			this.widgetService.handleError(error);
		});
	}

	public copy() {
		this.rootScope["clipboardWidget"] = {};
		$.extend(true, this.rootScope["clipboardWidget"], this.widget);
	}

	public showPublishConfiguration() {
		// Create an object that can be edited by the dialog.
		// This object is a copy so any changes to the definition will not have any effect until applied.
		const widget = this.widget;

		try {
			WidgetUtil.updateMetadata(widget);
		} catch (e) {
			this.error("Failed get metadata for widget " + widget.id, e);
		}

		const editableItem = this.createEditableItem(widget);
		const definition = widget.definition;
		const parameter: c.IPublishWidgetOptions = {
			item: editableItem,
			definition: definition
		};

		const options = <lm.IDialogOptions>{
			title: this.lang.editPublishConfiguration,
			templateUrl: "scripts/lime/templates/widget-customize.html",
			parameter: parameter,
			style: "width:640px;",
			id: c.Constants.modalWidgetCustomize
		};

		var self = this;
		this.dialogService.show(options).then((r: lm.IDialogResult) => {
			self.onClosePublishConfiguration(r);
		});
	}

	private onClosePublishConfiguration(r: lm.IDialogResult): void {
		const info: c.IWidgetPublishInfo = r.value;
		if (!info) {
			return;
		}

		this.publishInfo = info;
		const item = info.publishedItem;
		const definition = item.definition;
		const widget = this.widget;
		const sourceDefinition = widget.definition;
		const isPublished = sourceDefinition.isPublished;
		const isEditMode = this.editModeService.isActive();
		const widgetData = widget.data;
		let localization: c.IStringToEntityLocalizationMap = null;
		const isCatalogTitle = definition.isCatalogTitle;
		const customWidget = sourceDefinition.custom;

		if (info.isLocalizationChanged) {
			localization = info.publishedItem.localization;
		}
		let customItem = widgetData.custom;

		if (!isPublished) {
			// Save only a subset of the settings metadata.
			definition.settings = this.getPublishSettings(definition.settings);

			// For a non-published widget the custom configuration is stored in the custom property in the widget data
			if (!customItem) {
				customItem = <c.IPublishedWidgetItem>{};
				widgetData.custom = customItem;
			}
			customItem.definition = definition;
			customItem.localization = localization;
		}

		if (sourceDefinition.enableTitleEditDef !== false) {
			if (isCatalogTitle) {
				if (customItem) {
					customItem.definition.isCatalogTitle = true;
				} else if (customWidget) {
					customWidget.isCatalogTitle = true;
				}
				if (isPublished) {
					widget.definition.title = definition.title;
				}
				widget.setTitleInternal(null); // This will reset any existing title (by design for now).
			} else {
				if (customItem) {
					customItem.definition.isCatalogTitle = false;
				} else if (customWidget) {
					customWidget.isCatalogTitle = false;
				}
				widget.updateTitle();
			}
		}

		if (!isEditMode) {
			// Only save here if we are not in edit mode since it should be possible to cancel edit mode without applying changes.
			this.containerService.getContainer().saveAndRefreshCurrent();
		}
	}

	/**
	* Show the about dialog for a widget.
	*/
	private showAbout() {
		const options = <lm.IDialogOptions>{
			title: this.lang.about,
			templateUrl: "scripts/lime/templates/widget-about.html",
			parameter: { widget: this.widget },
			style: "width:356px;" // width of input fields + padding
		};
		this.dialogService.show(options);
	}

	private exportWidget() {
		var url = this.widgetService.exportWidget(this.widget.data);
		//this.openWidgetExport(url, this.widget.data); // TODO: Doesn't work yet!
		//window.open(url, '_blank');
	}

	private openWidgetExport(url, data) {
		var form = document.createElement("form");
		form.action = url;
		form.method = "POST";
		form.target = "_blank";
		if (data) {
			for (var key in data) {
				var input = document.createElement("textarea");
				input.name = key;
				input.value = typeof data[key] === "object" ? JSON.stringify(data[key]) : data[key];
				form.appendChild(input);
			}
		}
		form.style.display = "none";
		document.body.appendChild(form);
		form.submit();
		// TODO Remove when finsihed
	}

	private getTitle(widget: c.IWidget): string {
		return widget.title;
	}

	private applyEnabled(source: lm.IWidgetSettingMetadata[], target: lm.IWidgetSettingMetadata[]): void {
		if (source && target) {
			for (var i = 0; i < source.length; i++) {
				var sourceSetting = source[i];
				var targetSetting = <lm.IWidgetSettingMetadata>lm.ArrayUtil.itemByProperty(target, "name", sourceSetting.name);
				if (targetSetting) {
					targetSetting.isEnabled = sourceSetting.isEnabled;
					targetSetting.isVisible = sourceSetting.isVisible;
				}
			}
		}
	}

	private createEditableItem(widget: c.IWidget): c.IPublishedWidgetItem {
		var definition = widget.definition;

		// Settings are always retrieved from the definition since modifications have been applied in setDefinition
		var settings = definition.settings ? angular.copy(definition.settings) : null;
		var sourceDefinition: c.IWidgetDefinition;
		var title: string = null;
		var enableSettings = false;
		var enableTitleEdit = false;
		let enableFromDefinition = true;
		var localization: c.IStringToEntityLocalizationMap = null;
		var isTitleEditEnabled = widget.definition.enableTitleEditDef !== false;

		var info = this.publishInfo;
		var item = this.publishedItem;
		if (info) {
			// The dialog has been open in edit mode
			var infoItem = info.publishedItem;
			sourceDefinition = infoItem.definition;
			localization = infoItem.localization;
		} else if (item) {
			// Editing a published widget
			sourceDefinition = item.definition;
			localization = item.localization;
		} else {
			var customItem = widget.data.custom;
			if (customItem && customItem.definition) {
				// Config has been saved but widget is not published
				sourceDefinition = customItem.definition;
				localization = customItem.localization;
				this.publishInfo = { publishedItem: { localization: localization, definition: sourceDefinition }, isLocalizationChanged: true };
			} else {
				sourceDefinition = widget.definition;
				title = widget.title;
				// Default to not enabled for both settings and title the first time
				enableFromDefinition = false;
			}
		}

		if (!title) {
			title = sourceDefinition.title || definition.standardTitle;
		}

		const description = sourceDefinition.description;
		const tags = sourceDefinition.tags;
		const isCatalogTitle = widget.isCatalogTitle();

		if (enableFromDefinition) {
			// Default value is false if undefined
			enableSettings = !!sourceDefinition.enableSettings;
			enableTitleEdit = !!sourceDefinition.enableTitleEdit;

			// Apply any edited values if the dialog is opened and closed multiple times in edit mode.
			this.applyEnabled(sourceDefinition.settings, settings);
		}

		const editableDefinition: c.IWidgetDefinition = {
			settings: settings,
			enableSettings: enableSettings,
			enableTitleEdit: enableTitleEdit,
			title: title,
			description: description,
			tags: tags,
			isCatalogTitle: isCatalogTitle
		};

		const publishItem: c.IPublishedWidgetItem = {
			definition: editableDefinition,
			localization: localization ? angular.copy(localization) : null
		};
		return publishItem;
	}

	public static add(m: ng.IModule) {
		m.controller("lmWidgetContainerCtrl", WidgetContainerCtrl);
	}
}

class WidgetResizeCtrl extends c.CoreBase {
	static $inject = ["$scope", "lmPageService", "lmContextService"];
	private dialog: lm.IDialog = null;
	private context: c.IContext;

	constructor(public scope: any, private pageService: c.IPageService, private contextService: c.IContextService) {
		super("[AddPageCtrl] ");
		this.context = contextService.getContext();
		var dialog: lm.IDialog = scope["lmDialog"];
		if (!dialog) {
			this.error("lmDialog is not found in scope when opening add page dialog");
			return;
		}
		this.dialog = dialog;
		dialog.result = <lm.IDialogResult>{};
		scope["layout"] = dialog.parameter;

		dialog.result.value = dialog.parameter;
	}

	static add(m: ng.IModule) {
		m.controller("lmResizeWidgetCtrl", WidgetResizeCtrl);
	}
}

export class WidgetSettingsContext implements lm.IWidgetSettingsContext {

	private isSaveEnabledInternal = true;
	angularConfig: lm.IAngularWidgetConfig = null;

	constructor(private widget: c.IWidget, private element: JQuery, private dialog: lm.IDialog) {
	}

	getWidgetContext(): lm.IWidgetContext {
		return this.widget.context;
	}

	getElement(): JQuery {
		return this.element;
	}

	enableSave(isEnabled: boolean): void {
		this.isSaveEnabledInternal = isEnabled;
	}

	isSaveEnabled(): boolean {
		return this.isSaveEnabledInternal;
	}

	close(isSave: boolean): void {
		var result: lm.IDialogResult = {};

		result.button = isSave ? lm.DialogButtonType.Ok : lm.DialogButtonType.Cancel;
		this.dialog.close(result);
	}
}

export class WidgetContext extends c.CoreBase implements lm.IWidgetContext {
	private visible = false;
	private language: lm.ILanguage;
	private config: c.IConfiguration = null;
	private application: lm.IApplication;
	private applications: lm.IApplication[];

	/**
	* Gets or sets the unique widget ID.
	*/
	private id: string;

	private data: any;

	// TODO Private?
	widget: c.IWidget;

	constructor(private q: ng.IQService, private timeout: ng.ITimeoutService, private widgetService: c.IWidgetService, widget: c.IWidget, private settings: lm.IWidgetSettings, private element: JQuery, private angularContext: lm.IAngularContext, private context: c.IContext, languageService: c.ILanguageService) {
		super("[WidgetContext] ");
		this.widget = widget;
		this.config = context.getConfiguration();

		var language = <lm.ILanguage>(widget.definition.lang || {});

		// Extend the language object with the get function.
		language.get = (id: string) => {
			var text = language[id];
			return text || null;
		};

		// Extend the language object with supported shared lime language constants
		const limeLanguage = languageService.getLanguage();
		for (let i = 0; i < c.Constants.sharedLimeLanguageConstants.length; i++) {
			if (!language.hasOwnProperty(c.Constants.sharedLimeLanguageConstants[i])) {
				language[c.Constants.sharedLimeLanguageConstants[i]] = limeLanguage[c.Constants.sharedLimeLanguageConstants[i]];
			}
		}

		this.language = language;

		this.initializeApplication();
	}

	private isValidLogicalId(logicalId: string) {
		const logicalIdPrefix = this.getLogicalIdPrefix();
		return logicalIdPrefix && logicalId && logicalId.indexOf(logicalIdPrefix) == 0;
	}

	private initializeApplication(): void {
		const logicalIdPrefix = this.getLogicalIdPrefix();
		if (!logicalIdPrefix) {
			return;
		}

		// Check if the default logical ID has been overridden by the widget (and is still valid).
		const data = this.widget.data;
		let logicalId = data.logicalId;
		if (logicalId) {
			if (!this.isValidLogicalId(logicalId)) {
				logicalId = null;
				delete data.logicalId;
			}
		}
		this.setApplication(logicalId || logicalIdPrefix);
	}

	private setApplication(logicalId: string) {
		if (logicalId) {
			this.applications = this.config.getApplicationsCached(logicalId);
			this.application = this.config.getApplicationCached(logicalId);
		} else {
			this.applications = null;
			this.application = null;
		}
	}

	getId(): string {
		return this.widget.id;
	}

	getSettings(): lm.IWidgetSettings {
		return this.settings;
	}

	getLanguage(): lm.ILanguage {
		return this.language;
	}

	getElement(): JQuery {
		return this.element;
	}

	getUrl(path?: string): string {
		return WidgetUtil.getUrl(this.widget.definition, path);
	}

	getAngularContext(): lm.IAngularContext {
		return this.angularContext;
	}

	public isPublished(): boolean {
		const widget = this.widget;
		return widget.definition.isPublished || widget.parentContext.isPublished;
	}

	public isDev(): boolean {
		return c.ClientConfiguration.isDev();
	}

	public save(): void {
		this.widget.raiseChanged();
	}

	isActive(): boolean {
		var widget = this.widget;
		return widget.isVisible && widget.state === lm.WidgetState.running && !widget.isEdit && !widget.isSettings;
	}

	isVisible(): boolean {
		return this.widget.isVisible;
	}

	setState(state: string): void {
		// TODO Validate state
		const widget = this.widget;
		if (widget.state !== state) {
			widget.state = state;
			this.timeout(() => {
				// Nothing to do here at the moment but we need a new digest loop for non-angular widgets.
			});
		}
	}

	getState(): string {
		return this.widget.state;
	}

	getTitle(): string {
		return this.widget.data.title;
	}

	getStandardTitle(): string {
		return this.widget.definition.standardTitle;
	}

	setTitle(title: string): void {
		try {
			const widget = this.widget;
			widget.titleApi = title;
			widget.data.titleApi = title;

			if (widget.isCatalogTitle() || !widget.data.isTitleLocked) {
				if (this.isDebug()) {
					this.debug("Ignoring setTitle call from implementation becuase widget is configured to use catalog title or the title is unlocked");
				}
				return;
			}

			widget.setTitleInternal(title);
		} catch (ex) {
			this.error("Failed to setTitle " + ex);
		}
	}

	public enableTitleEdit(isEnabled: boolean) {
		this.widget.isTitleEditEnabled = isEnabled;
	}

	public isTitleEditEnabled(): boolean {
		return this.widget.isTitleEditEnabled;
	}

	public getPageId(): string {
		try {
			return this.widget.parentContext.id;
		} catch (ex) {
			return null;
		}
	}

	public getStandardWidgetId(): string {
		return this.widget.definition.standardWidgetId || this.widget.id;
	}

	public getWidgetInstanceId(): string {
		return this.widget.data.instanceId;
	}

	public getService<T>(name: string): T {
		var element = this.widget.element;
		if (element) {
			var injector = (<ng.IAugmentedJQuery>element).injector();
			if (injector) {
				try {
					return injector.get(name);
				} catch (ex) {
					this.error("Failed to get service " + name, ex);
				}
			}
		}
		return null;
	}

	public getApplication(): lm.IApplication {
		return this.application;
	}

	public getApplications(): lm.IApplication[] {
		return this.applications || [];
	}

	public getLogicalId(): string {
		const application = this.application;
		return application ? application.logicalId : null;
	}

	public setLogicalId(logicalId: string): void {
		const data = this.widget.data;
		if (logicalId) {
			if (!this.isValidLogicalId(logicalId)) {
				throw "Invalid logical ID";
			}
			data.logicalId = logicalId;
		} else {
			delete data.logicalId;
		}
		this.initializeApplication();
	}

	public isCloud(): boolean {
		return this.context.isCloud();
	}

	public getContainerUrl(): string {
		return this.context.getContainerUrl();
	}

	public getApplicationAsync(logicalId: string): ng.IPromise<lm.IApplication> {
		return this.config.getApplication(logicalId);
	}

	public getApplicationsAsync(logicalId: string): ng.IPromise<lm.IApplication[]> {
		return this.config.getApplications(logicalId);
	}

	public getIonApiCustomerContext(): string {
		return this.config.ionApiCustomerContext;
	}

	public getIonApiContextAsync(options: lm.IIonApiOptions): ng.IPromise<lm.IIonApiContext> {
		return this.config.getIonApiContextAsync(options);
	}

	public executeIonApiAsync<T>(options: lm.IIonApiRequestOptions): ng.IPromise<ng.IHttpPromiseCallbackArg<T>> {
		return this.config.executeIonApiAsync(options);
	}

	public resolveAndReplaceAsync(template: string, logicalId: string): ng.IPromise<string> {
		const deferred = this.q.defer<string>();
		this.resolveAndReplaceInternalAsync(template, logicalId || this.getLogicalId(), deferred, true, false);
		return deferred.promise;
	}

	private getViewTemplate(views: c.IApplicationView[], viewId: string): string {
		const view = <c.IApplicationView>lm.ArrayUtil.itemByProperty(views, "viewId", viewId);
		return view ? view.urlTemplate : null;
	}

	private resolveViewUrl(options: lm.IViewUrlOptions, application: lm.IApplication, deferred: ng.IDeferred<string>): void {
		// The views property is not officially part of the API for now and not inlcuded in IApplicationView.
		// Views might also be loaded asynchronously if the amount data is to much to always return wheter its used or not.
		var views: c.IApplicationView[] = (<any>application).views;
		if (views) {
			var template = this.getViewTemplate(views, options.viewId);
			if (template) {
				if (options.resolve === false) {
					deferred.resolve(template);
					return;
				}
				this.resolveAndReplaceInternalAsync(template, application.logicalId, deferred, true, true);
				return;
			}
		}
		deferred.reject("View not found");
	}

	public getViewUrlAsync(options: lm.IViewUrlOptions): ng.IPromise<string> {
		var deferred = this.q.defer<string>();
		const logicalId = options.logicalId || this.getLogicalId();
		this.config.getApplication(logicalId).then((application: lm.IApplication) => {
			this.resolveViewUrl(options, application, deferred);
		}, (e: any) => {
			deferred.reject(e);
		});
		return deferred.promise;
	}

	private getAbsoluteUrl(url: string, useHttps: any): string {
		if (url.indexOf("http://") != 0 && url.indexOf("https://") != 0) {
			url = this.getScheme(useHttps) + "://" + url;
		}
		return url;
	}

	resolveAndReplaceInternalAsync(template: string, logicalId: string, deferred: ng.IDeferred<string>, isFirst: boolean, isUrl: boolean): void {
		//// Alternative regex implementation
		//var matches = template.match(/{(lid:\/\/.*?)}/);
		//if (matches.length > 1) {
		//	template = template.replace(matches[0], "");
		//	logicalId = matches[1];
		//}


		// Check if the template contains an override logical ID prefix
		if (template.indexOf("{lid://") == 0) {
			var end = template.indexOf("}");
			if (end > 0) {
				logicalId = template.substring(1, end);
				template = template.substring(end + 1);
			}
		}

		if (!logicalId) {
			deferred.resolve(this.resolveAndReplace(template));
			return;
		}

		// Get the application to make sure that it exists in the cache before resolving
		this.config.getApplication(logicalId).then((application: lm.IApplication) => {
			template = this.resolveAndReplaceInternal(template, logicalId);

			if (isFirst && template && template.indexOf("{") >= 0) {
				// If the template still contains replacement variables we try once more. Fully recursive replacement is not supported for now.
				this.resolveAndReplaceInternalAsync(template, logicalId, deferred, false, isUrl);
			} else {
				if (isUrl) {
					template = this.getAbsoluteUrl(template, application.useHttps);
				}
				deferred.resolve(template);
			}
		}, () => {
			deferred.reject();
		});
	}

	private getLogicalIdPrefix(): string {
		return this.widget.definition.applicationLogicalId;
	}

	resolve(key: string): string {
		return this.resolveValue(key, this.getLogicalId());
	}

	private resolveValue(key: string, logicalId: string): string {
		if (!key) {
			return key;
		}

		var i = key.indexOf(".");
		var prefix = null;
		if (i > 1) {
			prefix = key.substring(0, i);
			prefix = prefix.toLowerCase();
		}

		var cst = c.Constants;
		var widget = this.widget;
		var config = this.config;

		// If it is prefixed then it must come from the correct source or null will be returned
		if (prefix && (c.Constants.configurationPrefixes.indexOf(prefix) >= 0)) {
			// Substring but exclude the dot.
			var name = key.substring(i + 1, key.length);
			// Value is scoped to a specific container
			var resolvedValue = null;

			// Special case for application.Scheme
			if (name.toLowerCase() === c.Constants.scheme && prefix === cst.configurationApplicationPrefix) {
				// Special case Scheme maps to UseHttps
				var schema = this.resolveScheme(logicalId, config, prefix);
				if (schema) {
					return schema;
				}
			}

			if (prefix === cst.configurationWidgetPrefix) {
				resolvedValue = this.resolveFromSource(widget.data, logicalId, cst.configurationSettings, name);
			} else if (prefix === cst.configurationLocalizationPrefix) {
				resolvedValue = this.resolveFromSource(widget.context.getLanguage(), logicalId, null, name);
			} else if (prefix === cst.configurationViewPrefix) {
				var application = this.config.getApplicationCached(logicalId);
				if (application) {
					// TODO Typing of views property
					resolvedValue = this.getViewTemplate(<c.IApplicationView[]>(<any>application).views, name);
					if (resolvedValue && resolvedValue.indexOf("http") !== 0) {
						resolvedValue = this.getScheme(application.useHttps) + "://" + resolvedValue;
					}
				}
			} else if (prefix === cst.configurationFrameworkPrefix) {
				resolvedValue = this.resolveFramework(name);
			} else {
				resolvedValue = this.resolveFromSource(config, logicalId, prefix, name);
			}
			return resolvedValue;
		}

		// First check settings for widget
		var value = this.resolveFromSource(widget.data, logicalId, cst.configurationSettings, key);
		if (value != null) {
			return value.toString();
		}

		// Check ad-hoc configuration
		value = this.resolveFromSource(config, logicalId, cst.configurationProperties, key);
		if (value != null) {
			return value;
		}

		var keyLowerCase = key.toLocaleLowerCase();
		// Check if this is to resolve tenantid
		if (keyLowerCase === c.Constants.tenantId) {
			return this.context.getTenantId();
		}

		// Check if this is to resolve userid
		if (keyLowerCase === c.Constants.userid) {
			return this.context.getUserId();
		}

		// Check if this is to resolve language
		if (keyLowerCase === c.Constants.language) {
			return this.context.getLanguage();
		}

		// Check Ming.le configuration
		value = this.resolveFromSource(config, logicalId, cst.configurationApplication, key);
		if (value != null) {
			return value;
		}

		// For key Scheme use UseHttps
		if (keyLowerCase === c.Constants.scheme) {
			return this.resolveScheme(logicalId, config, cst.configurationApplication);
		}

		return null;
	}

	private getScheme(useHttps: any): string {
		return useHttps === true || useHttps === "true" || useHttps === "1" ? "https" : "http";
	}

	private resolveFramework(name: string) {
		var widget = this.widget;
		name = name.toLowerCase();
		if ("pageid" === name) {
			return widget.parentContext.id;
		}
		if ("widgetid" === name) {
			return widget.id;
		}
		if ("standardwidgetid" === name) {
			return widget.definition.standardWidgetId || widget.id;
		}
		if ("widgetinstanceid" === name) {
			return widget.data.instanceId;
		}
		if ("containerurl" === name) {
			return widget.context.getContainerUrl();
		}
		return null;
	}

	private resolveScheme(logicalId: string, container: any, prefix: string): string {
		let useHttps = this.resolveFromSource(container, logicalId, prefix, c.Constants.useHttps);
		if (useHttps) {
			useHttps = useHttps.toLowerCase();
			return this.getScheme(useHttps);
		}
		return null;
	}

	private resolveFromSource(container: any, logicalId: string, propertyName: string, key: string): string {
		if (!container) {
			return null;
		}
		var mapObject;
		var cst = c.Constants;
		if (!propertyName) {
			mapObject = container;
		} else if (propertyName === cst.configurationApplication) {
			mapObject = (<c.IConfiguration>container).getApplicationCached(logicalId);
		} else if (propertyName === cst.configurationPropertyPrefix) {
			mapObject = container[cst.configurationProperties];
		} else {
			mapObject = container[propertyName];
		}

		if (!mapObject) {
			if (this.isDebug()) {
				this.debug("[resolveFromSource] " + propertyName + " " + key + ", no such configuration.");
			}
			return null;
		}

		// Try with exact case
		var stringValue;
		var value = mapObject[key];
		if (lm.CommonUtil.hasValue(value)) {
			stringValue = value.toString();
			if (this.isDebug()) {
				this.debug("[resolveFromSource] Resolved " + key + " to: " + stringValue);
			}
			return stringValue;
		}

		// Try case insensitive
		var keyUpper = key.toUpperCase();
		for (var name in mapObject) {
			if (keyUpper === name.toUpperCase()) {
				value = mapObject[name];
				if (lm.CommonUtil.hasValue(value)) {
					stringValue = value.toString();
					if (this.isDebug()) {
						this.debug("[resolveFromSource] Resolved " + keyUpper + " to: " + stringValue);
					}
					return stringValue;
				} else {
					return null;
				}
			}
		}

		if (this.isDebug()) {
			this.debug("[resolve] " + propertyName + " has no value for " + key + ".");
		}
		return null;
	}

	resolveAndReplace(template: string): string {
		return this.resolveAndReplaceInternal(template, this.getLogicalId());
	}

	private resolveAndReplaceInternal(template: string, logicalId: string): string {
		// Resolve special case with :{Port} that should collapse to empty if 0 or blank
		template = this.replaceSpecialCases(template, logicalId);

		// TODO Encode apply rules - parse for rule
		var resolveFunction = (key) => {
			var value = this.resolveInternal(key, logicalId);
			return value;
		}

		return lm.StringUtil.replaceParameters(template, resolveFunction);
	}

	private replaceSpecialCases(template: string, logicalId: string): string {
		// Search and replace port & context
		template = this.replaceSpecialVariable(template, logicalId, ":{Port}", "Port", ":", "");
		template = this.replaceSpecialVariable(template, logicalId, ":{Application.Port}", "Application.Port", ":", "");
		template = this.replaceSpecialVariable(template, logicalId, "/{Context}", "Context", "/", "");
		template = this.replaceSpecialVariable(template, logicalId, "/{Application.Context}", "Application.Context", "/", "");
		return template;
	}

	private replaceSpecialVariable(template: string, logicalId: string, searchText: string, variableName: string, resolvedPrefix: string, defaultText: string): string {
		if (template && template.indexOf(searchText) > -1) {
			let resolved = this.resolveInternal(variableName, logicalId);
			// ReSharper disable once CoercedEqualsUsing
			if (!resolved || resolved == "0") {
				// Replace with default eg empty
				template = template.replace(searchText, defaultText);
			} else {
				if (resolvedPrefix) {
					resolved = resolvedPrefix + resolved;
				}
				template = template.replace(searchText, resolved);
			}
		}
		return template;
	}

	private resolveInternal(key: string, logicalId: string): string {
		// Check if we have a rule that should be applied after replacing
		let name = key;
		const index = key.indexOf("|");
		let encode = true;
		let defaultValue = "";
		let useUriEncode = true;
		if (index > 0) {
			name = key.substring(0, index);
			let filter = key.substring(index + 1, key.length);
			filter.trim();

			if (filter && filter.length > 1) {
				filter = filter.toLowerCase();
				const ruleIndex = filter.indexOf(":");
				let filterParam: string = null;
				if (ruleIndex > 0) {
					// Get filter before we change the filter
					filterParam = filter.substring(ruleIndex + 1, filter.length);
					filterParam.trim();
					filterParam = filterParam.toLowerCase();

					filter = filter.substring(0, ruleIndex);
				}

				if (filter === "encode") {
					if (filterParam === "none") {
						encode = false;
					} else if (filterParam === "uri") {
						useUriEncode = true;
					} else if (filterParam === "component") {
						useUriEncode = false;
					}
				} else if (filter === "default") {
					defaultValue = filterParam;
				}

			}
		}

		name = name.trim();
		const value = this.resolveValue(name, logicalId);
		if (value) {
			// Apply encoding or default values according to filter
			if (encode) {
				if (useUriEncode) {
					return encodeURI(value);
				} else {
					return encodeURIComponent(value);
				}
			}
			return value;
		}

		return defaultValue;
	}

	public launch(launchOptions: lm.ILaunchOptions) {
		if (!launchOptions) {
			throw "launchOptions is not set";
		}

		if (!launchOptions.url) {
			throw "url is not set";
		}

		var url = launchOptions.url;
		if (lm.CommonUtil.isUndefined(launchOptions.resolve)) {
			launchOptions.resolve = true;
		}

		if (launchOptions.resolve === true && url.indexOf("{") >= 0) {
			this.debug("About to resolve launch of: " + url);
			this.resolveAndReplaceAsync(url, null).then(
				(result) => {
					this.launchInternal(result);
				},
				(err) => {
					if (c.ClientConfiguration.isDev()) {
						alert("Not supported in test mode unless configration is provided and dev-configration attribute set on test widget. Please see Homepages developers guide");
					}
					this.error("Failed to resolve " + url + " " + err);
				});
		} else {
			this.launchInternal(url);
		}
	}

	private launchInternal(url: string) {
		if (url.indexOf("http") === 0 || url.indexOf("/") === 0) {
			// Open in a new tab
			this.debug("Launching URL in tab " + url);
			window.open(url);
		} else {
			this.debug("Launching URL in Ming.le " + url);
			var isFavorite = url.indexOf("?favoriteContext") === 0;
			var client = infor.companyon.client;
			if (isFavorite) {
				client.sendPrepareFavoritesMessage(url);
			} else {
				client.sendPrepareDrillbackMessage(url);
			}
		}
	}

	public showWidgetMessage(message: lm.IWidgetMessage) {
		this.widget.message = message;
	}

	public removeWidgetMessage() {
		delete this.widget.message;
	}
}

class WidgetSettings implements lm.IWidgetSettings {

	constructor(private widgetService: c.IWidgetService, private widget: c.IWidget, private values: any) {
	}

	private getSetting(name: string): lm.IWidgetSettingMetadata {
		return lm.ArrayUtil.itemByProperty(this.getMetadata(), "name", name);
	}

	public getValues(): any {
		return this.values;
	}

	public setValues(values: any): void {
		this.values = values;
		// need to set reference between Widget.data.settings and WidgetSettings.values back correctly
		this.widget.data.settings = this.values;
	}

	public get<T>(name: string, defaultValue?: T): T {
		var value = this.values[name];
		return !lm.CommonUtil.isUndefined(value) ? value : defaultValue;
	}

	public set(name: string, value: any): void {
		this.values[name] = value;
	}

	public getString(name: string, defaultValue?: string): string {
		var value = this.values[name];
		return value ? value.toString() : defaultValue;
	}

	showSettings(options?: lm.IShowSettingsOptions): void {
		var data = options ? options.data : null;
		this.widgetService.showSettings(this.widget, data);
	}

	public getMetadata(): lm.IWidgetSettingMetadata[] {
		return this.widget.definition.settings;
	}

	public setMetadata(metadata: lm.IWidgetSettingMetadata[]): any {
		var definition = this.widget.definition;
		if (metadata) {
			var customMetadata = definition.customMetadata;
			if (customMetadata) {
				metadata = WidgetUtil.applyRestrictions(metadata, customMetadata);
			}
		}
		definition.settings = metadata;
	}

	public isSettingsEnabled(): boolean {
		return this.widget.isSettingsEnabled();
	}

	private getCustomSetting(name: string): lm.IWidgetSettingMetadata {
		const metadata = this.widget.definition.customMetadata;
		if (metadata) {
			return lm.ArrayUtil.itemByProperty(metadata, "name", name);
		}
		return null;
	}

	public isSettingEnabled(name: string): boolean {
		if (!this.isSettingsEnabled()) {
			return false;
		}
		var setting = this.getCustomSetting(name);
		if (setting && setting.isEnabled === false) {
			return false;
		}
		setting = this.getSetting(name);
		return setting && setting.isEnabled == false ? false : true;
	}

	public isSettingVisible(name: string): boolean {
		var setting = this.getCustomSetting(name);
		if (setting && setting.isVisible === false) {
			return false;
		}
		setting = this.getSetting(name);
		return setting && setting.isVisible == false ? false : true;
	}

	public enableSettingsMenu(enabled: boolean): void {
		this.widget.setSettingsMenuEnabled(enabled);
	}
}

class WidgetContainerDirective extends c.CoreBase {
	private widgetInstance: lm.IWidgetInstance;

	constructor(private rootScope: ng.IRootScopeService, private q: ng.IQService, private timeout: ng.ITimeoutService, private compile: ng.ICompileService, private templateCache: ng.ITemplateCacheService, private widgetService: c.IWidgetService, private contextService: c.IContextService, private languageService: c.ILanguageService) {
		super("[WidgetContainerDirective] ");
	}

	private createContext(scope: ng.IScope, widget: c.IWidget, element: JQuery, definition: c.IWidgetDefinition): lm.IWidgetContext {
		// TODO Add default settings values if no settings exists

		let values = widget.data.settings;
		if (!values) {
			widget.data.settings = values = <c.IStringToAnyMap>{};
		}

		// TODO Consider creating a class for this
		const angularContext = scope != null ? {
			module: WidgetContainerDirective.externalModule,
			scope: scope,
			compile: this.compile,
			getTemplateUrl: (relativeUrl: string): string => {
				return WidgetUtil.getUrl(definition, relativeUrl);
			}
		} : null;
		const settings = new WidgetSettings(this.widgetService, widget, values);
		const context = this.contextService.getContext();
		return new WidgetContext(this.q, this.timeout, this.widgetService, widget, settings, element, angularContext, context, this.languageService);
	}

	private attach(scope: ng.IScope, controller: WidgetContainerCtrl, widget: c.IWidget, element: JQuery): void {
		var unregister = widget.restored().on(() => {
			if (controller) {
				// Exernal widgets (iframe) will only be reloaded if url has changed
				controller.setUrl("");
			}
			unregister();
			element.empty();
			this.addWidget(scope, controller, widget, element);
		});
	}

	private addInline(scope: ng.IScope, widget: c.IWidget, element: JQuery) {
		var factory = widget.widgetModule.widgetFactory;
		if (!factory) {
			this.error("The widget module for widget with id " + widget.data.id + " does not export a factory function for widget.");
			return;
		}

		//TODO Karin this should already be in the IWidget
		var definition = this.widgetService.getCachedDefinition(widget.id);
		if (!definition) {
			this.error("Definition for id " + widget.id + " is not in the cache.");
			return;
		}

		var context = this.createContext(scope, widget, element, definition);
		widget.context = context;
		// Put the context in the scope for the widget to use
		scope[lm.WidgetConstants.widgetContextKey] = context;
		var instance: lm.IWidgetInstance = factory(context);
		scope[lm.WidgetConstants.widgetInstanceKey] = instance;

		// TODO Error handling, the factory should be allowed to throw exceptions

		widget.instance = instance;
		this.widgetInstance = instance;

		var config = this.widgetInstance.angularConfig;
		if (config) {
			WidgetUtil.cacheTemplates(this.templateCache, config);
			WidgetUtil.addAngularContent(scope, this.compile, element, config, definition);
		}

		this.attach(scope, null, widget, element);

	}

	private addExternal(scope: ng.IScope, controller: WidgetContainerCtrl, widget: c.IWidget, element: JQuery) {
		var iframe = lm.HtmlUtil.iframe(null, widget.data.instanceId);

		element.addClass("lm-position-r");
		element.append(iframe);
		// TODO Karin the definiition should already be in the IWidget
		var definition = this.widgetService.getCachedDefinition(widget.id);
		var context = this.createContext(null, widget, element, definition);
		widget.context = context;
		controller.loadExternal(widget, iframe);

		this.attach(scope, controller, widget, element);
	}

	private addWidget(scope: ng.IScope, controller: WidgetContainerCtrl, widget: c.IWidget, element: JQuery) {
		scope["lmWidget"] = widget;

		if (widget.data.isBroken || this.rootScope[c.Constants.safeMode]) { return; }

		var type = widget.widgetType.toLowerCase();
		if (type === c.WidgetType.Inline) {
			this.addInline(scope, widget, element);
		} else if (type === c.WidgetType.External) {
			this.addExternal(scope, controller, widget, element);
		} else {
			this.error("Widget type " + type + " is not supported.");
		}
	}

	public link(scope: ng.IScope, element: ng.IAugmentedJQuery, attributes: ng.IAttributes, controller: any, transclude: ng.ITranscludeFunction) {
		var widget = <c.IWidgetData>scope.$parent["lmWidget"]; // TODO Name dependency

		// Find the content element in the template
		var content = element.find(".widget-content");

		// Load the widget and add it to the template
		this.widgetService.loadWidget(widget).then((w) => this.addWidget(scope, controller, w, content));
	}

	private static externalModule: ng.IModule;

	static add(externalModule: ng.IModule, internalModule: ng.IModule) {
		WidgetContainerDirective.externalModule = externalModule;
		internalModule.directive("lmWidgetContainer", ["$rootScope", "$q", "$timeout", "$compile", "$templateCache", "lmWidgetService", "lmContextService", "lmLanguageService", ($rootScope, $q, $timeout, $compile, $templateCache, widgetService, contextService, languageService) => {
			var directive = new WidgetContainerDirective($rootScope, $q, $timeout, $compile, $templateCache, widgetService, contextService, languageService);
			return {
				scope: {},
				restrict: "E",
				controller: WidgetContainerCtrl,
				controllerAs: "ctrl",
				replace: true,
				templateUrl: "scripts/lime/templates/widget.html",
				link: (s, e, a, c, t) => directive.link(s, e, a, c, t)
			};
		}]);
	}
}

class CustomWidgetSettingsDirective extends c.CoreBase {
	private widgetInstance: lm.IWidgetInstance;

	constructor(private compile: ng.ICompileService, private widgetService: c.IWidgetService) {
		super("[CustomWidgetSettingsDirective] ");
	}

	static add(m: ng.IModule) {
		m.directive("lmCustomWidgetSettings", ["$compile", "lmWidgetService", ($compile, templateCache, widgetService) => {
			var directive = new CustomWidgetSettingsDirective($compile, widgetService);
			return {
				scope: {},
				restrict: "E",
				link: (s, e, a, c, t) => directive.link(s, e, a, c, t)
			};
		}]);
	}

	public link(scope: ng.IScope, element: ng.IAugmentedJQuery, attributes: ng.IAttributes, controller: any, transclude: ng.ITranscludeFunction) {
		var dialog = <lm.IDialog>scope.$parent["lmDialog"];
		var parameter: WidgetSettingsParameter = dialog.parameter;
		if (!parameter) {
			this.error("Parameter property not set on IDialog");
			return;
		}

		// Find the content element in the template
		var content = element.find(".lm-widget-settings-content");
		if (!content) {
			content = null;
			this.error("Missing lm-widget-settings-content div");
		}
		try {
			var widget = parameter.widget;
			var context = new WidgetSettingsContext(widget, content, dialog);
			var settingsInstance = parameter.widgetSettingsFactory(context);

			scope.$parent["lmSettingsInstance"] = settingsInstance;

			var config = settingsInstance.angularConfig;
			if (config) {
				WidgetUtil.addAngularContent(scope, this.compile, element, config, widget.definition);
			}
		} catch (e) {
			this.error("Failed to create custom settings with factory ", e);
		}
	}
}

/**
* Widget About Controller
*
* Handles the data for a widget's about page.
*/
class WidgetAboutCtrl {
	static $inject = ["$scope", "lmWidgetService", "lmLanguageService", "lmProgressService", "lmDialogService"];

	private dialog: lm.IDialog;
	private widget: c.IWidget;
	private lang: ILanguageLime;
	private widgetDefinition: c.IWidgetDefinition;

	constructor(public scope: ng.IScope, private widgetService: c.IWidgetService, languageService: c.ILanguageService, private progressService: c.IProgressService, private dialogService: lm.IDialogService) {
		this.dialog = scope["lmDialog"];
		this.lang = languageService.getLanguage();
		const parameter = <WidgetSettingsParameter>this.dialog.parameter;
		if (parameter) {
			this.widget = parameter.widget;
			if (this.widget.data.isBroken) {
				return;
			}
			const id = this.widget.id;
			const definition = widgetService.getCachedDefinition(id);
			this.widgetDefinition = definition;
			const title = this.widget.title;

			// Set the current title
			scope["title"] = title;

			// Set the widget catalog title
			scope["name"] = definition.title;

			if (definition.isPublished && !this.widget.isDev) {
				// Set the standard widget title for a published widget
				scope["titleBasedOn"] = definition.standardTitle;
			}
		}
	}

	private getTitle(definition: c.IWidgetDefinition): string {
		// TODO Common utility function?
		let title;
		const lang = definition.lang;
		if (lang) {
			title = lang[lm.WidgetConstants.widgetTitle];
		}
		return title || definition.standardTitle;
	}

	public onClose() {
		this.dialog.close();
	}

	/**
	* Copy data to clipboard.
	* @returns {} 
	*/
	public copyToClipboard(): void {
		const basedOn = this.scope["titleBasedOn"] ? 'Based on: ' + this.scope["titleBasedOn"] + ", \n" : "";
		const basedOnID = this.widgetDefinition.standardWidgetId ? 'Based on (ID): ' + this.widgetDefinition.standardWidgetId + ", \n" : "";
		const ownerName = this.widgetDefinition.ownerName ? ', \nOwner Name: ' + this.widgetDefinition.ownerName : "";
		const ownerId = this.widgetDefinition.owner ? ', \nOwner ID: ' + this.widgetDefinition.owner : "";

		const data = 'Title: ' + this.widget.title + ", \n" +
			'Name: ' + this.scope["name"] + ", \n" +
			'ID: ' + this.widget.data.id + ", \n" +
			basedOn +
			basedOnID +
			'Version: ' + this.widgetDefinition.version +
			ownerName +
			ownerId;
		this.dialogService.copyToClipboard({ copyData: data });
	}

	public static add(m: ng.IModule) {
		m.controller("lmWidgetAboutCtrl", WidgetAboutCtrl);
	}
}

interface IWidgetDefinitionItemResponse extends c.IOperationResponse {
	content: c.IWidgetDefinitionItem;
}

interface IPublishedWidgetItemResponse extends c.IOperationResponse {
	content: c.IPublishedWidgetItem;
}

interface IPublishdWidgetItemRequest extends c.IOperationRequest {
	content: c.IPublishedWidgetItem;
}

export var init = (externalModule: ng.IModule, internalModule: ng.IModule) => {
	WidgetService.add(internalModule);
	WidgetSettingsCtrl.add(internalModule);
	CustomWidgetSettingsCtrl.add(internalModule);
	CustomWidgetSettingsDirective.add(internalModule);
	WidgetContainerCtrl.add(internalModule);
	WidgetContainerDirective.add(externalModule, internalModule);
	WidgetResizeCtrl.add(internalModule);
	WidgetCustomizationCtrl.add(internalModule);
	WidgetAboutCtrl.add(internalModule);
};
