var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../lime", "../../core"], function (require, exports, lm, c) {
    var WidgetAccessCtrl = (function (_super) {
        __extends(WidgetAccessCtrl, _super);
        function WidgetAccessCtrl(scope, dialogService, commonDataService) {
            _super.call(this, "[WidgetAccessCtrl] ");
            this.scope = scope;
            this.dialogService = dialogService;
            this.commonDataService = commonDataService;
            var dialog = scope["lmDialog"];
            this.dialog = dialog;
            this.accessEntities = this.getAccess(dialog.parameter.accessList);
            var widgetAccessLevel = c.WidgetAccessLevel;
            this.accessLevels = [
                { name: "Disabled", value: widgetAccessLevel.Disabled },
                { name: "View", value: widgetAccessLevel.View },
                { name: "Configure", value: widgetAccessLevel.Configure }];
        }
        WidgetAccessCtrl.prototype.getAccess = function (items) {
            items = angular.copy(items);
            var principal = c.Constants.groupEveryone;
            var everyoneAccess = lm.ArrayUtil.itemByProperty(items, "principal", principal);
            if (!everyoneAccess) {
                everyoneAccess = {
                    id: this.dialog.parameter.id,
                    principal: principal,
                    accessLevel: c.WidgetAccessLevel.Configure,
                    isCatalog: true,
                    isUser: false
                };
                items.unshift(everyoneAccess);
            }
            everyoneAccess.principalName = "Everyone";
            return items;
        };
        WidgetAccessCtrl.prototype.isDisabled = function (access) {
            return !access.isUser && c.Constants.groupEveryone === access.principal;
        };
        WidgetAccessCtrl.prototype.ok = function () {
            var result = {
                button: lm.DialogButtonType.Ok,
                value: this.accessEntities
            };
            this.dialog.close(result);
        };
        WidgetAccessCtrl.prototype.close = function () {
            this.dialog.close();
        };
        WidgetAccessCtrl.prototype.getDisplayValue = function (value) {
            return lm.ArrayUtil.itemByProperty(this.accessLevels, "value", value).name;
        };
        WidgetAccessCtrl.prototype.delete = function (entity) {
            lm.ArrayUtil.remove(this.accessEntities, entity);
        };
        WidgetAccessCtrl.prototype.showAccessDialog = function (entity, isAddUser) {
            if (!this.isAddEditDialogOpen) {
                var self = this;
                var options = {
                    title: entity ? "Edit Permissions" : "Add Permissions",
                    templateUrl: "scripts/lime/admin/templates/add-edit-widget-access.html",
                    parameter: {
                        accessEntity: entity || {},
                        id: self.dialog.parameter.id,
                        existingEntities: this.accessEntities,
                        isAddUser: isAddUser
                    }
                };
                self.isAddEditDialogOpen = true;
                self.dialogService.show(options).then(function (r) {
                    self.isAddEditDialogOpen = false;
                    if (r.button === lm.DialogButtonType.Ok && r.value) {
                        var item = r.value;
                        self.addOrUpdateEntityAccess(item, entity);
                    }
                });
            }
        };
        WidgetAccessCtrl.prototype.addOrUpdateEntityAccess = function (newItem, oldItem) {
            var accessEntities = this.accessEntities;
            if (!lm.CommonUtil.isUndefined(oldItem) && oldItem !== null) {
                var entityIndex = lm.ArrayUtil.indexByProperty(accessEntities, "principal", oldItem.principal);
                accessEntities[entityIndex] = newItem;
            }
            else {
                accessEntities.push(newItem);
            }
        };
        WidgetAccessCtrl.add = function (m) {
            m.controller("lmWidgetAccessCtrl", WidgetAccessCtrl);
        };
        WidgetAccessCtrl.$inject = ["$scope", "lmDialogService", "lmCommonDataService"];
        return WidgetAccessCtrl;
    })(c.CoreBase);
    var AddEditWidgetAccessCtrl = (function (_super) {
        __extends(AddEditWidgetAccessCtrl, _super);
        function AddEditWidgetAccessCtrl(scope, dialogService, commonDataService, adminService) {
            _super.call(this, "[AddEditWidgetAccessCtrl] ");
            this.scope = scope;
            this.dialogService = dialogService;
            this.commonDataService = commonDataService;
            this.adminService = adminService;
            this.isEdit = false;
            var dialog = scope["lmDialog"];
            this.dialog = dialog;
            var accessEntity = angular.copy(dialog.parameter.accessEntity);
            this.accessEntity = accessEntity;
            var widgetAccessLevel = c.WidgetAccessLevel;
            var buttonText = "Ok";
            if (accessEntity.principal) {
                this.isEdit = true;
            }
            else {
                buttonText = "Add";
                accessEntity.isCatalog = true;
                accessEntity.accessLevel = widgetAccessLevel.View;
                this.isAddUser = dialog.parameter.isAddUser;
                this.init();
            }
            scope["buttonText"] = buttonText;
            this.accessLevels = [
                { name: "Disabled", value: widgetAccessLevel.Disabled },
                { name: "View", value: widgetAccessLevel.View },
                { name: "Configure", value: widgetAccessLevel.Configure }
            ];
        }
        AddEditWidgetAccessCtrl.prototype.ok = function () {
            var result = { button: lm.DialogButtonType.Ok };
            var entity = this.accessEntity;
            if (!this.isEdit && !this.isAddUser) {
                var roleName = entity.principalName || this.roleInput;
                if (lm.ArrayUtil.containsByProperty(this.dialog.parameter.existingEntities, "principal", roleName)) {
                    this.existsMsg = "Group already added";
                    return;
                }
                delete this.existsMsg;
                entity.isUser = false;
                if (!entity.principalName) {
                    entity.principal = roleName;
                    entity.principalName = roleName;
                }
            }
            result.value = entity;
            this.dialog.close(result);
        };
        AddEditWidgetAccessCtrl.prototype.close = function () {
            this.dialog.close();
        };
        AddEditWidgetAccessCtrl.prototype.onChangedAccessLevel = function () {
            var accessEntity = this.accessEntity;
            if (accessEntity.accessLevel === c.WidgetAccessLevel.Disabled) {
                accessEntity.isCatalog = false;
            }
        };
        AddEditWidgetAccessCtrl.prototype.init = function () {
            var self = this;
            var autocompleteElem;
            if (this.isAddUser) {
                this.autocompleteOptions = {
                    source: function (query, done) {
                        self.commonDataService.searchUsers(query).then(function (response) {
                            done(query, lm.ArrayUtil.sortByProperty(c.CoreUtil.getEntityArray(response.content), "label"));
                        }, function (r) {
                            self.commonDataService.handleError(r);
                        });
                    },
                    template: c.Templates.autocompleteEntity
                };
                autocompleteElem = $("#widget-access-principal");
                this.autocompleteElem = autocompleteElem;
            }
            else {
                this.autocompleteOptionsRole = {
                    source: function (query, done) {
                        self.adminService.searchRoles(query).then(function (result) {
                            done(query, lm.ArrayUtil.sortByProperty(result, "label"));
                        });
                    },
                    template: c.Templates.autocompleteEntity,
                    filterMode: "contains"
                };
                autocompleteElem = $("#widget-access-role");
                this.autocompleteElemRole = autocompleteElem;
                this.scope.$watch("ctrl.roleInput", function (newValue, oldValue) {
                    if (newValue !== oldValue) {
                        delete self.accessEntity.principalName;
                        delete self.existsMsg;
                    }
                });
            }
            this.connectAutoComplete(autocompleteElem, this.scope);
            this.scope.$on("$destroy", function () {
                autocompleteElem.off();
            });
        };
        AddEditWidgetAccessCtrl.prototype.connectAutoComplete = function (element, scope) {
            var self = this;
            element.on("selected", function (event, target, object) {
                if (lm.CommonUtil.isUndefined(object) || lm.CommonUtil.isUndefined(object.value)) {
                    return;
                }
                var value = object.value;
                self.existsMsg = "";
                if (lm.ArrayUtil.containsByProperty(self.dialog.parameter.existingEntities, "principal", value)) {
                    self.existsMsg = "Permissions are already configured";
                }
                else {
                    var accessEntity = self.accessEntity;
                    accessEntity.principal = value;
                    accessEntity.principalName = object.label ? object.label : value;
                    accessEntity.isUser = true;
                    self.scope.$apply("accessEntity");
                }
                self.scope.$apply("existsMsg");
            });
        };
        AddEditWidgetAccessCtrl.add = function (m) {
            m.controller("lmAddEditWidgetAccessCtrl", AddEditWidgetAccessCtrl);
        };
        AddEditWidgetAccessCtrl.$inject = ["$scope", "lmDialogService", "lmCommonDataService", "lmAdminService"];
        return AddEditWidgetAccessCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        WidgetAccessCtrl.add(m);
        AddEditWidgetAccessCtrl.add(m);
    };
});
//# sourceMappingURL=widget-access.js.map