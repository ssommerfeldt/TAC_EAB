declare var internalModule: ng.IModule;
export = internalModule;
