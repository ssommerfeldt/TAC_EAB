var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../lime", "../../core"], function (require, exports, lm, c) {
    var SettingSetValueCtrl = (function (_super) {
        __extends(SettingSetValueCtrl, _super);
        function SettingSetValueCtrl(scope, adminService, dialogService) {
            _super.call(this, "[SettingsSetValueCtrl] ");
            this.scope = scope;
            this.adminService = adminService;
            this.dialogService = dialogService;
            var dialog = scope["lmDialog"];
            var dialogParameter = dialog.parameter;
            this.dialog = dialog;
            var settingItem = angular.copy(dialogParameter.setting);
            var settingValue = settingItem.value;
            this.item = settingItem;
            if (settingItem.displayValue === settingValue && settingItem.type !== "string" && settingItem.type !== "int") {
                settingValue = "";
            }
            var pages = angular.copy(dialogParameter.pages);
            this.pages = pages;
            if (settingItem.type === c.SettingsNames.mandatoryPages) {
                var mandatories = settingValue ? settingValue.split(",") : [];
                settingValue = [];
                mandatories.forEach(function (id) {
                    pages.forEach(function (page) {
                        if (id === page.data.id) {
                            settingValue.push(page);
                        }
                    });
                });
                this.sortableOptions = {
                    connectWith: ".mandatory-pages-container",
                    axis: "y"
                };
            }
            if (settingItem.type === "boolean" && !settingValue) {
                settingValue = false;
            }
            this.item.value = settingValue;
        }
        SettingSetValueCtrl.prototype.onCancel = function () {
            var result = {
                button: lm.DialogButtonType.Cancel,
                value: null
            };
            this.dialog.close(result);
        };
        SettingSetValueCtrl.prototype.onOk = function () {
            var item = this.item;
            item.changeDate = lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*";
            item.changedByName = this.dialog.parameter.userName;
            item.setting.isChanged = true;
            if (item.type !== c.SettingsNames.mandatoryPages) {
                item.displayValue = this.getDisplayValue();
            }
            var result = {
                button: lm.DialogButtonType.Ok,
                value: item
            };
            this.dialog.close(result);
        };
        SettingSetValueCtrl.prototype.getDisplayValue = function () {
            var displayValue;
            var item = this.item;
            var itemValue = item.value;
            var itemType = item.type;
            if (itemType === c.SettingsNames.defaultPage || itemType === c.SettingsNames.startPage) {
                displayValue = this.adminService.getPageDisplayTitle(itemValue);
            }
            else if (itemType === "selector") {
                var valueObject = lm.ArrayUtil.itemByProperty(item.setting.values, "value", itemValue);
                if (valueObject) {
                    displayValue = valueObject.label;
                }
                else {
                    displayValue = itemValue;
                }
            }
            else {
                displayValue = itemValue;
            }
            return displayValue;
        };
        SettingSetValueCtrl.add = function (m) {
            m.controller("lmSettingSetValueCtrl", SettingSetValueCtrl);
        };
        SettingSetValueCtrl.$inject = ["$scope", "lmAdminService", "lmDialogService"];
        return SettingSetValueCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        SettingSetValueCtrl.add(m);
    };
});
//# sourceMappingURL=setting-set-value.js.map