﻿import lm = require("./lime");

/**
* Defines an error state.
* 
* This interface is implemented by classes that need a common 
* way to indicate an error state. Common examples are response objects for services.
*/
export interface IErrorState {
	/**
	* Gets or sets an error.
	*/
	error?: any;

	/**
	* Gets or sets an error message.
	*/
	errorMessage?: string;

	/**
	* Gets or sets an error code.
	*/
	errorCode?: string;

	/**
	* Gets a value that indicates if an error exists.
	* 
	* An error is considered to exist if any of the error, errorMessage or errorCode properties are set.
	* Note that if one property is set there is no guarantee that any of the other properties are set.
	* 
	* @returns True if an error exists.
	*/
	hasError(): boolean;
}

export interface IUser {
	userName: string;
	firstName?: string;
	lastName?: string;
	profilePhoto?: number;
	displayName: string;
}

/**
* Represents a Ming.le bookmark or bookmark folder.
*/
export interface IBookmark {
	/**
	* Gets or sets a value that indicates if this bookmark if bookmark folder.
	*/
	isFolder?: boolean;

	/**
	* Gets or sets the bookmark URL. The URL will be null for folders.
	*/
	url?: string;

	/**
	* Gets or sets the name of the bookmark or bookmark folder.
	*/
	name: string;

	/**
	* Gets or sets a list of child items for a bookmark folder. This property will be null for a bookmark.
	*/
	items?: IBookmark[];
}

export interface IMingleContext {
	type: string;
	id: string;
}

export class CoreBase implements IErrorState {

	constructor(public logPrefix: string) {
		if (!logPrefix) {
			this.logPrefix = "";
		}
	}

	/**
	* See [[IErrorState]].hasError()
	*/
	public hasError(): boolean {
		var state = <IErrorState>this;
		return state.errorMessage || state.errorCode || state.error;
	}

	public isDebug(): boolean {
		return lm.Log.isDebug();
	}

	public error(message: string, ex?: any): void {
		lm.Log.error(this.logPrefix + message, ex);
	}

	public warning(message: string): void {
		lm.Log.warning(this.logPrefix + message);
	}

	public info(message: string): void {
		lm.Log.info(this.logPrefix + message);
	}

	public debug(message: string): void {
		lm.Log.debug(this.logPrefix + message);
	}

	public logResponse(response: IOperationResponse) {
		this.error(response.toErrorLog());
	}
}

/**
* Defines an instance event.
* 
* An instance event can be used for lightweight events when you can have
* an object reference to the source of the event. In cases when you can't
* use object references refer to IEvent and IEventService instead.
* 
* **Example:**
* 
* Use the component context to get notified on state changes.
* 
*				componentContext.stateChanged().on((state: Odin.ComponentState) => {
*		Odin.Log.debug("Component state changed to: " + state);
*	});
*/
export interface IInstanceEvent<T> {
	/**
	* Registers an event handler function.
	* @param handler The event handler function to register.
	* @returns A function that can be used to unsubscribe to the event. Calling this function will have the same effect as calling the off function.
	*/
	on(handler: { (data?: T): void }): Function;

	/**
	* Unregisters an existing event handler function.
	* @param handler The event handler function to unregister.
	*/
	off(handler: { (data?: T): void });
}

/**
* Instance event implementation.
* 
* Use this class to defined your own instance event.
* If you just want to consume instance events refer to IInstanceEvent.
*/
export class InstanceEvent<T> implements IInstanceEvent<T> {

	private handlers: { (data?: T): void; }[] = [];

	/**
	* Registers an event handler function.
	* @param handler The event handler function to register.
	*/
	public on(handler: { (data?: T): void }): Function {
		this.handlers.push(handler);
		return () => {
			this.off(handler);
		};
	}

	/**
	* Unregisters an existing event handler function.
	* @param handler The event handler function to unregister.
	*/
	public off(handler: { (data?: T): void }) {
		this.handlers = this.handlers.filter(h => h !== handler);
	}

	/**
	* Raises an event.
	* @param data The event data. 
	*/
	public raise(data?: T) {
		if (this.handlers) {
			try {
				this.handlers.slice(0).forEach(h => h(data));
			} catch (e) {
				lm.Log.error("Exception in core.raise", e);
			}

		}
	}

	/**
	* Clears all event handlers for this event.
	*/
	public clear(): void {
		this.handlers = [];
	}
}



/**
* Represents a response from the server.
* The hasError function should always be checked to determine if the operation was successful or not.
*/
export interface IOperationResponse {
	id: string;
	content: any;
	errorList?: ErrorInfo[];
	messageList?: MessageInfo[];

	/**
	 * Optional error code when the http promise was rejected.
	 * Used for invalid session if the code is "0".
	 */
	errorHttpCode?: string;

	/**
	* Gets a value that indicates if the response contains one or more errors.
	*/
	hasError(): boolean;

	/**
	* Gets a value that indicates if the response contains one or more messages.
	*/
	hasMessage(): boolean;

	/**
	* Shows translated error messages if translations exists on the client
	* for the error codes. If no translations exist a generic error message will
	* be displayed instead.
	*/
	showErrorMessages();

	/**
	* Concatenates error messages to a string.
	*/
	toErrorLog(): string;

	/**
	* Error text.
	*/
	errorText?: string;
}

/**
 * Used to represents if an external call (e.g. REST) made inside a dialog was successful or not.
 */
export class DialogResponseCode {
	// ReSharper disable InconsistentNaming
	static Success = 1;
	static Fail = 2;
	// ReSharper restore InconsistentNaming
}

/**
* Represents an import options object passed to an import controller.
*/
export interface IImportOptions {
	operation: string;
	url?: string;
	title?: string;
	formFields?: IStringMap;
	buttonText?: string;
	/**
	 * String with file extension(s) to include by default in file picker.
	 * 
	 * Example: ".zip" or ".zip,.json"
	 */
	acceptFileExtension?: string;
}

/**
* Represents the response object returned from the server.
*/
export class OperationResponse implements IOperationResponse {
	id: string = null;
	content: any = null;
	errorList: ErrorInfo[] = null;
	messageList: MessageInfo[] = null;
	/**
 * Optional error code when the http promise was rejected.
 * Used for invalid session if the code is "0".
 */
	errorHttpCode: string;

	constructor(content?: any) {
		this.content = content;
	}

	hasError(): boolean {
		return this.errorList && (this.errorList.length > 0);
	}

	hasMessage(): boolean {
		return this.messageList && this.messageList.length > 0;
	}

	showErrorMessages() {
		//TODO Not implemented
	}

	toErrorLog(): string {
		if (!this.errorList) {
			return "";
		}
		let output = "";

		const listLength = this.errorList.length;
		for (let i = 0; i < listLength; i++) {
			const errorInfo = this.errorList[i];
			output += errorInfo.message + " (Error code: " + errorInfo.code + ")" + (i === listLength - 1 ? "" : ", ");
		}
		return output;
	}
}

/*
* HTTP Response Error Codes (and others).
*
* HTTP error codes that have non generic error messages.
*/
export class ResponseErrorCodes {
	// Probably a 302 after the session is terminated - but the browser will not show that
	public static undefined = 0;
	public static unauthorized = 401;
	public static forbidden = 403;
	public static notFound = 404;
	public static timeout = 408;
	public static unavailable = 503;
	public static exceedsMaxSize = 1001;
	public static tenantContextNotAvailable = 1000;
}

export class Product {
	/**
	* Gets the application name (Infor Ming.le Homepages).
	*/
	public static productName = "Infor Ming.le Homepages";
}

/**
* Defines constants for localized error messages.
*/
export class ErrorConstants {
	public static generic = "errorGeneric";
	public static unauthorized = "errorUnauthorized";
	public static notFound = "errorNotFound";
	public static timeout = "errorTimeout";
	public static unavailable = "errorUnavailable";
	public static signout = "errorSignOut";
	public static exceedsMaxSize = "exceedsMaxSize";
}

export class MessageInfo {
	code: number;
	message: string;
	isTranslated: boolean;
}

export class ErrorInfo {
	code: number;
	severity: number;
	message: string;
	isTranslated: boolean;
	error: string;
}

export enum SettingType { User = 0, Application = 1 };
/*
* Setting, as used in Admin page.
*/
export interface ISetting {
	/*
	* Date of last change. 
	*/
	changeDate: string;

	/*
	* User who made the last change. 
	*/
	changedBy: string;

	/*
	* Display name of changedBy.
	*/
	changedByName: string;

	/*
	* Data type.
	*/
	dataType: string;

	/*
	* Index
	*/
	index: number;

	/*
	* Indicates if the settings has been changed.
	*/
	isChanged: boolean;

	/*
	* Label
	*/
	label: string;

	/*
	* Module for which setting applies.
	*/
	module: string;

	/*
	* Indicates íf setting is read only.
	*/
	readOnly: boolean;

	/*
	* Name of setting.
	*/
	settingName: string;

	/*
	* Setting type.
	*/
	type: SettingType;

	/*
	* Value.
	*/
	value: string;

	/*
	* Values, if several objects.
	*/
	values?: Object[];

	/*
	* Setting rules.
	*/
	rules?: ISettingRule[];

	/*
	* Area. Common, Page or Widget.
	*/
	area: string;

	/*
	* Indicates if the setting shuld be visible in the admin tool.
	*/
	isVisible: boolean;
}

/*
* Item wraps a setting with temporary client side data.
*/
export interface ISettingItem {
	/*
	* Settings object, same as on server.
	*/
	setting: ISetting;

	/*
	* Temporary setting value on client.
	*/
	value: any;

	/*
	* Temporary setting values on client.
	*/
	values?: any[];

	/*
	* Temporary display value on client.
	*/
	displayValue: any;

	/*
	* Temporary setting rules on client.
	*/
	rules: ISettingRule[];

	/*
	* Temporary type on client.
	*/
	type: any;

	/*
	* Temporary change date on the client.
	*/
	changeDate: string;

	/*
	* Temporary name on client.
	*/
	changedByName: string;

	/*
	* Temporary settingName on client for comparison purposes
	*/
	settingName: string;

	/*
	* View value for number of rules
	*/
	noOfRules: number;
}

/*
* Rule for a setting.
*/
export interface ISettingRule {
	/*
	* No of affected entities for the rule (view)
	*/
	affectedUsers?: number;
	/*
	* Date of last change.
	*/
	changeDate: string;

	/*
	* User who made the last change.
	*/
	changedBy: string;

	/*
	* Display name of changedBy.
	*/
	changedByName: string;

	/*
	* Display date of last change
	*/
	displayChangeDate?: string;

	/*
	* Indicates if the rule has been changed.
	*/
	isChanged: boolean;

	/*
	* Mode
	*/
	mode: any; //todo: is this correct?

	/*
	* Moduel for which the rule applies.
	*/
	module: string;

	/*
	* Name of rule.
	*/
	name: string;

	/*
	* Indicates if the rule is read only.
	*/
	readOnly: boolean;

	/*
	* Connected users/groups.
	*/
	ruleConnections: ISettingRuleConnection[];

	/*
	* Rule ID.
	*/
	ruleSettingId: string;

	/*
	* Rule name.
	*/
	settingName: string;

	/*
	* Sort Order
	*/
	sortOrder: number;

	/*
	* Value of rule.
	*/
	value: any;

	/*
	* DisplayValue of rule.
	*/
	displayValue?: any;
}

/*
* Connection(s) for a rule.
*/
export interface ISettingRuleConnection {

	/* 
	* Date of last change.
	*/
	changeDate: string;

	/*
	* Display date of last change
	*/
	displayChangeDate?: string;

	/* 
	* User who made the last change.
	*/
	changedBy: string;

	/* 
	* Display name of changedBy.
	*/
	changedByName: string;

	/* 
	* Indicates of the connection has been changed.
	*/
	isChanged: boolean;

	/* 
	* Indicates the type of connection.
	*/
	isUser: boolean;

	/* 
	* Module for which the connection applies.
	*/
	module: string;

	/* 
	* Name of connected user/group.
	*/
	name: string;

	/* 
	* ID of rule.
	*/
	ruleSettingId: string;
}

/*
* Setting info used for non admin parts of Homepages. Note that in the container only name and value is returned.
*/
export interface ISettingInfo {
	/* 
	* Data type.
	*/
	dataType?: string;

	/* 
	* Default setting value.
	*/
	defaultValue?: any;

	/* 
	* Indicates if the setting has been changed.
	*/
	isChanged?: boolean;

	/* 
	* Indicates if the setting is read only.
	*/
	isReadOnly?: boolean;

	/* 
	* Name of setting.
	*/
	name: string;

	/* 
	* Setting type.
	*/
	type?: SettingType;

	/* 
	* Setting value.
	*/
	value: any;
}

/**
* Defines access types for pages.
*/
export enum AccessType {
	/**
	* The owner or an administrator is allowed access.
	*/
	Owner = 0,
	/**
	* The user must belong to a role that has access or the user must have access.
	*/
	Role = 100,
	/**
	* Everyone is allowed access.
	*/
	Everyone = 200
}

/**
* Defines levels of access to a page.
*/
export enum AccessLevel {
	/**
	* The user is allowed to view the page.
	*/
	View = 0,
	/**
	* The user is allowed to view and edit the page.
	*/
	Edit = 100
}

/**
* Represents an access level granted to a specific principal which may be a group, role or a single user.
*/
export interface IEntityAccess {

	/**
	* Gets or sets the access level.
	*/
	accessLevel: AccessLevel;

	/**
	* Gets or sets the group, role or user that the access level applies to.
	*/
	principal: string;

	/**
	* Gets or sets the name of the group, role or user that the access level applies to.
	*/
	principalName: string;


	/**
	* Gets or sets the info of the group, role or user that the access level applies to. This is currently only used for emails for users.
	*/
	info: string;

	/**
	* States whether the entity is a user or group.
	*/
	type?: PrincipalType;
}

export interface IPageAccess {
	userAccess: IStringToIEntityAccessMap;
	roleAccess: IEntityAccess[];
	pageId: string;
}

export interface IStringToIEntityAccessMap {
	[key: string]: IEntityAccess;
}

export interface IWidgetLayout {
	column: number;
	row: number;
	columnSpan: number;
	rowSpan: number;
}

export class WidgetLayout implements IWidgetLayout {
	constructor(public column: number, public row: number, public columnSpan: number = 1, public rowSpan: number = 1) {
	}

	public static isSameCell(a: IWidgetLayout, b: IWidgetLayout): boolean {
		return a.column === b.column && a.row === b.row;
	}

	/**
	* Gets a value that indicates if widget A is after widget B in the page layout.
	*/
	public static isAfter(a: IWidgetLayout, b: IWidgetLayout): boolean {
		return a.row > b.row || (a.row === b.row && a.column > b.column);
	}

	/**
	* Gets a value that indicates if widget A is before widget B in the page layout.
	*/
	public static isBefore(a: IWidgetLayout, b: IWidgetLayout): boolean {
		return a.row < b.row || (a.row === b.row && a.column < b.column);
	}
}

/**
 * Defines the available widget types.
 */
export class WidgetType {
	// ReSharper disable InconsistentNaming

	/**
	 * An inline widget is implemented using aa and AMD module using JavaScript / TypeScript and its content
	 * is added directly in the Homespages DOM.
	 */
	public static Inline = "inline";

	/**
	 * An external widgets is an HTML pages loaded in an IFrame using a URL or URL template.
	 */
	public static External = "external";

	// ReSharper restore InconsistentNaming
}

// TODO Rename this interface to avoid duplicate name in two modules
export interface IWidgetModule {
	name?: string;
	isShared?: boolean;
}

/**
* Represents a widget when displayed in the widget library.
*/
export interface IWidgetInfo {
	widgetId?: string;
	type?: string;

	/**
	* Gets the widget version.
	*/
	version?: string;

	/**
	* Gets the widget category.
	* See [[WidgetCategory]].
	*/
	category?: string;
	tags?: string;
	vendor?: string;
	standardIconName?: string;
	iconFile?: string;

	/**
	* Gets the widget title.
	*/
	title?: string;

	/**
	* Gets the widget description.
	*/
	description?: string;

	/**
	* Gets or sets the owner of the widget.
	* 
	* If the owner is set it means that the widget is customized.
	* Widgets that are not customized will not have the owner property set.
	*/
	owner?: string;

	ownerName?: string;
	standardWidgetId?: string;
	changedByName?: string;
	changeDate?: string;
	/**
	* Set to true on published widgets the user as configure rights to the standard widget.
	*/
	canCopy?: boolean;
	/**
	* Set to true on published widgets if the standard widget is visible in the catalog.
	*/
	isLink?: boolean;

	/** 
	* Used for UI display only	 
	*/
	displayCategory?: string;
	displayIcon?: string;
	/**
	* Only used in admin list.
	*/
	hasRestrictions?: boolean;

	/**
	* Only used in admin list.
	*/
	hasAccess?: boolean;
}

export interface IAddWidgetInfo {
	widgetInfo: IWidgetInfo;
	byRef: boolean;

	/**
	* Custom data when a widget is added as a duplicate
	*/
	customWidget?: ICustomWidget;
}

/**
* Represents the customized data for a published widget.
*/
export interface ICustomWidget {
	/**
	* Gets or sets the settings map.
	*/
	settings?: IStringToAnyMap;

	/**
	 * Gets or sets settings metadata.
	 */
	metadata?: lm.IWidgetSettingMetadata[];

	/**
	 * Gets or sets the widget title.
	 */
	title?: string;

	titleApi?: string;

	/**
	 * Gets or sets a value that indicates if the catalog title should be used as the widget title.
	 * The default value is false.
	 */
	isCatalogTitle?: boolean;

	/**
	 * Gets or sets a value that indicates if the title is locked.
	 * The default value is true.
	 */
	isTitleLocked?: boolean;

	/**
	 * Gets or sets the logical ID for the published widget.
	 */
	logicalId?: string;
}

export interface ISharedModule {
	name: string;
	path?: string;
}

/**
 * Represents a widget definition.
 * 
 * Note that a widget definition and a widget manifest are JSON compatible on the server.
 */
export interface IWidgetDefinition {
	/**
	 * Gets or sets the widget ID.
	 */
	widgetId?: string;

	/**
	 * Gets or sets the ID of a standard widget that a published widget is based on.
	 * This property should only be set on a published widget.
	 */
	standardWidgetId?: string;

	/**
	 * Gets or sets the widget type.
	 */
	type?: string;

	/**
	 * Gets or sets the widget version.
	 */
	version?: string;

	/**
	 * Gets or sets the widget module name. The default value is "widget".
	 */
	moduleName?: string;

	/**
	 * Gets or sets the URL or URL template for an external widget.
	 */
	url?: string;

	/**
	 * Gets or sets the help URL for a widget.
	 */
	helpUrl?: string;

	/**
	 * Gets or sets a list of widget settings metadata.
	 */
	settings?: lm.IWidgetSettingMetadata[];

	/**
	 * Gets or sets the widget category.
	 */
	category?: string;

	/**
	 * Gets or sets a value that indicates if settings are enabled. The default value is true. If settings are disabled in the manifest it will not be possible
	 * to enable them in the widget code.
	 */
	enableSettings?: boolean;

	/**
	 * Gets or sets a value that indicates if settings are enabled in the standard widget definition.
	 */
	enableSettingsDef?: boolean;

	/**
	 * Gets or sets a value that indicates if widget title edit is enabled. The default value is true. If widget title edit is disabled in the manifest it will
	 * not be possible to enable this in the widget code.
	 */
	enableTitleEdit?: boolean;

	/**
	 * Gets or sets a value that indicates if widget title edit is enabled in the standard widget definition.
	 */
	enableTitleEditDef?: boolean;

	/**
	 * Gets or sets an optional logical ID used for widgets related to an application.
	 */
	applicationLogicalId?: string;

	/**
	 * Gets or sets an optional application version used for widgets related to an application.
	 */
	applicationVersion?: string;

	/**
	 * Gets or sets an optional list of shared modules.
	 */
	sharedModules?: ISharedModule[];

	/**
	 * Gets or sets an optional custom icon file name.
	 */
	iconFile?: string;

	/**
	 * Gets or sets the ID of the widget owner.
	 */
	owner?: string;

	/**
	 * Gets or sets the widget owner display name.
	 */
	ownerName?: string;

	/**
	 * Default widget title.
	 */
	title?: string;

	/**
	 * Default widget description.
	 */
	description?: string;

	/**
	 * Gets or sets a value that indicates if this is a published widget.
	 */
	isPublished?: boolean;

	/**
	* Gets or sets custom widget data and settings for a published widget.
	*/
	custom?: ICustomWidget;

	isByRef?: boolean;

	tags?: string;

	/**
	 * Gets the standard widget title.
	 * Note that this value is set on the client,
	 */
	standardTitle?: string;

	/*
	 * Localization texts.
	 */
	lang?: any;

	// TODO Document
	localization?: any;

	// TODO Do we need this?
	modules?: IWidgetModule[];

	/**
	 * Optional configuration for widgets implemented using AngularJS.
	 */
	angularConfig?: lm.IAngularWidgetConfig;

	/**
	 * Gets or sets the base path to the widget used in widget development mode.
	 */
	devPath?: string;

	/**
	 * Gets or sets the AccessLevel for the current user.
	 * Only used on the client.
	 */
	accessLevel?: WidgetAccessLevel;

	/**
	 * Gets or sets the AccessLevel for the standard widget for the current user.
	 * Only used on the client.
	 */
	standardAccessLevel?: WidgetAccessLevel;

	/**
	 * Gets or sets a value that indicates if the widget should be displayed in the widget catalog for the current user.
	 * Only used on the client.
	 */
	isCatalog?: boolean;

	/**
	 * Gets or sets the original unmodified definition.
	 * Only used on the client.
	 */
	original?: IWidgetDefinition;

	customMetadata?: lm.IWidgetSettingMetadata[];

	/**
	 * Gets or sets a value that indicates if the widget should get the default title from the catalog when added.
	 * Only used on the client.
	 */
	isCatalogTitle?: boolean;
}

export interface IWidgetDefinitionItem {
	definition: IWidgetDefinition;
	localization: IStringToStringMap;

	/**
	 * Gets or sets the localized standard widget title.
	 */
	standardTitle: string;

	/**
	 * Gets or sets the localized widget catalog title.
	 */
	catalogTitle: string;

	accessLevel: WidgetAccessLevel;
	standardAccessLevel: WidgetAccessLevel;
	isCatalog: boolean;

	/**
	* The application instances are only when returning single definitions. In the page container the applications are part of the configuration.
	*/
	applications?: lm.IApplication[];
}

export interface IPublishedWidgetItem {
	/**
	 * Gets or sets a widget definition to publish.
	 */
	definition: IWidgetDefinition;

	/**
	 * Gets or sets localization maps for one or more languages.
	 */
	localization?: IStringToEntityLocalizationMap;
}

/**
 * Represents options when publishing a widget.
 */
export interface IPublishWidgetOptions {
	/**
	 * Gets or sets the item to publish.
	 */
	item: IPublishedWidgetItem;

	/**
	 * Gets or sets the base widget definition.
	 */
	definition?: IWidgetDefinition;
}

export interface IWidgetPublishInfo {
	publishedItem: IPublishedWidgetItem;

	isLocalizationChanged?: boolean;

	/**
	 * Gets or sets a value that indicates if the widget should be published directly or not.
	 */
	isPublish?: boolean;
}

export interface IWidgetData {
	/**
	 * Gets or sets a generated unique ID for the widget instance.
	 */
	instanceId?: string;

	/**
	 * Gets or sets the widget ID.
	 * The ID can be a standard widget ID or a GUID for a published widget.
	 */
	id?: string;

	type?: string;

	title?: string;

	/**
	 * Gets or sets a value that indicates if the widget title is locked for editing.
	 */
	isTitleLocked?: boolean;

	/**
	 * Gets or sets the title if the widget set it using the API.
	 */
	titleApi?: string;

	background?: string;

	layout?: WidgetLayout;

	isEditable?: boolean;

	// TODO Move these to IWidget ->
	isBroken?: boolean;
	brokenMessage?: string;
	// <-

	/**
	 * Raw data in dictionary.
	 */
	settings?: IStringToAnyMap;

	/**
	 *
	 */
	custom?: IPublishedWidgetItem;

	/**
	 * Gets or sets the logical ID for the widget. This property should only be used
	 * for widgets that supports multiple instances of an application. This property should only be set if
	 * the widget belongs to an application.
	 */
	logicalId?: string;
}

/**
* Represents the context in which a widget is or will be hosted. In most cases the context is a page.
*/
export interface IWidgetParentContext {
	/**
	 * Gets or sets the ID of the parent context.
	 */
	id?: string;

	/**
	 * Gets a value that indicates if the widget is hosted in a published context.
	 */
	isPublished?: boolean;

	/**
	 * Gets optional user settings for a widget. These user settings might be available for a published widget or
	 * a widget on a published page.
	 */
	userSettings?: IStringToAnyMap;

	addWidget(widget: IWidget): void;
}

/**
 * Represents a widget in runtime.
 */
export interface IWidget {
	id: string;
	data: IWidgetData;
	parentContext: IWidgetParentContext;
	widgetModule: any;
	definition: IWidgetDefinition;

	/**
	 * Gets or sets a value that indicates if the widget is published.
	 * 
	 */
	byRef: boolean;

	elementId: string;
	element: JQuery;

	state: string;
	isVisible: boolean;
	isEdit: boolean;
	isSettings: boolean;
	isTitleEditEnabled: boolean;

	// We need to store the title set by implementation if the widget is unlocked and then locked
	titleApi: string;

	/**
	* Gets the current calculated widget title.
	*/
	title: string;

	/**
	 * Used by the framework to set title. If the widget sets the title it will use setTitle on the context and
	 * the framework will know that the title is set by widget.
	 */
	setTitleInternal(title: string): void;

	/**
	* Gets or sets a value that indicates if the widget is in development mode (running in the development container).
	*/
	isDev: boolean;

	externalUrl: string;
	context: lm.IWidgetContext;
	widgetType: string;

	/*
	* Access level for the user to this widget. See WidgetAccessLevel
	*/
	accessLevel: WidgetAccessLevel;

	/**
	* Gets or sets the widget instace.
	* 
	* The widget instance is implemented by the widget developer and might just be an empty object
	* if the widget do not support any of the widget APIs.
	*/
	instance: lm.IWidgetInstance;

	/**
	* Gets a value that indicates if the widget is published or not.
	* 
	* A widget is considered to be published in the standardWidgetId property is set.
	*/
	isPublished(): boolean;

	isSettingsEnabled(): boolean;

	isCatalogTitle(): boolean;

	/**
	* Gets if the Configure menu should be enabled (visible).
	*/
	isSettingsMenuEnabled(): boolean;

	/**
	* Sets if the Configure menu should be enabled (visible).
	*/
	setSettingsMenuEnabled(enabled: boolean): void;

	/**
	 * Copies additional configuration properties from a source widget.
	 */
	copyFrom(source: IWidget): void;

	/**
	* Temporarily enables settings. Can be used in edit mode such as publish widget or publish page.
	* @param enable True to enable settings
	*/
	enableSettingsTemporary(enable: boolean): void;

	/**
	* Sets the widget definition and also sets default settings values if the widget is new (added from the library).
	*/
	setDefinition(definition: IWidgetDefinition, addWidgetInfo: IAddWidgetInfo);

	calculateTitle(isTitleLocked: boolean): string;
	updateTitle(): void;
	getDefaultTitle(): string;

	updateSettings(triggerChanged?: boolean);

	changed(): IInstanceEvent<IWidget>;
	raiseChanged(): void;

	remove(): void;
	removed(): IInstanceEvent<IWidget>;

	restore(): void;
	restored(): IInstanceEvent<IWidget>;

	added(): IInstanceEvent<IWidget>;
	raiseAdded();

	/**
	* Gets the event that is raised when the widget is destroyed.
	*/
	destroyed(): IInstanceEvent<IWidget>;

	/**
	* Destroys the widget.
	*/
	destroy(): void;

	/**
	* Gets the event that is raised when the internal widget state is updated.
	* 
	* This event will for example be raised each time the widget implementation changes related to settings such as disabling settings.
	*/
	updated(): IInstanceEvent<IWidget>;

	/**
	* Gets user data for a published widget or a widget on a published page.
	* If settings are not enabled or no individual settings is enabled this function will 
	* return null indicating that no user data is available.
	*/
	getUserData(): any;

	hasVisibleActions(): boolean;

	/**
	*  Set or get information on how this widget is added. For example was created as a copy from an existing widget.
	*/
	addWidgetInfo: IAddWidgetInfo;

	/*
	* If set, an inline widget message is shown.
	*/
	message?: lm.IWidgetMessage;
}

export interface IWidgetListResponse extends IOperationResponse {
	content: IWidgetInfo[];
}

export interface IWidgetInfoResponse extends IOperationResponse {
	content: IWidgetInfo;
}

export interface IGroupInfoListResponse extends IOperationResponse {
	content: IGroupInfo[];
}

export enum WidgetAccessLevel {

	/**
	* The widget is disabled for the user
	*/
	Disabled = 0,

	/**
	*The user is allowed to view the widget.
	*/
	View = 100,

	/**
	* The user is allowed to view and edit the widget.
	*/
	Configure = 200
}

/**
* Represents the core page data in the server serialization format.
* 
* This data is common for all instances of this page even if it is shared.
* See [[IPage]] for user specific data related to a page.
*/
export interface IPageData {
	/**
	* Gets the page ID.
	*/
	id?: string;

	/**
	* Gets the page visibility.
	*/
	viewAccess?: AccessType;

	/**
	* Gets or sets the page edit level.
	*/
	editAccess?: AccessType;

	/**
	* Gets the user ID of the page owner.
	*/
	ownerId?: string;

	/**
	* Gets or sets the page title.
	*/
	title?: string;

	/**
	* Gets or sets the page description.
	*/
	description?: string;
	createdBy?: string;
	changedBy?: string;
	changedByName?: string;
	ownerName?: string;
	changeDate?: string;
	popularity?: number;
	widgetRefs?: IWidgetHandle[];
	tags?: string;
	sortOrder?: number;
	widgets?: IWidgetData[];

	/**
	* Gets or sets user settings for published widgets on a private page. This parameter is only for input.
	*/
	userSettings?: any;
}

// Ming.le groups
export interface IGroup {
	id: string;
	name: string;
}

// User for Session Provider roles, id is a ID and name is description
export interface IGroupInfo {
	id: string;
	name: string;
}

export interface IWidgetHandle {
	id: string;
	byRef?: boolean;
}

export interface ILocalizationParameter {
	defaultLocalization: IEntityLocalization;
	localizationMap: IStringToEntityLocalizationMap;
	isWidget?: boolean;
}

/**
* Represents a localized description of an entity such as a page or a widget.
*/
export interface IEntityLocalization {
	/**
	* Gets or sets the entity title.
	*/
	title: string;

	/**
	* Gets or sets the entity description.
	*/
	description: string;
}

export interface IStringMap {
	[key: string]: string;
}

export interface IStringToAnyMap {
	[key: string]: any;
}

export interface IStringToWidgetSettingMetadata {
	[key: string]: lm.IWidgetSettingMetadata;
}

export interface IStringToEntityLocalizationMap {
	[key: string]: IEntityLocalization;
}

/**
* Represents a page in the server serialization format.
*/
export interface IPage {
	/**
	* Gets or sets the localized page title in the current user language. This property may be null if no localization exists.
	*/
	title?: string;

	/**
	* Gets or sets the localized page description in the current user language. This property may be null if no localization exists.
	*/
	description?: string;

	/**
	* Gets the core page data.
	* @input
	* @output
	*/
	data: IPageData;

	/**
	* Gets a value that indicates if this page is mandatory for the current user.
	* @output
	*/
	isMandatory?: boolean;

	/**
	* Gets a value that indicates if the current user is allowed to edit the page.
	* @output
	*/
	isEditable?: boolean;

	/**
	* Gets a value that indicates if the current user is allowed to view the page.
	* 
	* A page that the user is not allowed to view will still be returned by the server but 
	* without any widget content and with this property set to false.
	* 
	* @output
	*/
	isViewable?: boolean;

	/**
	* Gets the user access map.
	*/
	userAccess?: IStringToIEntityAccessMap;

	/**
	* Gets the role access list.
	*/
	roleAccess?: IEntityAccess[];

	widgetDefinitions?: IWidgetDefinitionItem[];

	applications?: IStringToIApplicationArrayMap;

	/**
	* The page localization data used when publishing or updating a published page.
	* @input
	*/
	localization?: IStringToEntityLocalizationMap;

	/**
	* Gets or sets additional user settings for a published page.
	*/
	settings?: IStringToAnyMap;

	/**
	* Date of last change.
	*/
	changeDate?: string;

	/**
	 * Gets or sets the page sort order.
	 */
	sortOrder?: number;
}


/**
* Represents a page in runtime when hosted in the page container.
*/
export interface IPageInstance extends IPage {
	id: string;
	widgets: IWidget[];
	noOfWidgets(): number;
	add(widget: IWidget): void;
	afterPublishedStandard(widget: IWidget, definition: IWidgetDefinition): void;
	remove(widget: IWidget): void;
	removed(): IInstanceEvent<IPageInstance>;
	changed(): IInstanceEvent<IPageInstance>;

	widgetAdded(): IInstanceEvent<IWidget>;
	widgetsAddedCount: number;

	/**
	* Notify all widgets that the page is shown.
	*/
	show(): void;

	/**
	* Notify all widgets that the page is hidden.
	*/
	hide(): void;

	/**
	* Destroys the page including all widgets.
	*/
	destroy(): void;

	/**
	* Gets a value that indicates if the current page can be published or not.
	* 
	* Private pages can be published if the user is allowed to do so which is controlled by a setting.
	* 
	* @returns True if th page can be published.
	*/
	isPublishEnabled(): boolean;

	/**
	* Gets a value that indicates if the page is published.
	*/
	isPublished(): boolean;

	toggleEditMode(isEdit: boolean): void;

	/**
	 * Notifies all non-published widgets on the page that the page publishing mode is starting.
	 */
	notifyPublishingMode(): void;
	updateWidgets(editedWidgets: IEditableWidget[], isSave: boolean): void;

	getWidgetParentContext(widget?: IWidgetData);
	getWidgetByInstanceId(instanceId: string): IWidget;

	getWidgetUserSettings();
	setWidgetUserSettings(data: any): boolean;
	createSavePageData(): IPageData;
}

/**
* Represents options for stopping edit moded using [[IEditModeService]].
*/
export interface IEditModeStartOptions {
	/**
	* Gets or sets the type of edit mode. Available modes are defined in [[EditModes]]
	*/
	mode: string;

	/**
	* Gets or sets the title of the edit mode.
	*/
	title?: string;

	/**
	* Gets or sets the type of edit submode. Available modes are defined in [[EditSubmodes]]
	*/
	submode?: string;

	/**
	* Gets or sets an optional parameter.
	*/
	parameter?: any;

	/**
	* The command buttons of the command bar.
	*/
	actions?: ICommandBarAction[];

	/**
	* The secondary command buttons of the command bar.
	*/
	secondaryActions?: ICommandBarAction[];

	/**
	* Command text
	*/
	commandText?: string;
}

/**
* Represents options for starting edit moded using [[IEditModeService]].
*/
export interface IEditModeStopOptions {
	/**
	* Gets or sets a value that indicates if the edit mode changes have been saved or not.
	*/
	isSave: boolean;

	/**
	* Gets or sets an optional result.
	*/
	result?: any;
}

/**
* Defines available edit modes.
*/
export class EditModes {
	public static none = "none";
	public static layout = "layout";
	public static widget = "widget";
	public static page = "page";
	public static preview = "preview";
}

/**
* Defines available edit modes.
*/
export class EditSubmodes {
	public static publish = "publish";
	public static republish = "republish";
	public static publishCopy = "publishCopy";
}

export interface IEditModeService {
	start(options: IEditModeStartOptions): void;
	stop(options: IEditModeStopOptions): void;

	isActive(): boolean;

	/**
	* Gets a value that indicates if the specified mode exists in the mode stack. 
	* The mode does not have to be the active one if more than one edit mode has been started.
	* @param mode The mode to check
	* @returns True if the mode was found
	*/
	containsMode(mode: string): boolean;

	/**
	* Gets a value that indicates if the specified mode is the current mode. 
	* @param mode The mode to check
	* @returns True if the mode is the current mode
	*/
	isMode(mode: string): boolean;

	getCurrent(): IEditMode;

	/**
	* Gets an event that is raised when edit mode starts.
	*/
	started(): IInstanceEvent<IEditMode>;

	/**
	* Gets an event that is raised when edit mode stops.
	*/
	stopped(): IInstanceEvent<IEditMode>;

	/**
	* Gets an event that is raised when edit mode either starts or stops.
	*/
	changed(): IInstanceEvent<IEditMode>;
}

/**
* Represents the state of the page edit mode.
*/
export interface IEditMode extends IEditModeStartOptions, IEditModeStopOptions {
	/**
	* Gets or sets a value that indicates if edit mode is currently active.
	* 
	* When edit mode starts this property will be true and when edit mode stops this property will be false.
	*/
	isActive: boolean;
}

/**
* Used to position IEditableWidget in Edit Page.
*/
export interface IEditableWidgetStyle {
	left: string;
	top: string;
}

/**
* Simpler widget used in Edit Page.
*/
export interface IEditableWidget {
	id?: string;
	title?: string;
	layout: IWidgetLayout;
	style?: IEditableWidgetStyle;
	isPlaceholder?: boolean;
	elementId?: string;
	widget?: IWidget;
}

export interface IPageContainerData {
	tenantId?: string;
	userId?: string;
	userName?: string;
	isAdministrator?: boolean;
	isPageAdministrator?: boolean;

	/**
	 * Gets a value that indicates if the Homepages server is running the cloud mode or on-premise mode.
	 */
	isCloud?: boolean;

	/**
	* Gets the ping interval in minutes.
	*/
	pingInterval?: number;

	/**
	* Gets the server version.
	*/
	version?: string;
	selectedId?: string;
	pages?: IPage[];
	userSettings?: ISettingInfo[];
	applicationSettings?: ISettingInfo[];
	widgetDefinitions?: IWidgetDefinitionItem[];
	configuration?: IConfigurationData;
}

export interface IContextService {
	getContext(): IContext;
}

/**
* Represents the runtime page container.
*/
export interface IPageContainer extends IErrorState {

	/**
	* Gets the context with access to user and user settings.
	*/
	context: IContext;

	/**
	* Gets the page container data.
	*/
	data: IPageContainerData;

	pages: IPageInstance[];

	/**
	* Gets the current page.
	*/
	selectedPage: IPageInstance;

	/**
	* Adds a new page.
	* 
	* If the page is added successfully the added and changed events will be raised.
	* 
	* @param pageData The page to add.
	*/
	add(pageData: IPageData, showToastConfirmation: boolean, definitions?: IWidgetDefinition[], applicationConfig?: IStringToIApplicationArrayMap);

	/**
	* Removes an existing page.
	* 
	* If the page is removed successfully the removed and changed events will be raised.
	* 
	* @param pageId The ID of the page to remove.
	*/
	remove(page: IPageInstance): ng.IPromise<IOperationResponse>;

	/**
	* Removes all pages from the client.
	* @returns {} 
	*/
	removeAllPagesFromClient(): void;

	reorder(order: string[]): ng.IPromise<IOperationResponse>;

	delete(pageId: string, name: string, isShared: boolean): ng.IPromise<IOperationResponse>;

	publish(page: IPage, isUpdate?: boolean);

	/**
	* Gets a value that indicates if the container contains a page with the specified page ID.
	* @param id A page ID
	*/
	contains(id: string): boolean;

	editPageConfiguration(isUpdate?: boolean);

	refresh();
	saveCurrent(): ng.IPromise<IOperationResponse>;
	saveAndRefreshCurrent(): void;

	onCancelPublish();

	/**
	* Creates a new page.
	* 
	* If the page is added successfully the added and changed events will be raised.
	* 
	* @param pageData The page to add.
	*/
	create(pageData: IPageData);

	/**
	* Gets the event that is raised when a page is selected.
	* @return The selected event.
	*/
	selected(): IInstanceEvent<IPageInstance>;

	/**
	* Gets the event that is raised when a page is added.
	* @return The added event.
	*/
	added(): IInstanceEvent<IPageInstance>;

	/**
	* Gets the event that is raised when the page container is changed.
	* 
	* This event will be raised when changes are detected that requires that the container is saved 
	* such as adding or removing a page or a widget on page.
	* 
	* @return The changed event.
	*/
	changed(): InstanceEvent<IPageContainer>;

	refreshed(): InstanceEvent<IPageContainer>;

	/**
	* Selects the page with the specified ID and raises the selected event.
	*/
	select(pageId: string): void;

	showAddPage(): void;

	/**
	* Shows Informations for the specified page or the current page.
	* 
	* @param page The page to show information for.
	*/
	//showPageSettings(id: string);
	showPageInformation(id: string);

	showPageLibrary();

	addExistingPage(page: IPage, showToastConfirmation: boolean, isCopy?: boolean, copyTitle?: string, busyCallback?: Function): void;

	copyPage(page: IPage, showToastConfirmation: boolean, fromPreview: boolean, busyCallback?: Function): void;

	/**
	* Opens a dialog where the user can choose to import a page (json file)
	*/
	openImportPageDialog(): ng.IPromise<lm.IDialogResult>;

	/**
	* Opens a dialog with info about a page.
	*/
	showAboutPage(): void;

	/**
	* Gets and previews a page.
	*/
	previewPage(pageId: string, external: boolean): void;

	/**
	* Destroys the page container including all pages and all widgets.
	*/
	destroy(): void;
}

export interface IContext {
	init(container: IPageContainerData, containerUrl: string);

	isBusy(): boolean;
	setBusy(isBusy: boolean): void;

	/**
	 * Gets a value that indicates if the Homepages server is running the cloud mode or on-premise mode.
	 * 
	 * @returns True if the server is running in cloud mode.
	 */
	isCloud(): boolean;

	/**
	* Gets the ID of the current user.
	*/
	getUserId(): string;

	/**
	* Gets the tenantId of the current user.
	*/
	getTenantId(): string;

	/**
	* Get the application version number.
	*/
	getVersion(): string;

	/**
	* Gets a value that indicates if the the current user is an administrator.
	*/
	isAdministrator: boolean;

	/**
	* Gets a value that indicates if the the current user is a page administrator.
	*/
	isPageAdmininistrator: boolean;

	/**
	* Gets a value that indicates if the provided user is the same as the current user.
	*/
	isCurrentUser(user: string): boolean;

	/**
	* Gets a value that indicates if the client is running in development mode.
	*/
	isDev: boolean;

	/**
	* Access to all settings.
	*/
	settings: IServerSettings; // TODO -> Function instead of property

	/**
	* Access to configuration values from Ming.le or ad-hoc configuration with key-values.
	*/
	getConfiguration(): IConfiguration;

	isOperationEnabled(page: IPageData, settingValue: boolean);

	/**
	* Gets the current language constant for the active user.
	*/
	getLanguage(): string;

	/**
	 * Gets the current container Url that should be used by widgets using iframes to send the top contianer URL.
	 * The URL must be validated server side and then an X-Frame-Option with that URL has to be set.
	 */
	getContainerUrl(): string;
}

/**
* Defines service functions for pages.
*/
export interface IPageService {
	createPrivate(page: IPageData): ng.IPromise<IPageResponse>;
	update(page: IPageData): ng.IPromise<IOperationResponse>;
	updateSettings(page: IPageData): ng.IPromise<IPageDataResponse>;
	delete(id: string): ng.IPromise<IOperationResponse>;
	getPublished(id: string): ng.IPromise<IPageResponse>;
	getPublishedExtended(pageId: string): ng.IPromise<IPageResponse>;
	listPublished(reload: boolean): ng.IPromise<IPageListResponse>;

	/**
	* Publishes a private page or updates an already published page.
	*/
	updatePublished(page: IPage): ng.IPromise<IPageDataResponse>;

	/**
	* Deletes published pages.
	* @param pages A list of published page ID's.
	* 
	* @return The number of pages that were successfully deleted.
	*/
	deletePublished(pages: string[]): ng.IPromise<IIntegerResponse>;

	addConnection(id: string, asTemplate: boolean, sortOrder: number, templateTitle?: string): ng.IPromise<IPageResponse>;
	reorderConnections(pages: string[]): ng.IPromise<IOperationResponse>;

	/**
	* Updates user settings for an existing published page.
	*/
	updateConnectionSettings(pageId: string, settings: any): ng.IPromise<IOperationResponse>;

	removeConnection(id: string): ng.IPromise<IOperationResponse>;

	/**
	* Forwards errors to DataService error handler.
	*/
	handleError(response: IOperationResponse, message?: string);

	/**
	* Gets widget references and definitions for a page.
	*/
	getPreview(pageId: string): ng.IPromise<IPageResponse>;

	/**
	* Invalidates the Page cache.
	*/
	invalidatePageCache(): void;
}

export interface IPageResponse extends IOperationResponse {
	content: IPage;
}


export interface IPageDataResponse extends IOperationResponse {
	content: IPageData;
}

export interface IPageListResponse extends IOperationResponse {
	content: IPage[];
}

export interface IStringResponse extends IOperationResponse {
	content: string;
}

export interface IGroupListResponse extends IOperationResponse {
	content: IGroup[];
}

export interface IBookmarkResponse extends IOperationResponse {
	content: IBookmark[];
}

export interface IUserListResponse extends IOperationResponse {
	content: IUser[];
}

export interface IEntityListResponse extends IOperationResponse {
	content: lm.IAutocompleteEntity[];
}

export interface ILanguagueResponse extends IOperationResponse {
	content: IStringMap;
}

export interface IApplicationResponse extends IOperationResponse {
	content: lm.IApplication[];
}

export interface IEntityLocalizationResponse {
	content: IStringToEntityLocalizationMap;
}

export interface IIntegerResponse extends IOperationResponse {
	content: number;
}

export interface IPageAccessResponse extends IOperationResponse {
	content: IPageAccess;
}

export interface IServerSettings {
	/**
	* Gets a value that indicates if the user is a grid application administrator.
	*/
	isAdministrator(): boolean;

	/**
	* Gets a value that indicates if the user is a page administrator.
	*/
	isPageAdministrator(): boolean;

	/**
	* Gets a value that indicates if a specific widget is enabled for the current user.
	*/
	isWidgetEnabled(type: string);

	/**
	* Gets a value that indicates if private pages are enabled.
	*/
	isPrivatePagesEnabled(): boolean;

	/**
	* Gets a value that indicates if the user can select a homepage (start page).
	*/
	isSelectHomepageEnabled(): boolean;

	/**
	* Gets the maximum number of pages a user is allowed to have, not including mandatory pages.
	* A number of zero indicates that the user is not allowed to have any private pages.
	*/
	getMaxUserPageCount(): number;

	/**
	* Gets a valued that indicates if the user is allowed to publish a page (make it public).
	*/
	isPagePublishEnabled(): boolean;

	/**
	* Gets current log specified from the server.
	*/
	getLogLevel(): number;

	/**
	* If the user is allowed to add a public page.
	*/
	isPublicPageAddEnabled(): boolean;

	/**
	* If the user is allowed to copy a public page.
	*/
	isPublicPageCopyEnabled(): boolean;

	/**
	* Checks if the user is allowed to publish widgets.
	*/
	isWidgetPublishEnabled(): boolean;

	isPageCatalogEnabled(): boolean;

	/**
	* Checks the user is allowed to add a new connection and private pages are allowed.
	*/
	getCanAddPrivatePage(userPageCount: number): boolean;

	/**
	* If the user has room for another favorite page and is allowed to add a favorite page.
	*/
	getCanAddFavoritePage(userPageCount: number): boolean;

	/**
	* If the user is allowed to export a page (any page).
	*/
	isPageExportEnabled(): boolean;

	/**
	* If the user is allowed to import a page. Note that he must be allowed to create a private page as well.
	*/
	isPageImportEnabled(): boolean;

	/**
	* gets the page id of the page that is used as start page
	*/
	getStartPage(): string;

	/**
	* sets which page should be used as start page
	*/
	setStartPage(value: string);

	/**
	* Save user settings to server
	*/
	saveUserSettings(): ng.IPromise<IStringResponse>;

	/**
	* If translation of content is enabled.
	*/
	isContentTranslationEnabled(): boolean;

	/**
	 * Gets the default language for the current user.
	 */
	getDefaultLanguage(): string;

	/**
	* Application Settings.
	*/
	applicationSettings?: Array<IApplicationSetting>;
}

export interface IApplicationSetting {
	/**
	* Name.
	*/
	name: string;

	/**
	* Value.
	*/
	value: any;
}

/**
* Represents a handler that can show messages to the user.
*/
export interface IInteractionHandler {
	showError(message: string, header?: string);

	/**
	* Gets a value that indicates if the client is busy.
	*/
	isBusy(): boolean;

	/**
	* Sets a value that indicates if the client is busy.
	*/
	setBusy(value: boolean);
}

export interface IDevConfiguration {
	devData: DevConfigurationData;
	id?: string;
	definition?: IWidgetDefinition;
	container?: IPageContainerData;
	initPage(page: IPageData): void;
	load(id: string): IPageContainerData;
	save();
	clear();
}
export class DevConfiguration extends CoreBase implements IDevConfiguration {
	public devData: DevConfigurationData;
	public id: string;
	public definition: IWidgetDefinition;
	public container: IPageContainerData;

	private isPersistent = true; // TODO Set from directive
	private storagePrefix = "lmDevContainer-";

	constructor() {
		super("[DevConfiguration] ");
	}

	public initPage(page: IPageData): void {
		if (!page.id) {
			page.id = lm.CommonUtil.random();
		}
		page.changedBy = page.createdBy = "developer";
		page.changeDate = "2015-01-01T12:00:00.000Z";
		page.viewAccess = AccessType.Owner;
	}

	private getKey() {
		return this.storagePrefix + this.id;
	}

	public load(id: string): IPageContainerData {
		this.id = id;
		var container: IPageContainerData = null;
		if (this.isPersistent) {
			try {
				var data = localStorage.getItem(this.getKey());
				if (data) {
					container = JSON.parse(decodeURI(data));
					if (container && container.pages && container.pages.length === 0) {
						// Don't start with an empty test container even if it was last saved as empty. Load a page with the widget.
						container.pages = null;
					}
					this.debug("Loaded container in dev mode for widget" + id);
				}
			} catch (e) {
				container = null;
			}
		} else {
			// Clear the stored container
			this.clear();
		}

		if (!container || !container.pages || !container.pages[0].data) {
			container = {
				userId: "TEST",
				version: "1.0",
				pages: [
					{
						data: {
							id: lm.CommonUtil.random(),
							title: "Test Page"
						}
					}]
			};
		}

		this.container = container;
		return container;
	}

	public clear() {
		this.container = null;
		this.save();
		this.debug("Cleared local dev container");
	}

	public save() {
		try {
			var key = this.getKey();
			if (this.container) {
				var content = encodeURI(JSON.stringify(this.container));
				localStorage.setItem(key, content);
				this.debug("Saved local dev container");
			} else {
				localStorage.removeItem(key);
			}
		} catch (e) {
			this.error("Failed to save local dev container", e);
		}
	}
}

/**
 * Represents configuration data for a widget in the development environment.
 */
export class DevConfigurationData {
	/**
	* Gets or sets the widget ID.
	*/
	widgetId: string;

	/**
	* Gets or sets the path to an optional JSON file with widget settings.
	* When this settings file is used the settings in local storage will be ignored.
	*/
	settingsPath: string;

	/**
	* Gets or sets widget settings loaded from a JSON settings file.
	* If this property is set it should override settings from local storage.
	*/
	settings: any;

	/**
	* Gets or sets the name of the settings property.
	* 
	*/
	propSettings = "settings";

	/**
	* Gets or sets the path to an optional JSON file with configuration data.
	*/
	configurationPath: string;

	/**
	* Gets or sets configuration data from the configuration JSON file.
	* Since the configuration file is optional this property might not be set.
	*/
	configuration: IConfigurationData;

	/**
	* Gets or sets the name of the configuration property.
	* 
	*/
	propConfiguration = "configuration";

	/**
	 * Gets or sets the widget definition.
	 */
	widgetDefinition: IWidgetDefinition;

	/**
	* Gets or sets the name of the widget definition property.
	*/
	propWidgetDefinition = "widgetDefinition";

	customDefinitionPath: string;

	customDefinition: IWidgetDefinition;

	propCustomDefinition = "customDefinition";
}

export class ClientConfiguration {
	private static url = "";
	private static local;
	private static logicalId;

	public static dev: IDevConfiguration = null;

	public static overrideUrl(url: string) {
		ClientConfiguration.url = url;
	}

	public static initialize(location: ng.ILocationService) {
		var config = ClientConfiguration;
		if (location.host() === "localhost") {
			lm.Log.setDebug();
			config.overrideUrl("http://localhost:8081");
			config.local = true;
		}

		config.logicalId = location.search()["LogicalId"];
	}

	public static getLogicalId(): string {
		return ClientConfiguration.logicalId || "lid://infor.homepages.1";
	}

	public static isLocal(): boolean {
		return ClientConfiguration.local;
	}

	public static initDevConfiguration(devData: DevConfigurationData) {
		if (devData) {
			var dev = new DevConfiguration();
			dev.devData = devData;
			ClientConfiguration.dev = dev;
		}
	}

	public static getUrl() {
		return ClientConfiguration.url;
	}

	/**
	* Gets a value that indicates if the application is running in development mode.
	* 
	* When the applicatio is in development mode only parts of it will be functional.
	* No calls will be made to a server and pages are stored locally.
	*/
	public static isDev(): boolean {
		return ClientConfiguration.dev != null;
	}
}

export class SettingsNames {
	// Application settings
	public static defaultPage = "DefaultPage";
	public static defaultLanguage = "DefaultLanguage";
	public static enablePageCatalog = "EnablePageCatalog";
	public static mandatoryPages = "MandatoryPages";
	public static enablePagePublish = "EnablePagePublish";
	public static enablePrivatePages = "EnablePrivatePages";
	public static maxUserPageCount = "MaxUserPageCount";
	public static enableAddPublishedPage = "EnableAddPublishedPage";
	public static enableDuplicatePublishedPage = "EnableDuplicatePublishedPage";
	public static enableSelectHomepage = "EnableSelectHomepage";
	public static enablePageExport = "EnablePageExport";
	public static enablePageImport = "EnablePageImport";
	public static enableWidgetPublish = "EnableWidgetPublish";
	public static enableContentTranslation = "EnableContentTranslation";

	// User settings
	public static startPage = "StartPage";
	public static logLevel = "LogLevel";
}

export class Constants {
	public static applicationName = "Homepages";

	public static restRoot = "limerest";
	public static webRoot = "lime";
	public static mingleLocale = "inforCurrentLocale";
	public static mingleLanguage = "inforCurrentLanguage";
	public static mingleTimeZone = "inforTimeZone";
	public static mingleThemeName = "inforThemeName";
	public static useHttps = "usehttps";
	public static scheme = "scheme";
	public static tenantId = "tenantid";
	public static userid = "userid";
	public static language = "language";
	public static safeMode = "safeMode";

	/**
	* Built-in group that represents every user (HOMEPAGES-Everyone).
	*/
	public static groupEveryone = "HOMEPAGES-Everyone";

	// Configuration properties and prefixes
	public static configurationSettings = "settings";
	public static configurationProperties = "properties";
	public static configurationApplication = "applications";

	public static configurationApplicationPrefix = "application";
	public static configurationFrameworkPrefix = "framework";
	public static configurationLocalizationPrefix = "localization";
	public static configurationPropertyPrefix = "property";
	public static configurationViewPrefix = "view";
	public static configurationWidgetPrefix = "widget";

	public static configurationPrefixes = [
		Constants.configurationApplicationPrefix,
		Constants.configurationFrameworkPrefix,
		Constants.configurationLocalizationPrefix,
		Constants.configurationPropertyPrefix,
		Constants.configurationViewPrefix,
		Constants.configurationWidgetPrefix
	];

	public static widgetTitleLength = 40;
	public static widgetDescriptionLength = 1024;
	public static pageTitleLength = 40;
	public static pageDescriptionLength = 256;

	// Settings areas
	public static pageArea = 0;
	public static widgetArea = 1;
	public static commonArea = 2;
	public static allArea = 3; // Client side only

	// Modal IDs
	public static modalPageAbout = "lmPageAbout";
	public static modalPagePublish = "lmPagePublish";
	public static modalWidgetCustomize = "lmWidgetCustomize";
	public static contextualActionPanelId = "lmContextualActionPanel";

	// List Caches
	public static adminCacheStandardWidgets = "Standard Widgets Cache";
	public static adminCachePublishedWidgets = "Published Widgets Cache";
	public static adminCachePublishedPages = "Published Pages Cache";
	public static adminCacheProperties = "Properties Cache";
	public static adminCachePrivatePages = "Private Pages Cache";
	public static adminCacheRoles = "Roles Cache";

	public static clientCacheWidgets = "Widgets Cache";
	public static clientCachePages = "Pages Cache";

	// Cache lifetime
	public static cacheLifetime = 900000;

	// Widget definition defaults
	public static widgetModuleDefaultName = "widget";

	// Supported shared lime language constants array
	public static sharedLimeLanguageConstants = ["ok", "cancel", "yes", "no", "refresh", "add", "save", "delete", "name", "url", "edit"];

	// Maximum number of tags per widget/page.
	public static tagsMaxCount = 5;

	//Standard widget IDs
	// ReSharper disable once InconsistentNaming
	public static mingleWebWidgetID = "infor.mingle.web";

	// Widget reserved settings names
	public static settingsNameWidgetTitle = "lmWidgetTitle";
}

export interface ICacheService {
	createCache(name: string): IDataListCache;
	updateCache(cache: IDataListCache, response: IOperationResponse, deferred?: ng.IDeferred<any>);
}

export class Templates {
	/**
	* Used for displaying Autocomplete hits in multiple lines.
	*/
	public static autocompleteEntity = '<script type="text/html">' +
	'<li id="{{listItemId}}" {{#hasValue}} data-value="{{value}}" {{/hasValue}} role="listitem">' +
	'<a href="#" tabindex="-1">' +
	'<span class="display-value">{{& label}}</span>' +
	'<small class="lm-autocomplete-secondary lm-truncate-text">{{& info}}</small>' +
	'</a></li></script>';
}

export class WidgetCategory {
	// ReSharper disable InconsistentNaming
	public static BusinessProcess = "businessprocess";
	public static Application = "application";
	public static Social = "social";
	public static Utilities = "utilities";
	public static BusinessIntelligence = "businessintelligence";
	public static All = "all";
	// ReSharper restore InconsistentNaming
}

export interface IProgressService {
	isBusy(): boolean;
	setBusy(isBusy: boolean): void;
}

export interface IDataService {
	startPing(pingInterval: number): void;
	setLanguage(language: string): void;
	executeGet(resource: string, parameters?: any): ng.IPromise<IOperationResponse>;
	executePost(resource: string, request?: any, parameters?: any): ng.IPromise<IOperationResponse>;
	getUrl(path?: string): string;
	upload(operationUrl: string, operation: string, files: any[], formFields?: IStringMap): ng.IPromise<IOperationResponse>;
	handleError(response: IOperationResponse, message?: string): void;
}

export interface ICommonDataService {
	getApplication(logicalIdPrefix: string): ng.IPromise<IApplicationResponse>;
	handleError(response: IOperationResponse, message?: string);
	listBookmarks(): ng.IPromise<IBookmarkResponse>;
	listGroups(): ng.IPromise<IGroupListResponse>;
	listLanguages(): ng.IPromise<ILanguagueResponse>;
	searchUsers(query: string): ng.IPromise<IUserListResponse>;
	searchGroups(query: string): ng.IPromise<IGroupListResponse>;
	searchEntities(query: string): ng.IPromise<IEntityListResponse>;
}

export interface IOperationRequest {
	id: string;
}

class OperationRequest {
	id: string = null;
}

export interface IWidgetService {
	loadWidget(widget: IWidgetData): ng.IPromise<IWidget>;
	listWidgets(reload: boolean): ng.IPromise<IWidgetListResponse>;
	/**
	* Get the already loaded definition from the client cache.
	*/
	getCachedDefinition(id: string): IWidgetDefinition;

	getDefinition(id: string): ng.IPromise<IWidgetDefinition>;

	addDefinitions(list: IWidgetDefinition[]);
	addDefinitionItem(item: IWidgetDefinitionItem): IWidgetDefinition;
	removeDefinition(widgetId: string);
	addWidgetCopyToPage(context: IWidgetParentContext, addWidgetInfo: IAddWidgetInfo): ng.IPromise<IWidget>;
	preAddWidget(context: IWidgetParentContext, addWidgetInfo: IAddWidgetInfo, busyCallback?: Function): ng.IPromise<IWidget>;
	getAddWidgetInfo(widget: IWidget): IAddWidgetInfo;

	showSettings(widget: IWidget, data?: any, isWidgetUnlocked?: boolean): ng.IPromise<lm.IDialogResult>;
	showCatalog(context: IWidgetParentContext, callback?: Function): ng.IPromise<IWidget>;

	getPublished(id: string): ng.IPromise<IPublishedWidgetItem>; // TODO: needed?
	publish(item: IPublishedWidgetItem): ng.IPromise<IStringResponse>;
	updatePublished(item: IPublishedWidgetItem): ng.IPromise<IStringResponse>;
	deletePublished(widgets: string[]): ng.IPromise<IIntegerResponse>;
	exportWidget(widgetData: IWidgetData): string;

	updatePublishedOwner(widgetId: string, ownerId: string): ng.IPromise<IWidgetInfoResponse>;

	/**
	* Forwards errors to error handler in Data Service.
	*/
	handleError(response: IOperationResponse, message?: string);

	/**
	* Creates a path to a custom or generic Widget icon.
	*/
	createImagePath(widget: IWidgetInfo): string;

	/**
	* Invalidates the Widget cache.
	*/
	invalidateWidgetCache(): void;

	/**
	* Close and destroy the catalog.
	*/
	closeCatalog(dialog: IContextualActionPanel): void;
}

export interface IContextualActionPanel {
	destroy(): void;
}

export interface IStringToStringMap {
	[key: string]: String;
}

export interface IStringtoDefinitionMap {
	[key: string]: IWidgetDefinition;
}

export interface IStringToIApplicationArrayMap {
	[key: string]: lm.IApplication[];
}

export interface IConfigurationData {
	applications?: IStringToIApplicationArrayMap;
	properties: IStringToStringMap;

	/**
	 * Gets the ION API customer context (CustomerApi by default). 
	 */
	ionApiCustomerContext: string;

	/**
	 * Gets the base URL to the ION API.
	 */
	ionApiUrl: string;

	/**
	 * Token from ION APIs. Currently only used in devemopment mode when reading widget from configuration file.
	 * Widgets should use getIonApiContextAsync on the widgetContext.
	 */
	ionApiToken: string;
}

/**
* Represents Ming.le application configuration and Ad-hoc properties.
*/
export interface IConfiguration {
	applications?: IStringToIApplicationArrayMap;
	properties: IStringToStringMap;
	ionApiCustomerContext: string;
	addApplication(application: lm.IApplication): void;
	addApplications(applications: lm.IApplication[]): void;
	addApplicationMap(applications: IStringToIApplicationArrayMap): void;
	getApplication(logicalId: string): ng.IPromise<lm.IApplication>;
	getApplicationCached(logicalId: string): lm.IApplication;
	getApplications(logicalId: string): ng.IPromise<lm.IApplication[]>; // TODO Name consistency (async vs cached)
	getApplicationsCached(logicalId: string): lm.IApplication[];
	getIonApiContextAsync(options: lm.IIonApiOptions): ng.IPromise<lm.IIonApiContext>;
	executeIonApiAsync<T>(options: lm.IIonApiRequestOptions): ng.IPromise<ng.IHttpPromiseCallbackArg<T>>;
}

/**
* Represents a Ming.le application view.
*/
export interface IApplicationView {
	viewId: string;
	urlTemplate: string;
}

/**
* Represents the (hash) Tag Service.
*/
export interface ITagService {
	/**
	* Deletes a tag.
	*/
	deleteTag(allTags: string, tagToDelete: string): string;

	/**
	* Checks if a tag is valid.
	*/
	isTagValid(tag: string): IIsTagValidResponse;

	/**
	* Adds a tag.
	*/
	addTag(allTags: string, tag: string);

	/**
	* Checks if a string of tags are valid.
	*/
	areTagsValid(tags: string);
}

/**
* Represents the response from TagServcie: isTagValid()
*/
export interface IIsTagValidResponse {
	/**
	* Is the tag valid?
	*/
	isValid: boolean;

	/**
	* Error that explains what is wrong with the tag.
	*/
	errorMsg?: string;
}

/**
* Represents the response from TagService: areTagsValid()
*/
export interface IAreTagsValidResponse {
	/**
	* Is the tag valid?
	*/
	areValid: boolean;

	/**
	* Error that explains what is wrong with the tag(s).
	*/
	errorMsg?: string;
}

/**
* Represents the response from TagService: addTag()
*/
export interface IAddTagResponse {
	/**
	* All the tags with the newly added one included.
	*/
	allTags: string;

	/**
	* Was the tag invalid?
	*/
	hasError: boolean;

	/**
	* Error that explains what is wrong with the tag(s).
	*/
	errorMsg?: string;
}

/**
* Represents the language service.
*/
export interface ILanguageService {
	/**
	* Gets an object with all language constants.
	*/
	getLanguage(): ILanguageLime;

	/**
	* Gets a single language constant.
	* @param name The name of the constant to get.
	*/
	get(name: string): string;
}

class LanguageService implements ILanguageService {
	private language: ILanguageLime = null;

	static $inject = ["$rootScope"];

	constructor(rootScope: ng.IRootScopeService) {
		var language: ILanguageLime;
		if (typeof infor !== "undefined") {
			language = <ILanguageLime>infor.lime.ResourcesKeys;
		}
		else {
			language = <ILanguageLime>{};
		}
		language.format = lm.StringUtil.format;
		language.get = (name: string): string => {
			var text = language[name];
			return text ? text : name;
		};
		this.language = language;
		rootScope["lmLang"] = language;
	}

	public getLanguage(): ILanguageLime {
		return this.language;
	}

	public get(name: string): string {
		return this.language ? this.language.get(name) : name;
	}

	static add(m: ng.IModule) {
		m.service("lmLanguageService", LanguageService);
	}
}

/*
* Error code class for unique errors that should have different error messages on the client.
*/
export class UniqueError {
	public static failedToAddMaxUserPagesReached: number = 11015;
}

export class EntityCategory {
	static standardWidget = 1;
	static publishedWidget = 2;
	static publishedPage = 3;
	static privatePage = 4;
	static adHocProperties = 7;
}

/**
* A type that separates users from groups.
*/
export enum PrincipalType {
	MingleGroup = 0,
	User = 1,
	Role = 2
}

export interface IDataListCache {
	name: string;
	isValid: boolean;
	cachedResponse: IOperationResponse;
	timeoutId: number;
}

export interface ICommandBarAction extends lm.IWidgetAction {
	cssClass?: string;
}

/**
* Utility functions.
*/
export class CoreUtil {
	/**
	* Converts an array of users or group to an entity array that can be used with the autocomplete control.
	*/
	public static getEntityArray(array: any[]): lm.IAutocompleteEntity[] {
		var entityList: lm.IAutocompleteEntity[] = [];
		for (var i = 0; i < array.length; i++) {
			var item = array[i];
			var isUser = !lm.CommonUtil.isUndefined(item.userName);
			var label = isUser ? item.displayName : item.name;
			var labelInfo = isUser ? item.email : item.description;
			var value = isUser ? item.userName : item.id.toString();
			var entity: lm.IAutocompleteEntity = {
				label: label,
				value: value,
				type: isUser ? PrincipalType.User : PrincipalType.MingleGroup,
				info: labelInfo
			};
			entityList.push(entity);
		}
		return entityList;
	}
}

/**
 * UI utility functions.
 */
// ReSharper disable once InconsistentNaming
export class UIUtil {
	/**
	* Removes all popupmenus from the given element.
	* @param element Element from which to search for and remove xi-popupmenus
	*/
	public static removePopupMenus(element: JQuery): void {
		const popupMenus = element.find(".btn-menu[aria-haspopup]");
		for (let i = 0; i < popupMenus.length; i++) {
			const data = $(popupMenus[i]).data("popupmenu");
			if (data) {
				data["close"]();
				data["destroy"]();
			}
		}
	}
}

/**
* HTTP utility functions.
*/
export class HttpUtil {
	/**
	* Parses a query string to a parameter map.
	* 
	* Note that this function does not support multiple parameters with the same name.
	* 
	* @param query A query string.
	* @returns A parameter map.
	*/
	public static parseQuery(query: string): any {
		var match,
			pl = /\+/g,  // Regex for replacing addition symbol with a space
			search = /([^&=]+)=?([^&]*)/g,
			decode = (s: string) => { return decodeURIComponent(s.replace(pl, " ")); };

		var parameters = {};
		while ((match = search.exec(query))) {
			parameters[decode(match[1])] = decode(match[2]);
		}
		return parameters;
	}

	public static combine(url1: string, url2): string {
		if (!url1) {
			return url2;
		}
		if (!url2) {
			return url1;
		}
		const end = url1.length - 1;
		if (url1.charAt(end) === '/') {
			url1 = url1.substring(0, end);
		}
		if (url2.charAt(0) === '/') {
			url2 = url2.substring(1);
		}
		return url1 + "/" + url2;
	}
}

// Keep this at the end of the file
export var init = (m: ng.IModule) => {
	LanguageService.add(m);
};
