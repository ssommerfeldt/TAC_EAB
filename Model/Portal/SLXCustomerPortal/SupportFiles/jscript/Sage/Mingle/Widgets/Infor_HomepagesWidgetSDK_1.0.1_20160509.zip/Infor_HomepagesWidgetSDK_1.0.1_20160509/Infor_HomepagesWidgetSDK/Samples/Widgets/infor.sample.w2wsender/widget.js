define(["require", "exports", "lime"], function (require, exports, lm) {
    // Mock data
    var persons = [
        {
            id: 1,
            lastName: "Asper",
            firstName: "David",
            title: "Engineer",
            status: "Fulltime employee",
            anniversary: "2015-01-12"
        },
        {
            id: 2,
            lastName: "Baxter",
            firstName: "Michael",
            title: "System Architect",
            status: "Freelance 3-6months",
            anniversary: "2008-05-27"
        },
        {
            id: 3,
            lastName: "John",
            firstName: "Steven",
            title: "Graphic Designer",
            status: "Fulltime employee",
            anniversary: "2001-02-17"
        },
        {
            id: 4,
            lastName: "Donald",
            firstName: "Samual",
            title: "System Architect",
            status: "Fulltime employee",
            anniversary: "1989-11-05"
        },
        {
            id: 5,
            lastName: "Bronte",
            firstName: "Emily",
            title: "Quality Assurance Analyst",
            status: "Fulltime employee",
            anniversary: "2010-09-21"
        },
        {
            id: 6,
            lastName: "Davendar",
            firstName: "Konda",
            title: "Engineer",
            status: "Fulltime employee",
            anniversary: "2003-12-05"
        },
        {
            id: 7,
            lastName: "Little",
            firstName: "Jeremy",
            title: "Quality Assurance Analyst",
            status: "Fulltime employee",
            anniversary: "1999-01-13"
        },
        {
            id: 8,
            lastName: "Ayers",
            firstName: "Julie",
            title: "Architect",
            status: "Freelance 3-6months",
            anniversary: "2012-06-17"
        },
        {
            id: 9,
            lastName: "Ortega",
            firstName: "Hector",
            title: "Senior Architect",
            status: "Freelance 3-6months",
            anniversary: "2013-07-01"
        },
        {
            id: 10,
            lastName: "McConnel",
            firstName: "Mary",
            title: "Engineer",
            status: "Freelance 3-6months",
            anniversary: "2013-07-01"
        }
    ];
    var W2WSenderCtrl = (function () {
        function W2WSenderCtrl(scope) {
            var _this = this;
            this.scope = scope;
            // Get the widget context and instance from the scope
            var widgetContext = scope[lm.WidgetConstants.widgetContextKey];
            var widgetInstance = scope[lm.WidgetConstants.widgetInstanceKey];
            this.widgetContext = widgetContext;
            this.language = widgetContext.getLanguage();
            this.instanceId = widgetContext.getWidgetInstanceId();
            var pageId = widgetContext.getPageId();
            this.pageId = pageId;
            this.logPrefix = "[" + widgetContext.getId() + "] ";
            // Subscribe to the event that is triggered when settings are saved to be able to update the message type
            widgetInstance.settingsSaved = function () {
                _this.updateMessageType();
            };
            // Set initial message type used for communication
            this.updateMessageType();
            this.persons = persons;
        }
        W2WSenderCtrl.prototype.updateMessageType = function () {
            var messageType = this.widgetContext.getSettings().get("MessageType");
            var newMessageType = messageType + this.pageId;
            if (!lm.StringUtil.isNullOrWhitespace(messageType) && newMessageType !== this.messageType) {
                this.messageType = newMessageType;
                lm.Log.debug(this.logPrefix + "Message type updated to: " + newMessageType);
            }
        };
        W2WSenderCtrl.prototype.sendMessage = function (person) {
            if (person) {
                infor.companyon.client.sendMessage(this.messageType, person);
                lm.Log.debug(this.logPrefix + "Message sent for message type: " + this.messageType);
            }
        };
        W2WSenderCtrl.add = function (m) {
            m.controller("W2WSenderCtrl", W2WSenderCtrl);
        };
        W2WSenderCtrl.$inject = ["$scope"];
        return W2WSenderCtrl;
    })();
    exports.widgetFactory = function (context) {
        var m = context.getAngularContext().module;
        W2WSenderCtrl.add(m);
        return {
            angularConfig: {
                relativeTemplateUrl: "widget.html"
            }
        };
    };
});
//# sourceMappingURL=widget.js.map