var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../lime", "../../core", "../service"], function (require, exports, lm, c, s) {
    var AdminPrivatePagesCtrl = (function (_super) {
        __extends(AdminPrivatePagesCtrl, _super);
        function AdminPrivatePagesCtrl(scope, adminService, dialogService, pageService, commonDataService, uiGridConstants) {
            var _this = this;
            _super.call(this, "[AdminPrivatePagesCtrl] ");
            this.scope = scope;
            this.adminService = adminService;
            this.dialogService = dialogService;
            this.pageService = pageService;
            this.commonDataService = commonDataService;
            this.uiGridConstants = uiGridConstants;
            this.privatePages = [];
            this.refreshText = "Refresh";
            this.initGrid();
            var adminConstants = s.AdminConstants;
            var self = this;
            scope.$watch(adminConstants.openTab, function (tab) {
                if (tab === adminConstants.privatePagesTab) {
                    if (self.selectedUser) {
                        self.listPrivatePages(self.selectedUser, false);
                    }
                }
            });
            scope.$on("$destroy", function () {
                _this.autocompleteElem.off();
            });
        }
        AdminPrivatePagesCtrl.prototype.setBusy = function (isBusy) {
            this.adminService.setBusy(isBusy);
        };
        AdminPrivatePagesCtrl.prototype.onError = function (error) {
            this.adminService.handleError(error);
            this.setBusy(false);
        };
        AdminPrivatePagesCtrl.prototype.listPrivatePages = function (userId, reload, callback) {
            var self = this;
            var adminService = self.adminService;
            if (reload) {
                this.noOfSelected = 0;
                if (this.scope["pagesGridApi"]) {
                    this.scope["pagesGridApi"].selection.clearSelectedRows();
                }
            }
            adminService.setBusy(true);
            adminService.listPrivatePages(userId, reload).then(function (r) {
                var privatePages = r.content;
                self.privatePages = privatePages;
                self.pagesGridOptions.data = privatePages;
                adminService.setBusy(false);
                if (callback) {
                    callback();
                }
            }, function (r) {
                adminService.handleError(r);
                adminService.setBusy(false);
                if (callback) {
                    callback();
                }
            });
        };
        AdminPrivatePagesCtrl.prototype.import = function () {
            var _this = this;
            var dialogTitle = "Import Private Pages";
            var adminService = this.adminService;
            var options = {
                title: dialogTitle,
                operation: c.EntityCategory.privatePage.toString()
            };
            var map = {};
            map["userId"] = this.selectedUser;
            options.formFields = map;
            var self = this;
            adminService.openImportFilesDialog(options).then(function (r) {
                var value = r.value;
                if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Success) {
                    _this.adminService.showUploadCompleteDialog(dialogTitle, value.message).then(function (result) {
                        if (result.button === lm.DialogButtonType.Ok) {
                            self.listPrivatePages(self.selectedUser, true);
                        }
                    });
                }
                else if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Fail) {
                    adminService.showUploadCompleteDialog(dialogTitle, value.message, true);
                }
            });
        };
        AdminPrivatePagesCtrl.prototype.export = function () {
            if (this.noOfSelected === this.privatePages.length) {
                this.exportAll();
            }
            else {
                var pagesToExport = this.getSelectedRows();
                this.adminService.exportPrivatePages(this.selectedUser, pagesToExport);
            }
        };
        AdminPrivatePagesCtrl.prototype.exportAll = function () {
            this.adminService.exportPrivatePages(this.selectedUser);
        };
        AdminPrivatePagesCtrl.prototype.delete = function (page) {
            var _this = this;
            var pagesToDelete = page ? [page] : this.getSelectedRows();
            var options = this.adminService.getDeletePageOptions(pagesToDelete, true);
            this.dialogService.showMessage(options).then(function (result) {
                if (result.button === lm.DialogButtonType.Yes) {
                    _this.deletePrivatePage(pagesToDelete);
                }
            });
        };
        AdminPrivatePagesCtrl.prototype.initGrid = function () {
            var gridConstants = this.uiGridConstants;
            var pageActionTemplate = '<div class="ui-grid-cell-contents lm-center-text"><button type="button" ng-click="$event.stopPropagation();" class="btn-actions lm-transparent" xi-popupmenu="grid.appScope.ctrl.menuOptions">' +
                '<span class="audible">Actions</span><svg class="icon" focusable="false" aria-hidden="false"><use xlink:href="#icon-more"/></svg></button><ul class="popupmenu actions top"><li><a ng-click="grid.appScope.ctrl.delete(row.entity)">Delete</a></li></ul></div>';
            var self = this;
            this.pagesGridOptions = {
                columnDefs: [{
                        field: "data.title",
                        name: "Title",
                        sort: { direction: gridConstants.ASC, priority: 1 },
                        filter: { condition: gridConstants.filter.CONTAINS },
                        minWidth: 50, maxWidth: 600
                    },
                    { field: "data.ownerName", name: "Owner", enableFiltering: false, enableColumnResizing: false },
                    {
                        field: "data.changeDate", name: "ChangeDate", displayName: "Change date", enableColumnResizing: false,
                        cellTemplate: "<div class='ui-grid-cell-contents'>{{COL_FIELD | lmLocaleDate}}</div>"
                    },
                    { field: "data.changedByName", name: "ChangedBy", displayName: "Changed by", enableColumnResizing: false },
                    { field: "actions", name: "Actions", maxWidth: 110, cellTemplate: pageActionTemplate, enableFiltering: false, enableSorting: false, enableColumnResizing: false }
                ],
                data: [],
                rowHeight: 48,
                enableFiltering: true,
                enableSorting: true,
                enableColumnMenus: false,
                onRegisterApi: function (gridApi) {
                    self.scope["pagesGridApi"] = gridApi;
                    self.noOfSelected = 0;
                    var gridSelection = gridApi.selection;
                    var onSelection = gridSelection.on;
                    onSelection.rowSelectionChanged(self.scope, function () {
                        self.noOfSelected = gridSelection.getSelectedRows().length;
                    });
                    onSelection.rowSelectionChangedBatch(self.scope, function () {
                        self.noOfSelected = gridSelection.getSelectedRows().length;
                    });
                }
            };
            if (!this.isAutocompleteInitialized) {
                this.scope["autocomplete"] = {
                    source: function (query, done) {
                        self.commonDataService.searchUsers(query).then(function (response) {
                            done(query, lm.ArrayUtil.sortByProperty(c.CoreUtil.getEntityArray(response.content), "label"));
                        }, function (r) {
                            self.commonDataService.handleError(r);
                        });
                    },
                    template: c.Templates.autocompleteEntity
                };
                this.autocompleteElem = $("#autocomplete-private-pages");
                this.autocompleteElem.on("selected", function (event, target, object) {
                    if (lm.CommonUtil.isUndefined(object) || lm.CommonUtil.isUndefined(object.value)) {
                        return;
                    }
                    self.selectedUser = object.value;
                    self.selectedUserEmail = object.info;
                    self.selectedUserDisplayName = object.label;
                    self.listPrivatePages(self.selectedUser, true);
                });
                this.isAutocompleteInitialized = true;
            }
        };
        AdminPrivatePagesCtrl.prototype.getSelectedRows = function () {
            return this.scope["pagesGridApi"].selection.getSelectedRows();
        };
        AdminPrivatePagesCtrl.prototype.deletePrivatePage = function (pages) {
            var _this = this;
            var self = this;
            var pageList = pages.map(function (page) {
                return page.data.id;
            });
            this.setBusy(true);
            this.adminService.deletePrivatePages(pageList).then(function (r) {
                if (r.content > 0) {
                    for (var _i = 0; _i < pages.length; _i++) {
                        var page = pages[_i];
                        _this.adminService.unselectGridItem(lm.ArrayUtil.itemByPredicate(self.privatePages, function (item) { return item.data.id === page.data.id; }), _this.scope["pagesGridApi"]);
                        lm.ArrayUtil.removeByPredicate(self.privatePages, function (item) { return item.data.id === page.data.id; });
                    }
                }
                self.setBusy(false);
            }, function (e) {
                self.onError(e);
            });
        };
        AdminPrivatePagesCtrl.prototype.clearSelection = function () {
            this.noOfSelected = 0;
            var grid = this.scope["pagesGridApi"];
            if (grid) {
                grid.selection.clearSelectedRows();
            }
        };
        AdminPrivatePagesCtrl.add = function (m) {
            m.controller("lmAdminPrivatePagesCtrl", AdminPrivatePagesCtrl);
        };
        AdminPrivatePagesCtrl.$inject = ["$scope", "lmAdminService", "lmDialogService", "lmPageService", "lmCommonDataService", "uiGridConstants"];
        return AdminPrivatePagesCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        AdminPrivatePagesCtrl.add(m);
    };
});
//# sourceMappingURL=private-pages.js.map