﻿import lm = require("../lime");
import c = require("../core");
import s = require("./service");

/**
 * Interface specifying methods commonly used in both the bulk export and import operation.
 */
interface IAdminOperationBase {
	checkStatus(scope: any, callback?: Function): void;
	cancel(scope: any): void;
	setBusy(isBusy: boolean): void;
}

/**
 * Abstract base class for bulk import and export used for inheritance.
 */
abstract class AdminOperationBase extends c.CoreBase implements IAdminOperationBase {
	public includeOptions: c.IStringToAnyMap = {};
	public statusMessageList: c.MessageInfo[];

	private unsubscribers: Array<Function> = [];

	constructor(public logPrefix: string, public scope: ng.IScope, public timeout: ng.ITimeoutService, public adminService: s.IAdminService, public dialogService: lm.IDialogService) {
		super(logPrefix);

		this.initDefaults();
		const includeOptions = this.includeOptions;
		const adminConstants = s.AdminConstants;
		scope["includeOptions"] = includeOptions;

		// Disable child switches when parent gets disabled
		this.unsubscribers.push(
			scope.$watch('includeOptions["includesettings"]', (value: boolean) => {
				if (value === false) {
					includeOptions[adminConstants.parameterIncludeSettingsRules] = false;
				}
			})
		);

		this.unsubscribers.push(
			scope.$watch('includeOptions["includepublishedwidgets"]', (value: boolean) => {
				if (value === false) {
					includeOptions[adminConstants.parameterIncludePublishedWidgetAccess] = false;
				}
			})
		);

		this.unsubscribers.push(
			scope.$watch('includeOptions["includepublishedpages"]', (value: boolean) => {
				if (value === false) {
					includeOptions[adminConstants.parameterIncludePublishedPageConnections] = false;
					includeOptions[adminConstants.parameterIncludePublishedPageAccess] = false;
				}
			})
		);

		scope.$on("$destroy", () => {
			angular.forEach(this.unsubscribers, (unsubscribe) => {
				unsubscribe();
			});
		});
	}

	/**
	 * Starts polling the server for the current operation's status.
	 * @param scope Scope of the sub-class
	 * @param callback Method to be called when the operation has finished
	 */
	public checkStatus(scope: any, callback?: Function): void {
		const self = scope;
		self.adminService.getOperationStatus().then((r: s.IAdminOperationResponse) => {
			const content = r.content;
			if (content.messageList) {
				self.statusMessageList = content.messageList;
			}

			// Keep polling if operation is still active
			if (content.isRunning) {
				self.timeout(() => self.checkStatus(self, callback), s.AdminConstants.checkStatusInterval);
			} else {
				self.setBusy(false);
				if (callback) {
					callback();
				}
			}
		}, (r: c.IOperationResponse) => {
			const content = r.content;
			if (content.messageList) {
				self.statusMessageList = content.messageList;
			}

			// Keep polling if operation is still active, errors may occur during e.g. import
			if (content.isRunning) {
				self.timeout(() => self.checkStatus(self, callback), s.AdminConstants.checkStatusInterval);
			} else {
				self.setBusy(false);
				if (callback) {
					callback();
				}
				// Errors will persist in responses, show errors only after operation is complete
				if (r.hasError()) {
					self.adminService.showUploadCompleteDialog("Error", r.toErrorLog(), true);
				}
			}
		});
	}

	/**
	 * Cancels the current operation running on the server.
	 * @param scope Scope of the sub-class
	 */
	public cancel(scope?: any): void {
		const self = scope || this;
		self.adminService.cancelOperation().then((r: s.IAdminOperationResponse) => {
			const content = r.content;
			if (content.isRunning) {
				self.checkStatus(self);
			} else {
				self.setBusy(false);
			}

			if (content.messageList) {
				self.statusMessageList = content.messageList;
			}
		}, (r: c.IOperationResponse) => {
			self.setBusy(false);
			self.adminService.showUploadCompleteDialog("Error", r.toErrorLog(), true);
		});
	}

	/**
	 * Abstract set busy method to be overridden by sub-classes.
	 * @param isBusy 
	 */
	public abstract setBusy(isBusy: boolean): void;

	/**
	 * Sets initial values for what content to include in either a bulk import or export.
	 */
	private initDefaults(): void {
		const includeOptions = this.includeOptions;
		const adminConstants = s.AdminConstants;
		includeOptions[adminConstants.parameterIncludeSettings] = true;
		includeOptions[adminConstants.parameterIncludeSettingsRules] = true;
		includeOptions[adminConstants.parameterIncludeUserSettings] = true;
		includeOptions[adminConstants.parameterIncludeProperties] = true;
		includeOptions[adminConstants.parameterIncludePublishedWidgets] = true;
		includeOptions[adminConstants.parameterIncludePublishedWidgetAccess] = true;
		includeOptions[adminConstants.parameterIncludePublishedPages] = true;
		includeOptions[adminConstants.parameterIncludePublishedPageConnections] = true;
		includeOptions[adminConstants.parameterIncludePublishedPageAccess] = true;
		includeOptions[adminConstants.parameterIncludePrivatePages] = true;
	}
}

/**
 * UI controller for the bulk export operation.
 */
class AdminExportCtrl extends AdminOperationBase {
	static $inject = ["$scope", "$timeout", "lmAdminService", "lmDialogService"];

	constructor(public scope: ng.IScope, public timeout: ng.ITimeoutService, public adminService: s.IAdminService, public dialogService: lm.IDialogService) {
		super("[AdminExportCtrl] ", scope, timeout, adminService, dialogService);
	}

	/**
	 * Starts an export operation on the server with the content selected in the UI.
	 */
	public export(): void {
		this.setBusy(true);
		this.adminService.startExportOperation(this.includeOptions).then((r: s.IAdminOperationResponse) => {
			if (r.content.isRunning) {
				this.checkStatus(this);
			} else {
				this.setBusy(false);
			}
		}, (r: c.IOperationResponse) => {
			this.setBusy(false);
			this.adminService.showUploadCompleteDialog("Export Error", r.toErrorLog(), true);
		});
	}

	/**
	 * Downloads the export file from the server.
	 */
	public download(): void {
		this.adminService.downloadExportFile();
	}

	/**
	 * Set export UI busy status.
	 * @param isBusy True to set busy indication
	 */
	public setBusy(isBusy: boolean): void {
		this.scope["lmExportBusy"] = isBusy;
	}

	static add(m: ng.IModule) {
		m.controller("lmAdminExportCtrl", AdminExportCtrl);
	}
}

/**
 * UI controller for the bulk import operation.
 */
class AdminImportCtrl extends AdminOperationBase {
	static $inject = ["$scope", "$timeout", "lmAdminService", "lmDialogService"];

	constructor(public scope: ng.IScope, public timeout: ng.ITimeoutService, public adminService: s.IAdminService, public dialogService: lm.IDialogService) {
		super("[AdminImportCtrl] ", scope, timeout, adminService, dialogService);
	}

	/**
	 * Opens a a file upload dialog.
	 * Used for uploading an import file to the server.
	 */
	public upload(): void {
		const dialogTitle = "Upload Homepage Data";
		const adminService = this.adminService;
		const options: c.IImportOptions = {
			title: dialogTitle,
			operation: s.AdminOperations.importData,
			buttonText: "Upload"
		};

		adminService.openImportFilesDialog(options).then((r: lm.IDialogResult) => {
			var value = r.value;
			if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Success) {
				const message = value.message ? value.message : "The file was successfully uploaded to the server.";
				adminService.showUploadCompleteDialog(dialogTitle, message);
			} else if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Fail) {
				adminService.showUploadCompleteDialog(dialogTitle, value.message, true);
			}
		});
	}

	/**
	 * Starts an import operation on the server with the content selected in the UI.
	 */
	public import(): void {
		const self = this;
		const options: lm.IMessageDialogOptions = {
			title: "Import Homepage Data",
			message: "Are you sure you want to start an import operation?",
			standardButtons: lm.StandardDialogButtons.YesNo
		}
		this.dialogService.showMessage(options).then((result: lm.IDialogResult) => {
			if (result.button === lm.DialogButtonType.Yes) {
				const includeOptions = self.includeOptions;
				self.setBusy(true);
				self.adminService.startImportOperation(includeOptions).then((r: s.IAdminOperationResponse) => {
					if (r.content.isRunning) {
						const callback = () => { this.onImported(includeOptions) };
						self.checkStatus(self, callback);
					} else {
						self.setBusy(false);
					}
				}, (r: c.IOperationResponse) => {
					self.setBusy(false);
					self.adminService.showUploadCompleteDialog("Import Error", r.toErrorLog(), true);
				});
			}
		});
	}

	/**
	 * Set import UI busy status.
	 * @param isBusy True to set busy indication
	 */
	public setBusy(isBusy: boolean): void {
		this.scope["lmImportBusy"] = isBusy;
	}

	/**
	 * Called after successful import operation, in order to invalidate affected caches on client.
	 * @param options Content that was imported.
	 */
	private onImported(options: c.IStringToAnyMap): void {
		this.adminService.invalidateCaches(options);
	}

	static add(m: ng.IModule) {
		m.controller("lmAdminImportCtrl", AdminImportCtrl);
	}
}

export var init = (m: ng.IModule) => {
	AdminExportCtrl.add(m);
	AdminImportCtrl.add(m);
}