﻿import lm = require("../lime");
import c = require("../core");
import w = require("../app/widget");
import p = require("../app/page");

interface IPageEditScope extends ng.IScope {
	widgetEditData: IWidgetEditData;
	onRepeatCompleted?: Function;
	clipboardWidget?: c.IWidget;
}

class PageEditCtrl extends c.CoreBase {
	private isEditMode = false;
	public widgets: c.IEditableWidget[];
	private page: c.IPageInstance;

	private homepage: JQuery;
	private homepageSettings: p.IHomepageSettings;
	private lang: ILanguageLime;

	static $inject = ["$scope", "$rootScope", "$compile", "lmWidgetService", "lmEditModeService", "lmContextService", "lmLanguageService", "lmDialogService"];

	constructor(public scope: IPageEditScope, private rootScope: ng.IRootScopeService, private compile: ng.ICompileService, private widgetService: c.IWidgetService,
		private editModeService: c.IEditModeService, private contextService: c.IContextService, private languageService: c.ILanguageService, private dialogService: lm.IDialogService) {
		super("[PageEditCtrl] ");
		this.lang = languageService.getLanguage();
		var unsubscribe = editModeService.started().on((editMode: c.IEditMode) => {
			if (editMode.isActive && editMode.mode === c.EditModes.layout) {
				this.setEditModeActions(editMode);
				this.initialize();
			}
		});

		this.scope.widgetEditData = <IWidgetEditData>{};

		scope.$on("$describe", () => {
			unsubscribe();
		});
	}

	private setEditModeActions(editMode: c.IEditMode): void {
		const lang = this.lang;

		var self = this;
		editMode.actions = [
			{
				text: lang.cancel,
				cssClass: "e2e-editPageCancel",
				execute: () => {
					self.close();
				}
			},
			{
				text: lang.save,
				cssClass: "e2e-editPageSave",
				execute: () => {
					self.save();
				}
			}
		];
		const secondaryActions: c.ICommandBarAction[] = [{
			text: lang.addWidget,
			execute: () => {
				self.addWidgetFromCatalog();
			}
		}];
		if (this.scope.clipboardWidget) {
			secondaryActions.push({
				text: lang.pasteWidget,
				execute: () => {
					self.pasteWidget();
				}
			});
		}
		editMode.secondaryActions = secondaryActions;
	}

	private onWidgetDropped(widget: c.IEditableWidget) {
		const editData = this.scope.widgetEditData;
		const widgets = this.widgets;
		const widgetElementId = widget.elementId;
		const editElementId = editData.elementId;
		if (lm.CommonUtil.isUndefined(editElementId) || lm.CommonUtil.isUndefined(widgetElementId)) {
			return;
		}

		const fromIndex = lm.ArrayUtil.indexByProperty(widgets, "elementId", editElementId);
		const toIndex = lm.ArrayUtil.indexByProperty(widgets, "elementId", widgetElementId);

		if (fromIndex === -1 || toIndex === -1) {
			this.refreshLayout();
			return;
		}
		lm.ArrayUtil.move(widgets, fromIndex, toIndex);

		// Need to trigger it manually here since scope doesn't react to event.
		this.scope.$apply("lmPageEditCtrl.widgets");
		this.refreshLayout();
	}

	private onWidgetResized() {
		const editData = this.scope.widgetEditData;
		const widgets = this.widgets;
		const editElementId = editData.elementId;
		if (lm.CommonUtil.isUndefined(editData.elementId) || lm.CommonUtil.isUndefined(editData.widgetLayout) ||
			!lm.ArrayUtil.containsByProperty(widgets, "elementId", editElementId)) {
			return;
		}

		const widget = lm.ArrayUtil.itemByProperty(widgets, "elementId", editElementId);
		widget.layout = editData.widgetLayout;
		// Needed to trigger algortihm every time.
		this.refreshLayout();
	}

	private refreshLayout() {
		p.PageUtil.refreshHomepageLayout(this.homepage);
	}

	private addWidgetFromCatalog() {
		const context = this.page.getWidgetParentContext();
		var widgetService = this.widgetService;
		var self = this;
		widgetService.showCatalog(context, (w: c.IAddWidgetInfo, c: Function) => { self.addWidget(w, c); }).then(() => {
			// Adding of widget handled by callback
        }, (r: c.IOperationResponse) => { lm.Log.error("Could not open Widget Catalog.");});
	}

	private pasteWidget() {
		const widgetCopy = this.scope.clipboardWidget;
		const widgetService = this.widgetService;
		const context = this.page.getWidgetParentContext();
		const addWidgetInfo = widgetService.getAddWidgetInfo(widgetCopy);
		widgetService.preAddWidget(context, addWidgetInfo).then((widget: c.IWidget) => {
			this.addWidgetInternal(widget, false);
		}, () => {
			this.dialogService.showMessage({ title: this.lang.unableToAddWidget, message: this.lang.brokenWidget, isError: true });
		});
	}

	public addWidget(addWidgetInfo: c.IAddWidgetInfo, busyCallback?: Function) {
		const context = this.page.getWidgetParentContext();
		this.widgetService.preAddWidget(context, addWidgetInfo, busyCallback).then((widget: c.IWidget) => {
			this.addWidgetInternal(widget, true);
		}, () => {
			this.dialogService.showMessage({ title: this.lang.unableToAddWidget, message: this.lang.brokenWidget, isError: true });
		});
	}

	private addWidgetInternal(widget: c.IWidget, showToastConfirmation: boolean): void {
		const editableWidget = this.createEditableWidget(widget, <c.IWidgetLayout>{ row: 0, rowSpan: 1, column: 0, columnSpan: 1 });
		editableWidget.widget = widget;
		editableWidget.elementId = lm.CommonUtil.random();
		this.widgets.push(editableWidget);
		setTimeout(() => {
			this.refreshLayout();
		}, 1);
		if (showToastConfirmation) {
			const lang = this.languageService.getLanguage();
			this.dialogService.showToast({ title: lang.widgetAdded, message: lang.format(lang.titleAddedMessage, editableWidget.title) });
		}
	}

	private deleteWidget(widget: c.IEditableWidget) {
		// Destroy widget scope and remove widget.
		const element = $("#" + widget.elementId);
		if (element.length > 0) {
			angular.element($("#" + widget.elementId)).scope().$destroy();
		}

		lm.ArrayUtil.remove(this.widgets, widget);

		// Need to trigger it manually here since scope doesn't react to event.
		setTimeout(() => {
			this.refreshLayout();
		}, 50);
	}

	private createEditableWidget(widget: c.IWidget, layout?: c.IWidgetLayout): c.IEditableWidget {
		const data = widget.data;
		const title = widget.title;
		return <c.IEditableWidget>{
			title: title,
			layout: layout ? layout : angular.copy(data.layout),
			isPlaceholder: false,
			id: data.id,
			elementId: widget.elementId
		};
	}

	private getLayoutClasses(widget: c.IEditableWidget): string {
		return widget.layout ? w.WidgetUtil.getLayoutClasses(widget.layout) : "";
	}

	private stopEdit(isSave: boolean) {
		let updatedWidgets = [];
		const widgets = this.widgets;
		const homepage = this.homepage;
		if (isSave) {
			const widgetElements = homepage.find(".widget").not(".placeholder");
			for (let i = 0; i < widgetElements.length; i++) {
				const widgetLayout = p.PageUtil.getLayout($(widgetElements[i]), this.homepageSettings);
				widgets[i].layout = widgetLayout;
			}
			updatedWidgets = angular.copy(widgets);
		}
		p.PageUtil.destroyHomepageControl(homepage);
		delete this.scope.onRepeatCompleted;
		this.editModeService.stop({ isSave: isSave, result: updatedWidgets });
	}

	public close() {
		this.stopEdit(false);
	}

	public save() {
		this.stopEdit(true);
	}

	public initialize() {
		const editableWidgets = [];
		const ctrl = this.scope["lmPageNavigatorCtrl"];
		if (ctrl) {
			this.page = ctrl.currentPage;
			const widgets = this.page.widgets;
			for (let widget of widgets) {
				editableWidgets.push(this.createEditableWidget(widget));
			}

			// Setup responsive behavior
			const homepage = $(".lm-page-edit .homepage");
			this.homepage = homepage;
			p.PageUtil.addHomepageControl(homepage);
			//TODO Type the data object
			const homepageData: any = homepage.data("homepage");
			this.homepageSettings = homepageData.settings;
			this.scope["widgetEditData"].homepageSettings = this.homepageSettings;
			var self = this;
			// Refresh manually first time to get correct width of container, and re-calculate toolbar buttons visibility
			setTimeout(() => {
				self.refreshLayout();
				self.scope.onRepeatCompleted = () => {
					self.refreshLayout();
				};
			}, 1);
		}
		this.widgets = editableWidgets;
	}

	public static add(m: ng.IModule) {
		m.controller("lmPageEditCtrl", PageEditCtrl);
	}
}

class PageEditDirective {
	static add(m: ng.IModule) {
		m.directive("lmPageEdit", ["$compile", ($compile) => {
			return {
				scope: false,
				restrict: "E",
				replace: false,
				controller: PageEditCtrl,
				controllerAs: "lmPageEditCtrl",
				templateUrl: "scripts/lime/templates/page-edit.html"
			};
		}]);
	}
}

class XiDraggableDirective {
	static add(m: ng.IModule) {
		m.directive("xiDraggable", [
			"$compile", ($compile) => {
				return {
					scope: false,
					restrict: "A",
					link: (scope: ng.IScope, elem: ng.IAugmentedJQuery, attrs: ng.IAttributes) => {
						var widget = scope["widget"];
						elem["draggable"]({
							revertDuration: 150,
							helper: "clone",
							opacity: 0.8,
							scrollSensitivity: 200,
							scrollSpeed: 10,
							start: (event, ui) => {
								var target = $(event.target);
								$(".lm-page-edit .widget").addClass("ui-draggable-passive");
								target.removeClass("ui-draggable-passive");
								target.addClass("ui-draggable-cloned");
								var editData = <IWidgetEditData>scope["widgetEditData"];
								editData.elementId = widget.elementId;
							},
							stop: (event, ui) => {
								$(".lm-page-edit .widget").removeClass("ui-draggable-passive");
								$(event.target).removeClass("ui-draggable-cloned");
							}
						});

						elem["droppable"]({
							greedy: true,
							tolerance: "pointer",
							hoverClass: "ui-droppable-active",
							drop: (event, ui) => {
								scope.$eval(attrs["onDropped"]);
							}
						});

						elem["resizable"]({
							handles: "e, s",
							autoHide: true,
							start: (event, ui) => {
								$(".lm-page-edit .widget").addClass("ui-resizable-passive");
								$(event.target).removeClass("ui-resizable-passive");
								var editData = <IWidgetEditData>scope["widgetEditData"];
								editData.elementId = widget.elementId;
								editData.widgetLayout = widget.layout;
							},
							stop: (event, ui) => {
								$(".lm-page-edit .widget").removeClass("ui-resizable-passive");
								var editData = <IWidgetEditData>scope["widgetEditData"];
								var diffWidth = ui.size.width - ui.originalSize.width;
								var diffHeight = ui.size.height - ui.originalSize.height;

								var isChanged = false;
								var element = $(ui.element);
								var settings = editData.homepageSettings;

								var columnSpan = editData.widgetLayout.columnSpan;
								var rowSpan = editData.widgetLayout.rowSpan;

								//Check horizontal change
								if (Math.abs(diffWidth) > settings.widgetWidth / 2) { //Widget should alter width horizontally
									isChanged = true;
									element.removeClass("double-width triple-width quad-width");
									const widthUnits = ui.size.width / settings.widgetWidth;
									if (widthUnits > 3.5) {
										element.addClass("quad-width");
										columnSpan = 4;
									} else if (widthUnits > 2.5) {
										element.addClass("triple-width");
										columnSpan = 3;
									} else if (widthUnits > 1.5) {
										element.addClass("double-width");
										columnSpan = 2;
									} else {
										columnSpan = 1;
									}
								}

								//Check vertical change
								if (Math.abs(diffHeight) > settings.widgetHeight / 2) { //Widget should alter width horizontally
									element.removeClass("double-height");
									isChanged = true;
									const heightUnits = ui.size.height / settings.widgetHeight;
									if (heightUnits > 1.5) {
										element.addClass("double-height");
										rowSpan = 2;
									} else {
										rowSpan = 1;
									}
								}

								// Removes styling added by resizing
								element.css({ "height": "", "width": "" });

								if (isChanged) {
									editData.widgetLayout.columnSpan = columnSpan;
									editData.widgetLayout.rowSpan = rowSpan;
									//Triggers event back to controller
									scope.$eval(attrs["onResized"]);
								}
							}
						});
					}
				};
			}
		]);
	}
}

interface IWidgetEditData {
	elementId?: string;
	newLayout?: c.IWidgetLayout;
	widgetLayout?: c.IWidgetLayout;
	dropSuccess?: boolean;
	homepageSettings?: p.IHomepageSettings;
}

export var init = (m: ng.IModule) => {
	PageEditDirective.add(m);
	PageEditCtrl.add(m);
	XiDraggableDirective.add(m);
};