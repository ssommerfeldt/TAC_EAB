/// <reference path="../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../scripts/typings/lime/lime.d.ts" />
define(["require", "exports", "lime"], function (require, exports, lm) {
    var IonApiSocialCtrl = (function () {
        function IonApiSocialCtrl(scope, http) {
            this.scope = scope;
            this.http = http;
            this.serviceUrl = "Mingle/SocialService.Svc";
            this.retryAttempted = false;
            this.widgetContext = scope[lm.WidgetConstants.widgetContextKey];
            this.instance = scope[lm.WidgetConstants.widgetInstanceKey];
            this.setBusy(true);
            this.loadUser();
        }
        IonApiSocialCtrl.prototype.setBusy = function (isBusy) {
            // Show the indeterminate progress indicator when the widget is busy by changing the widget state.
            this.widgetContext.setState(isBusy ? lm.WidgetState.busy : lm.WidgetState.running);
        };
        IonApiSocialCtrl.prototype.loadUser = function () {
            var _this = this;
            var request = this.createRequest("User/Detail");
            this.widgetContext.executeIonApiAsync(request).then(function (response) {
                _this.updateUser(response.data);
            }, function (error) {
                _this.onRequestError(error);
            });
        };
        IonApiSocialCtrl.prototype.updateUser = function (response) {
            var user = response.UserDetailList[0];
            this.user = user;
            this.fullName = user.FirstName + " " + user.LastName;
            this.loadPhoto();
        };
        IonApiSocialCtrl.prototype.loadPhoto = function () {
            var _this = this;
            var relativeUrl = "User/" + this.user.UserGUID + "/ProfilePhoto?thumbnailType=3";
            var request = this.createRequest(relativeUrl, { "Accept": "image/png, image/jpeg" });
            request.responseType = "blob";
            this.widgetContext.executeIonApiAsync(request).then(function (response) {
                _this.updatePhoto(response.data);
            }, function (error) {
                _this.onRequestError(error);
            });
        };
        IonApiSocialCtrl.prototype.updatePhoto = function (response) {
            var _this = this;
            var reader = new FileReader();
            reader.onload = function () {
                _this.photoUrl = reader.result;
                _this.setBusy(false);
                _this.scope.$apply();
            };
            reader.readAsDataURL(response);
        };
        IonApiSocialCtrl.prototype.createRequest = function (relativeUrl, headers) {
            if (!headers) {
                // Create default headers
                headers = { "Accept": "application/json" };
            }
            // Create the relative URL to the ION API
            var url = this.serviceUrl + "/" + relativeUrl;
            // Create HTTP GET request object
            var request = {
                method: "GET",
                url: url,
                cache: false,
                headers: headers
            };
            return request;
        };
        IonApiSocialCtrl.prototype.onRequestError = function (error) {
            alert("Failed to call ION API: " + error);
            this.setBusy(false);
        };
        IonApiSocialCtrl.$inject = ["$scope", "$http"];
        return IonApiSocialCtrl;
    })();
    exports.widgetFactory = function (context) {
        var m = context.getAngularContext().module;
        m.controller("sample.IonApiSocialCtrl", IonApiSocialCtrl);
        return {
            angularConfig: {
                relativeTemplateUrl: "widget.html"
            }
        };
    };
});
//# sourceMappingURL=widget.js.map