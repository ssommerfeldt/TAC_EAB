var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../lime", "../../core"], function (require, exports, lm, c) {
    var RuleAddConnectionCtrl = (function (_super) {
        __extends(RuleAddConnectionCtrl, _super);
        function RuleAddConnectionCtrl(scope, adminService, commonDataService) {
            _super.call(this, "[RuleAddConnectionCtrl] ");
            this.scope = scope;
            this.adminService = adminService;
            this.commonDataService = commonDataService;
            this.ruleConnectionsString = "ruleConnections";
            var dialog = scope["lmDialog"];
            var dialogParameter = dialog.parameter;
            this.dialog = dialog;
            this.rule = angular.copy(dialogParameter.rule);
            this.userName = angular.copy(dialogParameter.userName);
            this.isUser = dialogParameter.isUser;
            scope[this.ruleConnectionsString] = [];
            if (this.isUser) {
                this.autocompleteElem = $("#autocomplete-add-connection");
                this.autocompleteOptions = {
                    source: function (query, done) {
                        commonDataService.searchEntities(query).then(function (response) {
                            done(query, lm.ArrayUtil.sortByProperty(response.content, "label"));
                        }, function (r) {
                            commonDataService.handleError(r);
                        });
                    },
                    template: c.Templates.autocompleteEntity
                };
                this.connectAutoComplete(this.autocompleteElem, scope);
            }
            else {
                this.autocompleteRoleOptions = {
                    source: function (query, done) {
                        adminService.searchRoles(query).then(function (result) {
                            done(query, lm.ArrayUtil.sortByProperty(result, "label"));
                        }, function (r) {
                        });
                    },
                    template: c.Templates.autocompleteEntity
                };
                this.autocompleteElemRole = $("#autocomplete-add-connection-role");
                this.connectAutoComplete(this.autocompleteElemRole, scope);
            }
        }
        RuleAddConnectionCtrl.prototype.connectAutoComplete = function (element, scope) {
            var self = this;
            element.on("selected", function (event, target, object) {
                if (lm.CommonUtil.isUndefined(object) || lm.CommonUtil.isUndefined(object.value)) {
                    return;
                }
                var value = object.value;
                var entityType = object.type;
                self.existsMsg = "";
                if (lm.ArrayUtil.containsByProperty(self.rule.ruleConnections, "name", value) || lm.ArrayUtil.containsByProperty(self.scope[self.ruleConnectionsString], "name", value)) {
                    self.existsMsg = entityType === c.PrincipalType.User ? "User already added" : "Group already added";
                }
                else {
                    var ruleConnection = {
                        name: value,
                        isUser: entityType === c.PrincipalType.User,
                        displayName: object.label ? object.label : value,
                        isChanged: true,
                        info: object.info || value
                    };
                    scope[self.ruleConnectionsString].push(ruleConnection);
                    self.resultInput = "";
                    scope.$apply(self.ruleConnectionsString);
                }
                scope.$apply("existsMsg");
            });
            scope.$on("$destroy", function () {
                element.off();
            });
        };
        RuleAddConnectionCtrl.prototype.addRole = function () {
            var groupName = angular.copy(this.resultInput);
            if (lm.ArrayUtil.containsByProperty(this.rule.ruleConnections, "name", groupName) || lm.ArrayUtil.containsByProperty(this.scope[this.ruleConnectionsString], "name", groupName)) {
                this.existsMsg = "Role already added";
            }
            else {
                delete this.resultInput;
                delete this.existsMsg;
                var ruleConnection = {
                    name: groupName,
                    isUser: false,
                    displayName: groupName,
                    info: groupName
                };
                this.scope[this.ruleConnectionsString].push(ruleConnection);
            }
        };
        RuleAddConnectionCtrl.prototype.onCancel = function () {
            var result = {
                button: lm.DialogButtonType.Cancel,
                value: null
            };
            this.dialog.close(result);
        };
        RuleAddConnectionCtrl.prototype.onOk = function () {
            if (this.scope[this.ruleConnectionsString].length > 0) {
                this.addConnections();
                var result = {
                    button: lm.DialogButtonType.Ok,
                    value: {
                        rule: this.rule,
                        displayChangeDate: lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*",
                        changedBy: this.userName
                    }
                };
                this.dialog.close(result);
            }
            else {
                this.onCancel();
            }
        };
        RuleAddConnectionCtrl.prototype.remove = function (connection) {
            var ruleConnections = this.scope[this.ruleConnectionsString];
            var connectionIndex = ruleConnections.indexOf(connection);
            ruleConnections.splice(connectionIndex, 1);
        };
        RuleAddConnectionCtrl.prototype.addConnections = function () {
            var self = this;
            angular.forEach(this.scope[this.ruleConnectionsString], function (newConnection) {
                newConnection.displayChangeDate = lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*";
                newConnection.changedByName = self.userName;
                self.rule.ruleConnections.push(newConnection);
            });
        };
        RuleAddConnectionCtrl.add = function (m) {
            m.controller("lmRuleAddConnectionCtrl", RuleAddConnectionCtrl);
        };
        RuleAddConnectionCtrl.$inject = ["$scope", "lmAdminService", "lmCommonDataService"];
        return RuleAddConnectionCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        RuleAddConnectionCtrl.add(m);
    };
});
//# sourceMappingURL=rule-add-connection.js.map