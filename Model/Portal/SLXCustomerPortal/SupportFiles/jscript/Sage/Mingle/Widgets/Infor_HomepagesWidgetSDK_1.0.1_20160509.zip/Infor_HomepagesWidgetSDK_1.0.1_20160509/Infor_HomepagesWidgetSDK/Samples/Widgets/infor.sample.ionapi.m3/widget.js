/// <reference path="../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../scripts/typings/lime/lime.d.ts" />
define(["require", "exports", "lime"], function (require, exports, lm) {
    var IonApiM3Ctrl = (function () {
        function IonApiM3Ctrl(scope, http) {
            var _this = this;
            this.scope = scope;
            this.http = http;
            this.widgetContext = scope[lm.WidgetConstants.widgetContextKey];
            this.instance = scope[lm.WidgetConstants.widgetInstanceKey];
            scope["model"] = this;
            var request = this.createRequest();
            this.widgetContext.executeIonApiAsync(request).then(function (response) {
                _this.showCustomers(response.data.MIRecord);
            }, function (error) { _this.onRequestError(error); });
        }
        IonApiM3Ctrl.prototype.createRequest = function () {
            var request = {
                method: "GET",
                url: "/M3/m3api-rest/execute/CRS610MI/LstByName",
                cache: false,
                headers: {
                    "Accept": "application/json"
                }
            };
            return request;
        };
        IonApiM3Ctrl.prototype.showCustomers = function (records) {
            var items = this.getItems(records, "CUNO", "CUNM");
            this.scope["customers"] = items;
        };
        IonApiM3Ctrl.prototype.getItems = function (records, titleField, descriptionField) {
            var items = [];
            for (var i = 0; i < records.length; i++) {
                var nameValues = records[i].NameValue;
                var customer = {
                    title: this.getValue(nameValues, titleField),
                    description: this.getValue(nameValues, descriptionField)
                };
                items.push(customer);
            }
            return items;
        };
        IonApiM3Ctrl.prototype.getValue = function (nameValues, name) {
            for (var i = 0; i < nameValues.length; i++) {
                var nameValue = nameValues[i];
                if (nameValue.Name === name) {
                    return nameValue.Value.trim();
                }
            }
            return null;
        };
        IonApiM3Ctrl.prototype.onRequestError = function (error) {
            alert("Failed to call ION API: " + error);
        };
        IonApiM3Ctrl.$inject = ["$scope", "$http"];
        return IonApiM3Ctrl;
    })();
    exports.widgetFactory = function (context) {
        var m = context.getAngularContext().module;
        m.controller("sample.IonApiM3Ctrl", IonApiM3Ctrl);
        return {
            angularConfig: {
                relativeTemplateUrl: "widget.html"
            }
        };
    };
});
//# sourceMappingURL=widget.js.map