/// <reference path="jquery.d.ts"/>

//interface JQuery {
//	toJSON(s: any): string;
//}

interface JQueryStatic {
	toJSON(s: any): string;
}