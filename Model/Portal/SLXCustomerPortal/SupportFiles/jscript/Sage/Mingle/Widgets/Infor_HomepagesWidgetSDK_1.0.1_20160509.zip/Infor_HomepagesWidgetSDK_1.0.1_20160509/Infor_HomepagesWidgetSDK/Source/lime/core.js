var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "./lime"], function (require, exports, lm) {
    var CoreBase = (function () {
        function CoreBase(logPrefix) {
            this.logPrefix = logPrefix;
            if (!logPrefix) {
                this.logPrefix = "";
            }
        }
        CoreBase.prototype.hasError = function () {
            var state = this;
            return state.errorMessage || state.errorCode || state.error;
        };
        CoreBase.prototype.isDebug = function () {
            return lm.Log.isDebug();
        };
        CoreBase.prototype.error = function (message, ex) {
            lm.Log.error(this.logPrefix + message, ex);
        };
        CoreBase.prototype.warning = function (message) {
            lm.Log.warning(this.logPrefix + message);
        };
        CoreBase.prototype.info = function (message) {
            lm.Log.info(this.logPrefix + message);
        };
        CoreBase.prototype.debug = function (message) {
            lm.Log.debug(this.logPrefix + message);
        };
        CoreBase.prototype.logResponse = function (response) {
            this.error(response.toErrorLog());
        };
        return CoreBase;
    })();
    exports.CoreBase = CoreBase;
    var InstanceEvent = (function () {
        function InstanceEvent() {
            this.handlers = [];
        }
        InstanceEvent.prototype.on = function (handler) {
            var _this = this;
            this.handlers.push(handler);
            return function () {
                _this.off(handler);
            };
        };
        InstanceEvent.prototype.off = function (handler) {
            this.handlers = this.handlers.filter(function (h) { return h !== handler; });
        };
        InstanceEvent.prototype.raise = function (data) {
            if (this.handlers) {
                try {
                    this.handlers.slice(0).forEach(function (h) { return h(data); });
                }
                catch (e) {
                    lm.Log.error("Exception in core.raise", e);
                }
            }
        };
        InstanceEvent.prototype.clear = function () {
            this.handlers = [];
        };
        return InstanceEvent;
    })();
    exports.InstanceEvent = InstanceEvent;
    var DialogResponseCode = (function () {
        function DialogResponseCode() {
        }
        DialogResponseCode.Success = 1;
        DialogResponseCode.Fail = 2;
        return DialogResponseCode;
    })();
    exports.DialogResponseCode = DialogResponseCode;
    var OperationResponse = (function () {
        function OperationResponse(content) {
            this.id = null;
            this.content = null;
            this.errorList = null;
            this.messageList = null;
            this.content = content;
        }
        OperationResponse.prototype.hasError = function () {
            return this.errorList && (this.errorList.length > 0);
        };
        OperationResponse.prototype.hasMessage = function () {
            return this.messageList && this.messageList.length > 0;
        };
        OperationResponse.prototype.showErrorMessages = function () {
        };
        OperationResponse.prototype.toErrorLog = function () {
            if (!this.errorList) {
                return "";
            }
            var output = "";
            var listLength = this.errorList.length;
            for (var i = 0; i < listLength; i++) {
                var errorInfo = this.errorList[i];
                output += errorInfo.message + " (Error code: " + errorInfo.code + ")" + (i === listLength - 1 ? "" : ", ");
            }
            return output;
        };
        return OperationResponse;
    })();
    exports.OperationResponse = OperationResponse;
    var ResponseErrorCodes = (function () {
        function ResponseErrorCodes() {
        }
        ResponseErrorCodes.undefined = 0;
        ResponseErrorCodes.unauthorized = 401;
        ResponseErrorCodes.forbidden = 403;
        ResponseErrorCodes.notFound = 404;
        ResponseErrorCodes.timeout = 408;
        ResponseErrorCodes.unavailable = 503;
        ResponseErrorCodes.exceedsMaxSize = 1001;
        ResponseErrorCodes.tenantContextNotAvailable = 1000;
        return ResponseErrorCodes;
    })();
    exports.ResponseErrorCodes = ResponseErrorCodes;
    var Product = (function () {
        function Product() {
        }
        Product.productName = "Infor Ming.le Homepages";
        return Product;
    })();
    exports.Product = Product;
    var ErrorConstants = (function () {
        function ErrorConstants() {
        }
        ErrorConstants.generic = "errorGeneric";
        ErrorConstants.unauthorized = "errorUnauthorized";
        ErrorConstants.notFound = "errorNotFound";
        ErrorConstants.timeout = "errorTimeout";
        ErrorConstants.unavailable = "errorUnavailable";
        ErrorConstants.signout = "errorSignOut";
        ErrorConstants.exceedsMaxSize = "exceedsMaxSize";
        return ErrorConstants;
    })();
    exports.ErrorConstants = ErrorConstants;
    var MessageInfo = (function () {
        function MessageInfo() {
        }
        return MessageInfo;
    })();
    exports.MessageInfo = MessageInfo;
    var ErrorInfo = (function () {
        function ErrorInfo() {
        }
        return ErrorInfo;
    })();
    exports.ErrorInfo = ErrorInfo;
    (function (SettingType) {
        SettingType[SettingType["User"] = 0] = "User";
        SettingType[SettingType["Application"] = 1] = "Application";
    })(exports.SettingType || (exports.SettingType = {}));
    var SettingType = exports.SettingType;
    ;
    (function (AccessType) {
        AccessType[AccessType["Owner"] = 0] = "Owner";
        AccessType[AccessType["Role"] = 100] = "Role";
        AccessType[AccessType["Everyone"] = 200] = "Everyone";
    })(exports.AccessType || (exports.AccessType = {}));
    var AccessType = exports.AccessType;
    (function (AccessLevel) {
        AccessLevel[AccessLevel["View"] = 0] = "View";
        AccessLevel[AccessLevel["Edit"] = 100] = "Edit";
    })(exports.AccessLevel || (exports.AccessLevel = {}));
    var AccessLevel = exports.AccessLevel;
    var WidgetLayout = (function () {
        function WidgetLayout(column, row, columnSpan, rowSpan) {
            if (columnSpan === void 0) { columnSpan = 1; }
            if (rowSpan === void 0) { rowSpan = 1; }
            this.column = column;
            this.row = row;
            this.columnSpan = columnSpan;
            this.rowSpan = rowSpan;
        }
        WidgetLayout.isSameCell = function (a, b) {
            return a.column === b.column && a.row === b.row;
        };
        WidgetLayout.isAfter = function (a, b) {
            return a.row > b.row || (a.row === b.row && a.column > b.column);
        };
        WidgetLayout.isBefore = function (a, b) {
            return a.row < b.row || (a.row === b.row && a.column < b.column);
        };
        return WidgetLayout;
    })();
    exports.WidgetLayout = WidgetLayout;
    var WidgetType = (function () {
        function WidgetType() {
        }
        WidgetType.Inline = "inline";
        WidgetType.External = "external";
        return WidgetType;
    })();
    exports.WidgetType = WidgetType;
    (function (WidgetAccessLevel) {
        WidgetAccessLevel[WidgetAccessLevel["Disabled"] = 0] = "Disabled";
        WidgetAccessLevel[WidgetAccessLevel["View"] = 100] = "View";
        WidgetAccessLevel[WidgetAccessLevel["Configure"] = 200] = "Configure";
    })(exports.WidgetAccessLevel || (exports.WidgetAccessLevel = {}));
    var WidgetAccessLevel = exports.WidgetAccessLevel;
    var EditModes = (function () {
        function EditModes() {
        }
        EditModes.none = "none";
        EditModes.layout = "layout";
        EditModes.widget = "widget";
        EditModes.page = "page";
        EditModes.preview = "preview";
        return EditModes;
    })();
    exports.EditModes = EditModes;
    var EditSubmodes = (function () {
        function EditSubmodes() {
        }
        EditSubmodes.publish = "publish";
        EditSubmodes.republish = "republish";
        EditSubmodes.publishCopy = "publishCopy";
        return EditSubmodes;
    })();
    exports.EditSubmodes = EditSubmodes;
    var DevConfiguration = (function (_super) {
        __extends(DevConfiguration, _super);
        function DevConfiguration() {
            _super.call(this, "[DevConfiguration] ");
            this.isPersistent = true;
            this.storagePrefix = "lmDevContainer-";
        }
        DevConfiguration.prototype.initPage = function (page) {
            if (!page.id) {
                page.id = lm.CommonUtil.random();
            }
            page.changedBy = page.createdBy = "developer";
            page.changeDate = "2015-01-01T12:00:00.000Z";
            page.viewAccess = AccessType.Owner;
        };
        DevConfiguration.prototype.getKey = function () {
            return this.storagePrefix + this.id;
        };
        DevConfiguration.prototype.load = function (id) {
            this.id = id;
            var container = null;
            if (this.isPersistent) {
                try {
                    var data = localStorage.getItem(this.getKey());
                    if (data) {
                        container = JSON.parse(decodeURI(data));
                        if (container && container.pages && container.pages.length === 0) {
                            container.pages = null;
                        }
                        this.debug("Loaded container in dev mode for widget" + id);
                    }
                }
                catch (e) {
                    container = null;
                }
            }
            else {
                this.clear();
            }
            if (!container || !container.pages || !container.pages[0].data) {
                container = {
                    userId: "TEST",
                    version: "1.0",
                    pages: [
                        {
                            data: {
                                id: lm.CommonUtil.random(),
                                title: "Test Page"
                            }
                        }]
                };
            }
            this.container = container;
            return container;
        };
        DevConfiguration.prototype.clear = function () {
            this.container = null;
            this.save();
            this.debug("Cleared local dev container");
        };
        DevConfiguration.prototype.save = function () {
            try {
                var key = this.getKey();
                if (this.container) {
                    var content = encodeURI(JSON.stringify(this.container));
                    localStorage.setItem(key, content);
                    this.debug("Saved local dev container");
                }
                else {
                    localStorage.removeItem(key);
                }
            }
            catch (e) {
                this.error("Failed to save local dev container", e);
            }
        };
        return DevConfiguration;
    })(CoreBase);
    exports.DevConfiguration = DevConfiguration;
    var DevConfigurationData = (function () {
        function DevConfigurationData() {
            this.propSettings = "settings";
            this.propConfiguration = "configuration";
            this.propWidgetDefinition = "widgetDefinition";
            this.propCustomDefinition = "customDefinition";
        }
        return DevConfigurationData;
    })();
    exports.DevConfigurationData = DevConfigurationData;
    var ClientConfiguration = (function () {
        function ClientConfiguration() {
        }
        ClientConfiguration.overrideUrl = function (url) {
            ClientConfiguration.url = url;
        };
        ClientConfiguration.initialize = function (location) {
            var config = ClientConfiguration;
            if (location.host() === "localhost") {
                lm.Log.setDebug();
                config.overrideUrl("http://localhost:8081");
                config.local = true;
            }
            config.logicalId = location.search()["LogicalId"];
        };
        ClientConfiguration.getLogicalId = function () {
            return ClientConfiguration.logicalId || "lid://infor.homepages.1";
        };
        ClientConfiguration.isLocal = function () {
            return ClientConfiguration.local;
        };
        ClientConfiguration.initDevConfiguration = function (devData) {
            if (devData) {
                var dev = new DevConfiguration();
                dev.devData = devData;
                ClientConfiguration.dev = dev;
            }
        };
        ClientConfiguration.getUrl = function () {
            return ClientConfiguration.url;
        };
        ClientConfiguration.isDev = function () {
            return ClientConfiguration.dev != null;
        };
        ClientConfiguration.url = "";
        ClientConfiguration.dev = null;
        return ClientConfiguration;
    })();
    exports.ClientConfiguration = ClientConfiguration;
    var SettingsNames = (function () {
        function SettingsNames() {
        }
        SettingsNames.defaultPage = "DefaultPage";
        SettingsNames.defaultLanguage = "DefaultLanguage";
        SettingsNames.enablePageCatalog = "EnablePageCatalog";
        SettingsNames.mandatoryPages = "MandatoryPages";
        SettingsNames.enablePagePublish = "EnablePagePublish";
        SettingsNames.enablePrivatePages = "EnablePrivatePages";
        SettingsNames.maxUserPageCount = "MaxUserPageCount";
        SettingsNames.enableAddPublishedPage = "EnableAddPublishedPage";
        SettingsNames.enableDuplicatePublishedPage = "EnableDuplicatePublishedPage";
        SettingsNames.enableSelectHomepage = "EnableSelectHomepage";
        SettingsNames.enablePageExport = "EnablePageExport";
        SettingsNames.enablePageImport = "EnablePageImport";
        SettingsNames.enableWidgetPublish = "EnableWidgetPublish";
        SettingsNames.enableContentTranslation = "EnableContentTranslation";
        SettingsNames.startPage = "StartPage";
        SettingsNames.logLevel = "LogLevel";
        return SettingsNames;
    })();
    exports.SettingsNames = SettingsNames;
    var Constants = (function () {
        function Constants() {
        }
        Constants.applicationName = "Homepages";
        Constants.restRoot = "limerest";
        Constants.webRoot = "lime";
        Constants.mingleLocale = "inforCurrentLocale";
        Constants.mingleLanguage = "inforCurrentLanguage";
        Constants.mingleTimeZone = "inforTimeZone";
        Constants.mingleThemeName = "inforThemeName";
        Constants.useHttps = "usehttps";
        Constants.scheme = "scheme";
        Constants.tenantId = "tenantid";
        Constants.userid = "userid";
        Constants.language = "language";
        Constants.safeMode = "safeMode";
        Constants.groupEveryone = "HOMEPAGES-Everyone";
        Constants.configurationSettings = "settings";
        Constants.configurationProperties = "properties";
        Constants.configurationApplication = "applications";
        Constants.configurationApplicationPrefix = "application";
        Constants.configurationFrameworkPrefix = "framework";
        Constants.configurationLocalizationPrefix = "localization";
        Constants.configurationPropertyPrefix = "property";
        Constants.configurationViewPrefix = "view";
        Constants.configurationWidgetPrefix = "widget";
        Constants.configurationPrefixes = [
            Constants.configurationApplicationPrefix,
            Constants.configurationFrameworkPrefix,
            Constants.configurationLocalizationPrefix,
            Constants.configurationPropertyPrefix,
            Constants.configurationViewPrefix,
            Constants.configurationWidgetPrefix
        ];
        Constants.widgetTitleLength = 40;
        Constants.widgetDescriptionLength = 1024;
        Constants.pageTitleLength = 40;
        Constants.pageDescriptionLength = 256;
        Constants.pageArea = 0;
        Constants.widgetArea = 1;
        Constants.commonArea = 2;
        Constants.allArea = 3;
        Constants.modalPageAbout = "lmPageAbout";
        Constants.modalPagePublish = "lmPagePublish";
        Constants.modalWidgetCustomize = "lmWidgetCustomize";
        Constants.contextualActionPanelId = "lmContextualActionPanel";
        Constants.adminCacheStandardWidgets = "Standard Widgets Cache";
        Constants.adminCachePublishedWidgets = "Published Widgets Cache";
        Constants.adminCachePublishedPages = "Published Pages Cache";
        Constants.adminCacheProperties = "Properties Cache";
        Constants.adminCachePrivatePages = "Private Pages Cache";
        Constants.adminCacheRoles = "Roles Cache";
        Constants.clientCacheWidgets = "Widgets Cache";
        Constants.clientCachePages = "Pages Cache";
        Constants.cacheLifetime = 900000;
        Constants.widgetModuleDefaultName = "widget";
        Constants.sharedLimeLanguageConstants = ["ok", "cancel", "yes", "no", "refresh", "add", "save", "delete", "name", "url", "edit"];
        Constants.tagsMaxCount = 5;
        Constants.mingleWebWidgetID = "infor.mingle.web";
        Constants.settingsNameWidgetTitle = "lmWidgetTitle";
        return Constants;
    })();
    exports.Constants = Constants;
    var Templates = (function () {
        function Templates() {
        }
        Templates.autocompleteEntity = '<script type="text/html">' +
            '<li id="{{listItemId}}" {{#hasValue}} data-value="{{value}}" {{/hasValue}} role="listitem">' +
            '<a href="#" tabindex="-1">' +
            '<span class="display-value">{{& label}}</span>' +
            '<small class="lm-autocomplete-secondary lm-truncate-text">{{& info}}</small>' +
            '</a></li></script>';
        return Templates;
    })();
    exports.Templates = Templates;
    var WidgetCategory = (function () {
        function WidgetCategory() {
        }
        WidgetCategory.BusinessProcess = "businessprocess";
        WidgetCategory.Application = "application";
        WidgetCategory.Social = "social";
        WidgetCategory.Utilities = "utilities";
        WidgetCategory.BusinessIntelligence = "businessintelligence";
        WidgetCategory.All = "all";
        return WidgetCategory;
    })();
    exports.WidgetCategory = WidgetCategory;
    var OperationRequest = (function () {
        function OperationRequest() {
            this.id = null;
        }
        return OperationRequest;
    })();
    var LanguageService = (function () {
        function LanguageService(rootScope) {
            this.language = null;
            var language;
            if (typeof infor !== "undefined") {
                language = infor.lime.ResourcesKeys;
            }
            else {
                language = {};
            }
            language.format = lm.StringUtil.format;
            language.get = function (name) {
                var text = language[name];
                return text ? text : name;
            };
            this.language = language;
            rootScope["lmLang"] = language;
        }
        LanguageService.prototype.getLanguage = function () {
            return this.language;
        };
        LanguageService.prototype.get = function (name) {
            return this.language ? this.language.get(name) : name;
        };
        LanguageService.add = function (m) {
            m.service("lmLanguageService", LanguageService);
        };
        LanguageService.$inject = ["$rootScope"];
        return LanguageService;
    })();
    var UniqueError = (function () {
        function UniqueError() {
        }
        UniqueError.failedToAddMaxUserPagesReached = 11015;
        return UniqueError;
    })();
    exports.UniqueError = UniqueError;
    var EntityCategory = (function () {
        function EntityCategory() {
        }
        EntityCategory.standardWidget = 1;
        EntityCategory.publishedWidget = 2;
        EntityCategory.publishedPage = 3;
        EntityCategory.privatePage = 4;
        EntityCategory.adHocProperties = 7;
        return EntityCategory;
    })();
    exports.EntityCategory = EntityCategory;
    (function (PrincipalType) {
        PrincipalType[PrincipalType["MingleGroup"] = 0] = "MingleGroup";
        PrincipalType[PrincipalType["User"] = 1] = "User";
        PrincipalType[PrincipalType["Role"] = 2] = "Role";
    })(exports.PrincipalType || (exports.PrincipalType = {}));
    var PrincipalType = exports.PrincipalType;
    var CoreUtil = (function () {
        function CoreUtil() {
        }
        CoreUtil.getEntityArray = function (array) {
            var entityList = [];
            for (var i = 0; i < array.length; i++) {
                var item = array[i];
                var isUser = !lm.CommonUtil.isUndefined(item.userName);
                var label = isUser ? item.displayName : item.name;
                var labelInfo = isUser ? item.email : item.description;
                var value = isUser ? item.userName : item.id.toString();
                var entity = {
                    label: label,
                    value: value,
                    type: isUser ? PrincipalType.User : PrincipalType.MingleGroup,
                    info: labelInfo
                };
                entityList.push(entity);
            }
            return entityList;
        };
        return CoreUtil;
    })();
    exports.CoreUtil = CoreUtil;
    var UIUtil = (function () {
        function UIUtil() {
        }
        UIUtil.removePopupMenus = function (element) {
            var popupMenus = element.find(".btn-menu[aria-haspopup]");
            for (var i = 0; i < popupMenus.length; i++) {
                var data = $(popupMenus[i]).data("popupmenu");
                if (data) {
                    data["close"]();
                    data["destroy"]();
                }
            }
        };
        return UIUtil;
    })();
    exports.UIUtil = UIUtil;
    var HttpUtil = (function () {
        function HttpUtil() {
        }
        HttpUtil.parseQuery = function (query) {
            var match, pl = /\+/g, search = /([^&=]+)=?([^&]*)/g, decode = function (s) { return decodeURIComponent(s.replace(pl, " ")); };
            var parameters = {};
            while ((match = search.exec(query))) {
                parameters[decode(match[1])] = decode(match[2]);
            }
            return parameters;
        };
        HttpUtil.combine = function (url1, url2) {
            if (!url1) {
                return url2;
            }
            if (!url2) {
                return url1;
            }
            var end = url1.length - 1;
            if (url1.charAt(end) === '/') {
                url1 = url1.substring(0, end);
            }
            if (url2.charAt(0) === '/') {
                url2 = url2.substring(1);
            }
            return url1 + "/" + url2;
        };
        return HttpUtil;
    })();
    exports.HttpUtil = HttpUtil;
    exports.init = function (m) {
        LanguageService.add(m);
    };
});
//# sourceMappingURL=core.js.map