import lm = require("./lime");
import c = require("./core");
export declare class DialogService extends c.CoreBase implements lm.IDialogService {
    private rootScope;
    private compile;
    private q;
    private languageService;
    private language;
    static $inject: string[];
    constructor(rootScope: ng.IScope, compile: ng.ICompileService, q: ng.IQService, languageService: c.ILanguageService);
    showContextualActionPanel(template: string, parameter?: any): ng.IPromise<lm.IDialogResult>;
    show(options?: lm.IDialogOptions): ng.IPromise<lm.IDialogResult>;
    private createAndOpenModal(element, dialog, title, buttons, modalScope);
    showMessage(options: lm.IMessageDialogOptions): ng.IPromise<lm.IDialogResult>;
    showToast(options: lm.IToastOptions): void;
    copyToClipboard(options: lm.ICopyToClipboardOptions): void;
    private setDefaultButtons(defaults, deferred, hasPrimaryButton);
    private setSpecificButtons(specificButtons, deferred, dialog);
    static add(ngModule: ng.IModule): void;
}
export declare var init: (externalModule: ng.IModule, internalModule: ng.IModule) => void;
