﻿import lm = require("../../lime");
import c = require("../../core");
import s = require("../service");

class AdminSettingsCtrl extends c.CoreBase {
	private items: c.ISettingItem[];
	private areas: Object[];
	private navState: string;
	private selectedArea: Object;
	private noOfSelected: number;
	private settingIsChanged = false;
	private ruleIsChanged = false;
	private settingsGridOptions: any;
	private rulesGridOptions: any;
	private connectionsGridOptions: any;
	private refreshText = "Refresh";
	private adminTool: s.IAdminTool;
	private publicPages: c.IPage[];
	private filteredItems: c.ISettingItem[];
	private chosenSetting: c.ISettingItem = null;
	private chosenRule: c.ISettingRule = null;
	private settingsWithChangedRules: string[] = [];
	private changeRuleErrorOccurred = false;

	static $inject = ["$rootScope", "$scope", "$q", "$filter", "lmAdminContext", "lmAdminService", "lmDialogService", "lmProgressService", "uiGridConstants"];

	constructor(private rootScope: ng.IScope, public scope: ng.IScope, private q: ng.IQService, private filter: ng.IFilterService, private adminContext: s.IAdminContext,
		private adminService: s.IAdminService, private dialogService: lm.IDialogService, private progressService: c.IProgressService, private uiGridConstants: any) {
		super("[AdminSettingsCtrl] ");

		this.initGrids();

		const constants = c.Constants;
		const areas: Object[] = [
			{ name: "All", value: constants.allArea },
			{ name: "Common", value: constants.commonArea },
			{ name: "Page", value: constants.pageArea },
			{ name: "Widget", value: constants.widgetArea }
		];
		this.selectedArea = areas[0];
		this.areas = areas;
		this.selectArea();

		var self = this;
		var unsubscribeTool = rootScope.$watch("lmAdminTool", (tool: s.IAdminTool) => {
			if (tool) {
				self.init(tool);
				unsubscribeTool();
			}
		});

		var adminConstants = s.AdminConstants;
		var unsubscribe = adminService.onCachesInvalidated().on((e: c.IStringToAnyMap) => {
			var unsubscribeTab = scope.$watch(adminConstants.openTab, (tab) => {
				if (tab === adminConstants.settingsTab && e[adminConstants.parameterIncludeSettings] === true) {
					self.reload();
					unsubscribeTab();
				}
			});
		});

		scope.$on("$destroy", () => {
			unsubscribe();
		});
	}

	public reload(): void {
		var adminService = this.adminService;

		adminService.setBusy(true);
		this.adminContext.initialize().then((r: s.IAdminToolResponse) => {
			this.settingIsChanged = false;
			this.ruleIsChanged = false;
			this.settingsWithChangedRules = [];
			this.init(r.content);
			adminService.setBusy(false);
		}, (r: c.IOperationResponse) => {
			adminService.setBusy(false);
			adminService.handleError(r);
		});
	}

	/**
	 * Select Area
	 * 
	 * Sets selected area and filters settings based on it.
	 * Also filters visible settings.
	 */
	public selectArea(selectedArea?: Object): void {
		const filter = this.filter;
		const items = this.items;
		if (selectedArea) {
			this.selectedArea = selectedArea;
		}
		const area = this.selectedArea["value"];

		if (area === c.Constants.allArea) {
			this.settingsGridOptions.data = filter("lmSettingsVisibility")(filter("lmSettingsArea")(items, null));
		} else {
			this.settingsGridOptions.data = filter("lmSettingsVisibility")(filter("lmSettingsArea")(items, area));
		}
	}

	public save(): void {
		const options = <lm.IDialogOptions>{
			title: "Save",
			templateUrl: "scripts/lime/admin/templates/setting-save.html",
			cssClass: "e2e-saveSettingDialog"
		}

		var self = this;
		this.dialogService.show(options).then((r: lm.IDialogResult) => {
			if (r.button === lm.DialogButtonType.Ok) {
				self.setBusy(true);
				self.reconstructSettings();
				// Update rule(s) that has/have been changed. Each setting with a changed rule will be updated
				// When all updates are completed (or failed), update the admin tool and sync with UI
				if (self.ruleIsChanged) {
					var settingsWithChangedRules = self.settingsWithChangedRules;
					var nrOfSettingsWithChangedRules = settingsWithChangedRules.length;
					angular.forEach(settingsWithChangedRules, (itemId) => {
						var item: c.ISettingItem = this.itemByProp(self.items, "settingName", itemId);
						item.setting.rules = item.rules;
						self.adminService.updateSettingRules(item.setting).then((result: c.IOperationResponse) => {
					
							// Update the admin tool with new setting
							var savedSetting = result.content;
							var settingToUpdate = this.itemByProp(self.adminTool.settings, "settingName", savedSetting.settingName);
							settingToUpdate.rules = savedSetting.rules;

							nrOfSettingsWithChangedRules -= 1;

							// Update the UI with new admin tool data
							if (nrOfSettingsWithChangedRules === 0) {
								settingsWithChangedRules = [];
								self.ruleIsChanged = false;

								// If a setting (not including its rules and connections) has not been changed,
								// update the admin tool on the client with the current data
								// Else, push changes to the server and update the client side admin tool
								if (!self.settingIsChanged) {
									self.init(self.adminTool);
									self.setBusy(false);
								} else {
									// Update settings on server
									this.updateSettings();
								}
							}
						}, (result: c.IOperationResponse) => {
							self.showErrorMessage(result);
						});
					});
					self.settingsWithChangedRules = [];
				}
				if (self.settingIsChanged && !self.ruleIsChanged) {
					// No rule has been changed, update settings
					this.updateSettings();
				}
			}
		});
	}

	public discard(): void {
		const options = <lm.IDialogOptions>{
			title: "Discard",
			templateUrl: "scripts/lime/admin/templates/setting-discard.html"
		};
		var self = this;
		this.dialogService.show(options).then((r: lm.IDialogResult) => {
			if (r.button === lm.DialogButtonType.Ok) {
				self.settingIsChanged = false;
				self.ruleIsChanged = false;
				self.settingsWithChangedRules = [];
				self.init(self.adminTool);
			}
		});
	}

	/**
	 * Add Or Edit Rule
	 *
	 * If the set value dialog requires pages to be loaded, the function will request
	 * them and supply it to the dialog. Otherwise the dialog will be opened without 
	 * the page load.
	 */
	public addOrEditRule(rule?: c.ISettingRule): void {
		const chosenSetting = this.chosenSetting;
		const settingName = chosenSetting.setting.settingName;
		const settingNames = c.SettingsNames;

		// Set dialog options
		const dialogParam = {
			setting: chosenSetting,
			rule: <c.ISettingRule>undefined,
			userName: this.adminTool.userName,
			pages: null,
		};

		let dialogTitle = "Add Rule";
		if (!lm.CommonUtil.isUndefined(rule)) {
			dialogParam.rule = rule;
			dialogTitle = "Edit Rule";
		}
		var options = <lm.IDialogOptions>{
			title: dialogTitle,
			templateUrl: "scripts/lime/admin/templates/setting-add-edit-rule.html",
			parameter: dialogParam,
			style: "width: 750px; min-height: 400px;"
		};
		
		// Add pages to dialog parameters if needed
		if (settingName === settingNames.defaultPage ||
			settingName === settingNames.mandatoryPages ||
			settingName === settingNames.startPage) {
			// Get pages and open dialog
			this.getPages().then((r: c.IPage[]) => {
				options.parameter.pages = r;
				this.openAddEditRuleDialog(options);
			});
		} else {
			// Open dialog without pages
			this.openAddEditRuleDialog(options);
		}
	}

	/**
	 * Open Add RuleConnection Dialog
	 *
	 * Opens a dialog so the user can connect users to a rule.
	 */
	public openAddRuleConnection(isUser: boolean): void {
		const dialogParam = {
			rule: this.chosenRule,
			userName: this.adminTool.userName,
			isUser: isUser
		};
		const options = <lm.IDialogOptions>{
			title: isUser ? "Add User" : "Add Role",
			templateUrl: "scripts/lime/admin/templates/rule-add-connection.html",
			parameter: dialogParam,
			style: "min-height: 400px;"
		};

		const self = this;
		this.dialogService.show(options).then((r: lm.IDialogResult) => {
			if (r.button === lm.DialogButtonType.Ok && r.value) {
				const updateItem = this.itemByProp(self.items, "settingName", self.chosenSetting.settingName);
				const updateItemRules = updateItem.rules;
				const updateRuleIndex = this.indexByProp(updateItemRules, "sortOrder", r.value.rule.sortOrder);
				updateItemRules[updateRuleIndex] = r.value.rule;

				if (self.settingsWithChangedRules.indexOf(updateItem.settingName) === -1) {
					self.settingsWithChangedRules.push(updateItem.settingName);
				}
				self.ruleIsChanged = true;
				this.listConnections(updateItemRules[updateRuleIndex]);
			}
		});
	}

	/*
	 * Delete Connections
	 *
	 * Delets all selected connections in the grid.
	 */
	public deleteConnections(): void {
		const connections = this.scope["connectionsGridApi"].selection.getSelectedRows();
		const chosenSettingName = this.chosenSetting.settingName;
		// Get setting item
		const updateItem = this.itemByProp(this.items, "settingName", chosenSettingName);
		const updateItemRules = updateItem.rules;
		// Get index of rule
		const updateRuleIndex = this.indexByProp(updateItemRules, "sortOrder", this.chosenRule.sortOrder);

		// Delete connection(s)
		angular.forEach(connections, (connection) => {
			// Get index of connection
			const connectionIndex = this.indexByProp(updateItemRules[updateRuleIndex].ruleConnections, "name", connection.name);
			// Remove connection from setting rule
			updateItemRules[updateRuleIndex].ruleConnections.splice(connectionIndex, 1);
		});

		// Save id of changed rule
		if (this.settingsWithChangedRules.indexOf(chosenSettingName) === -1) {
			this.settingsWithChangedRules.push(chosenSettingName);
		}

		// Set flags and update view data
		this.ruleIsChanged = true;
		this.listConnections(updateItemRules[updateRuleIndex]);
	}

	/*
	 * Delete Rules
	 *
	 * Deletes all rules selected in the grid.
	 */
	public deleteRules(singleRule?: c.ISettingRule): void {
		const rules = singleRule ? [singleRule] : this.scope["rulesGridApi"].selection.getSelectedRows();
		const chosenSetting = this.chosenSetting;
		let chosenSettingRules = chosenSetting.rules;
		const self = this;
		angular.forEach(rules, (rule) => {
			// Get index by sortOrder
			const ruleIndex = self.indexByProp(chosenSettingRules, "sortOrder", rule.sortOrder);
			// Remove rule from temp wrapper
			chosenSettingRules.splice(ruleIndex, 1);
		});

		// Sort rules by sortOrder and then Update sort order of remaining rules based on this
		chosenSettingRules = lm.ArrayUtil.sortByProperty(chosenSettingRules, "sortOrder");
		chosenSettingRules.forEach((rule, index) => {
			if (rule.sortOrder !== index + 1) {
				rule.isChanged = true;
				rule.displayChangeDate = this.getLocalChangeDate();
				rule.changedByName = this.adminTool.userName;
			}
			rule.sortOrder = index + 1;
		});

		// Save id of changed rule
		if (this.settingsWithChangedRules.indexOf(chosenSetting.settingName) === -1) {
			this.settingsWithChangedRules.push(chosenSetting.settingName);
		}

		// Update number of rules for setting
		chosenSetting.noOfRules = chosenSettingRules.length;

		// Set flags and update temp view data
		this.listRules();
		this.ruleIsChanged = true;
	}

	private initGrids(): void {
		const settingNameTemplate = '<div class= "ui-grid-cell-contents"><a class="hyperlink e2e-{{row.entity.settingName}}-drilldown" ng-click="grid.appScope.ctrl.listRules(row.entity)">{{COL_FIELD}}</a></div>';
		const settingValueTemplate = '<div class="ui-grid-cell-contents e2e-{{row.entity.settingName}}-value">{{COL_FIELD}}</div>';
		const settingActionBtnTemplate = '<div class="ui-grid-cell-contents lm-center-text"><button type="button" ng-click="grid.appScope.ctrl.chosenSetting = row.entity; $event.stopPropagation();" class="btn-actions lm-transparent e2e-{{row.entity.settingName}}-actions" xi-popupmenu="grid.appScope.ctrl.menuOptions"="grid.appScope.ctrl.menuOptions"="grid.appScope.ctrl.menuOptions"><span class="audible">Actions</span>' +
			'<svg class="icon" focusable="false" aria-hidden="false"><use xlink:href="#icon-more"/></svg></button>' +
			'<ul class="popupmenu actions top"><li class="e2e-{{row.entity.settingName}}-actions-edit"><a ng-click="grid.appScope.ctrl.setSettingsValue()">Edit</a></li><li class="e2e-{{row.entity.settingName}}-actions-add"><a ng-click="grid.appScope.ctrl.addOrEditRule()">Add Rule</a></li></ul></div>';
		const settingRuleCountTemplate = '<div class= "ui-grid-cell-contents e2e-{{row.entity.settingName}}-ruleCount">{{COL_FIELD}}</div>';

		const gridConstants = this.uiGridConstants;
		this.settingsGridOptions = {
			columnDefs: [
				{
					field: "setting.label",
					name: "SettingName",
					displayName: "Setting name",
					sort: { direction: gridConstants.ASC, priority: 1 },
					filter: { condition: gridConstants.filter.CONTAINS },
					cellTemplate: settingNameTemplate,
					width: 325
				},
				{ field: "displayValue", name: "Value", enableFiltering: false, cellTemplate: settingValueTemplate },
				{ field: "changeDate", name: "ChangeDate", displayName: "Change date" },
				{ field: "changedByName", name: "ChangedBy", displayName: "Changed by" },
				{ field: "noOfRules", name: "Rules", maxWidth: 100, cellTemplate: settingRuleCountTemplate },
				{ field: "actions", name: "Actions", maxWidth: 110, cellTemplate: settingActionBtnTemplate, enableFiltering: false, enableSorting: false }],
			data: [],
			rowHeight: 48,
			enableColumnMenus: false,
			enableFiltering: true,
			enableSorting: true,
			enableRowHeaderSelection: false
		};

		const ruleNameTemplate = '<div ng-if="row.entity.sortOrder" class="ui-grid-cell-contents"><a class="hyperlink" data-e2e="{{row.entity.name}}-name" ng-click="grid.appScope.ctrl.listConnections(row.entity)">{{COL_FIELD}}</a></div>' +
			'<div ng-if="!row.entity.sortOrder" class="ui-grid-cell-contents">{{COL_FIELD}}</div>';
		const ruleValueTemplate = '<div class="ui-grid-cell-contents" data-e2e="{{row.entity.name}}-value">{{COL_FIELD}}</div>';
		const ruleAffectedTemplate = '<div class="ui-grid-cell-contents" data-e2e="{{row.entity.name}}-affected">{{COL_FIELD}}</div>';
		const ruleDateTemplate = '<div class="ui-grid-cell-contents" data-e2e="{{row.entity.name}}-date"">{{COL_FIELD}}</div>';
		const ruleChangedByTemplate = '<div class="ui-grid-cell-contents" data-e2e="{{row.entity.name}}-changedBy">{{COL_FIELD}}</div>';
		const rulePrioTemplate = '<div class="ui-grid-cell-contents" data-e2e="{{row.entity.name}}-prio">{{COL_FIELD}}</div>';
		const ruleActionBtnTemplate = '<div class="ui-grid-cell-contents lm-center-text"><button ng-hide="!row.entity.sortOrder" data-e2e="{{row.entity.name}}-actions" type="button" ng-click="grid.appScope.ctrl.chosenRule = row.entity; $event.stopPropagation();" class="btn-actions lm-transparent" xi-popupmenu="grid.appScope.ctrl.menuOptions"><span class="audible">Actions</span>' +
			'<svg class="icon" focusable="false" aria-hidden="false"><use xlink:href="#icon-more"/></svg></button>' +
			'<ul class="popupmenu actions top"><li><a ng-click="grid.appScope.ctrl.addOrEditRule(grid.appScope.ctrl.chosenRule)" data-e2e="{{row.entity.name}}-edit">Edit</a></li><li><a ng-click="grid.appScope.ctrl.deleteRules(row.entity)" data-e2e="{{row.entity.name}}-delete">Delete</a></li><li ng-show="grid.appScope.ctrl.chosenSetting.rules.length > 1" class="separator"></li>' +
			'<li ng-show="grid.appScope.ctrl.chosenRule.sortOrder !== 1"><a ng-click="grid.appScope.ctrl.moveRule(\'up\')" data-e2e="{{row.entity.name}}-moveUp">Move Up</a></li><li ng-show="grid.appScope.ctrl.chosenRule.sortOrder < grid.appScope.ctrl.chosenSetting.rules.length"><a ng-click="grid.appScope.ctrl.moveRule(\'down\')" data-e2e="{{row.entity.name}}-moveDown">Move Down</a></li></ul></div>';

		const rowTemplate = '<div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{\'disabled\': !row.entity.sortOrder }" ui-grid-cell></div>';

		const self = this;
		this.rulesGridOptions = {
			columnDefs: [
				{ field: "name", name: "RuleName", displayName: "Rule name", cellTemplate: ruleNameTemplate, minWidth: 50, maxWidth: 600 },
				{ field: "displayValue", name: "Value", cellTemplate: ruleValueTemplate, enableColumnResizing: false },
				{ field: "affectedUsers", name: "AffectedUsers", displayName: "Affected users/groups", cellTemplate: ruleAffectedTemplate, enableColumnResizing: false },
				{ field: "displayChangeDate", name: "ChangeDate", displayName: "Change date", maxWidth: 160, cellTemplate: ruleDateTemplate, enableColumnResizing: false },
				{ field: "changedByName", name: "ChangedBy", displayName: "Changed by", cellTemplate: ruleChangedByTemplate, enableColumnResizing: false },
				{
					field: "sortOrder", name: "Priority",
					sort: { direction: gridConstants.ASC, priority: 1 },
					visible: true,
					maxWidth: 110,
					cellTemplate: rulePrioTemplate,
					enableColumnResizing: false
				},
				{ field: "actions", name: "Actions", maxWidth: 110, cellTemplate: ruleActionBtnTemplate, enableColumnResizing: false }
			],
			data: [],
			rowHeight: 48,
			rowTemplate: rowTemplate,
			enableColumnMenus: false,
			enableFiltering: false,
			enableSorting: false,
			onRegisterApi: (gridApi) => {
				self.scope["rulesGridApi"] = gridApi;
				// Set rule selected flag when a row selection change occurs
				self.noOfSelected = 0;
				const gridSelection = gridApi.selection;
				const onSelection = gridSelection.on;

				onSelection.rowSelectionChanged(self.scope, () => {
					self.noOfSelected = gridSelection.getSelectedRows().length;
				});
				onSelection.rowSelectionChangedBatch(self.scope, () => {
					self.noOfSelected = gridSelection.getSelectedRows().length;
				});
			},
			isRowSelectable: (row) => {
				// Make the default rule unselectable
				if (row.entity.sortOrder) {
					return true;
				}
				return false;
			}
		};

		this.connectionsGridOptions = {
			columnDefs: [
				{
					field: "displayName", name: "UserGroupName", displayName: "User/group name",
					sort: { direction: gridConstants.ASC, priority: 1 },
					filter: { condition: gridConstants.filter.CONTAINS }
				},
				{ field: "displayChangeDate", name: "ChangeDate", displayName: "Change date" },
				{ field: "changedByName", name: "ChangedBy", displayName: "Changed by" }
			],
			data: [],
			rowHeight: 48,
			enableColumnMenus: false,
			enableSorting: true,
			enableFiltering: true,
			onRegisterApi: (gridApi) => {
				self.scope["connectionsGridApi"] = gridApi;
				// Set connection selected flag when a row selection change occurs
				self.noOfSelected = 0;
				const gridSelection = gridApi.selection;
				const onSelection = gridSelection.on;

				onSelection.rowSelectionChanged(self.scope, () => {
					self.noOfSelected = gridSelection.getSelectedRows().length;
				});
				onSelection.rowSelectionChangedBatch(self.scope, () => {
					self.noOfSelected = gridSelection.getSelectedRows().length;
				});
			}
		};
	}

	private init(adminTool?: s.IAdminTool): void {
		adminTool ? this.adminTool = adminTool : this.adminTool = this.rootScope["lmAdminTool"];
		const items = [];
		const settings = adminTool.settings;
		const settingsNames = c.SettingsNames;
		const adminService = this.adminService;
		const filter = this.filter;

		for (let i = 0; i < settings.length; i++) {
			var setting = settings[i];
			var settingName = setting.settingName;
			var value: any = angular.copy(setting.value);
			var rules = setting.rules ? angular.copy(setting.rules) : [];
			var displayValue = value;
			var itemType: string;
			var values = [];
			var changeDate: string = setting.changeDate ? filter("lmLocaleDate")(angular.copy(setting.changeDate)) : "";

			// Set display values for settings
			if (setting.values) {
				itemType = "selector";
				var valueObject = this.itemByProp(setting.values, "value", value);
				if (valueObject) {
					displayValue = valueObject.label;
				}
			} else if (setting.dataType === "boolean") {
				value = value === "true";
				itemType = "boolean";
			} else if (setting.dataType === "int") {
				itemType = "int";
			} else if (settingName === settingsNames.defaultPage) {
				itemType = settingsNames.defaultPage;
				displayValue = adminService.getPageDisplayTitle(value);
			} else if (settingName === settingsNames.mandatoryPages) {
				itemType = settingsNames.mandatoryPages;
				displayValue = adminService.getPageDisplayTitle(value);
			} else if (settingName === settingsNames.startPage) {
				itemType = settingsNames.startPage;
				displayValue = adminService.getPageDisplayTitle(value);
			} else {
				itemType = "string";
			}

			// Set display values for rules and connections
			for (let j = 0; j < rules.length; j++) {
				// Set display value
				if (itemType === "selector") {
					valueObject = this.itemByProp(setting.values, "value", rules[j].value);
					if (valueObject) {
						rules[j].displayValue = valueObject.label;
					}
				} else if (itemType === settingsNames.defaultPage || itemType === settingsNames.mandatoryPages || itemType === settingsNames.startPage) {
					rules[j].displayValue = adminService.getPageDisplayTitle(rules[j].value);
				} else {
					rules[j].displayValue = rules[j].value;
				}
				// Set value for boolean
				if (itemType === "boolean") {
					rules[j].value = rules[j].value === "true";
				}
				// Set display change date
				rules[j].displayChangeDate = filter("lmLocaleDate")(rules[j].changeDate);
				// Set number of affected users/groups
				rules[j].affectedUsers = rules[j].ruleConnections ? rules[j].ruleConnections.length : 0;
				// Set rule connections
				rules[j].ruleConnections = rules[j].ruleConnections || [];

				// Set display change date for connections
				for (let k = 0; k < rules[j].ruleConnections.length; k++) {
					rules[j].ruleConnections[k].displayChangeDate = filter("lmLocaleDate")(rules[j].ruleConnections[k].changeDate);
				}
			}

			// Wrap setting with temporary data for the view
			var item: c.ISettingItem = {
				setting: setting, // Setting as on server side
				value: value, // Current value in view
				values: values, // Possible values in view
				displayValue: displayValue, // For objects/pages display label in grid
				rules: rules, // Rules in view
				type: itemType, // Type in view
				changeDate: changeDate, // Change date in view
				changedByName: angular.copy(setting.changedByName), // Name in view
				settingName: settingName, // Never changed, used for matching (save/discard) only 
				noOfRules: rules.length
			};
			items.push(item);
		}

		this.items = items;
		this.filteredItems = items;
		var chosenSetting = this.chosenSetting;
		var chosenRule = this.chosenRule;

		if (!this.navState || this.navState === "settings") {
			this.listSettings();
		} else if (this.navState === "rules") {
			chosenSetting = this.itemByProp(items, "settingName", chosenSetting.settingName);
			this.listRules(chosenSetting);
		} else if (this.navState === "connections") {
			chosenSetting = this.itemByProp(items, "settingName", chosenSetting.settingName);
			chosenRule = this.itemByProp(chosenSetting.rules, "sortOrder", chosenRule.sortOrder);
			if (chosenRule) {
				this.chosenSetting = chosenSetting;
				this.listConnections(chosenRule);
			} else {
				this.listRules(chosenSetting);
			}
		}
	}

	/**
	 * Update Settings
	 *
	 * Makes an update request and updates any changed settings on client and server.
	 */
	private updateSettings(): void {
		var settings = this.adminTool.settings;
		// Place all edited settings in an admin tool copy
		var editedSettings = angular.copy(this.adminTool);
		editedSettings.settings = [];
		angular.forEach(settings, (item: c.ISetting) => {
			if (item.isChanged) {
				editedSettings.settings.push(item);
			}
		});

		// Make update request
		this.adminService.updateTool(editedSettings).then((response) => {
			// Update settings on client side
			angular.forEach(response.content, (setting: c.ISetting) => {
				var settingToUpdate = this.itemByProp(settings, "settingName", setting.settingName);
				var settingIndex = settings.indexOf(settingToUpdate);
				settings[settingIndex] = setting;
				settings[settingIndex].isChanged = false;
			});
			this.init(this.adminTool);
			this.settingIsChanged = false;
			this.setBusy(false);
		}, (r: c.IOperationResponse) => {
			this.showErrorMessage(r);
		});

	}

	private reconstructSettings(): void {
		const settings = this.adminTool.settings;
		for (let i = 0; i < settings.length; i++) {
			const setting = settings[i];
			const item = this.items[i];

			if (item.setting.isChanged) {
				let value: string;
				if (item.type === "boolean") {
					value = item.value ? "true" : "false";
				} else {
					value = item.value;
				}

				setting.value = value;
				setting.isChanged = true;
			}
		}
	}

	/**
	 * Get Pages
	 *
	 * Requests and returns pages or returns already loaded pages.
	 */
	private getPages(): ng.IPromise<c.IPage[]> {
		var adminService = this.adminService;
		var defer = this.q.defer();
		// Request pages or use already loaded ones...
		this.setBusy(true);
		adminService.listPublishedPages(false).then((r: c.IPageListResponse) => {
			// Pages loaded, resolve promise
			var publishedPages = r.content;
			adminService.publishedPages = publishedPages;
			defer.resolve(publishedPages);
			this.setBusy(false);
		}, (r: c.IOperationResponse) => {
			// Pages could not be loaded, show error message and reject promise
			if (r.hasMessage()) {
				lm.Log.error(r.toErrorLog());
			}
			this.setBusy(false);
			this.dialogService.showMessage({
				title: "Could not load pages",
				message: "The pages could not be loaded and therefore no value can be set."
			});
			defer.reject();
		});
		return defer.promise;
	}

	/**
	 * Set Settings Value
	 *
	 * If the set value dialog requires pages to be loaded, the function will request
	 * them and supply it to the dialog. Otherwise the dialog will be opened without 
	 * the page load.
	 */
	private setSettingsValue(): void {
		const chosenSetting = this.chosenSetting;
		const settingName = chosenSetting.setting.settingName;
		const settingNames = c.SettingsNames;
		var options = <lm.IDialogOptions>{
			title: "Edit Setting",
			templateUrl: "scripts/lime/admin/templates/setting-set-value.html",
			style: settingName === "MandatoryPages" ? "min-height: 400px;" : "",
			parameter: {
				setting: chosenSetting,
				userName: this.adminTool.userName,
				pages: null,
				widgets: null
			}
		};

		// Open dialog with or without pages/widgets
		if (settingName === settingNames.defaultPage ||
			settingName === settingNames.mandatoryPages ||
			settingName === settingNames.startPage) {
			// Get pages and open dialog with them provided
			this.getPages().then((r: c.IPage[]) => {
				options.parameter.pages = r;
				this.openSetSettingDialog(options);
			});
		} else {
			// Open dialog without pages
			this.openSetSettingDialog(options);
		}
	}

	/**
	 * Open Set Setting Dialog
	 *
	 * Opens a dialog so the user can set a value of a setting.
	 */
	private openSetSettingDialog(options: lm.IDialogOptions): void {
		var updateItemIndex: number;
		var self = this;
		this.dialogService.show(options).then((r: lm.IDialogResult) => {
			if (r.button === lm.DialogButtonType.Ok && r.value) {
				const setting = angular.copy(r.value);
				if (setting.type === c.SettingsNames.mandatoryPages) {
					setting.value = setting.value.map((page: c.IPage) => {
						return page.data.id;
					}).join(",");
					setting.displayValue = self.adminService.getPageDisplayTitle(setting.value);
				}
				// Update items
				updateItemIndex = self.indexByProp(self.items, "settingName", self.chosenSetting.settingName);
				self.items[updateItemIndex] = setting;

				// Update filtered items
				const gridOptionsData = self.settingsGridOptions.data;
				updateItemIndex = self.indexByProp(gridOptionsData, "settingName", self.chosenSetting.settingName);
				gridOptionsData[updateItemIndex] = setting;

				self.settingIsChanged = true;
			}
		});
	}

	/**
	 * Open Add Edit Rule Dialog
	 *
	 * Opens a dialog so the user can set rule values and connect users.
	 */
	private openAddEditRuleDialog(options: lm.IDialogOptions): void {
		var self = this;
		this.dialogService.show(options).then((r: lm.IDialogResult) => {
			if (r.button === lm.DialogButtonType.Ok && r.value) {
				const updateItem = this.itemByProp(self.items, "settingName", self.chosenSetting.settingName);
				updateItem.rules = r.value.rules;
				updateItem.noOfRules = r.value.rules.length;

				if (self.settingsWithChangedRules.indexOf(updateItem.settingName) === -1) {
					self.settingsWithChangedRules.push(updateItem.settingName);
				}
				if (self.navState === "rules") {
					self.listRules();
				}

				self.ruleIsChanged = true;
			}
		});
	}

	private listSettings(): void {
		this.navState = "settings";
		this.chosenSetting = null;
		this.chosenRule = null;
		this.selectArea();
	}

	private listRules(setting?: c.ISettingItem): void {
		this.navState = "rules";
		this.scope["rulesGridApi"].selection.clearSelectedRows();
		if (!lm.CommonUtil.isUndefined(setting)) {
			this.chosenSetting = setting;
		}
		const chosenSetting = this.chosenSetting;
		this.rulesGridOptions.data = angular.copy(chosenSetting.rules);

		this.rulesGridOptions.data.push({
			name: chosenSetting.setting.label,
			displayValue: chosenSetting.displayValue,
			affectedUsers: "All",
			displayChangeDate: chosenSetting.changeDate,
			changedByName: chosenSetting.setting.changedByName
		});
		this.noOfSelected = 0;
	}

	private listConnections(rule: c.ISettingRule): void {
		this.navState = "connections";
		this.scope["connectionsGridApi"].selection.clearSelectedRows();
		this.chosenRule = rule;
		rule.affectedUsers = rule.ruleConnections.length;
		this.connectionsGridOptions.data = angular.copy(rule.ruleConnections);
		this.noOfSelected = 0;
	}

	private moveRule(direction: string): void {
		let ruleToMoveUp;
		let ruleToMoveDown;
		const chosenSetting = this.chosenSetting;
		const chosenSettingRules = chosenSetting.rules;
		const chosenRuleSortOrder = this.chosenRule.sortOrder;
		if (direction === "up") {
			ruleToMoveUp = this.itemByProp(chosenSettingRules, "sortOrder", chosenRuleSortOrder);
			ruleToMoveDown = this.itemByProp(chosenSettingRules, "sortOrder", chosenRuleSortOrder - 1);
		} else if (direction === "down") {
			ruleToMoveDown = this.itemByProp(chosenSettingRules, "sortOrder", chosenRuleSortOrder);
			ruleToMoveUp = this.itemByProp(chosenSettingRules, "sortOrder", chosenRuleSortOrder + 1);
		} else {
			return;
		}

		ruleToMoveUp.sortOrder -= 1;
		ruleToMoveUp.isChanged = true;
		ruleToMoveUp.displayChangeDate = this.getLocalChangeDate();
		ruleToMoveUp.changedByName = this.adminTool.userName;
		ruleToMoveDown.sortOrder += 1;
		ruleToMoveDown.isChanged = true;
		ruleToMoveDown.displayChangeDate = this.getLocalChangeDate();
		ruleToMoveDown.changedByName = this.adminTool.userName;
		if (this.settingsWithChangedRules.indexOf(chosenSetting.settingName) === -1) {
			this.settingsWithChangedRules.push(chosenSetting.settingName);
		}
		this.ruleIsChanged = true;
		this.listRules();
	}

	private setBusy(isBusy: boolean): void {
		this.progressService.setBusy(isBusy);
	}

	private itemByProp(array: any[], name: string, value: any): any {
		return lm.ArrayUtil.itemByProperty(array, name, value);
	}

	private indexByProp(array: any[], name: string, value: any): number {
		return lm.ArrayUtil.indexByProperty(array, name, value);
	}

	private getLocalChangeDate(): string {
		return lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*";
	}

	/*
	 * Show Error Message
	 *
	 * Opens a modal with a generic error message and logs any response errors.
	 */
	private showErrorMessage(r: c.IOperationResponse): void {
		const options: lm.IMessageDialogOptions = {
			title: "Could not update settings",
			message: "An error occured while updating the settings.",
			standardButtons: lm.StandardDialogButtons.Ok
		}
		this.dialogService.showMessage(options);
		this.setBusy(false);

		if (r.hasMessage()) {
			lm.Log.error("[Admin Settings] " + r.toErrorLog());
		}
	}

	static add(m: ng.IModule) {
		m.controller("lmAdminSettingsCtrl", AdminSettingsCtrl);
	}
}

export var init = (m: ng.IModule) => {
	AdminSettingsCtrl.add(m);
}