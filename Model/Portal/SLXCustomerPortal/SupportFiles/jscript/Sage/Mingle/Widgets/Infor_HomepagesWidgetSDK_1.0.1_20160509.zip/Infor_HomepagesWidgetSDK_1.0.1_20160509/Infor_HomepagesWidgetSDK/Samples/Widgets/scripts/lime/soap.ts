﻿
// TODO Typings of maps

export interface ISoapElement {
	getName(): string;
	getValue(): any;
	setValue(value: any): ISoapElement;
	getAttribute(name: string): string;
	setAttribute(name: string, value: string): void;
	getAttributes(): any;
	addNamespace(name: string, url: string): void;
	appendChild(obj: any): void;
	newChild(name: string): ISoapElement;
	addParameter(name: string, value: string): ISoapElement;
	getChildren(): any;
	hasChildren(): boolean;
	find(name: string): ISoapElement;
	toString(): string;
}

export interface ISoapEnvelope {
	addAttribute(name: string, value: any): void;
	addNamespace(name: string, uri: string): void;
	addHeader(element: ISoapElement): void;
	addBody(element: ISoapElement): void;
	toString(): string;
}

export interface ISoapRequest {

}

export interface ISoapResponse {

}

export interface ISoapService {
	execute(request: ISoapRequest): ng.IPromise<ISoapResponse>;
}

export interface ISoapVersion {
	contentType: string;
	namespaceUri: string;
}

export class SoapConstants {
	public static xml = '<?xml version="1.0" encoding="UTF-8"?>';
	public static xsi = "http://www.w3.org/2001/XMLSchema-instance";
	public static xsd = "http://www.w3.org/2001/XMLSchema";

	public static soap11: ISoapVersion = <ISoapVersion>{
		contentType: "text/xml",
		namespaceUri: "http://schemas.xmlsoap.org/soap/envelope/"
	};

	public static soap12: ISoapVersion = <ISoapVersion>{
		contentType: "application/soap+xml",
		namespaceUri: "http://www.w3.org/2003/05/soap-envelope"
	};

	public static entityMap = {
		"<": "&lt;",
		">": "&gt;",
		"&": "&amp;",
		"\"": "&quot;",
		"'": "&apos;"
	};
}

export class SoapElement implements ISoapElement {
	public className = "SoapElement";
	private parent: ISoapElement = null;
	private attributes: any = {};
	private namespaces: any = {};
	private children: any[] = [];
	private value: any = undefined;

	constructor(private name: string) {
	}

	public getName(): string {
		return this.name;
	}

	public getValue(): any {
		if (this.getAttribute("xsi:nil") == "true") {
			return null;
		}
		return this.value;
	}

	public setValue(value: any): ISoapElement {
		if (value == null) {
			this.setAttribute("xsi:nil", "true");
		} else {
			this.value = value;
		}
		return this;
	}

	public getAttributes(): any {
		return this.attributes;
	}

	public getAttribute(name: string): string {
		return this.attributes[name];
	}

	public setAttribute(name: string, value: string) {
		if (!!value || value === "") {
			this.attributes[name] = value;
		}
	}

	public addNamespace(name: string, url: string): void {
		this.namespaces[name] = url;
	}

	public appendChild(child: any): void {
		child.parent = this;
		this.children.push(child);
	}

	public newChild(name: string): ISoapElement {
		var child = new SoapElement(name);
		this.appendChild(child);
		return this;
	}

	public addParameter(name: string, value: any): ISoapElement {
		var child = new SoapElement(name);
		child.setValue(value);
		this.appendChild(child);
		return this;
	}

	public getChildren(): any {
		return this.children;
	}

	public hasChildren(): boolean {
		return this.children.length > 0;
	}

	public find(name: string): ISoapElement {
		if (this.name === name) {
			return this;
		}
		var children = this.children;
		for (var i = 0; i < children.length; i++) {
			var result = children[i].find(name);
			if (result) {
				return result;
			}
		}
		return null;
	}

	public toString(): string {
		var out = [];

		out.push('<' + this.name);
		
		// Namespaces
		for (var name in this.namespaces) {
			out.push(' xmlns:' + name + '="' + this.namespaces[name] + '"');
		}

		// Node Attributes
		for (var attr in this.attributes) {
			if (typeof (this.attributes[attr]) === "string") {
				out.push(' ' + attr + '="' + this.attributes[attr] + '"');
			}
		}
		out.push(">");

		// Node children
		if (this.hasChildren()) {
			for (var cPos in this.children) {
				var cObj = this.children[cPos];
				if ((typeof (cObj) === "object") && (cObj.className === this.className)) {
					out.push(cObj.toString());
				}
			}
		}

		// Node Value
		if (this.value !== undefined) {
			var encodedValue = null;
			var typeOf = typeof (this.value);
			if (typeOf === "string") {
				encodedValue = this.value.match(/<!\[CDATA\[.*?\]\]>/) ?
					this.value :
					this.value.replace(/[<>&"']/g,(ch) => {
						return SoapConstants.entityMap[ch];
					});
			} else if (typeOf === "number") {
				encodedValue = this.value.toString();
			}
			if (encodedValue != null) {
				out.push(encodedValue);
			}
		}

		// Close Tag
		out.push("</" + this.name + ">");
		return out.join("");
	}
}

export class SoapEnvelope implements ISoapEnvelope {
	public className = "SoapEnvelope";

	private prefix = "soap";
	private soapVersion: ISoapVersion = null;
	private attributes = {};
	private headers: ISoapElement[] = [];
	private bodies: ISoapElement[] = [];

	constructor(element: ISoapElement) {
		// Soap namespace prefix
		var parts = element.getName().split(":");
		if (parts[1] === "Envelope" || parts[1] === "Body") {
			this.prefix = parts[0];
			if (element.getAttribute("xmlns:" + this.prefix) === SoapConstants.soap12.namespaceUri) {
				this.soapVersion = SoapConstants.soap12;
			} else {
				this.soapVersion = SoapConstants.soap11;
			}

			// Envelope
			var envelope = element.find(this.prefix + ":Envelope");
			if (envelope) {
				var attributes = envelope.getAttributes();
				if (attributes) {
					for (var i in attributes) {
						this.addAttribute(i, attributes[i]);
					}
				}
			}

			var children;

			// Headers
			var header = element.find(this.prefix + ":Header");
			if (header) {
				children = header.getChildren();
				for (var j = 0; j < children.length; j++) {
					this.addHeader(children[j]);
				}
			}

			// Body
			var body = element.find(this.prefix + ":Body");
			if (body) {
				children = body.getChildren();
				for (var k = 0; k < children.length; k++) {
					this.addBody(children[k]);
				}
			} else {
				children = element.getChildren();
				for (var l = 0; l < children.length; l++) {
					this.addBody(children[l]);
				}
			}
		} else {
			// Data element
			this.addBody(element);
		}
	}

	public addAttribute(name: string, value: any): void {
		this.attributes[name] = value;
	}

	public addNamespace(name: string, uri: string): void {
		this.addAttribute("xmlns:" + name, uri);
	}

	public addHeader(element: ISoapElement): void {
		this.headers.push(element);
	}

	public addBody(element: ISoapElement): void {
		this.bodies.push(element);
	}

	public toString(): string {
		var element = new SoapElement(this.prefix + ":Envelope");

		// Add attributes
		for (var name in this.attributes) {
			element.setAttribute(name, this.attributes[name]);
		}

		// Add headers
		if (this.headers.length > 0) {
			var soapHeader = element.newChild(this.prefix + ":Header");
			for (var i = 0; i < this.headers.length; i++) {
				soapHeader.appendChild(this.headers[i]);
			}
		}

		// Add bodies
		if (this.bodies.length > 0) {
			var soapBody = element.newChild(this.prefix + ":Body");
			for (var j = 0; j < this.bodies.length; j++) {
				soapBody.appendChild(this.bodies[j]);
			}
		}

		// Add namespaces
		if (!element.getAttribute("xmlns:" + this.prefix)) {
			element.addNamespace(this.prefix, this.soapVersion.namespaceUri);
		}
		if (!element.getAttribute("xmlns:xsi")) {
			element.addNamespace("xsi", SoapConstants.xsi);
		}
		if (!element.getAttribute("xmlns:xsd")) {
			element.addNamespace("xsd", SoapConstants.xsd);
		}

		return SoapConstants.xml + element.toString();
	}
}