﻿/// <reference path="../typings/requirejs/require.d.ts" />
/// <reference path="../typings/angularjs/angular.d.ts" />

infor.lime.requireFunction = require;
infor.lime.requireConfig = {
	waitSeconds: 180,
	baseUrl: "",
	urlArgs: "",
	paths: {
		"angular": "scripts/vendor/angular.min",
		"sortable": "scripts/vendor/sortable",
		"sohoxi": "scripts/xi/sohoxi-angular"
	},
	shim: {
		"angular": { exports: "angular" },
		"sortable": ["angular"],
		"sohoxi": ["angular"]
	},
	map: {
		'*': {
			"lime": "scripts/lime/lime"
		}
	}
};

require.config(infor.lime.requireConfig);

require(["angular", "sortable", "sohoxi", "scripts/lime/module"],
	(angular: ng.IAngularStatic) => {
		$(() => {
			angular.bootstrap(document, ["sohoxi", "lime", "lime.internal"]);
		});
	});