var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "./lime", "./core"], function (require, exports, lm, c) {
    var ProgressService = (function () {
        function ProgressService(rootScope) {
            this.rootScope = rootScope;
        }
        ProgressService.prototype.isBusy = function () {
            return this.rootScope["lmBusy"] ? true : false;
        };
        ProgressService.prototype.setBusy = function (isBusy) {
            this.rootScope["lmBusy"] = isBusy;
        };
        ProgressService.add = function (m) {
            m.service("lmProgressService", ProgressService);
        };
        ProgressService.$inject = ["$rootScope"];
        return ProgressService;
    })();
    var DataService = (function (_super) {
        __extends(DataService, _super);
        function DataService(http, q, timeout, progressService, dialogService, languageService) {
            _super.call(this, "[DataService] ");
            this.http = http;
            this.q = q;
            this.timeout = timeout;
            this.progressService = progressService;
            this.dialogService = dialogService;
            this.languageService = languageService;
            this.language = "en-US";
            this.pingInterval = -1;
            this.isExecuting = false;
            this.timestamp = Date.now();
        }
        DataService.prototype.checkPing = function () {
            var _this = this;
            var diff = Date.now() - this.timestamp;
            if (!this.isExecuting && diff >= this.pingInterval) {
                this.executePost("/common/ping", {}).then(function () {
                    _this.debug("Pinged server.");
                }, function () {
                    _this.warning("Failed to ping server.");
                });
            }
        };
        DataService.prototype.done = function () {
            this.isExecuting = false;
            this.timestamp = Date.now();
        };
        DataService.prototype.getUrl = function (path) {
            if (path) {
                return this.getBaseUrl() + "/" + c.Constants.restRoot + "/" + path;
            }
            return this.getBaseUrl() + "/" + c.Constants.restRoot + "/";
        };
        DataService.prototype.setLanguage = function (language) {
            this.language = language;
        };
        DataService.prototype.startPing = function (pingInterval) {
            var _this = this;
            if (pingInterval > 0 && this.pingInterval <= 0) {
                this.pingInterval = pingInterval;
                var checkInterval = Math.round((pingInterval / 4) * 60 * 1000);
                setInterval(function () { _this.checkPing(); }, checkInterval);
            }
        };
        DataService.prototype.overrideUrl = function (url) {
            this._overrideUrl = url;
        };
        DataService.prototype.upload = function (operationUrl, operation, files, formFields) {
            var _this = this;
            var deferred = this.q.defer();
            var url = this.getBaseUrl() + "/lime/upload" + operationUrl;
            var formData = new FormData();
            formData.append("operation", operation);
            for (var key in formFields) {
                formData.append(key, formFields[key]);
            }
            for (var i = 0; i < files.length; i++) {
                formData.append("datafile", files[i]);
            }
            var params = {
                withCredentials: true,
                headers: { "Content-Type": undefined },
                transformRequest: angular.identity
            };
            this.http.post(url, formData, params).then(function (httpResponse) {
                try {
                    var response = new c.OperationResponse();
                    angular.copy(httpResponse.data, response);
                    if (response.hasError()) {
                        _this.debug("has errors " + httpResponse.data);
                        deferred.reject(response);
                    }
                    else {
                        _this.debug("completed " + httpResponse.data);
                        deferred.resolve(response);
                    }
                }
                catch (e) {
                    _this.error("Failed to parse response for " + url);
                    var errorResponse = new c.OperationResponse();
                    var errorInfo = new c.ErrorInfo();
                    errorInfo.error = e;
                    errorInfo.code = httpResponse.status;
                    errorResponse.errorList = [errorInfo];
                    deferred.reject(errorResponse);
                }
            }, function (httpResponse) {
                var errorResponse = new c.OperationResponse();
                var errorInfo = new c.ErrorInfo();
                errorInfo.message = "The action could not be performed.";
                errorInfo.code = httpResponse.status;
                errorResponse.errorList = [errorInfo];
                _this.error("Failed to call " + url + " Response: " + angular.toJson(httpResponse));
                deferred.reject(errorResponse);
            });
            return deferred.promise;
        };
        DataService.prototype.handleError = function (response, message) {
            var options = {
                title: c.Constants.applicationName,
                standardButtons: lm.StandardDialogButtons.Ok,
                message: ""
            };
            var addAdminMessage = true;
            if (response && response.errorList[0].code) {
                var id;
                var errorConstants = c.ErrorConstants;
                switch (response.errorList[0].code) {
                    case c.ResponseErrorCodes.unauthorized:
                        id = errorConstants.unauthorized;
                        break;
                    case c.ResponseErrorCodes.forbidden:
                        id = errorConstants.unauthorized;
                        break;
                    case c.ResponseErrorCodes.notFound:
                        id = errorConstants.notFound;
                        break;
                    case c.ResponseErrorCodes.timeout:
                        id = errorConstants.timeout;
                        break;
                    case c.ResponseErrorCodes.unavailable:
                        id = errorConstants.unavailable;
                        break;
                    case c.ResponseErrorCodes.exceedsMaxSize:
                        id = errorConstants.exceedsMaxSize;
                        addAdminMessage = false;
                        break;
                    case c.ResponseErrorCodes.undefined:
                        id = c.ErrorConstants.signout;
                        break;
                    default:
                        id = errorConstants.generic;
                        break;
                }
                if (message) {
                    options.message = message;
                }
                else {
                    var genericMessage = this.getMessage(id);
                    options.message = addAdminMessage ? genericMessage + " " + this.getMessage("contactAdminRetry") : genericMessage;
                }
            }
            else if (message) {
                options.message = message;
            }
            else {
                var isSessionRedirect = response.errorHttpCode === c.ResponseErrorCodes.undefined.toString();
                var constant = isSessionRedirect ? c.ErrorConstants.signout : c.ErrorConstants.generic;
                options.message = this.getMessage(constant);
            }
            if (response.hasMessage()) {
                lm.Log.error(response.toErrorLog());
            }
            this.dialogService.showMessage(options);
        };
        DataService.prototype.executeGet = function (resource, params) {
            return this.execute(resource, "GET", null, params);
        };
        DataService.prototype.executePost = function (resource, request, params) {
            return this.execute(resource, "POST", request, params);
        };
        DataService.prototype.execute = function (resource, type, request, params) {
            var deferred = this.q.defer();
            var url = this.getBaseUrl() + "/" + c.Constants.restRoot + resource;
            this.debug("Executing url " + url);
            var method = "POST";
            if (type === "GET") {
                method = "GET";
            }
            if (request) {
                request["language"] = this.language;
                request["id"] = lm.CommonUtil.random();
            }
            var requestConfig = { method: method, url: url, data: request, params: params, cache: false };
            this.executeHttp(deferred, requestConfig);
            return deferred.promise;
        };
        DataService.prototype.executeHttp = function (deferred, requestConfig) {
            var _this = this;
            this.isExecuting = true;
            this.http(requestConfig).then(function (httpResponse) {
                try {
                    _this.done();
                    var response = new c.OperationResponse();
                    angular.copy(httpResponse.data, response);
                    if (response.hasError()) {
                        _this.debug("has errors " + httpResponse.data);
                        deferred.reject(response);
                    }
                    else {
                        _this.debug("completed " + httpResponse.data);
                        deferred.resolve(response);
                    }
                }
                catch (e) {
                    var message = "Failed to parse response for " + requestConfig.url;
                    _this.error(message);
                    deferred.reject(_this.getErrorResponse(httpResponse, message, e));
                }
            }, function (httpResponse) {
                _this.done();
                _this.error("Failed to call " + requestConfig.url + " Response: " + angular.toJson(httpResponse));
                var errorResponse = _this.getErrorResponse(httpResponse, "The action could not be performed.", null);
                errorResponse.errorHttpCode = httpResponse.status.toString();
                deferred.reject(errorResponse);
            });
        };
        DataService.prototype.getErrorResponse = function (httpResponse, message, ex) {
            var errorResponse = new c.OperationResponse();
            var errorInfo = new c.ErrorInfo();
            errorInfo.message = message;
            errorInfo.error = ex;
            errorInfo.code = httpResponse.status;
            errorResponse.errorList = [errorInfo];
            return errorResponse;
        };
        DataService.prototype.getMessage = function (id) {
            var message = this.languageService.get(id);
            return message || id;
        };
        DataService.prototype.getBaseUrl = function () {
            return (this._overrideUrl ? this._overrideUrl : c.ClientConfiguration.getUrl());
        };
        DataService.add = function (ngModule) {
            ngModule.service("lmDataService", DataService);
        };
        DataService.$inject = ["$http", "$q", "$timeout", "lmProgressService", "lmDialogService", "lmLanguageService"];
        return DataService;
    })(c.CoreBase);
    var CommonDataService = (function (_super) {
        __extends(CommonDataService, _super);
        function CommonDataService(dataService, q) {
            _super.call(this, "[CommonDataService] ");
            this.dataService = dataService;
            this.q = q;
        }
        CommonDataService.prototype.searchUsers = function (query) {
            return this.dataService.executePost("/user/search", { content: query });
        };
        CommonDataService.prototype.searchGroups = function (query) {
            return this.dataService.executePost("/group/search", { content: query });
        };
        CommonDataService.prototype.searchEntities = function (query) {
            var deferredUsers = jQuery.Deferred();
            var deferredGroups = jQuery.Deferred();
            var deferredEntities = this.q.defer();
            $.when(deferredUsers, deferredGroups).then(function (users, groups) {
                if (users && groups) {
                    var list = users.concat(groups);
                    deferredEntities.resolve({ content: list });
                }
            }, function () {
                deferredEntities.reject({});
            });
            this.searchUsers(query).then(function (response) {
                deferredUsers.resolve(c.CoreUtil.getEntityArray(response.content));
            });
            this.searchGroups(query).then(function (response) {
                deferredGroups.resolve(c.CoreUtil.getEntityArray(response.content));
            });
            return deferredEntities.promise;
        };
        CommonDataService.prototype.listBookmarks = function () {
            return this.dataService.executePost("/user/bookmark/list", { content: null });
        };
        CommonDataService.prototype.listGroups = function () {
            return this.dataService.executePost("/group/list", { content: null });
        };
        CommonDataService.prototype.listLanguages = function () {
            return this.dataService.executePost("/common/language/list", { content: null });
        };
        CommonDataService.prototype.getApplication = function (logicalIdPrefix) {
            return this.dataService.executePost("/common/application", { content: logicalIdPrefix });
        };
        CommonDataService.prototype.handleError = function (response, message) {
            if (!message) {
                this.dataService.handleError(response);
            }
            else {
                this.dataService.handleError(response, message);
            }
        };
        CommonDataService.add = function (ngModule) {
            ngModule.service("lmCommonDataService", CommonDataService);
        };
        CommonDataService.$inject = ["lmDataService", "$q"];
        return CommonDataService;
    })(c.CoreBase);
    var Dialog = (function () {
        function Dialog(deferred) {
            this.deferred = deferred;
            this.canClose = false;
        }
        Dialog.prototype.resolve = function () {
            var modal = this.modal;
            if (modal) {
                modal.remove();
                this.modal = null;
            }
            var result = this.result || {};
            this.deferred.resolve(result);
        };
        Dialog.prototype.init = function (modal) {
            var _this = this;
            this.modal = modal;
            modal.one("beforeclose", function () {
                var closing = _this.closing;
                if (closing) {
                    var e = { dialog: _this };
                    closing(e);
                    return e.cancel ? false : true;
                }
                else {
                    return _this.canClose;
                }
            });
            modal.one("afterclose", function () {
                var closed = _this.closed;
                if (closed) {
                    var e = { dialog: _this };
                    closed(e);
                }
                _this.resolve();
            });
            modal.one("open", function () {
                var opened = _this.opened;
                if (opened) {
                    var e = { dialog: _this };
                    opened(e);
                }
            });
        };
        Dialog.prototype.close = function (result) {
            this.canClose = true;
            if (result) {
                this.result = result;
            }
            var modal = this.modal;
            if (modal) {
                modal.modal("close");
            }
        };
        return Dialog;
    })();
    var DialogService = (function (_super) {
        __extends(DialogService, _super);
        function DialogService(rootScope, compile, q, languageService) {
            _super.call(this, "[DialogService] ");
            this.rootScope = rootScope;
            this.compile = compile;
            this.q = q;
            this.languageService = languageService;
            this.language = languageService.getLanguage();
        }
        DialogService.prototype.showContextualActionPanel = function (template, parameter) {
            var deferred = this.q.defer();
            var container = $("<div class='lm-display-none' id='" + c.Constants.contextualActionPanelId + "'></div>");
            var body = $("body");
            body.append(container);
            var modalScope = this.rootScope.$new(true);
            modalScope["lmLang"] = this.rootScope["lmLang"];
            modalScope["lmCallback"] = parameter;
            var cap = this.compile($(template))(modalScope);
            cap.insertAfter(container);
            var unsubscribe = modalScope.$on('$includeContentLoaded', function () {
                unsubscribe();
                var element = $(".contextual-action-panel");
                container["contextualactionpanel"]({ trigger: "immediate" });
                modalScope["lmDialog"] = container;
                element.one("beforeclose", function () {
                    element.find("img, svg, a, span").remove();
                });
                element.one("afterclose", function () {
                    modalScope.$destroy();
                    container.remove();
                    deferred.resolve();
                });
            });
            return deferred.promise;
        };
        DialogService.prototype.show = function (options) {
            var _this = this;
            var deferred = this.q.defer();
            var title = null;
            if (options) {
                title = options.title;
            }
            if (!title) {
                title = "";
            }
            var dialog = new Dialog(deferred);
            var modalScope = (options.scope || this.rootScope).$new();
            if (options && options.parameter) {
                dialog.parameter = options.parameter;
            }
            modalScope["lmDialog"] = dialog;
            var contentTemplate = options.template;
            if (!contentTemplate) {
                var url = options.templateUrl;
                if (!url) {
                    throw "One of the template and templateUrl properties must be set";
                }
                contentTemplate = "<div ng-include=\"'" + url + "'\"></div>";
            }
            var style = options.style || "";
            var css = options.cssClass || "";
            var id = options.id || lm.CommonUtil.random(8);
            var template = '<div class="modal lm-scroll-no-y ' + css + '" id="' + id + '" style="' + style + '">' +
                '<div class="modal-content"><div class="modal-header"></div><div class="modal-body">' + contentTemplate + '</div>';
            var element = $(template);
            var headerElement = element.find(".modal-header");
            if (options.actionPanel) {
                element.removeClass().addClass("contextual-action-panel modal " + css);
                headerElement.append($('<div class="toolbar"><div class="title">' + title + '</div></div>'));
            }
            else {
                headerElement.append($('<h1 class="modal-title">' + title + '<h1>'));
            }
            $("body").append(this.compile(element)(modalScope));
            var buttons = null;
            if (options.buttons) {
                buttons = this.setSpecificButtons(options.buttons, deferred, dialog);
            }
            if (options.template && options.template.indexOf("ng-include") === -1) {
                this.createAndOpenModal(element, dialog, title, buttons, modalScope);
            }
            else {
                var unsubscribe = modalScope.$on('$includeContentLoaded', function () {
                    _this.createAndOpenModal(element, dialog, title, buttons, modalScope);
                    unsubscribe();
                });
            }
            return deferred.promise;
        };
        DialogService.prototype.createAndOpenModal = function (element, dialog, title, buttons, modalScope) {
            var modal = element.modal({
                title: title,
                buttons: buttons
            });
            dialog.init(modal);
            if (!buttons) {
                modal.modal("addButtons");
            }
            modal.one("beforeclose", function () {
                modalScope.$destroy();
                c.UIUtil.removePopupMenus(element);
            });
            modal.modal("open");
        };
        DialogService.prototype.showMessage = function (options) {
            var deferred = this.q.defer();
            var element = $("body");
            var buttons = null;
            if (!options.buttons && !options.standardButtons) {
                options.standardButtons = lm.StandardDialogButtons.Ok;
            }
            if (options.standardButtons != null) {
                buttons = this.setDefaultButtons(options.standardButtons, deferred, lm.CommonUtil.isUndefined(options.hasPrimaryButton) || options.hasPrimaryButton === true);
            }
            else if (options.buttons) {
                buttons = this.setSpecificButtons(options.buttons, deferred, null);
            }
            element.message({
                title: options.title,
                message: options.message,
                isError: options.isError === true,
                buttons: buttons,
                cssClass: options.cssClass
            });
            return deferred.promise;
        };
        DialogService.prototype.showToast = function (options) {
            if (!options.position) {
                options.position = "bottom right";
            }
            if (!options.timeout) {
                options.timeout = 3000;
            }
            $("body")["toast"](options);
        };
        DialogService.prototype.copyToClipboard = function (options) {
            var copyElement = document.createElement("textarea");
            copyElement.setAttribute("type", "text");
            copyElement.setAttribute("id", "lm-copy-to-clipboard");
            document.body.appendChild(copyElement);
            $("#lm-copy-to-clipboard").val(options.copyData);
            copyElement.select();
            if (options.forceDialog) {
                this.showMessage({ title: this.language.copyToClipboard, message: options.copyData, cssClass: "lm-text" });
            }
            else {
                try {
                    document.execCommand("copy");
                }
                catch (e) {
                    this.showMessage({ title: this.language.copyToClipboard, message: options.copyData, cssClass: "lm-text" });
                }
            }
            $("#lm-copy-to-clipboard").remove();
        };
        DialogService.prototype.setDefaultButtons = function (defaults, deferred, hasPrimaryButton) {
            var language = this.language;
            var buttons = [];
            if (defaults == lm.StandardDialogButtons.OkCancel || defaults == lm.StandardDialogButtons.YesNoCancel) {
                buttons.push({
                    text: language.cancel || "Cancel",
                    click: function () {
                        $(this).modal("close");
                        deferred.resolve({ button: lm.DialogButtonType.Cancel });
                    },
                    isDefault: false
                });
            }
            if (defaults == lm.StandardDialogButtons.Ok || defaults == lm.StandardDialogButtons.OkCancel) {
                buttons.push({
                    text: language.ok || "OK",
                    click: function () {
                        $(this).modal("close");
                        deferred.resolve({ button: lm.DialogButtonType.Ok });
                    },
                    isDefault: hasPrimaryButton
                });
            }
            else if (defaults == lm.StandardDialogButtons.YesNo || defaults == lm.StandardDialogButtons.YesNoCancel) {
                buttons.push({
                    text: language.no || "No",
                    click: function () {
                        $(this).modal("close");
                        deferred.resolve({ button: lm.DialogButtonType.No });
                    },
                    isDefault: false
                });
                buttons.push({
                    text: language.yes || "Yes",
                    click: function () {
                        $(this).modal("close");
                        deferred.resolve({ button: lm.DialogButtonType.Yes });
                    },
                    isDefault: hasPrimaryButton
                });
            }
            return buttons;
        };
        DialogService.prototype.setSpecificButtons = function (specificButtons, deferred, dialog) {
            var buttons = [];
            specificButtons.forEach(function (button, index) {
                button.click = function () {
                    if (dialog) {
                        dialog.close();
                    }
                    else {
                        $(this).modal("close");
                    }
                    var result;
                    if (dialog) {
                        result = dialog.result || {};
                        result.button = button.type;
                        deferred.resolve(result);
                    }
                    else {
                        result = { button: button.type };
                    }
                    deferred.resolve(result);
                };
                buttons.push(button);
            });
            return buttons;
        };
        DialogService.add = function (ngModule) {
            ngModule.service("lmDialogService", DialogService);
        };
        DialogService.$inject = ["$rootScope", "$compile", "$q", "lmLanguageService"];
        return DialogService;
    })(c.CoreBase);
    exports.DialogService = DialogService;
    var TagService = (function () {
        function TagService(languageService) {
            this.languageService = languageService;
            this.lang = languageService.getLanguage();
        }
        TagService.prototype.isTagValid = function (tag) {
            var response = {
                isValid: true
            };
            if (!/[^A-Za-z0-9_#]/.test(tag)) {
                if (tag[0] !== "#") {
                    response.isValid = false;
                    response.errorMsg = this.lang.tagFormatInfo;
                    return response;
                }
                if (tag.lastIndexOf("#") !== 0) {
                    response.isValid = false;
                    response.errorMsg = this.lang.tagFormatInfo;
                    return response;
                }
                if (tag.length < 3) {
                    response.isValid = false;
                    response.errorMsg = this.lang.invalidTagMinLength;
                    return response;
                }
                if (tag.length > 33) {
                    response.isValid = false;
                    response.errorMsg = this.lang.invalidTagMaxLength;
                    return response;
                }
            }
            else {
                response.isValid = false;
                response.errorMsg = this.lang.tagFormatInfo;
                return response;
            }
            return response;
        };
        TagService.prototype.areTagsValid = function (tags) {
            var _this = this;
            var response = {
                areValid: true
            };
            if (tags[0] === "#") {
                if (tags.match(/#/g).length <= 5) {
                    var tagsArray = tags.split("#");
                    tagsArray.shift();
                    angular.forEach(tagsArray, function (value, i) {
                        var valueTagged = "#" + value;
                        var validityResponse = _this.isTagValid(valueTagged);
                        tagsArray[i] = tagsArray[i].toLowerCase();
                        if (!validityResponse.isValid) {
                            response.areValid = false;
                            response.errorMsg = validityResponse.errorMsg;
                            return response;
                        }
                        else {
                            if (tagsArray.indexOf(value.toLowerCase()) != tagsArray.lastIndexOf(value.toLowerCase())) {
                                response.areValid = false;
                                response.errorMsg = _this.lang.duplicateTag;
                                return response;
                            }
                        }
                    });
                }
                else {
                    response.areValid = false;
                    response.errorMsg = this.lang.format(this.lang.maxCountTag, c.Constants.tagsMaxCount);
                }
            }
            else {
                response.areValid = false;
                response.errorMsg = this.lang.tagFormatInfo;
            }
            return response;
        };
        TagService.prototype.addTag = function (allTags, tag) {
            var response = {
                allTags: allTags,
                hasError: true
            };
            if (this.isTagValid(tag).isValid) {
                if ((allTags.match(/#/g) || "").length < 5) {
                    response.allTags += tag;
                }
                else {
                    response.hasError = true;
                    response.errorMsg = this.lang.format(this.lang.maxCountTag, c.Constants.tagsMaxCount);
                }
            }
            else {
                response.hasError = true;
                response.errorMsg = this.isTagValid(tag).errorMsg;
            }
            return response;
        };
        TagService.add = function (ngModule) {
            ngModule.service("lmTagService", TagService);
        };
        TagService.$inject = ["lmLanguageService"];
        return TagService;
    })();
    var CacheService = (function (_super) {
        __extends(CacheService, _super);
        function CacheService() {
            _super.call(this, "[CacheService] ");
        }
        CacheService.prototype.createCache = function (name) {
            return {
                name: name,
                isValid: false,
                cachedResponse: null,
                timeoutId: null
            };
        };
        CacheService.prototype.updateCache = function (cache, response, deferred) {
            var _this = this;
            cache.cachedResponse = response;
            cache.isValid = true;
            if (cache.timeoutId) {
                window.clearTimeout(cache.timeoutId);
                cache.timeoutId = null;
            }
            cache.timeoutId = window.setTimeout(function () {
                cache.isValid = false;
                lm.Log.debug(_this.logPrefix + cache.name + " cache invalidated.");
            }, c.Constants.cacheLifetime);
            if (deferred) {
                deferred.resolve(response);
            }
        };
        CacheService.add = function (ngModule) {
            ngModule.service("lmCacheService", CacheService);
        };
        return CacheService;
    })(c.CoreBase);
    exports.init = function (externalModule, internalModule) {
        DialogService.add(externalModule);
        ProgressService.add(internalModule);
        DataService.add(internalModule);
        CommonDataService.add(externalModule);
        TagService.add(internalModule);
        CacheService.add(internalModule);
    };
});
//# sourceMappingURL=service.js.map