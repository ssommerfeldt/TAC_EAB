﻿import lm = require("../lime");
import c = require("../core");
import w = require("./widget");
import p = require("./page");
import container = require("./container");

class WidgetNotifications {
	public static show = "show";
	public static hide = "hide";
	public static close = "close";
}

export class PageLayout {

	private maxColumns = 3;
	private matrix: boolean[][];

	constructor(private widgets: c.IWidget[]) {
		this.matrix = this.createMatrix(widgets);
	}

	public getMatrix() {
		return this.matrix;
	}

	public firstEmpty(): c.IWidgetLayout {
		var matrix = this.matrix;
		var rows = matrix.length;
		var columns = matrix[0].length;
		for (var row = 0; row < rows; row++) {
			for (var col = 0; col < columns; col++) {
				if (this.matrix[row][col] === false) {
					// Found an empty cell
					return new c.WidgetLayout(col, row);
				}
			}
		}

		// Add a new empty row
		matrix.push(lm.ArrayUtil.array(this.maxColumns, false));
		return new c.WidgetLayout(0, rows);
	}

	private getMaxRow(widgets: c.IWidget[]): number {
		var max = 0;
		for (var i = 0; i < widgets.length; i++) {
			var layout = widgets[i].data.layout;
			if (layout) {
				var row = layout.row + layout.rowSpan - 1;
				if (row > max) {
					max = row;
				}
			}
		}
		return max;
	}

	private createMatrix(widgets: c.IWidget[]): boolean[][] {
		var max = this.getMaxRow(widgets);
		var matrix = lm.ArrayUtil.matrix<boolean>(max + 1, this.maxColumns, false);
		for (var i = 0; i < widgets.length; i++) {
			var widget = widgets[i];
			var layout = widget.data.layout;
			if (layout) {
				var column = layout.column;
				var row = layout.row;
				for (var c = 0; c < layout.columnSpan; c++) {
					matrix[row][column + c] = true;
				}
				for (var r = 0; r < layout.rowSpan; r++) {
					matrix[row + r][column] = true;
				}
			}
		}
		return matrix;
	}
}

export class Page extends c.CoreBase implements c.IPageInstance {
	private removedEvent = new c.InstanceEvent<c.IPageInstance>();
	private changedEvent = new c.InstanceEvent<c.IPageInstance>();
	private widgetAddedEvent = new c.InstanceEvent<c.IWidget>();
	public widgetsAddedCount = 0;

	public id: string;
	public widgets: c.IWidget[] = [];
	public data: c.IPageData;
	public settings: any;

	public title: string;
	public description: string;
	public isEditable: boolean;
	public isViewable: boolean;
	public isMandatory: boolean;
	public roleAccess: c.IEntityAccess[];
	public userAccess: c.IStringToIEntityAccessMap;
	public applications: c.IStringToIApplicationArrayMap;

	constructor(private context: c.IContext, private page: c.IPage, private widgetService: c.IWidgetService, private lang: ILanguageLime, private progressService: c.IProgressService) {
		super("[Page] ");

		this.isMandatory = page.isMandatory === true;
		this.isEditable = page.isEditable === true;
		this.isViewable = page.isViewable !== false;
		this.roleAccess = page.roleAccess;
		this.userAccess = page.userAccess;
		this.settings = page.settings;

		var data = page.data;
		this.data = data;
		this.id = data.id;

		// Get the localized title from the page or the default title if no localized title exists.
		this.title = page.title || data.title;
		this.description = page.description || data.description;

		var widgets = data.widgets;
		var widgetReferences = data.widgetRefs;
		if (widgets) {
			for (var i = 0; i < widgets.length; i++) {
				var widget = widgets[i];
				var id = widget.id;

				// Just skip widgets without IDs for now 
				if (id) {
					var ref: c.IWidgetHandle = lm.ArrayUtil.itemByProperty(widgetReferences, "id", id);
					var definitionExist = this.widgetService.getCachedDefinition(widget.id);
					if (definitionExist) {
						var parentContext = this.getWidgetParentContext(widget);
						this.addToWidgets(new w.Widget(parentContext, widget, false, ref ? ref.byRef : false));
					} else {
						widget.isBroken = true;
						widget.brokenMessage = this.lang.brokenWidget;
						this.addToWidgets(new w.Widget({ addWidget: (w) => { this.add(w); } }, widget, false, true));
						this.warning("No definition was found in page for widget ID: " + id);
					}
				}
			}
		} else {
			data.widgets = [];
		}
	}

	public noOfWidgets() {
		return this.widgets.length;
	}

	public getWidgetByInstanceId(instanceId: string): c.IWidget {
		var widgets = this.widgets;
		if (widgets) {
			for (var i = 0; i < widgets.length; i++) {
				var widget = widgets[i];
				if (widget.data.instanceId == instanceId) {
					return widget;
				}
			}
		}
		return null;
	}

	public getWidgetParentContext(widget: c.IWidgetData) {
		var parentContext = <c.IWidgetParentContext>{
			id: this.id,
			isPublished: this.isPublished(),
			addWidget: (w) => { this.add(w); }
		};
		if (widget) {
			parentContext.userSettings = this.getUserSettingsForWidget(this.page, widget.instanceId);
		}
		return parentContext;
	}

	private getUserSettingsForWidget(page: c.IPage, instanceId: string) {
		var settings = page.settings;
		if (settings) {
			var widgets = settings["widgets"];
			if (widgets) {
				return widgets[instanceId];
			}
		}
		return null;
	}

	public isPublished(): boolean {
		return this.data.viewAccess !== c.AccessType.Owner;
	}

	public isPublishEnabled(): boolean {
		// Private pages can be published if the users is allowed to do so.
		return !this.isPublished() && this.context.settings.isPagePublishEnabled();
	}

	/**
	 * Gets the layout for the first empty cell where a widget can be added.
	 */
	private getLayout(): c.IWidgetLayout {
		if (this.widgets.length === 0) {
			return new c.WidgetLayout(0, 0);
		}
		const pageLayout = new PageLayout(this.widgets);
		return pageLayout.firstEmpty();
	}

	private clearWidgets() {
		const widgets = this.widgets;
		for (let k = 0; k < widgets.length; k++) {
			widgets[k].destroy();
		}

		// Clear the content but preserve any external references to the arrays
		widgets.length = 0;
		this.data.widgets.length = 0;
	}

	public notifyPublishingMode(): void {
		const widgets = this.widgets;
		for (let widget of widgets) {
			try {
				if (widget.definition && !widget.definition.isPublished) {
					widget.enableSettingsTemporary(true);
					const publishing = widget.instance.publishing;
					if (publishing) {
						publishing();
					}
				}
			} catch (ex) {
				this.error("Failed to call publishing event function", ex);
			}
		}
	}

	public updateWidgets(editedWidgets: c.IEditableWidget[], isSave: boolean): void {
		const widgets = this.widgets;
		const updatedWidgets = <c.IWidget[]>[];

		for (var i = 0; i < editedWidgets.length; i++) {
			var editedWidget = editedWidgets[i];
			var layout = editedWidget.layout;
			if (editedWidget.id) {
				var data: c.IWidgetData;
				var byRef: boolean;
				var isNew = true;
				var existing: c.IWidget = editedWidget.elementId ? lm.ArrayUtil.itemByProperty(widgets, "elementId", editedWidget.elementId) : null;
				if (existing) {
					isNew = false;
					data = existing.data;
					data.layout = layout;
					byRef = existing.byRef;
				} else {
					if (lm.CommonUtil.isUndefined(editedWidget.widget.data)) {
						continue;
					}
					data = editedWidget.widget.data;
					data.layout = editedWidget.layout;
					byRef = editedWidget.widget.byRef;
				}

				let parentContext = this.getWidgetParentContext(data);

				// Check if widget has been deleted 
				const def = this.widgetService.getCachedDefinition(editedWidget.id);

				if (!def) {
					data.isBroken = true;
					data.brokenMessage = this.lang.brokenWidget;
					parentContext = { addWidget: (w) => { this.add(w); } };
					this.warning("No definition was found in page for widget ID: " + editedWidget.id);
				}

				const widget = new w.Widget(parentContext, data, isNew, byRef);
				if (existing && def) {
					widget.copyFrom(<w.Widget>existing);
				}

				updatedWidgets.push(widget);
			}
		}

		this.clearWidgets();
		
		// Add the updated widgets
		for (let updated of updatedWidgets) {
			this.addInternal(updated, -1);
			this.widgetAddedEvent.raise(updated);
		}

		// Notify change so the page is saved
		if (isSave) {
			this.raiseChanged();
		}
	}

	private addToWidgets(widget: c.IWidget, index?: number) {
		widget.isDev = c.ClientConfiguration.isDev();

		if (index >= 0) {
			this.widgets.splice(index, 0, widget);
		} else {
			this.widgets.push(widget);
		}

		widget.changed().on((w: c.IWidget) => {
			if (w) {
				this.raiseChanged();
			}
		});

		widget.removed().on((w: c.IWidget) => {
			if (w) {
				this.remove(w);
			}
		});
	}

	private addInternal(widget: c.IWidget, index: number): void {
		if (!widget.data.layout) {
			widget.data.layout = this.getLayout();
		}

		// TODO Should the index still be used or always add last?

		this.addToWidgets(widget, index);

		if (index >= 0) {
			this.data.widgets.splice(index, 0, widget.data);
		} else {
			this.data.widgets.push(widget.data);
		}
	}

	public afterPublishedStandard(widget: c.IWidget, sourceDefinition: c.IWidgetDefinition) {
		// Custom widget was created. 
		// Create widget definition from standard widget, replace the standard widget on the page, save the page.
		const definition = angular.copy(widget.definition);
		definition.standardWidgetId = angular.copy(widget.id);
		definition.widgetId = sourceDefinition.widgetId;
		definition.settings = sourceDefinition.settings;
		definition.enableSettings = sourceDefinition.enableSettings;
		definition.enableTitleEdit = sourceDefinition.enableTitleEdit;
		definition.owner = this.context.getUserId();
		
		//TODO include byRef flag?
		widget.definition = definition;
		widget.id = sourceDefinition.widgetId;

		delete widget.data.title;
		widget.data.id = sourceDefinition.widgetId;

		for (var i = 0; i < this.data.widgetRefs.length; i++) {
			if (this.data.widgetRefs[i].id === definition.standardWidgetId) {
				this.data.widgetRefs[i].id = definition.widgetId;
				//TODO include byRef flag?
				break;
			}
		}
		this.raiseChanged();
	}

	public add(widget: c.IWidget): void {
		this.progressService.setBusy(true);
		this.addInternal(widget, -1);
		this.widgetAddedEvent.raise(widget);
		this.raiseChanged();
		this.progressService.setBusy(false);
	}

	private removeInternal(widget: c.IWidget): void {
		lm.ArrayUtil.remove(this.widgets, widget);
		lm.ArrayUtil.remove(this.data.widgets, widget.data);
	}

	public remove(widget: c.IWidget): void {
		this.removeInternal(widget);
		widget.destroy();
		this.raiseChanged();
		this.notify(lm.WidgetActivationType.close, false);
	}

	private raiseChanged(): void {
		this.changedEvent.raise(this);
	}

	changed(): c.IInstanceEvent<c.IPageInstance> {
		return this.changedEvent;
	}

	removed(): c.IInstanceEvent<c.IPageInstance> {
		return this.removedEvent;
	}

	widgetAdded(): c.IInstanceEvent<c.IWidget> {
		return this.widgetAddedEvent;
	}

	public show(): void {
		this.notify(lm.WidgetActivationType.visibility, true);
	}

	public hide(): void {
		this.notify(lm.WidgetActivationType.visibility, false);
	}

	public destroy(): void {
		this.clearWidgets();

		this.changedEvent.clear();
		this.removedEvent.clear();
		this.widgetAddedEvent.clear();
	}

	public toggleEditMode(isEdit: boolean): void {
		var widgets = this.widgets;
		for (var i = 0; i < widgets.length; i++) {
			var instance = widgets[i].instance;
			if (instance) {
				var f = instance[isEdit ? "editing" : "edited"];
				if (f) {
					try {
						f();
					} catch (e) {
						this.debug("Failed to call " + f + " for widget with id: " + widgets[i].id);
					}
				}
			}
		}
	}

	private notify(widgetActivationType: string, isActivate: boolean) {
		var functionName = isActivate ? "activated" : "deactivated";
		var widgets = this.widgets;
		for (var i = 0; i < widgets.length; i++) {
			var widget = widgets[i];
			var instance = widget.instance;
			if (instance) {
				var activation: lm.IWidgetActivationArg = { type: widgetActivationType };
				if (widgetActivationType === lm.WidgetActivationType.visibility) {
					widget.isVisible = isActivate;
				}
				if (instance[functionName]) {
					try {
						instance[functionName](activation);
					} catch (e) {
						this.error("Failed to call " + functionName + " for widget with id: " + widget.id);
					}
				}
			}
		}
	}

	private hasSettings(): boolean {
		var settings = this.settings;
		return settings && Object.keys(settings).length > 0;
	}

	public getWidgetUserSettings(): any {
		// Iterate widgets and collect user data which might not be anything if all settings are disabled
		// User data should not be collected for private widget on private pages
		var isPublishedPage = this.isPublished();
		var page = this;
		var data: any = null;
		var widgets = page.widgets;
		if (widgets) {
			for (var i = 0; i < widgets.length; i++) {
				var widget = widgets[i];
				var instanceId: string = widget.data.instanceId;
				if (instanceId) {
					if (isPublishedPage || widget.isPublished()) {
						var instanceData = widget.getUserData();
						if (instanceData) {
							if (!data) {
								data = {};
							}
							data[instanceId] = instanceData;
						}
					}
				}
			}
		}
		return data;
	}

	public setWidgetUserSettings(data: any): boolean {
		var page = this;
		var settings = page.settings;
		if (!settings && !data) {
			return false;
		}

		if (!settings) {
			page.settings = settings = {};
		}

		var name = "widgets";
		if (data) {
			settings[name] = data;
		} else {
			delete settings[name];
		}

		return true;
	}

	public createSavePageData(): c.IPageData {
		const page = this;
		var pageData: c.IPageData = page.data;
		pageData.widgetRefs = null;

		// Copy page data before saving since it it modified by this function
		pageData = angular.copy(pageData);

		var widgetRefs: c.IWidgetHandle[] = [];
		var widgetDatas = pageData.widgets;
		if (widgetDatas) {
			for (var i = 0; i < widgetDatas.length; i++) {
				var widgetData = widgetDatas[i];
				var id: string = widgetData.id;
				if (id) {
					var widget = page.getWidgetByInstanceId(widgetData.instanceId);
					if (widget) {
						var isByRef = widget.byRef;
						widgetRefs.push({ id: id, byRef: isByRef });

						if (isByRef) {
							// Clear properties that should not be saved
							delete widgetData.settings;
							delete widgetData.title;
						}
					}
				}
			}
		}

		pageData.widgetRefs = widgetRefs;

		const hadSettings = this.hasSettings();
		const widgetUserSettings = this.getWidgetUserSettings();
		this.setWidgetUserSettings(widgetUserSettings);
		const hasSettings = this.hasSettings();

		var userSettings = null;
		if (hasSettings) {
			userSettings = page.settings;
		} else if (hadSettings) {
			// Set to empty object to clear on server
			userSettings = {};
		}
		pageData.userSettings = userSettings;

		return pageData;
	}
}

class NameNumberValue {
	name: string;
	value: number;
}

class AddPageCtrl extends c.CoreBase {
	static $inject = ["$scope", "lmPageService", "lmContextService"];
	private newPage: c.IPageData = {};
	private dialog: lm.IDialog = null;
	private context: c.IContext;
	private pageTitleLength;
	private pageDescriptionLength;

	constructor(public scope: any, private pageService: c.IPageService, private contextService: c.IContextService) {
		super("[AddPageCtrl] ");
		this.context = contextService.getContext();
		var dialog: lm.IDialog = scope["lmDialog"];
		if (!dialog) {
			this.error("lmDialog is not found in scope when opening add page dialog");
			return;
		}

		this.pageTitleLength = c.Constants.pageTitleLength;
		this.pageDescriptionLength = c.Constants.pageDescriptionLength;

		this.dialog = dialog;
		dialog.result = <lm.IDialogResult>{};
		scope["newPage"] = this.newPage;
	}

	public close() {
		this.dialog.close();
	}

	public create() {
		var result: lm.IDialogResult = { value: this.newPage, button: lm.DialogButtonType.Ok };
		this.dialog.close(result);
	}

	static add(m: ng.IModule) {
		m.controller("lmAddPageCtrl", AddPageCtrl);
	}
}

class CopyPageCtrl extends c.CoreBase {
	static $inject = ["$scope", "lmPageService"];
	private newPage: c.IPageData = {};
	private dialog: lm.IDialog = null;
	private pageTitleLength;

	constructor(public scope: any, private pageService: c.IPageService) {
		super("[CopyPageCtrl] ");
		var dialog: lm.IDialog = scope["lmDialog"];
		if (!dialog) {
			this.error("lmDialog is not found in scope when opening add page dialog");
			return;
		}

		this.pageTitleLength = c.Constants.pageTitleLength;

		this.dialog = dialog;
		dialog.result = <lm.IDialogResult>{};

		this.newPage = this.dialog.parameter || {};
		scope["newPage"] = this.newPage;
	}

	public close() {
		this.dialog.close();
	}

	public copy() {
		var result: lm.IDialogResult = { value: this.newPage, button: lm.DialogButtonType.Ok };
		this.dialog.close(result);
	}

	static add(m: ng.IModule) {
		m.controller("lmCopyPageCtrl", CopyPageCtrl);
	}
}

/**
 * Controller class for the publish page dialog.
 */
class PageCustomizationCtrl extends c.CoreBase {

	private dialog: lm.IDialog = null;
	private context: c.IContext;
	private lang: ILanguageLime;
	private pageTitleLength;
	private pageDescriptionLength;
	private page: c.IPageInstance;
	private pageData: c.IPageData;
	private tabOptions: xi.ITabsOptions;
	private translationEnabled: boolean;
	private openTab: string;
	private tagHolder: string;

	static $inject = ["$scope", "lmPageService", "lmContextService", "lmLanguageService", "lmContainerService"];

	constructor(public scope: any, private pageService: c.IPageService, private contextService: c.IContextService, languageService: c.ILanguageService, private containerService: container.IContainerService) {
		super("[PagePublishCtrl] ");
		this.context = contextService.getContext();
		var dialog: lm.IDialog = scope["lmDialog"];
		this.dialog = dialog;
		this.lang = languageService.getLanguage();
		this.pageTitleLength = c.Constants.pageTitleLength;
		this.pageDescriptionLength = c.Constants.pageDescriptionLength;
		this.translationEnabled = this.context.settings.isContentTranslationEnabled();
		this.tabOptions = { modalId: c.Constants.modalPagePublish };
		this.tagHolder = "#" + new Date().getFullYear().toString();

		if (dialog.parameter) {
			var page = <c.IPageInstance>dialog.parameter;
			this.page = page;

			this.pageData = angular.copy(this.page.data);
			scope["pageData"] = this.pageData;
			scope["localization"] = {
				defaultLocalization: { title: this.pageData.title, description: this.pageData.description },
				localizationMap: this.page.localization ? angular.copy(this.page.localization) : {},
				isWidget: false
			};
			scope["roleAccess"] = this.page.roleAccess ? angular.copy(this.page.roleAccess) : [];
			scope["userAccess"] = $.isEmptyObject(this.page.userAccess) ? {} : angular.copy(this.page.userAccess);
		}
	}

	public apply() {
		// Set title, tags and desc since these are generated from createSavePageData()
		this.page.data.title = this.pageData.title;
		this.page.data.tags = this.pageData.tags;
		this.page.data.description = this.pageData.description;

		var pageData = this.page.createSavePageData();
		var pageRequest = <c.IPage>{
			data: pageData,
			roleAccess: this.scope["roleAccess"],
			userAccess: this.scope["userAccess"],
			localization: this.scope["localization"].localizationMap
		};

		this.dialog.close({ value: pageRequest });
	}

	private onClickTab(tabName: string): void {
		this.openTab = tabName;
		if (tabName === "translations") {
			var data = this.pageData;
			this.scope.localization.defaultLocalization = { title: data.title, description: data.description };
		}
	}

	public cancel() {
		this.dialog.close();
	}

	static add(m: ng.IModule) {
		m.controller("lmPageCustomizationCtrl", PageCustomizationCtrl);
	}
}

export interface IHomepageSettings {
	gutterSize: number;
	widgetWidth: number;
	widgetHeight: number;
	animate: boolean;
	timeout: number;
	columns: number;
	easing: string;
}

export class PageUtil {
	/**
	 * Copies values from the source to the target page.
	 */
	public static copyValues(source: c.IPageData, target: c.IPageData) {
		target.id = source.id;
		target.title = source.title;
		target.description = source.description;
		target.editAccess = source.editAccess;
		target.ownerId = source.ownerId;
		target.ownerName = source.ownerName;
		target.changeDate = source.changeDate;
		target.changedBy = source.changedBy;
		target.changedByName = source.changedByName;
		target.viewAccess = source.viewAccess;
		target.tags = source.tags;

		// Values that might be undefined
		target.popularity = source.popularity ? source.popularity : 0;
	}

	public static copy(page: c.IPageData): c.IPageData {
		var p: c.IPageData = {};
		PageUtil.copyValues(page, p);
		return p;
	}

	/**
	* Checks if a page is private
	*/
	public static isPagePrivate(pageData: c.IPageData): boolean {
		if (pageData.viewAccess == c.AccessType.Owner) {
			return true;
		}
		return false;
	}

	public static addHomepageControl(element: JQuery): void {
		if (!lm.CommonUtil.isUndefined(element.data("homepage"))) {
			PageUtil.attachHomepageEvents(element, true);
			return;
		}
		element["homepage"]();
	}

	public static destroyHomepageControl(element: JQuery): void {
		var data: any = element.data("homepage");
		if (lm.CommonUtil.isUndefined(data)) { return; }
		data.destroy();
	}

	public static attachHomepageEvents(element: JQuery, refresh: boolean): void {
		var data: any = element.data("homepage");
		if (lm.CommonUtil.isUndefined(data)) {
			PageUtil.addHomepageControl(element);
			return;
		}
		data.attachEvents();
		if (refresh) {
			PageUtil.refreshHomepageLayout(element);
		}
	}

	public static detachHomepageEvents(element: JQuery): void {
		// TODO Use a type
		var data: any = element.data("homepage");
		if (lm.CommonUtil.isUndefined(data)) { return; }
		data.detachEvents();
	}

	public static refreshHomepageLayout(element: JQuery): void {
		// TODO Type data
		var data: any = element.data("homepage");
		if (lm.CommonUtil.isUndefined(data)) {
			PageUtil.addHomepageControl(element);
			return;
		}
		data.resize(data, true);
	}

	/**
	 * Returns the current Xi Homepages settings from one of the active homepages
	 */
	public static getSettings(): IHomepageSettings {
		var homepages = $(".homepage");
		for (var i = 0; i < homepages.length; i++) {
			var data: any = $(homepages[i]).data("homepage");
			if (data) {
				return <IHomepageSettings>data.settings;
			}
		}
		return null;
	}

	public static getLayout(element: JQuery, settings: IHomepageSettings): c.IWidgetLayout {
		// Note that this function currently ignores extra gutters for widgets greater than 1x1.
		// Currently this is OK since the values are rounded to integers.

		var getVal = (name: string): number => {
			return parseInt(element.css(name));
		};
		var widgetHeight = settings.widgetHeight;
		var widgetWidth = settings.widgetWidth;
		var gutter = settings.gutterSize;
		var location: c.IWidgetLayout = {
			column: Math.round(getVal("left") / (widgetWidth + gutter)),
			row: Math.round(getVal("top") / (widgetHeight + gutter)),
			columnSpan: Math.round(getVal("width") / widgetWidth),
			rowSpan: Math.round(getVal("height") / widgetHeight)
		};
		return location;
	}

	public static updateLayout(widgets: c.IWidget[]): void {
		var settings = PageUtil.getSettings();
		if (!settings) {
			return;
		}
		for (var i = 0; i < widgets.length; i++) {
			var widget = widgets[i];
			var layout = this.getLayout(widget.element, settings);
			if (layout) {
				widget.data.layout = layout;
			}
		}
	}
}

/**
 * Controller class for the page settings dialog.
 */
class PageSettingsCtrl extends c.CoreBase {
	private dialog: lm.IDialog = null;
	private context: c.IContext;
	private editLevels = [];
	static $inject = ["$scope", "lmPageService", "lmContextService", "lmDialogService"];
	private pageTitleLength;
	private pageDescriptionLength;

	constructor(public scope: any, private pageService: c.IPageService, private contextService: c.IContextService, private dialogService: lm.IDialogService) {
		super("[PageSettingsCtrl] ");
		this.context = contextService.getContext();
		var dialog: lm.IDialog = scope["lmDialog"];
		this.dialog = dialog;
		this.pageTitleLength = c.Constants.pageTitleLength;
		this.pageDescriptionLength = c.Constants.pageDescriptionLength;

		if (dialog.parameter && dialog.parameter.data) {
			var page: c.IPage = { data: PageUtil.copy(dialog.parameter.data), isEditable: dialog.parameter.isEditable, isMandatory: dialog.parameter.isMandatory };
			//var page = angular.copy(pageInput);

			scope["page"] = page;
			scope["isPublic"] = page.data.viewAccess !== c.AccessType.Owner;

			// Only enable input level for owner or admin
			scope["isOwnerOrAdmin"] = page.data.ownerId === this.context.getUserId();
		}
	}

	public close() {
		this.dialog.close();
	}

	public save() {
		var page = <c.IPageInstance>this.scope["page"];
		var pageData = PageUtil.copy(page.data);

		var self = this;
		this.pageService.updateSettings(pageData).then((r: c.IPageDataResponse) => {
			// Return the real page
			var originalData: c.IPageData = self.dialog.parameter; // TODO: Need some error checking?
			// Update real page with the new values
			PageUtil.copyValues(r.content, originalData);
			var result = <lm.IDialogResult>{ button: lm.DialogButtonType.Ok };
			self.dialog.close(result);
		}, (r: c.IOperationResponse) => { this.pageService.handleError(r); });
	}

	static add(m: ng.IModule) {
		m.controller("lmPageSettingsCtrl", PageSettingsCtrl);
	}
}

export class MyPagesCtrl extends c.CoreBase {

	private pageContainer: c.IPageContainer;
	private pages: c.IPageInstance[];
	private selectedPage: string;
	private home: string;
	private dialog: lm.IDialog = null;
	private context: c.IContext;
	private sortableOptions;
	private isHomepageSelectionEnabled: boolean;
	private popupmenuOptions: xi.IPopupMenuOptions;
	private contextMenuId: string;

	static $inject = ["$scope", "lmPageService", "lmContextService", "lmProgressService", "lmDialogService"];
	constructor(public scope: any, private pageService: c.IPageService, private contextService: c.IContextService, private progressService: c.IProgressService, private dialogService: lm.IDialogService) {
		super("[MyPagesCtrl] ");
		this.setSortableOptions();
		this.context = contextService.getContext();
		this.isHomepageSelectionEnabled = contextService.getContext().settings.isSelectHomepageEnabled();
		this.popupmenuOptions = {
			menu: "lmCopyMenu",
			trigger: "rightClick"
		}
		if (this.scope.$parent.lmPageContainer) {
			try {
				this.pageContainer = <c.IPageContainer>this.scope.$parent.lmPageContainer;
				this.pages = this.pageContainer.pages;
				$.each(this.pages, (i, page: c.IPageInstance) => {
					page["isPrivate"] = p.PageUtil.isPagePrivate(page.data);
					// Fetch ownerName and changedByName if not set
					if (!page["isPrivate"] && lm.CommonUtil.isUndefined(page.data.ownerName)) {
						page.data.ownerName = page.data.ownerId;
						page.data.changedByName = page.data.changedBy;
						pageService.getPublished(page.id).then((response: c.IPageResponse) => {
							var p = <c.IPage>response.content;
							if (!lm.CommonUtil.isUndefined(p)) {
								page.data.ownerName = p.data.ownerName;
								page.data.changedByName = p.data.changedByName;
							}
						});
					}
				});
				this.selectedPage = this.pageContainer.selectedPage.id;
				this.getAndUpdateHome();
			} catch (ex) {
				this.error("Failed to initialize");
			}
		}
		this.attachPopupmenus();
	}

	private setSortableOptions() {
		this.sortableOptions = {
			items: "> li:not(.unsortable)",
			opacity: 0.8,
			placeholder: "lm-my-pages-placeholder",
			tolerance: "pointer",
			cursor: "move",
			axis: "x",
			delay: 100,
			update: (event, ui) => {
				this.sortableOptions.disabled = true;
				var startIndex = ui.item.sortable.index;
				var dropIndex = ui.item.sortable.dropindex;
				if (startIndex != dropIndex) {
					this.progressService.setBusy(true);
					var newOrder = this.getNewOrder(startIndex, dropIndex);
					this.pageContainer.reorder(newOrder).then(() => {
						// Sortable handles model update
						this.sortableOptions.disabled = false;
						this.progressService.setBusy(false);
					}, (r: c.IOperationResponse) => {
						// If something goes wrong, cancel/revert the action
						this.revertOrder(startIndex, dropIndex);
						this.sortableOptions.disabled = false;
						this.progressService.setBusy(false);
					});
				}
			},
			stop: () => {
				this.refreshSvgIcons();
			}
		}
	}

	// Check if private (cause role and public should probably be treated as unsubscribe)
	private isPagePrivate(page: c.IPageInstance): boolean {
		return PageUtil.isPagePrivate(page.data);
	}

	private setSelected(page: c.IPageInstance): void {
		this.selectedPage = page.id;
		var index = lm.ArrayUtil.indexByProperty(this.pages, "id", this.selectedPage);
		this.scope.slideIntoView(index);
		this.attachPopupmenus();
	}

	private isSelectedPage(page: c.IPageInstance): boolean {
		return this.selectedPage === page.id;
	}

	private refreshSvgIcons(): void {
		const userAgent = navigator.userAgent;
		// Refresh SVG elements if IE11
		if (!!userAgent.match(/Trident.*rv\:11\./) && userAgent.toLowerCase().indexOf("windows nt 10") !== -1) {
			const svgElements = $(".lm-my-pages-card-container svg");
			for (let i = 0; i < svgElements.length; i++) {
				const parent = $(svgElements[i]).parent();
				parent.html(parent.html());
			}
		}
	}

	private moveLeft(page: c.IPageInstance) {
		var currentIndex = lm.ArrayUtil.indexOf(this.pages, page);
		var isMoveLeftAllowed = currentIndex != -1 && currentIndex >= 1;
		if (isMoveLeftAllowed) {
			this.progressService.setBusy(true);
			var newOrder = this.getNewOrder(currentIndex, currentIndex - 1);
			this.pageContainer.reorder(newOrder).then((r: c.IOperationResponse) => {
				var movedPage = this.pages.splice(currentIndex, 1)[0];
				this.pages.splice(currentIndex - 1, 0, movedPage);
				this.refreshSvgIcons();
				this.progressService.setBusy(false);
			}, (r: c.IOperationResponse) => {
				this.progressService.setBusy(false);
			});
		} else {
			this.debug("Page with id: " + page.id + " was not found, or cannot be moved");
		}
	}

	private moveRight(page: c.IPageInstance) {
		var currentIndex = lm.ArrayUtil.indexOf(this.pages, page);
		var isMoveRightAllowed = currentIndex != -1 && currentIndex < this.pages.length - 1;
		if (isMoveRightAllowed) {
			this.progressService.setBusy(true);
			var newOrder = this.getNewOrder(currentIndex, currentIndex + 1);
			this.pageContainer.reorder(newOrder).then((r: c.IOperationResponse) => {
				var movingPage = this.pages.splice(currentIndex, 1)[0];
				this.pages.splice(currentIndex + 1, 0, movingPage);
				this.refreshSvgIcons();
				this.progressService.setBusy(false);
			}, (r: c.IOperationResponse) => {
				this.progressService.setBusy(false);
			});
		} else {
			this.debug("Page with id: " + page.id + " was not found, or cannot be moved");
		}
	}

	/**
	 * Method should only be used from Sortable update if the reorder isn't successful
	 */
	private revertOrder(beforeDrop: number, afterDrop: number) {
		var movedPage = this.pages.splice(afterDrop, 1)[0];
		this.pages.splice(beforeDrop, 0, movedPage);
	}

	private getNewOrder(oldIndex: number, newIndex: number): string[] {
		var pages: string[] = this.pages.map((page: c.IPageInstance) => {
			return page.id;
		});

		var movedPage = pages.splice(oldIndex, 1)[0];
		pages.splice(newIndex, 0, movedPage);

		return pages;
	}

	private canMoveLeft(page: c.IPageInstance): boolean {
		if (page.isMandatory) {
			return false;
		}
		var index = this.pages.indexOf(page);
		if (index == 0) {
			return false;
		}
		var leftPage = this.pages[index - 1];
		if (leftPage && leftPage.isMandatory) {
			return false;
		}
		return true;
	}

	private canMoveRight(page: c.IPageInstance): boolean {
		if (page.isMandatory) {
			return false;
		}
		var index = this.pages.indexOf(page);
		if (index == this.pages.length - 1) {
			return false;
		}
		return true;
	}

	private showSettings(page: c.IPageInstance) {
		this.pageContainer.showPageInformation(page.id);
	}

	private removePage(page: c.IPageInstance) {
		var pageIndex: number;
		if (this.isSelectedPage(page)) {
			pageIndex = this.pages.indexOf(page);
		}
		this.pageContainer.remove(page).then((r: c.IOperationResponse) => {
			if (this.isSelectedPage(page)) {
				this.updateSelectedOnRemove(pageIndex);
			}
		}, (r: c.IOperationResponse) => { this.pageService.handleError(r); });
	}

	private deletePage(page: c.IPageInstance) {
		var pageIndex: number;
		if (this.isSelectedPage(page)) {
			pageIndex = this.pages.indexOf(page);
		}
		this.pageContainer.delete(page.id, page.title, false).then((r: c.IOperationResponse) => {
			if (this.isSelectedPage(page)) {
				this.updateSelectedOnRemove(pageIndex);
			}
		}, (r: c.IOperationResponse) => { this.pageService.handleError(r); });
	}

	private getAndUpdateHome() {
		if (this.isHomepageSelectionEnabled) {
			var pageId = this.context.settings.getStartPage();
			this.home = pageId;
		}
	}

	private setHome(page: c.IPageInstance) {
		var oldHome = this.home;
		if (oldHome == page.id) {
			this.home = "";
		} else {
			this.home = page.id;
		}
		this.context.settings.setStartPage(this.home);
		this.context.settings.saveUserSettings().then((r: c.IStringResponse) => {

		}, (r: c.IOperationResponse) => {
			this.home = oldHome;
			this.pageService.handleError(r);
		});

	}

	private updateSelectedOnRemove(index: number) {
		if (this.pages.length === 0) {
			this.close();
		}
		else if (0 <= index && index < this.pages.length) {
			this.selectedPage = (this.pages[index].id);
		} else {
			this.selectedPage = (this.pages[index - 1].id);
		}
	}

	private close() {
		this.scope.$parent["lmShowMyPages"] = false;
		if (this.pageContainer && this.pageContainer.selectedPage) {
			setTimeout(() => {
				p.PageUtil.attachHomepageEvents($("#" + this.pageContainer.selectedPage.id).parent(".homepage"), true);
			}, 100);
		}
	}

	/**
	 * Copy data to clipboard
	 * @returns {} 
	 */
	public copyToClipboard(): void {
		let page: c.IPageInstance = lm.ArrayUtil.itemByProperty(this.pages, "id", this.selectedPage);
		let usedBy = !lm.CommonUtil.isUndefined(page.data.popularity) ? "Used by: " + page.data.popularity + ", \n" : "";
		let ownerName = page.data.ownerName ? "Owner name: " + page.data.ownerName + ", \n" : "";
		let ownerId = page.data.ownerId ? "Owner ID: " + page.data.ownerId + ", \n" : "";
		let data = 'Title: ' + page.data.title + ", \n" +
			'Page ID: ' + page.data.id + ", \n" +
			usedBy +
			ownerName +
			ownerId +
			'Description: ' + page.data.description + ", \n" +
			'Last Edited: ' + page.data.changeDate;
		this.dialogService.copyToClipboard({ copyData: data });
	}

	/*
	* Attaches a popupmenu to a specified element
	*/
	private attachPopupmenu(element: JQuery): void {
		element.on("contextmenu", (e) => {
			element["popupmenu"]({ menuId: this.popupmenuOptions.menu, trigger: "immediate", eventObj: e });
			this.contextMenuId = element.attr("id");
			return false;
		});
	}

	/*
	 * Attaches a popupmenu to all elements with attribute 'data-popupmenu'
	 */
	private attachPopupmenus(): void {
		setTimeout(() => {
			const popupmenus = $('.lm-ctc-area');
			for (let i = 0; i < popupmenus.length; i++) {
				this.attachPopupmenu($(popupmenus[i]));
			}
		}, 500);
	}

	static add(m: ng.IModule) {
		m.controller("lmMyPagesCtrl", MyPagesCtrl);
	}
}

/**
 * Page About Controller
 * 
 * Controller for the About Page dialog.
 */
export class PageAboutCtrl extends c.CoreBase {
	private dialog: lm.IDialog;
	private lang: ILanguageLime;

	static $inject = ["$scope", "lmContainerService", "lmDialogService", "lmLanguageService"];

	constructor(public scope: any, private containerService: container.IContainerService, private dialogService: lm.IDialogService, private languageService: c.ILanguageService) {
		super("[PageAboutCtrl] ");
		this.dialog = scope["lmDialog"];
		scope["applicationVersion"] = containerService.getContainer().data.version;
		this.lang = languageService.getLanguage();
	}

	private showUserSettings(): void {
		var options: lm.IDialogOptions = {
			title: this.lang.userPermissions,
			templateUrl: "scripts/lime/templates/page-user-settings.html"
		}
		this.dialogService.show(options);
	}

	static add(m: ng.IModule) {
		m.controller("lmPageAboutCtrl", PageAboutCtrl);
	}
}

/**
 * Page User Settings Controller
 * 
 * Controller for the User Settings tab in the About Page dialog.
 */
export class PageUserSettingsCtrl extends c.CoreBase {
	public orderedSettings: lm.IAutocompleteEntity[];

	private dialog: lm.IDialog;
	private lang: ILanguageLime;
	private settings: c.IServerSettings;
	private maxUserPages: string;

	static $inject = ["$scope", "lmContextService", "lmLanguageService"];

	constructor(public scope: any, private contextService: c.IContextService, private languageService: c.ILanguageService) {
		super("[PageUserSettingsCtrl] ");

		const dialog: lm.IDialog = scope["lmDialog"];
		this.dialog = dialog;
		this.settings = contextService.getContext().settings;
		this.lang = languageService.getLanguage();
		this.orderedSettings = this.createOrderedSettingsObject();
	}

	/**
	 * Closes the dialog.
	 */
	public close(): void {
		this.dialog.close();
	}

	/**
	 * Creates a settings array with translated content.
	 */
	private createOrderedSettingsObject(): lm.IAutocompleteEntity[] {
		const settings = this.settings;
		const lang = this.lang;
		const orderedSettings: lm.IAutocompleteEntity[] = [];

		this.maxUserPages = lang.format(lang.maxUserPages, settings.getMaxUserPageCount());
		// Page
		orderedSettings.push({
			label: lang.enablePrivatePages,
			value: settings.isPrivatePagesEnabled()
		});
		orderedSettings.push({
			label: lang.enablePageCatalog,
			value: settings.isPageCatalogEnabled()
		});
		orderedSettings.push({
			label: lang.enablePublicPageAdd,
			value: settings.isPublicPageAddEnabled()
		});
		orderedSettings.push({
			label: lang.enablePublicPageCopy,
			value: settings.isPublicPageCopyEnabled()
		});
		orderedSettings.push({
			label: lang.enablePagePublish,
			value: settings.isPagePublishEnabled()
		});
		orderedSettings.push({
			label: lang.enablePageExport,
			value: settings.isPageExportEnabled()
		});
		orderedSettings.push({
			label: lang.enablePageImport,
			value: settings.isPageImportEnabled()
		});
		orderedSettings.push({
			label: lang.selectionOfHomepage,
			value: settings.isSelectHomepageEnabled()
		});

		// Widget and translation
		orderedSettings.push({
			label: lang.enableWidgetPublish,
			value: settings.isWidgetPublishEnabled()
		});
		orderedSettings.push({
			label: lang.enableContentTranslation,
			value: settings.isContentTranslationEnabled()
		});

		return orderedSettings;
	}

	static add(m: ng.IModule) {
		m.controller("lmPageUserSettingsCtrl", PageUserSettingsCtrl);
	}
}

class MyPagesDirective {
	static add(m: ng.IModule) {
		m.directive("lmMyPages", ["$compile", ($compile) => {
			return {
				scope: false,
				restrict: "E",
				replace: false,
				controller: MyPagesCtrl,
				controllerAs: "lmMyPagesCtrl",
				templateUrl: "scripts/lime/templates/my-pages.html"
			};
		}]);
	}
}

// TODO Where to place this?
class SliderDirective {
	private liWidth: number = 0;

	constructor(private scope: ng.IScope, private element: ng.IAugmentedJQuery, private $compile: ng.ICompileService) {

		var div = $("<div/>").addClass("lm-slider-list-container");
		element.addClass("lm-slider-list");
		element.wrap(div);

		var previous = $('<button ng-show="showPrevious"><svg class="icon" aria-hidden="true" focusable="false"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-previous-page" /></svg></button>');
		previous.addClass("lm-slider-button lm-slider-button-previous");
		previous.insertAfter(element.parent());
		previous.click(() => {
			scope.$apply(() => {
				this.scroll(-this.liWidth);
			});
		});
		$compile(previous)(scope);

		var next = $('<button ng-show="showNext"><svg class="icon" aria-hidden="true" focusable="false"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-next-page" /></svg></button>');
		next.addClass("lm-slider-button lm-slider-button-next");
		next.insertAfter(previous);
		next.click(() => {
			scope.$apply(() => {
				this.scroll(this.liWidth);
			});
		});
		$compile(next)(scope);

		this.setShowPrevious(false);
		this.setShowNext(true);

		scope["slideIntoView"] = (index) => {
			var child = <HTMLLIElement>(this.element.children("li")[index]);
			if (this.liWidth == 0) {
				this.setWidth();
			}
			this.slideIntoView(child);
		}

		// Update when number of children changes
		scope.$watch(() => {
			var length = this.element.children().length;
			return length;
		}, () => {
			this.initialize();
			if (this.liWidth == 0) {
				this.setWidth();
				//this.pushOutScroll(); // TODO: push out or use css?
			}
		});

		//TODO: ok? Will it run to often?
		$(window).on("resize", () => {
			scope.$apply(() => {
				this.initialize();
			});
		});

		scope.$on("$destroy", () => {
			$(window).off();
		});
	}

	private initialize() {
		var currentScroll = this.element.parent()[0].scrollLeft;
		this.setShowButtons(currentScroll);
	}

	private setShowButtons(scrollValue) {
		//var width = this.element[0].clientWidth; // or this.element.outerWidth();
		var width = this.element.parent().width();
		var maxScroll = this.element.parent()[0].scrollWidth;

		var isNoScroll = width + 1 >= maxScroll;
		if (isNoScroll) {
			this.setShowNext(false);
			this.setShowPrevious(false);
		} else {
			if (scrollValue + width >= maxScroll) {
				this.setShowPrevious(true);
				this.setShowNext(false);
			}
			else if (scrollValue <= 1) {
				this.setShowPrevious(false);
				this.setShowNext(true);
			} else {
				this.setShowPrevious(true);
				this.setShowNext(true);
			}
		}
	}

	// TODO: Currently not used Remove if choose to use css
	private pushOutScroll() {
		// Push scroll out of window
		var h = this.element.parent().parent().height();
		var bl = parseFloat(getComputedStyle(this.element[0]).borderLeftWidth);
		var br = parseFloat(getComputedStyle(this.element[0]).borderRightWidth);
		var top = this.element.parent().position().top;

		var scrollbarHeight = this.element[0].offsetHeight - this.element[0].clientHeight - bl - br;
		this.element.css("height", h - top + scrollbarHeight); // TODO: Push scroll out of window or use classes?
	}

	private setWidth() {
		var e = this.element.children("li");
		if (e.length > 0) {
			var child = e.first();
			this.liWidth = child.outerWidth();
		}
	}

	private scroll(scrollValue) {
		var scrollNext = this.element.parent().scrollLeft() + scrollValue;
		this.element.parent().animate({ scrollLeft: scrollNext }, 200);
		//this.element.parent().scrollLeft(scrollNext);	
		this.setShowButtons(scrollNext);
	}

	private setShowPrevious(show) {
		this.scope["showPrevious"] = show;
	}

	private setShowNext(show) {
		this.scope["showNext"] = show;
	}

	private slideIntoView(li: HTMLLIElement) {
		if (li == null) {
			return;
		}
		this.scroll(this.distanceIntoView(li));
	}

	private distanceIntoView(elem: HTMLLIElement): number {
		var ulLeft = $(this.element.parent()).offset().left - $(this.element.parent()).position().left;
		var ulRight = ulLeft + $(this.element.parent()).innerWidth();

		var elemLeft = $(elem).position().left;
		var elemRight = Math.round(elemLeft + $(elem).outerWidth()) + 1; // Scroll 1 extra px

		var returnVal = 0;
		if (elemRight > ulRight) {
			returnVal = elemRight - ulRight;
		}
		else if (elemLeft < ulLeft) {
			returnVal = elemLeft - ulLeft;
		}
		return returnVal;
	}

	static add(m: ng.IModule) {
		m.directive("lmSlider", ["$compile", ($compile) => {
			return {
				scope: false,
				restrict: "A",
				link: (scope: ng.IScope, element: ng.IAugmentedJQuery, attributes: ng.IAttributes, controller: any, transclude: ng.ITranscludeFunction) => {
					var directive = new SliderDirective(scope, element, $compile);
				}
			};
		}]);
	}
}

export var init = (m: ng.IModule) => {
	PageSettingsCtrl.add(m);
	AddPageCtrl.add(m);
	CopyPageCtrl.add(m);
	PageCustomizationCtrl.add(m);
	MyPagesCtrl.add(m);
	PageAboutCtrl.add(m);
	PageUserSettingsCtrl.add(m);
	MyPagesDirective.add(m);
	SliderDirective.add(m);
};