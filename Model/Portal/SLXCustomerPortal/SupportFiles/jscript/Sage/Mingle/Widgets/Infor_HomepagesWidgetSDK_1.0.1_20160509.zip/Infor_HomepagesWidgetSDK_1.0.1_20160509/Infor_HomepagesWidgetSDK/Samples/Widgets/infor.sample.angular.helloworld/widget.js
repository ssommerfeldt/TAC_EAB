/// <reference path="../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../scripts/typings/lime/lime.d.ts" />
define(["require", "exports", "lime"], function (require, exports, lm) {
    var HelloWorldCtrl = (function () {
        function HelloWorldCtrl(scope) {
            var _this = this;
            this.scope = scope;
            this.defaultColor = "1A1A1A";
            // Get the widget context and the widget instance that are made available on the scope by the framework
            this.widgetContext = scope[lm.WidgetConstants.widgetContextKey];
            this.widgetInstance = scope[lm.WidgetConstants.widgetInstanceKey];
            // Subscribe to the event that is triggered when settings are saved to be able to update the message text
            this.widgetInstance.settingsSaved = function () {
                _this.updateContent();
            };
            // Initial update of the message text and color
            this.updateContent();
        }
        HelloWorldCtrl.prototype.getColor = function () {
            var color = this.widgetContext.getSettings().get("Color");
            return color || this.defaultColor;
        };
        HelloWorldCtrl.prototype.updateContent = function () {
            var message = this.widgetContext.getSettings().get("Message");
            var color = "#" + this.getColor();
            this.scope["message"] = message;
            this.scope["color"] = color;
        };
        HelloWorldCtrl.add = function (m) {
            m.controller("HelloWorldCtrl", HelloWorldCtrl);
        };
        // Use the $inject array to avoid issues with minification
        HelloWorldCtrl.$inject = ["$scope"];
        return HelloWorldCtrl;
    })();
    // Widget factory function
    exports.widgetFactory = function (context) {
        // Add the controller class to the provided AngularJS module
        var m = context.getAngularContext().module;
        HelloWorldCtrl.add(m);
        // Create and return the widget instance
        var instance = {
            angularConfig: {
                template: "<div ng-controller='HelloWorldCtrl as ctrl'><h1 ng-bind='message' ng-style=\"{'margin-top': '20px', 'text-align': 'center', 'color': color}\"></h1></div>"
            }
        };
        return instance;
    };
});
//# sourceMappingURL=widget.js.map