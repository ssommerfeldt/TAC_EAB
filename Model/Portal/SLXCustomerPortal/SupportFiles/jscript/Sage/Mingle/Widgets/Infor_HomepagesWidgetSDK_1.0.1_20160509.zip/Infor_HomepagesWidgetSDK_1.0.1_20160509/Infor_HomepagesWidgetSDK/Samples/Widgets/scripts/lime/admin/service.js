var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../core", "../lime"], function (require, exports, c, lm) {
    var AdminOperations = (function () {
        function AdminOperations() {
        }
        AdminOperations.updateRules = "updateRules";
        AdminOperations.importData = "import";
        AdminOperations.exportData = "export";
        return AdminOperations;
    })();
    exports.AdminOperations = AdminOperations;
    var AdminConstants = (function () {
        function AdminConstants() {
        }
        AdminConstants.openTab = "openTab";
        AdminConstants.settingsTab = "settings";
        AdminConstants.propertiesTab = "properties";
        AdminConstants.privatePagesTab = "privatePages";
        AdminConstants.publishedPagesTab = "publishedPages";
        AdminConstants.publishedWidgetsTab = "publishedWidgets";
        AdminConstants.standardWidgetsTab = "standardWidgets";
        AdminConstants.errorsTab = "errors";
        AdminConstants.gridPageSize = 15;
        AdminConstants.checkStatusInterval = 2000;
        AdminConstants.parameterIncludeSettings = "includesettings";
        AdminConstants.parameterIncludeUserSettings = "includeusersettings";
        AdminConstants.parameterIncludeSettingsRules = "includesettingsrules";
        AdminConstants.parameterIncludeProperties = "includeproperties";
        AdminConstants.parameterIncludePrivatePages = "includeprivatepages";
        AdminConstants.parameterIncludePublishedPages = "includepublishedpages";
        AdminConstants.parameterIncludePublishedPageConnections = "includepublishedpageconnections";
        AdminConstants.parameterIncludePublishedPageAccess = "includepublishedpageaccess";
        AdminConstants.parameterIncludePublishedWidgets = "includepublishedwidgets";
        AdminConstants.parameterIncludePublishedWidgetAccess = "includepublishedwidgetaccess";
        AdminConstants.parameterIncludeRoles = "includeroles";
        AdminConstants.parameterUserSettingsFilter = "usersettingsfilter";
        AdminConstants.parameterPublishedWidgetsFilter = "publishedwidgetsfilter";
        AdminConstants.parameterPublishedPagesFilter = "publishedpagesfilter";
        AdminConstants.parameterPrivatePagesFilter = "privatepagesfilter";
        return AdminConstants;
    })();
    exports.AdminConstants = AdminConstants;
    var SettingValueInfo = (function () {
        function SettingValueInfo() {
        }
        return SettingValueInfo;
    })();
    exports.SettingValueInfo = SettingValueInfo;
    var AppInfo = (function () {
        function AppInfo() {
        }
        return AppInfo;
    })();
    exports.AppInfo = AppInfo;
    var AdminService = (function (_super) {
        __extends(AdminService, _super);
        function AdminService(rootScope, q, dataService, progressService, dialogService, cacheService) {
            _super.call(this, "[AdminService] ");
            this.rootScope = rootScope;
            this.q = q;
            this.dataService = dataService;
            this.progressService = progressService;
            this.dialogService = dialogService;
            this.cacheService = cacheService;
            this.publishedPages = null;
            this.allWidgets = null;
            this.roles = null;
            this.invalidatedCachesEvent = new c.InstanceEvent();
            this.isRoleRequestPending = false;
            var createCache = cacheService.createCache;
            var constants = c.Constants;
            this.standardWidgetsCache = createCache(constants.adminCacheStandardWidgets);
            this.publishedWidgetsCache = createCache(constants.adminCachePublishedWidgets);
            this.publishedPagesCache = createCache(constants.adminCachePublishedPages);
            this.propertiesCache = createCache(constants.adminCacheProperties);
            this.privatePagesCache = createCache(constants.adminCachePrivatePages);
            this.rolesCache = createCache(constants.adminCacheRoles);
        }
        AdminService.prototype.getTool = function () {
            return this.dataService.executePost("/admin/tool");
        };
        AdminService.prototype.updateTool = function (adminTool) {
            var request = { content: adminTool };
            return this.dataService.executePost("/admin/tool/update", request);
        };
        AdminService.prototype.updateSettingRules = function (setting) {
            var request = { content: setting };
            return this.dataService.executePost("/admin/setting/rule/update", request);
        };
        AdminService.prototype.listProperties = function (reload) {
            var _this = this;
            var deferred = this.q.defer();
            if (!this.propertiesCache.isValid || reload) {
                this.dataService.executePost("/admin/property/list", {}).then(function (response) {
                    _this.cacheService.updateCache(_this.propertiesCache, response, deferred);
                }, function (response) {
                    _this.propertiesCache.isValid = false;
                    deferred.reject(response);
                });
            }
            else {
                deferred.resolve(this.propertiesCache.cachedResponse);
            }
            return deferred.promise;
        };
        AdminService.prototype.searchRoles = function (query) {
            var _this = this;
            var deferred = this.q.defer();
            this.getRoles(false).then(function (response) {
                if (response.content) {
                    var queryLower = query.toLowerCase();
                    var matches = lm.ArrayUtil.findAll(response.content, function (item) {
                        try {
                            if (item) {
                                if (item.id && item.id.toLowerCase().indexOf(queryLower) !== -1) {
                                    return true;
                                }
                                return false;
                            }
                            return false;
                        }
                        catch (error) {
                            lm.Log.error(_this.logPrefix + "Failed to filter " + error);
                        }
                    });
                    var result = [];
                    if (matches) {
                        for (var i = 0; i < 10; i++) {
                            var item = matches[i];
                            if (item) {
                                var entity = {
                                    label: item.id || item.name,
                                    value: item.id,
                                    type: c.PrincipalType.Role
                                };
                                if (item.name) {
                                    entity.info = item.name;
                                }
                                result.push(entity);
                            }
                        }
                    }
                    deferred.resolve(result);
                }
                else {
                    deferred.reject();
                }
            }, function () { deferred.reject(); });
            return deferred.promise;
        };
        AdminService.prototype.getRoles = function (reload) {
            var _this = this;
            var deferred = this.q.defer();
            var self = this;
            if (!self.rolesCache.isValid || reload) {
                if (this.isRoleRequestPending) {
                    return this.lastUsedListDeferred.promise;
                }
                this.isRoleRequestPending = true;
                this.lastUsedListDeferred = deferred;
                self.dataService.executePost("/admin/role/list", {}).then(function (response) {
                    _this.isRoleRequestPending = false;
                    lm.ArrayUtil.sortByProperty(response.content, "id");
                    self.cacheService.updateCache(self.rolesCache, response, deferred);
                }, function (response) {
                    _this.isRoleRequestPending = false;
                    self.rolesCache.isValid = false;
                    deferred.reject(response);
                });
            }
            else {
                deferred.resolve(self.rolesCache.cachedResponse);
            }
            return deferred.promise;
        };
        AdminService.prototype.createProperty = function (property) {
            var request = { content: property };
            return this.dataService.executePost("/admin/property/create", request);
        };
        AdminService.prototype.updateProperty = function (property) {
            var request = { content: property };
            return this.dataService.executePost("/admin/property/update", request);
        };
        AdminService.prototype.deleteProperty = function (propertyId) {
            var request = { content: propertyId };
            return this.dataService.executePost("/admin/property/delete", request);
        };
        AdminService.prototype.exportProperties = function (properties) {
            var query = "";
            if (properties) {
                for (var i = 0; i < properties.length; i++) {
                    query += i == 0 ? "?keys=" + properties[i].propertyId : "&keys=" + properties[i].propertyId;
                }
            }
            var url = this.dataService.getUrl("admin/property/export/" + encodeURI("properties") + ".json") + query;
            if (this.isDebug()) {
                this.debug("Executing url " + url);
            }
            window.open(url, '_blank');
        };
        AdminService.prototype.listPrivatePages = function (userId, reload) {
            var _this = this;
            var request = { content: userId };
            var deferred = this.q.defer();
            if (!this.privatePagesCache.isValid || reload) {
                this.dataService.executePost("/admin/page/private/list", request).then(function (response) {
                    _this.cacheService.updateCache(_this.privatePagesCache, response, deferred);
                }, function (response) {
                    _this.privatePagesCache.isValid = false;
                    deferred.reject(response);
                });
            }
            else {
                deferred.resolve(this.privatePagesCache.cachedResponse);
            }
            return deferred.promise;
        };
        AdminService.prototype.listPublishedPages = function (reload) {
            var _this = this;
            var deferred = this.q.defer();
            if (!this.publishedPagesCache.isValid || reload) {
                this.dataService.executePost("/admin/page/published/list", {}).then(function (response) {
                    response.content = _this.sortPublishedPages(response.content);
                    _this.cacheService.updateCache(_this.publishedPagesCache, response, deferred);
                }, function (response) {
                    _this.publishedPagesCache.isValid = false;
                    deferred.reject(response);
                });
            }
            else {
                deferred.resolve(this.publishedPagesCache.cachedResponse);
            }
            return deferred.promise;
        };
        AdminService.prototype.sortPublishedPages = function (pages) {
            return pages.sort(function (x, y) {
                var xTitle = x["title"] ? x["title"] : x["data"]["title"];
                var yTitle = y["title"] ? y["title"] : y["data"]["title"];
                var a = xTitle.toLocaleLowerCase();
                var b = yTitle.toLocaleLowerCase();
                if (a > b) {
                    return 1;
                }
                else if (a < b) {
                    return -1;
                }
                return 0;
            });
        };
        AdminService.prototype.deletePrivatePages = function (pages) {
            return this.dataService.executePost("/admin/page/private/delete", { content: pages });
        };
        AdminService.prototype.exportPublishedPages = function (pages) {
            var query = "";
            if (pages) {
                for (var i = 0; i < pages.length; i++) {
                    query += i == 0 ? "?keys=" + pages[i].data.id : "&keys=" + pages[i].data.id;
                }
            }
            var url = this.dataService.getUrl("admin/page/published/export/" + encodeURI("pages") + ".zip") + query;
            if (this.isDebug()) {
                this.debug("Executing url " + url);
            }
            window.open(url, "_blank");
        };
        AdminService.prototype.exportPrivatePages = function (userId, pages) {
            var query = "";
            if (pages) {
                for (var i = 0; i < pages.length; i++) {
                    query += i == 0 ? "?keys=" + pages[i].data.id : "&keys=" + pages[i].data.id;
                }
            }
            var url = this.dataService.getUrl("admin/page/private/export/" + userId + "/" + encodeURI("pages") + ".zip") + query;
            if (this.isDebug()) {
                this.debug("Executing url " + url);
            }
            window.open(url, "_blank");
        };
        AdminService.prototype.listStandardWidgets = function (reload) {
            var _this = this;
            var deferred = this.q.defer();
            if (!this.standardWidgetsCache.isValid || reload) {
                this.dataService.executePost("/admin/widget/standard/list", {}).then(function (response) {
                    _this.cacheService.updateCache(_this.standardWidgetsCache, response, deferred);
                }, function (response) {
                    _this.standardWidgetsCache.isValid = false;
                    deferred.reject(response);
                });
            }
            else {
                deferred.resolve(this.standardWidgetsCache.cachedResponse);
            }
            return deferred.promise;
        };
        AdminService.prototype.listPublishedWidgets = function (reload) {
            var _this = this;
            var deferred = this.q.defer();
            var publishedWidgetsCache = this.publishedWidgetsCache;
            if (!publishedWidgetsCache.isValid || reload) {
                this.dataService.executePost("/admin/widget/published/list", {}).then(function (response) {
                    _this.cacheService.updateCache(publishedWidgetsCache, response, deferred);
                }, function (response) {
                    publishedWidgetsCache.isValid = false;
                    deferred.reject(response);
                });
            }
            else {
                deferred.resolve(publishedWidgetsCache.cachedResponse);
            }
            return deferred.promise;
        };
        AdminService.prototype.exportPublishedWidgets = function (widgets) {
            var query = "";
            if (widgets) {
                for (var i = 0; i < widgets.length; i++) {
                    query += i == 0 ? "?keys=" + widgets[i].widgetId : "&keys=" + widgets[i].widgetId;
                }
            }
            var url = this.dataService.getUrl("admin/widget/published/export/" + encodeURI("widgets") + ".zip") + query;
            window.open(url, "_blank");
        };
        AdminService.prototype.getWidgetAccess = function (options) {
            var request = { content: options };
            return this.dataService.executePost("/admin/widget/access", request);
        };
        AdminService.prototype.updateWidgetAccess = function (options) {
            var request = { content: options };
            return this.dataService.executePost("/admin/widget/access/update", request);
        };
        AdminService.prototype.getPageAccess = function (pageId) {
            var request = { content: pageId };
            return this.dataService.executePost("/admin/page/access", request);
        };
        AdminService.prototype.updatePageAccess = function (pageAccess) {
            var request = { content: pageAccess };
            return this.dataService.executePost("/admin/page/access/update", request);
        };
        AdminService.prototype.openImportFilesDialog = function (options) {
            var dialogOptions = {
                title: options.title,
                templateUrl: "scripts/lime/admin/templates/import-dialog.html",
                style: "width:450px;",
                parameter: options
            };
            return this.dialogService.show(dialogOptions);
        };
        AdminService.prototype.startExportOperation = function (parameters) {
            return this.dataService.executePost("/admin/operation/export", { parameters: parameters });
        };
        AdminService.prototype.startImportOperation = function (parameters) {
            return this.dataService.executePost("/admin/operation/import", { parameters: parameters });
        };
        AdminService.prototype.cancelOperation = function () {
            return this.dataService.executePost("/admin/operation/cancel", {});
        };
        AdminService.prototype.getOperationStatus = function () {
            return this.dataService.executePost("/admin/operation/status", {});
        };
        AdminService.prototype.downloadExportFile = function () {
            var url = this.dataService.getUrl("admin/operation/export/download/" + encodeURI("LimeExport") + ".zip");
            if (this.isDebug()) {
                this.debug("Executing url " + url);
            }
            window.open(url, "_blank");
        };
        AdminService.prototype.onCachesInvalidated = function () {
            return this.invalidatedCachesEvent;
        };
        AdminService.prototype.invalidateCaches = function (options) {
            if (options[AdminConstants.parameterIncludeProperties] === true) {
                this.propertiesCache.isValid = false;
            }
            if (options[AdminConstants.parameterIncludePrivatePages] === true) {
                this.privatePagesCache.isValid = false;
            }
            if (options[AdminConstants.parameterIncludePublishedPages] === true) {
                this.publishedPagesCache.isValid = false;
            }
            if (options[AdminConstants.parameterIncludePublishedWidgets] === true) {
                this.publishedWidgetsCache.isValid = false;
            }
            if (options[AdminConstants.parameterIncludeRoles] === true) {
                this.rolesCache.isValid = false;
            }
            this.invalidatedCachesEvent.raise(options);
        };
        AdminService.prototype.setBusy = function (isBusy) {
            this.rootScope["lmBusy"] = isBusy;
        };
        AdminService.prototype.isBusy = function () {
            return this.rootScope["lmBusy"] ? true : false;
        };
        AdminService.prototype.getError = function () {
            return this.dataService.executePost("/management/error/status/node", {});
        };
        AdminService.prototype.handleError = function (response, message) {
            this.dataService.handleError(response, message);
        };
        AdminService.prototype.getPageDisplayTitle = function (value, pages) {
            var adminTool = this.rootScope["lmAdminTool"];
            var translations = adminTool.translations;
            var displayValue = "";
            var values = null;
            if (value) {
                if (value.indexOf(",") !== -1) {
                    values = value.split(",");
                }
                var publishedPages = this.publishedPages;
                if (values) {
                    if (publishedPages) {
                        angular.forEach(publishedPages, function (page) {
                            if (page.data.id === values[0]) {
                                displayValue = page.title || page.data.title;
                            }
                        });
                    }
                    else {
                        if (values[0] in translations) {
                            displayValue = translations[values[0]];
                        }
                        else {
                            displayValue = values[0];
                        }
                    }
                    if (values.length > 1) {
                        displayValue += " (+" + (values.length - 1) + " more)";
                    }
                }
                else {
                    if (publishedPages) {
                        angular.forEach(publishedPages, function (page) {
                            if (page.data.id === value) {
                                displayValue = page.title || page.data.title;
                            }
                        });
                    }
                    else {
                        if (translations && translations[value]) {
                            displayValue = translations[value];
                        }
                        else {
                            displayValue = value;
                        }
                    }
                }
            }
            else {
                displayValue = "";
            }
            return displayValue;
        };
        AdminService.prototype.showUploadCompleteDialog = function (title, message, isError) {
            return this.dialogService.showMessage({
                title: title,
                message: message,
                isError: isError
            });
        };
        AdminService.prototype.updatePageOwner = function (pageData) {
            return this.dataService.executePost("/page/owner/update", { content: pageData });
        };
        AdminService.prototype.openChangeOwnerDialog = function (title, currentOwnerId, callback) {
            var options = {
                title: "Change Owner - " + title,
                templateUrl: "scripts/lime/admin/templates/change-owner.html",
                style: "width: 100%; max-width: 500px;",
                parameter: currentOwnerId
            };
            this.dialogService.show(options).then(function (dialogResult) {
                var value = dialogResult.value;
                if (dialogResult.button === lm.DialogButtonType.Ok && value) {
                    callback(value);
                }
            });
        };
        AdminService.prototype.clearOrReplaceWidgetAccess = function (widgets, isReplace, callback, accessCopy) {
            var _this = this;
            this.progressService.setBusy(true);
            var nrOfWidgetsToUpdate = widgets.length;
            angular.forEach(widgets, function (updateWidget) {
                _this.updateWidgetAccess({ id: updateWidget.widgetId, accessList: isReplace ? accessCopy : [] }).then(function () {
                    nrOfWidgetsToUpdate -= 1;
                    if (nrOfWidgetsToUpdate === 0) {
                        callback();
                    }
                }, function (r) {
                    _this.handleError(r);
                    _this.progressService.setBusy(false);
                });
            });
        };
        AdminService.prototype.openWidgetAccessDialog = function (widget, callback) {
            var _this = this;
            var progressService = this.progressService;
            var options = {
                title: "Widget Permissions - " + widget.title,
                templateUrl: "scripts/lime/admin/templates/widget-access.html",
                style: "width: 100%; max-width: 600px;"
            };
            progressService.setBusy(true);
            this.getWidgetAccess({ id: widget.widgetId, accessList: [] }).then(function (r) {
                options.parameter = { accessList: r.content.accessList, id: widget.widgetId };
                progressService.setBusy(false);
                _this.dialogService.show(options).then(function (dialogResult) {
                    var value = dialogResult.value;
                    if (dialogResult.button === lm.DialogButtonType.Ok && value) {
                        progressService.setBusy(true);
                        _this.updateWidgetAccess({ id: widget.widgetId, accessList: value }).then(function (info) {
                            callback(info);
                        }, function (result) {
                            _this.handleError(result);
                            progressService.setBusy(false);
                        });
                    }
                });
            }, function (r) {
                _this.handleError(r);
                progressService.setBusy(false);
            });
        };
        AdminService.prototype.applyWidgetAccess = function (widgets, accessCopy, callback) {
            var _this = this;
            var progressService = this.progressService;
            var existingAccess;
            var nrOfWidgetsToUpdate = widgets.length;
            progressService.setBusy(true);
            angular.forEach(widgets, function (updateWidget) {
                _this.getWidgetAccess({ id: updateWidget.widgetId, accessList: [] }).then(function (r) {
                    existingAccess = r.content.accessList;
                    angular.forEach(accessCopy, function (accessEntity) {
                        var accessUpdateIndex = lm.ArrayUtil.indexByProperty(existingAccess, "principal", accessEntity.principal);
                        if (accessUpdateIndex !== -1) {
                            existingAccess[accessUpdateIndex] = accessEntity;
                        }
                        else {
                            existingAccess.push(accessEntity);
                        }
                    });
                    _this.updateWidgetAccess({ id: updateWidget.widgetId, accessList: existingAccess }).then(function () {
                        nrOfWidgetsToUpdate -= 1;
                        if (nrOfWidgetsToUpdate === 0) {
                            callback();
                        }
                    }, function (result) {
                        _this.handleError(result);
                        progressService.setBusy(false);
                    });
                }, function (r) {
                    _this.handleError(r);
                    progressService.setBusy(false);
                });
            });
        };
        AdminService.prototype.openPageAccessDialog = function (page, callback) {
            var self = this;
            var progressService = self.progressService;
            progressService.setBusy(true);
            this.getPageAccess(page.data.id).then(function (r) {
                if (r.content) {
                    var options = {
                        title: "Page Permissions",
                        templateUrl: "scripts/lime/admin/templates/page-access.html",
                        parameter: r.content,
                        style: "width: 100%; max-width: 600px;"
                    };
                    progressService.setBusy(false);
                    self.dialogService.show(options).then(function (res) {
                        var value = res.value;
                        if (res.button === lm.DialogButtonType.Ok && value) {
                            progressService.setBusy(true);
                            self.updatePageAccess(value).then(function (result) {
                                callback();
                            }, function (result) {
                                progressService.setBusy(false);
                                self.handleError(result);
                            });
                        }
                    });
                }
            }, function (r) {
                progressService.setBusy(false);
                self.handleError(r);
            });
        };
        AdminService.prototype.clearOrReplacePageAccess = function (pages, isReplace, callback, accessCopy) {
            var _this = this;
            var nrOfPagesToUpdate = pages.length;
            this.progressService.setBusy(true);
            angular.forEach(pages, function (updatePage) {
                _this.updatePageAccess(isReplace ? { pageId: updatePage.data.id, roleAccess: accessCopy.roleAccess, userAccess: accessCopy.userAccess }
                    : { pageId: updatePage.data.id, roleAccess: [], userAccess: {} }).then(function () {
                    nrOfPagesToUpdate -= 1;
                    if (nrOfPagesToUpdate === 0) {
                        callback();
                    }
                }, function (r) {
                    _this.handleError(r);
                    _this.progressService.setBusy(false);
                });
            });
        };
        AdminService.prototype.applyPageAccess = function (pages, accessCopy, callback) {
            var _this = this;
            var progressService = this.progressService;
            var existingAccess;
            var existingRoleAccess;
            var existingUserAccess;
            var nrOfPagesToUpdate = pages.length;
            progressService.setBusy(true);
            angular.forEach(pages, function (updatePage) {
                _this.getPageAccess(updatePage.data.id).then(function (r) {
                    existingAccess = r.content;
                    existingRoleAccess = existingAccess.roleAccess ? existingAccess.roleAccess : [];
                    existingUserAccess = $.isEmptyObject(existingAccess.userAccess) ? {} : existingAccess.userAccess;
                    angular.forEach(accessCopy.roleAccess, function (roleAccessEntity) {
                        var accessUpdateIndex = lm.ArrayUtil.indexByProperty(existingRoleAccess, "principal", roleAccessEntity.principal);
                        if (accessUpdateIndex !== -1) {
                            existingRoleAccess[accessUpdateIndex] = roleAccessEntity;
                        }
                        else {
                            existingRoleAccess.push(roleAccessEntity);
                        }
                    });
                    for (var i in accessCopy.userAccess) {
                        if (accessCopy.userAccess.hasOwnProperty(i)) {
                            existingUserAccess[i] = accessCopy.userAccess[i];
                        }
                    }
                    existingAccess.roleAccess = existingRoleAccess;
                    existingAccess.userAccess = existingUserAccess;
                    _this.updatePageAccess(existingAccess).then(function (result) {
                        nrOfPagesToUpdate -= 1;
                        if (nrOfPagesToUpdate === 0) {
                            callback();
                        }
                    }, function (result) {
                        _this.handleError(result);
                        progressService.setBusy(false);
                    });
                }, function (r) {
                    _this.handleError(r);
                    progressService.setBusy(false);
                });
            });
        };
        AdminService.prototype.unselectGridItem = function (item, gridApi) {
            if (lm.ArrayUtil.containsByProperty(gridApi.selection.getSelectedRows(), '$$hashKey', item.$$hashKey)) {
                gridApi.selection.toggleRowSelection(item);
                gridApi.selection.getSelectedRows();
                return gridApi.selection.getSelectedRows().length;
            }
        };
        AdminService.prototype.getDeletePageOptions = function (pages, isPrivate) {
            var pagesList = pages.map(function (page) {
                return page.data.id;
            });
            var isMultiple = (pagesList.length > 1);
            var title = isMultiple ? "Delete Pages" : "Delete Page";
            var message = isMultiple ? "Are you sure that you want to delete the selected pages?" :
                "Are you sure that you want to delete the page?";
            if (!isPrivate) {
                message = message + (isMultiple ? " They will be deleted for all users." : " It will be deleted for all users.");
            }
            var options = {
                title: title,
                message: message,
                standardButtons: lm.StandardDialogButtons.YesNo
            };
            return options;
        };
        AdminService.add = function (m) {
            m.service("lmAdminService", AdminService);
        };
        AdminService.$inject = ["$rootScope", "$q", "lmDataService", "lmProgressService", "lmDialogService", "lmCacheService"];
        return AdminService;
    })(c.CoreBase);
    var AdminContext = (function () {
        function AdminContext(q, location, adminService) {
            this.q = q;
            this.location = location;
            this.adminService = adminService;
            c.ClientConfiguration.initialize(location);
        }
        AdminContext.prototype.isLocalhost = function () {
            return this.location.host() === "localhost";
        };
        AdminContext.prototype.initialize = function () {
            var _this = this;
            var deferred = this.q.defer();
            this.adminService.getTool().then(function (r) {
                _this.adminTool = r.content;
                deferred.resolve(r);
            }, function (r) {
                deferred.reject(r);
            });
            return deferred.promise;
        };
        AdminContext.prototype.get = function () {
            return this.adminTool;
        };
        AdminContext.add = function (m) {
            m.service("lmAdminContext", AdminContext);
        };
        AdminContext.$inject = ["$q", "$location", "lmAdminService"];
        return AdminContext;
    })();
    var AdminImportDialogCtrl = (function (_super) {
        __extends(AdminImportDialogCtrl, _super);
        function AdminImportDialogCtrl(scope, dataService) {
            _super.call(this, "[AdminImportDialogCtrl] ");
            this.scope = scope;
            this.dataService = dataService;
            this.dialog = null;
            var dialog = scope["lmDialog"];
            if (!dialog) {
                this.error("lmDialog was not found in scope when opening import dialog.");
                return;
            }
            this.dialog = dialog;
            var dialogParam = dialog.parameter;
            this.options = dialogParam;
            this.acceptFileExtension = dialogParam.acceptFileExtension || ".zip";
            this.buttonText = dialogParam.buttonText || "Import";
        }
        AdminImportDialogCtrl.add = function (m) {
            m.controller("lmAdminImportDialogCtrl", AdminImportDialogCtrl);
        };
        AdminImportDialogCtrl.prototype.close = function () {
            this.dialog.close({ button: lm.DialogButtonType.Cancel });
        };
        AdminImportDialogCtrl.prototype.import = function (files) {
            if (!files) {
                this.debug("No file was selected.");
                return;
            }
            var dialog = this.dialog;
            var options = this.options;
            this.dataService.upload("/admin", options.operation, files, options.formFields).then(function (response) {
                var message = "";
                var messageList = response.messageList;
                if (messageList) {
                    angular.forEach(messageList, function (msg) {
                        message += msg.message;
                    });
                }
                dialog.close({ button: lm.DialogButtonType.Yes, value: { message: message, responseCode: c.DialogResponseCode.Success } });
            }, function (response) {
                var errorMsg = "";
                if (response.errorList) {
                    angular.forEach(response.errorList, function (error) {
                        errorMsg += error.message;
                    });
                }
                dialog.close({ button: lm.DialogButtonType.Yes, value: { message: errorMsg, responseCode: c.DialogResponseCode.Fail } });
            });
        };
        AdminImportDialogCtrl.$inject = ["$scope", "lmDataService"];
        return AdminImportDialogCtrl;
    })(c.CoreBase);
    var GuidSearchDialogCtrl = (function (_super) {
        __extends(GuidSearchDialogCtrl, _super);
        function GuidSearchDialogCtrl(scope) {
            _super.call(this, "[GuidSearchDialogCtrl] ");
            this.scope = scope;
            this.dialog = null;
            var dialog = scope["lmDialog"];
            if (!dialog) {
                this.error("lmDialog is not found in scope when opening guid search dialog.");
                return;
            }
            this.dialog = dialog;
        }
        GuidSearchDialogCtrl.prototype.close = function () {
            this.dialog.close({ button: lm.DialogButtonType.Cancel });
        };
        GuidSearchDialogCtrl.prototype.search = function (files) {
            this.dialog.close({
                button: lm.DialogButtonType.Ok,
                value: this.scope["searchString"]
            });
        };
        GuidSearchDialogCtrl.add = function (m) {
            m.controller("lmGuidSearchDialogCtrl", GuidSearchDialogCtrl);
        };
        GuidSearchDialogCtrl.$inject = ["$scope"];
        return GuidSearchDialogCtrl;
    })(c.CoreBase);
    var ChangeOwnerCtrl = (function (_super) {
        __extends(ChangeOwnerCtrl, _super);
        function ChangeOwnerCtrl(scope, commonDataService) {
            var _this = this;
            _super.call(this, "[ChangeOwnerCtrl] ");
            this.scope = scope;
            this.commonDataService = commonDataService;
            this.dialog = null;
            var dialog = scope["lmDialog"];
            if (!dialog) {
                this.error("lmDialog is not found in scope when opening change owner dialog.");
                return;
            }
            this.currentOwner = dialog.parameter;
            this.dialog = dialog;
            var self = this;
            this.autocompleteOptions = {
                source: function (query, done) {
                    self.commonDataService.searchUsers(query).then(function (response) {
                        lm.ArrayUtil.removeByProperty(response.content, "userName", self.currentOwner);
                        done(query, lm.ArrayUtil.sortByProperty(c.CoreUtil.getEntityArray(response.content), "label"));
                    });
                },
                template: c.Templates.autocompleteEntity
            };
            this.autocompleteElem = $("#autocomplete-change-owner");
            this.autocompleteElem.on("selected", function (event, target, object) {
                if (lm.CommonUtil.isUndefined(object) && self.currentOwner !== object.value) {
                    return;
                }
                self.selectedOwner = object;
                self.scope.$apply("selectedOwner");
            });
            scope.$on("$destroy", function () {
                _this.autocompleteElem.off();
            });
        }
        ChangeOwnerCtrl.prototype.onCancel = function () {
            this.dialog.close({ button: lm.DialogButtonType.Cancel });
        };
        ChangeOwnerCtrl.prototype.onOk = function () {
            this.dialog.close({
                button: lm.DialogButtonType.Ok,
                value: this.selectedOwner
            });
        };
        ChangeOwnerCtrl.add = function (m) {
            m.controller("lmChangeOwnerCtrl", ChangeOwnerCtrl);
        };
        ChangeOwnerCtrl.$inject = ["$scope", "lmCommonDataService"];
        return ChangeOwnerCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        AdminService.add(m);
        AdminContext.add(m);
        AdminImportDialogCtrl.add(m);
        GuidSearchDialogCtrl.add(m);
        ChangeOwnerCtrl.add(m);
    };
});
//# sourceMappingURL=service.js.map