﻿/// <reference path="../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../scripts/typings/lime/lime.d.ts" />

import lm = require("lime");

class HelloWorldCtrl {
	private defaultColor = "1A1A1A";
	private widgetContext: lm.IWidgetContext;
	private widgetInstance: lm.IWidgetInstance;

	// Use the $inject array to avoid issues with minification
	static $inject = ["$scope"];

	constructor(public scope: ng.IScope) {
		// Get the widget context and the widget instance that are made available on the scope by the framework
		this.widgetContext = scope[lm.WidgetConstants.widgetContextKey];
		this.widgetInstance = scope[lm.WidgetConstants.widgetInstanceKey];

		// Subscribe to the event that is triggered when settings are saved to be able to update the message text
		this.widgetInstance.settingsSaved = () => {
			this.updateContent();
		};

		// Initial update of the message text and color
		this.updateContent();
	}

	private getColor(): string {
		var color = this.widgetContext.getSettings().get<string>("Color");
		return color || this.defaultColor;
	}

	private updateContent() {
		var message = this.widgetContext.getSettings().get<string>("Message");
		var color = "#" + this.getColor();
		this.scope["message"] = message;
		this.scope["color"] = color;
	}

	public static add(m: ng.IModule) {
		m.controller("HelloWorldCtrl", HelloWorldCtrl);
	}
}

// Widget factory function
export var widgetFactory = (context: lm.IWidgetContext): lm.IWidgetInstance => {

	// Add the controller class to the provided AngularJS module
	var m = context.getAngularContext().module;
	HelloWorldCtrl.add(m);

	// Create and return the widget instance
	var instance: lm.IWidgetInstance = {
		angularConfig: <lm.IAngularWidgetConfig> {
			template: "<div ng-controller='HelloWorldCtrl as ctrl'><h1 ng-bind='message' ng-style=\"{'margin-top': '20px', 'text-align': 'center', 'color': color}\"></h1></div>"
		}
	};
	return instance;
};