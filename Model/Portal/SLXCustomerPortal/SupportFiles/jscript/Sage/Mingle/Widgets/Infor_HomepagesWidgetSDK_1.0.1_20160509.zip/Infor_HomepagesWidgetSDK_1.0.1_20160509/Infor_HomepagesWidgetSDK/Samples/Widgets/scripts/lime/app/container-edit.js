var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../lime", "../core", "../app/widget", "../app/page"], function (require, exports, lm, c, w, p) {
    var PageEditCtrl = (function (_super) {
        __extends(PageEditCtrl, _super);
        function PageEditCtrl(scope, rootScope, compile, widgetService, editModeService, contextService, languageService, dialogService) {
            var _this = this;
            _super.call(this, "[PageEditCtrl] ");
            this.scope = scope;
            this.rootScope = rootScope;
            this.compile = compile;
            this.widgetService = widgetService;
            this.editModeService = editModeService;
            this.contextService = contextService;
            this.languageService = languageService;
            this.dialogService = dialogService;
            this.isEditMode = false;
            this.lang = languageService.getLanguage();
            var unsubscribe = editModeService.started().on(function (editMode) {
                if (editMode.isActive && editMode.mode === c.EditModes.layout) {
                    _this.setEditModeActions(editMode);
                    _this.initialize();
                }
            });
            this.scope.widgetEditData = {};
            scope.$on("$describe", function () {
                unsubscribe();
            });
        }
        PageEditCtrl.prototype.setEditModeActions = function (editMode) {
            var lang = this.lang;
            var self = this;
            editMode.actions = [
                {
                    text: lang.cancel,
                    cssClass: "e2e-editPageCancel",
                    execute: function () {
                        self.close();
                    }
                },
                {
                    text: lang.save,
                    cssClass: "e2e-editPageSave",
                    execute: function () {
                        self.save();
                    }
                }
            ];
            var secondaryActions = [{
                    text: lang.addWidget,
                    execute: function () {
                        self.addWidgetFromCatalog();
                    }
                }];
            if (this.scope.clipboardWidget) {
                secondaryActions.push({
                    text: lang.pasteWidget,
                    execute: function () {
                        self.pasteWidget();
                    }
                });
            }
            editMode.secondaryActions = secondaryActions;
        };
        PageEditCtrl.prototype.onWidgetDropped = function (widget) {
            var editData = this.scope.widgetEditData;
            var widgets = this.widgets;
            var widgetElementId = widget.elementId;
            var editElementId = editData.elementId;
            if (lm.CommonUtil.isUndefined(editElementId) || lm.CommonUtil.isUndefined(widgetElementId)) {
                return;
            }
            var fromIndex = lm.ArrayUtil.indexByProperty(widgets, "elementId", editElementId);
            var toIndex = lm.ArrayUtil.indexByProperty(widgets, "elementId", widgetElementId);
            if (fromIndex === -1 || toIndex === -1) {
                this.refreshLayout();
                return;
            }
            lm.ArrayUtil.move(widgets, fromIndex, toIndex);
            this.scope.$apply("lmPageEditCtrl.widgets");
            this.refreshLayout();
        };
        PageEditCtrl.prototype.onWidgetResized = function () {
            var editData = this.scope.widgetEditData;
            var widgets = this.widgets;
            var editElementId = editData.elementId;
            if (lm.CommonUtil.isUndefined(editData.elementId) || lm.CommonUtil.isUndefined(editData.widgetLayout) ||
                !lm.ArrayUtil.containsByProperty(widgets, "elementId", editElementId)) {
                return;
            }
            var widget = lm.ArrayUtil.itemByProperty(widgets, "elementId", editElementId);
            widget.layout = editData.widgetLayout;
            this.refreshLayout();
        };
        PageEditCtrl.prototype.refreshLayout = function () {
            p.PageUtil.refreshHomepageLayout(this.homepage);
        };
        PageEditCtrl.prototype.addWidgetFromCatalog = function () {
            var context = this.page.getWidgetParentContext();
            var widgetService = this.widgetService;
            var self = this;
            widgetService.showCatalog(context, function (w, c) { self.addWidget(w, c); }).then(function () {
            }, function (r) { lm.Log.error("Could not open Widget Catalog."); });
        };
        PageEditCtrl.prototype.pasteWidget = function () {
            var _this = this;
            var widgetCopy = this.scope.clipboardWidget;
            var widgetService = this.widgetService;
            var context = this.page.getWidgetParentContext();
            var addWidgetInfo = widgetService.getAddWidgetInfo(widgetCopy);
            widgetService.preAddWidget(context, addWidgetInfo).then(function (widget) {
                _this.addWidgetInternal(widget, false);
            }, function () {
                _this.dialogService.showMessage({ title: _this.lang.unableToAddWidget, message: _this.lang.brokenWidget, isError: true });
            });
        };
        PageEditCtrl.prototype.addWidget = function (addWidgetInfo, busyCallback) {
            var _this = this;
            var context = this.page.getWidgetParentContext();
            this.widgetService.preAddWidget(context, addWidgetInfo, busyCallback).then(function (widget) {
                _this.addWidgetInternal(widget, true);
            }, function () {
                _this.dialogService.showMessage({ title: _this.lang.unableToAddWidget, message: _this.lang.brokenWidget, isError: true });
            });
        };
        PageEditCtrl.prototype.addWidgetInternal = function (widget, showToastConfirmation) {
            var _this = this;
            var editableWidget = this.createEditableWidget(widget, { row: 0, rowSpan: 1, column: 0, columnSpan: 1 });
            editableWidget.widget = widget;
            editableWidget.elementId = lm.CommonUtil.random();
            this.widgets.push(editableWidget);
            setTimeout(function () {
                _this.refreshLayout();
            }, 1);
            if (showToastConfirmation) {
                var lang = this.languageService.getLanguage();
                this.dialogService.showToast({ title: lang.widgetAdded, message: lang.format(lang.titleAddedMessage, editableWidget.title) });
            }
        };
        PageEditCtrl.prototype.deleteWidget = function (widget) {
            var _this = this;
            var element = $("#" + widget.elementId);
            if (element.length > 0) {
                angular.element($("#" + widget.elementId)).scope().$destroy();
            }
            lm.ArrayUtil.remove(this.widgets, widget);
            setTimeout(function () {
                _this.refreshLayout();
            }, 50);
        };
        PageEditCtrl.prototype.createEditableWidget = function (widget, layout) {
            var data = widget.data;
            var title = widget.title;
            return {
                title: title,
                layout: layout ? layout : angular.copy(data.layout),
                isPlaceholder: false,
                id: data.id,
                elementId: widget.elementId
            };
        };
        PageEditCtrl.prototype.getLayoutClasses = function (widget) {
            return widget.layout ? w.WidgetUtil.getLayoutClasses(widget.layout) : "";
        };
        PageEditCtrl.prototype.stopEdit = function (isSave) {
            var updatedWidgets = [];
            var widgets = this.widgets;
            var homepage = this.homepage;
            if (isSave) {
                var widgetElements = homepage.find(".widget").not(".placeholder");
                for (var i = 0; i < widgetElements.length; i++) {
                    var widgetLayout = p.PageUtil.getLayout($(widgetElements[i]), this.homepageSettings);
                    widgets[i].layout = widgetLayout;
                }
                updatedWidgets = angular.copy(widgets);
            }
            p.PageUtil.destroyHomepageControl(homepage);
            delete this.scope.onRepeatCompleted;
            this.editModeService.stop({ isSave: isSave, result: updatedWidgets });
        };
        PageEditCtrl.prototype.close = function () {
            this.stopEdit(false);
        };
        PageEditCtrl.prototype.save = function () {
            this.stopEdit(true);
        };
        PageEditCtrl.prototype.initialize = function () {
            var editableWidgets = [];
            var ctrl = this.scope["lmPageNavigatorCtrl"];
            if (ctrl) {
                this.page = ctrl.currentPage;
                var widgets = this.page.widgets;
                for (var _i = 0; _i < widgets.length; _i++) {
                    var widget = widgets[_i];
                    editableWidgets.push(this.createEditableWidget(widget));
                }
                var homepage = $(".lm-page-edit .homepage");
                this.homepage = homepage;
                p.PageUtil.addHomepageControl(homepage);
                var homepageData = homepage.data("homepage");
                this.homepageSettings = homepageData.settings;
                this.scope["widgetEditData"].homepageSettings = this.homepageSettings;
                var self = this;
                setTimeout(function () {
                    self.refreshLayout();
                    self.scope.onRepeatCompleted = function () {
                        self.refreshLayout();
                    };
                }, 1);
            }
            this.widgets = editableWidgets;
        };
        PageEditCtrl.add = function (m) {
            m.controller("lmPageEditCtrl", PageEditCtrl);
        };
        PageEditCtrl.$inject = ["$scope", "$rootScope", "$compile", "lmWidgetService", "lmEditModeService", "lmContextService", "lmLanguageService", "lmDialogService"];
        return PageEditCtrl;
    })(c.CoreBase);
    var PageEditDirective = (function () {
        function PageEditDirective() {
        }
        PageEditDirective.add = function (m) {
            m.directive("lmPageEdit", ["$compile", function ($compile) {
                    return {
                        scope: false,
                        restrict: "E",
                        replace: false,
                        controller: PageEditCtrl,
                        controllerAs: "lmPageEditCtrl",
                        templateUrl: "scripts/lime/templates/page-edit.html"
                    };
                }]);
        };
        return PageEditDirective;
    })();
    var XiDraggableDirective = (function () {
        function XiDraggableDirective() {
        }
        XiDraggableDirective.add = function (m) {
            m.directive("xiDraggable", [
                "$compile", function ($compile) {
                    return {
                        scope: false,
                        restrict: "A",
                        link: function (scope, elem, attrs) {
                            var widget = scope["widget"];
                            elem["draggable"]({
                                revertDuration: 150,
                                helper: "clone",
                                opacity: 0.8,
                                scrollSensitivity: 200,
                                scrollSpeed: 10,
                                start: function (event, ui) {
                                    var target = $(event.target);
                                    $(".lm-page-edit .widget").addClass("ui-draggable-passive");
                                    target.removeClass("ui-draggable-passive");
                                    target.addClass("ui-draggable-cloned");
                                    var editData = scope["widgetEditData"];
                                    editData.elementId = widget.elementId;
                                },
                                stop: function (event, ui) {
                                    $(".lm-page-edit .widget").removeClass("ui-draggable-passive");
                                    $(event.target).removeClass("ui-draggable-cloned");
                                }
                            });
                            elem["droppable"]({
                                greedy: true,
                                tolerance: "pointer",
                                hoverClass: "ui-droppable-active",
                                drop: function (event, ui) {
                                    scope.$eval(attrs["onDropped"]);
                                }
                            });
                            elem["resizable"]({
                                handles: "e, s",
                                autoHide: true,
                                start: function (event, ui) {
                                    $(".lm-page-edit .widget").addClass("ui-resizable-passive");
                                    $(event.target).removeClass("ui-resizable-passive");
                                    var editData = scope["widgetEditData"];
                                    editData.elementId = widget.elementId;
                                    editData.widgetLayout = widget.layout;
                                },
                                stop: function (event, ui) {
                                    $(".lm-page-edit .widget").removeClass("ui-resizable-passive");
                                    var editData = scope["widgetEditData"];
                                    var diffWidth = ui.size.width - ui.originalSize.width;
                                    var diffHeight = ui.size.height - ui.originalSize.height;
                                    var isChanged = false;
                                    var element = $(ui.element);
                                    var settings = editData.homepageSettings;
                                    var columnSpan = editData.widgetLayout.columnSpan;
                                    var rowSpan = editData.widgetLayout.rowSpan;
                                    if (Math.abs(diffWidth) > settings.widgetWidth / 2) {
                                        isChanged = true;
                                        element.removeClass("double-width triple-width quad-width");
                                        var widthUnits = ui.size.width / settings.widgetWidth;
                                        if (widthUnits > 3.5) {
                                            element.addClass("quad-width");
                                            columnSpan = 4;
                                        }
                                        else if (widthUnits > 2.5) {
                                            element.addClass("triple-width");
                                            columnSpan = 3;
                                        }
                                        else if (widthUnits > 1.5) {
                                            element.addClass("double-width");
                                            columnSpan = 2;
                                        }
                                        else {
                                            columnSpan = 1;
                                        }
                                    }
                                    if (Math.abs(diffHeight) > settings.widgetHeight / 2) {
                                        element.removeClass("double-height");
                                        isChanged = true;
                                        var heightUnits = ui.size.height / settings.widgetHeight;
                                        if (heightUnits > 1.5) {
                                            element.addClass("double-height");
                                            rowSpan = 2;
                                        }
                                        else {
                                            rowSpan = 1;
                                        }
                                    }
                                    element.css({ "height": "", "width": "" });
                                    if (isChanged) {
                                        editData.widgetLayout.columnSpan = columnSpan;
                                        editData.widgetLayout.rowSpan = rowSpan;
                                        scope.$eval(attrs["onResized"]);
                                    }
                                }
                            });
                        }
                    };
                }
            ]);
        };
        return XiDraggableDirective;
    })();
    exports.init = function (m) {
        PageEditDirective.add(m);
        PageEditCtrl.add(m);
        XiDraggableDirective.add(m);
    };
});
//# sourceMappingURL=container-edit.js.map