﻿import angular = require("angular");
import lm = require("./lime");
import core = require("./core");
import container = require("./app/container");
import containerEdit = require("./app/container-edit");
import service = require("./service");
import widget = require("./app/widget");
import page = require("./app/page");
import common = require("./components/common");
import pageLibrary = require("./page-library/page-library");
import widgetLibrary = require("./widget-library/widget-library");
import translations = require("./translations/translations");
import roleAccess = require("./role-access/role-access");
import tc = require("./templates/template-cache");
import mingle = require("./mingle");

var configureModule = (m: ng.IModule): void => {
	m.config([
		"$controllerProvider", "$provide", "$compileProvider", "$locationProvider", ($controllerProvider, $provide, $compileProvider, $locationProvider) => {
			m.controller = $controllerProvider.register;
			m.service = $provide.service;
			m.directive = $compileProvider.directive;
			$locationProvider.html5Mode({
				enabled: true,
				requireBase: false
			});
		}
	]);
};

var configureCaching = (m: ng.IModule): void => {
	m.run([
		"$location", "$templateCache", ($location, $templateCache) => {
			tc.TemplateCacher.cache($location, $templateCache);
		}
	]);
}

var externalModule = angular.module("lime", ["ui.sortable", "sohoxi"]);
configureModule(externalModule);

var internalModule = angular.module("lime.internal", ["ui.sortable", "sohoxi", "mingle.services", "mingle.factories", "lime"]);
configureModule(internalModule);
configureCaching(internalModule);

mingle.init(internalModule);

var version = "1.0.1";
infor.lime.version = version;
lm.Log.info("[Lime] Framework version " + version);

core.init(externalModule);
service.init(externalModule, internalModule);
widget.init(externalModule, internalModule);

page.init(internalModule);
container.init(internalModule);
containerEdit.init(internalModule);
common.init(internalModule);
pageLibrary.init(internalModule);
widgetLibrary.init(internalModule);
translations.init(internalModule);
roleAccess.init(internalModule);

export = internalModule;