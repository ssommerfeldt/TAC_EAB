var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../lime", "../../core"], function (require, exports, lm, c) {
    var PageAccessCtrl = (function (_super) {
        __extends(PageAccessCtrl, _super);
        function PageAccessCtrl(scope) {
            _super.call(this, "[PageAccessCtrl] ");
            this.scope = scope;
            this.dialog = null;
            this.dialog = scope["lmDialog"];
            var pageAccess = this.dialog.parameter;
            this.pageAccess = angular.copy(pageAccess);
            scope["roleAccess"] = pageAccess.roleAccess ? angular.copy(pageAccess.roleAccess) : [];
            scope["userAccess"] = $.isEmptyObject(pageAccess.userAccess) ? {} : angular.copy(pageAccess.userAccess);
        }
        PageAccessCtrl.prototype.save = function () {
            var pageAccess = this.pageAccess;
            pageAccess.roleAccess = this.scope["roleAccess"];
            pageAccess.userAccess = this.scope["userAccess"];
            var result = {
                button: lm.DialogButtonType.Ok,
                value: pageAccess
            };
            this.dialog.close(result);
        };
        PageAccessCtrl.prototype.cancel = function () {
            this.dialog.close();
        };
        PageAccessCtrl.add = function (m) {
            m.controller("lmPageAccessCtrl", PageAccessCtrl);
        };
        PageAccessCtrl.$inject = ["$scope"];
        return PageAccessCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        PageAccessCtrl.add(m);
    };
});
//# sourceMappingURL=page-access.js.map