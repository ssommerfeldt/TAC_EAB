define(["require", "exports", "angular"], function (require, exports, angular) {
    var IMP;
    var shell = {};
    infor["mingleshell"] = shell;
    var _constants = {
        Constants: {
            MsgType: {
                "PROXYMESSAGE": "workspaceProxyMessage",
                "SUBSCRIBE": "workspaceClientSubscribe",
                "DEFAULTMESSAGEHANDLER": "defaultMessageHandler",
                "INITCLIENT": "initClient",
                "DRILLBACK": "prepareApplicationDrillback",
                "APPINITCOMPLETED": "appInitComplete",
                "PROCESSDRILLBACK": "applicationDrillback",
                "SHORTCUTCONTEXT": "setShortcutContext",
                "IBC": "inforBusinessContext"
            },
            InitMethod: {
                "IMPLICIT": "Implicit",
                "EXPLICIT": "Explicit"
            },
            InternalMessages: [
                "setShortcutContext",
                "initClient",
                "appInitComplete",
                "defaultMessageHandler",
                "workspaceClientSubscribe",
                "generic_",
                "prepareFavoriteContext",
            ]
        }
    };
    shell = IMP = $.extend(shell, _constants);
    var mingleShellServices = angular.module('mingle.services', []);
    var mingleShellFactories = angular.module('mingle.factories', []);
    mingleShellFactories.factory("MessageHandlerFactory", ['commonFactory', 'Listener', 'Publisher', 'GlobalListener',
        function (commonFactory, Listener, Publisher, GlobalListener) {
            'use strict';
            var messageHandlerFactory = {};
            messageHandlerFactory.process = function (msg) {
                if (!commonFactory.IsNullOrEmpty(msg.type)) {
                    switch (msg.type) {
                        case IMP.Constants.MsgType.PROXYMESSAGE:
                            this.handleProxyMessage(msg.data);
                            break;
                        case IMP.Constants.MsgType.INITCLIENT:
                            this.registerInitClient(msg);
                            break;
                        case IMP.Constants.MsgType.PROCESSDRILLBACK:
                            this.handlePublishMessage(msg);
                            break;
                        default:
                            this.subscribeCustomMessage(msg);
                            break;
                    }
                }
            };
            messageHandlerFactory.subscribeCustomMessage = function (msg) {
                var modifiedMsg = { 'messageType': msg.type, 'callback': msg.callback };
                Listener.Add(modifiedMsg);
            };
            messageHandlerFactory.handleProxyMessage = function (msg) {
                if (typeof (msg) !== 'undefined') {
                    if (msg.type == IMP.Constants.MsgType.SUBSCRIBE) {
                        this.handleSubscriptionMessage(msg.data);
                    }
                    else {
                        this.handlePublishMessage(msg);
                    }
                }
            };
            messageHandlerFactory.registerInitClient = function (msg) {
                var modifiedMsg = { 'messageType': msg.type, 'callback': msg.callback };
                Listener.Add(modifiedMsg);
            };
            messageHandlerFactory.handleSubscriptionMessage = function (msg) {
                if (msg.messageType == IMP.Constants.MsgType.SyndicationMsgHandler) {
                    this.handleGlobalSubscriptionMessage(msg);
                }
                else {
                    Listener.Add(msg);
                }
            };
            messageHandlerFactory.handleGlobalSubscriptionMessage = function (msg) {
                GlobalListener.AddToGlobalMessages(msg);
            };
            messageHandlerFactory.handlePublishMessage = function (msg) {
                Publisher.Publish(Listener.GetListeners(), msg);
            };
            messageHandlerFactory.handleShortcutContextMessage = function (msg) {
                var modifiedMsg = { 'messageType': msg.type, 'callback': msg.callback };
                Listener.Add(modifiedMsg);
            };
            return messageHandlerFactory;
        }]);
    mingleShellFactories.factory("GlobalListener", ['commonFactory',
        function (commonFactory) {
            'use strict';
            var _globalListenerFactory = {};
            var globalMessages = [];
            _globalListenerFactory.AddToGlobalMessages = function (msg) {
                globalMessages.push(msg);
            };
            return _globalListenerFactory;
        }]);
    mingleShellFactories.factory("Listener", ['commonFactory',
        function (commonFactory) {
            'use strict';
            var _listenerFactory = {};
            var listeners = {};
            _listenerFactory.GetListeners = function () {
                return listeners;
            };
            _listenerFactory.Add = function (msg) {
                var bAddlistener = true;
                if (bAddlistener == true) {
                    if (typeof (listeners) === 'undefined')
                        listeners = {};
                    if (typeof (listeners[msg.messageType]) === 'undefined')
                        listeners[msg.messageType] = [];
                    var sameMsgFound = false;
                    angular.forEach(listeners[msg.messageType], function (obj, idx) {
                        if (typeof (obj.iframeName) !== 'undefined' && typeof (msg.iframeName) !== 'undefined' && msg.iframeName == obj.iframeName) {
                            sameMsgFound = true;
                            listeners[msg.messageType][idx] = msg;
                        }
                    }, this);
                    if (!sameMsgFound)
                        listeners[msg.messageType].push(msg);
                }
            },
                _listenerFactory.Remove = function (siteName, msg) {
                };
            return _listenerFactory;
        }]);
    mingleShellFactories.factory("Publisher", ['commonFactory',
        function (commonFactory) {
            'use strict';
            var _publisher = {};
            _publisher.Publish = function (listeners, msg) {
                var registeredListeners = this.getRegisteredListeners(listeners, msg.type);
                angular.forEach(registeredListeners, function (obj, idx) {
                    if (typeof (obj) !== 'undefined')
                        obj["valid"] = true;
                });
                if ((typeof (msg.data) === 'undefined' || msg.data.length == 0) && msg.type.toLowerCase() == IMP.Constants.MsgType.IBC.toLowerCase()) {
                    msg = { "data": { "screenId": "" } };
                }
                this.processMessage(registeredListeners, msg);
            },
                _publisher.processMessage = function (registeredListeners, msg) {
                    angular.forEach(registeredListeners, function (obj, idx) {
                        var target = null;
                        if (typeof (obj.callback) === 'function') {
                            obj.callback(msg.data);
                        }
                        else if (!commonFactory.IsNullOrEmpty(obj.iframeName) && obj.valid) {
                            if ($('iframe[name="' + obj.iframeName + '"]').length > 0)
                                target = $('iframe[name="' + obj.iframeName + '"]').get(0).contentWindow;
                        }
                        else {
                            target = null;
                        }
                        if (target != null) {
                            this.sendMessage(target, msg);
                        }
                    }, this);
                },
                _publisher.getRegisteredListeners = function (listeners, messageType) {
                    if (typeof (listeners) === 'undefined') {
                        return [];
                    }
                    if (typeof (listeners[messageType]) === 'undefined') {
                        return [];
                    }
                    return listeners[messageType];
                },
                _publisher.sendMessage = function (target, msg) {
                    var jsonMsg = JSON.stringify(msg);
                    target.postMessage(jsonMsg, "*");
                };
            return _publisher;
        }]);
    mingleShellFactories.factory('commonFactory', [
        function () {
            'use strict';
            var factory = {};
            factory.isValidMsg = function (data) {
                return true;
            };
            factory.getScope = function (elem) {
                var el = angular.element(elem);
                var elScope = el.scope();
                return elScope;
            };
            factory.IsNullOrEmpty = function (inputStr) {
                return ((typeof (inputStr) === 'undefined' || inputStr === null || inputStr.trim().length === 0) ? true : false);
            };
            factory.isValidMessage = function (jsonMsg) {
                if (typeof (jsonMsg.type) !== 'undefined' &&
                    jsonMsg.type !== null &&
                    typeof (jsonMsg.data) !== 'undefined' &&
                    jsonMsg.data !== null) {
                    return true;
                }
                else {
                    return false;
                }
            };
            return factory;
        }]);
    mingleShellServices.service('MingleMessageBroker', ['commonFactory', 'MessageHandlerFactory',
        function (commonFactory, MessageHandlerFactory) {
            'use strict';
            var _self = this;
            this.currentApplicationId = "";
            this.registeredListeners = {};
            this.initialize = function () {
                this.setupMessageListener();
            };
            this.setupMessageListener = function () {
                if (window.postMessage != null) {
                    if (window.addEventListener) {
                        window.addEventListener('message', this.onMessageReceived, false);
                    }
                }
            };
            this.onMessageReceived = function (ev) {
                try {
                    var incomingMessage = $.parseJSON(ev.data);
                    if (commonFactory.isValidMessage(incomingMessage)) {
                        MessageHandlerFactory.process(incomingMessage);
                    }
                    else {
                    }
                }
                catch (e) {
                }
            };
            this.publish = function (msg) {
                MessageHandlerFactory.process(msg);
            };
            this.register = function (msgType, callback) {
                MessageHandlerFactory.process({ 'type': msgType, 'callback': callback });
            };
        }]);
    exports.init = function (m) {
    };
});
//# sourceMappingURL=mingle.js.map