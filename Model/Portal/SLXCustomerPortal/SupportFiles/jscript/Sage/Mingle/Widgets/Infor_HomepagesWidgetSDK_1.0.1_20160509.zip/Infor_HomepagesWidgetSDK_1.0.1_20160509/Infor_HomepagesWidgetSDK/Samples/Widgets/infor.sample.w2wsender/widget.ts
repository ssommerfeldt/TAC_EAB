﻿import lm = require("lime");

interface IPerson {
	id: number;
	lastName: string;
	firstName: string;
	title: string;
	status: string;
	anniversary: string;
}

// Mock data
const persons: IPerson[] = [
	{
		id: 1,
		lastName: "Asper",
		firstName: "David",
		title: "Engineer",
		status: "Fulltime employee",
		anniversary: "2015-01-12"
	},
	{
		id: 2,
		lastName: "Baxter",
		firstName: "Michael",
		title: "System Architect",
		status: "Freelance 3-6months",
		anniversary: "2008-05-27"
	},
	{
		id: 3,
		lastName: "John",
		firstName: "Steven",
		title: "Graphic Designer",
		status: "Fulltime employee",
		anniversary: "2001-02-17"
	},
	{
		id: 4,
		lastName: "Donald",
		firstName: "Samual",
		title: "System Architect",
		status: "Fulltime employee",
		anniversary: "1989-11-05"
	},
	{
		id: 5,
		lastName: "Bronte",
		firstName: "Emily",
		title: "Quality Assurance Analyst",
		status: "Fulltime employee",
		anniversary: "2010-09-21"
	},
	{
		id: 6,
		lastName: "Davendar",
		firstName: "Konda",
		title: "Engineer",
		status: "Fulltime employee",
		anniversary: "2003-12-05"
	},
	{
		id: 7,
		lastName: "Little",
		firstName: "Jeremy",
		title: "Quality Assurance Analyst",
		status: "Fulltime employee",
		anniversary: "1999-01-13"
	},
	{
		id: 8,
		lastName: "Ayers",
		firstName: "Julie",
		title: "Architect",
		status: "Freelance 3-6months",
		anniversary: "2012-06-17"
	},
	{
		id: 9,
		lastName: "Ortega",
		firstName: "Hector",
		title: "Senior Architect",
		status: "Freelance 3-6months",
		anniversary: "2013-07-01"
	},
	{
		id: 10,
		lastName: "McConnel",
		firstName: "Mary",
		title: "Engineer",
		status: "Freelance 3-6months",
		anniversary: "2013-07-01"
	}
];

class W2WSenderCtrl implements lm.IWidgetInstance {
	public persons: IPerson[];

	private widgetContext: lm.IWidgetContext;
	private instanceId: string;
	private pageId: string;
	private language: lm.ILanguage;
	private messageType: string;
	private logPrefix: string;

	static $inject = ["$scope"];

	constructor(public scope: ng.IScope) {
		// Get the widget context and instance from the scope
		const widgetContext = scope[lm.WidgetConstants.widgetContextKey];
		const widgetInstance = scope[lm.WidgetConstants.widgetInstanceKey];

		this.widgetContext = widgetContext;
		this.language = widgetContext.getLanguage();
		this.instanceId = widgetContext.getWidgetInstanceId();
		const pageId = widgetContext.getPageId();
		this.pageId = pageId;
		this.logPrefix = "[" + widgetContext.getId() + "] ";

		// Subscribe to the event that is triggered when settings are saved to be able to update the message type
		widgetInstance.settingsSaved = () => {
			this.updateMessageType();
		};

		// Set initial message type used for communication
		this.updateMessageType();

		this.persons = persons;
	}

	private updateMessageType(): void {
		const messageType = this.widgetContext.getSettings().get<string>("MessageType");
		const newMessageType = messageType + this.pageId;
		if (!lm.StringUtil.isNullOrWhitespace(messageType) && newMessageType !== this.messageType) {
			this.messageType = newMessageType;

			lm.Log.debug(this.logPrefix + "Message type updated to: " + newMessageType);
		}
	}

	public sendMessage(person: IPerson): void {
		if (person) {
			infor.companyon.client.sendMessage(this.messageType, person);

			lm.Log.debug(this.logPrefix + "Message sent for message type: " + this.messageType);
		}
	}

	public static add(m: ng.IModule): void {
		m.controller("W2WSenderCtrl", W2WSenderCtrl);
	}
}

export var widgetFactory = (context: lm.IWidgetContext): lm.IWidgetInstance => {
	const m = context.getAngularContext().module;
	W2WSenderCtrl.add(m);

	return {
		angularConfig: {
			relativeTemplateUrl: "widget.html"
		}
	};
};