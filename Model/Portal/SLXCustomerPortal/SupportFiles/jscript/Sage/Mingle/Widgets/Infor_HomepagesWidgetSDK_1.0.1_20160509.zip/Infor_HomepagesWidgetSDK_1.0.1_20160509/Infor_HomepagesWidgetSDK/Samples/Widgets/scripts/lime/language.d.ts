﻿declare module infor.lime {
	var version: string;
	var ResourcesKeys: any;
	var language: string;
	var requireFunction: any;
	var requireConfig: any;
}

/**
 * Represents the lime framework language constants.
 */
interface ILanguageLime {
	format(...args: any[]): string;
	get(name: string): string;    
	/**
 	 * Cancel
 	 */
 	cancel: string; 
 	/**
 	 * OK
 	 */
 	ok: string; 
 	/**
 	 * My Pages
 	 */
 	myPages: string; 
 	/**
 	 * Page Catalog
 	 */
 	pageCatalog: string; 
 	/**
 	 * Widget Catalog
 	 */
 	widgetCatalog: string; 
 	/**
 	 * Add
 	 */
 	add: string; 
 	/**
 	 * Close
 	 */
 	close: string; 
 	/**
 	 * Are you sure that you want to remove the page '{0}'? The page will still be available in the Page Catalog.
 	 */
 	confirmRemovePublicPage: string; 
 	/**
 	 * Duplicate Page...
 	 */
 	duplicatePageEllipsis: string; 
 	/**
 	 * Create
 	 */
 	create: string; 
 	/**
 	 * Delete Widget
 	 */
 	deleteWidget: string; 
 	/**
 	 * Import
 	 */
 	importAction: string; 
 	/**
 	 * Import Page
 	 */
 	importPage: string; 
 	/**
 	 * New Page
 	 */
 	newPage: string; 
 	/**
 	 * No
 	 */
 	no: string; 
 	/**
 	 * Page Settings
 	 */
 	pageSettings: string; 
 	/**
 	 * Page Settings...
 	 */
 	pageSettingsEllipsis: string; 
 	/**
 	 * Publish
 	 */
 	publish: string; 
 	/**
 	 * Read Only
 	 */
 	readOnly: string; 
 	/**
 	 * Refresh
 	 */
 	refresh: string; 
 	/**
 	 * Remove Page
 	 */
 	removePage: string; 
 	/**
 	 * Remove Page...
 	 */
 	removePageEllipsis: string; 
 	/**
 	 * Save
 	 */
 	save: string; 
 	/**
 	 * Select
 	 */
 	select: string; 
 	/**
 	 * Settings
 	 */
 	settings: string; 
 	/**
 	 * Title
 	 */
 	title: string; 
 	/**
 	 * Used by {0}
 	 */
 	usedByCount: string; 
 	/**
 	 * Application Widgets
 	 */
 	widgetCategoryApplication: string; 
 	/**
 	 * Business Intelligence Widgets
 	 */
 	widgetCategoryBI: string; 
 	/**
 	 * Business Process Widgets
 	 */
 	widgetCategoryProcess: string; 
 	/**
 	 * Social Widgets
 	 */
 	widgetCategorySocial: string; 
 	/**
 	 * Utility Widgets
 	 */
 	widgetCategoryUtility: string; 
 	/**
 	 * All
 	 */
 	categoryAll: string; 
 	/**
 	 * Application
 	 */
 	categoryApplication: string; 
 	/**
 	 * Business Intelligence
 	 */
 	categoryBI: string; 
 	/**
 	 * Business Process
 	 */
 	categoryProcess: string; 
 	/**
 	 * Social
 	 */
 	categorySocial: string; 
 	/**
 	 * Utilities
 	 */
 	categoryUtilities: string; 
 	/**
 	 * Yes
 	 */
 	yes: string; 
 	/**
 	 * Add Page
 	 */
 	addPage: string; 
 	/**
 	 * by {0}
 	 */
 	byUser: string; 
 	/**
 	 * Last edited by {0}
 	 */
 	lastEditedBy: string; 
 	/**
 	 * Mandatory
 	 */
 	mandatory: string; 
 	/**
 	 * Owner
 	 */
 	owner: string; 
 	/**
 	 * Sort by
 	 */
 	sortBy: string; 
 	/**
 	 * Newest
 	 */
 	sortNewest: string; 
 	/**
 	 * Oldest
 	 */
 	sortOldest: string; 
 	/**
 	 * Title A-Z
 	 */
 	sortTitleAsc: string; 
 	/**
 	 * Title Z-A
 	 */
 	sortTitleDesc: string; 
 	/**
 	 * Add Widget
 	 */
 	addWidget: string; 
 	/**
 	 * The widget is not available.
 	 */
 	brokenWidget: string; 
 	/**
 	 * Are you sure that you want to remove the page '{0}'?
 	 */
 	confirmRemovePage: string; 
 	/**
 	 * Are you sure that you want to delete the page '{0}'? It will be deleted for all users.
 	 */
 	confirmDeletePublicPage: string; 
 	/**
 	 * Published
 	 */
 	publishedWidgetTag: string; 
 	/**
 	 * Delete Page...
 	 */
 	deletePageEllipsis: string; 
 	/**
 	 * Delete Widget...
 	 */
 	deleteWidgetEllipsis: string; 
 	/**
 	 * Can Edit
 	 */
 	editAccess: string; 
 	/**
 	 * Edit Page Layout
 	 */
 	editPageLayout: string; 
 	/**
 	 * Enable settings
 	 */
 	enableSettings: string; 
 	/**
 	 * Export Page...
 	 */
 	exportPageEllipsis: string; 
 	/**
 	 * Import Page...
 	 */
 	importPageEllipsis: string; 
 	/**
 	 * Language
 	 */
 	language: string; 
 	/**
 	 * You can only add {0} pages. You must remove a page in My Pages to be able to add another page.
 	 */
 	maxPageCountMessage: string; 
 	/**
 	 * New Page...
 	 */
 	newPageEllipsis: string; 
 	/**
 	 * The Page Already Exists
 	 */
 	pageExists: string; 
 	/**
 	 * You already have the page '{0}' in My Pages.
 	 */
 	pageExistsMessage: string; 
 	/**
 	 * Preview
 	 */
 	preview: string; 
 	/**
 	 * Publishing Widget
 	 */
 	publishWidget: string; 
 	/**
 	 * Publishing Page
 	 */
 	publishPage: string; 
 	/**
 	 * Publish Page...
 	 */
 	publishPageEllipsis: string; 
 	/**
 	 * Publish...
 	 */
 	publishWidgetEllipsis: string; 
 	/**
 	 * Remove...
 	 */
 	removeEllipsis: string; 
 	/**
 	 * Set as Homepage
 	 */
 	setAsHomepage: string; 
 	/**
 	 * Tags
 	 */
 	tags: string; 
 	/**
 	 * Unable to Add Page
 	 */
 	unableToAddPage: string; 
 	/**
 	 * View Only
 	 */
 	viewAccess: string; 
 	/**
 	 * Configure...
 	 */
 	widgetSettingsEllipsis: string; 
 	/**
 	 * Are you sure that you want to delete the widget '{0}'? It will be deleted for all users.
 	 */
 	confirmDeleteCustomWidget: string; 
 	/**
 	 * Duplicate Page
 	 */
 	duplicatePage: string; 
 	/**
 	 * {0} - Copy
 	 */
 	pageCopyTitle: string; 
 	/**
 	 * Add Translation
 	 */
 	addTranslation: string; 
 	/**
 	 * Edit Translation
 	 */
 	editTranslation: string; 
 	/**
 	 * Advanced
 	 */
 	advanced: string; 
 	/**
 	 * Back
 	 */
 	back: string; 
 	/**
 	 * Basic
 	 */
 	basic: string; 
 	/**
 	 * Configure Widget
 	 */
 	widgetSettings: string; 
 	/**
 	 * Translations
 	 */
 	translations: string; 
 	/**
 	 * Description
 	 */
 	description: string; 
 	/**
 	 * Last edited
 	 */
 	lastEdited: string; 
 	/**
 	 * Remove
 	 */
 	remove: string; 
 	/**
 	 * Update
 	 */
 	update: string; 
 	/**
 	 * The page could not be added.
 	 */
 	unableToAddPageMesssage: string; 
 	/**
 	 * Duplicate Widget
 	 */
 	duplicateWidget: string; 
 	/**
 	 * Administration
 	 */
 	administration: string; 
 	/**
 	 * Publishing Widget Copy
 	 */
 	publishWidgetCopy: string; 
 	/**
 	 * Republish
 	 */
 	republish: string; 
 	/**
 	 * Republishing Page
 	 */
 	republishPage: string; 
 	/**
 	 * Republishing Widget
 	 */
 	republishWidget: string; 
 	/**
 	 * About
 	 */
 	about: string; 
 	/**
 	 * Access Level
 	 */
 	accessLevel: string; 
 	/**
 	 * Edit Published Page
 	 */
 	editPublishedPage: string; 
 	/**
 	 * Publish the current page to the Page Catalog to share it with other users.
 	 */
 	publishPageDescription: string; 
 	/**
 	 * Apply
 	 */
 	apply: string; 
 	/**
 	 * Create New Page
 	 */
 	createNewPage: string; 
 	/**
 	 * Editing Page Layout
 	 */
 	editingPageLayout: string; 
 	/**
 	 * Edit Layout
 	 */
 	editLayout: string; 
 	/**
 	 * Edit Publish Configuration...
 	 */
 	editPublishConfigurationEllipsis: string; 
 	/**
 	 * Edit Published
 	 */
 	editPublishedWidget: string; 
 	/**
 	 * By adding widgets you can create a page that fits your specific needs.
 	 */
 	emptyPageDescription: string; 
 	/**
 	 * This page is currently empty
 	 */
 	emptyPageTitle: string; 
 	/**
 	 * Enabled
 	 */
 	enabled: string; 
 	/**
 	 * Publish Copy...
 	 */
 	publishWidgetCopyEllipsis: string; 
 	/**
 	 * Visible
 	 */
 	visible: string; 
 	/**
 	 * Welcome to Infor Ming.le™
 	 */
 	welcomeMessage: string; 
 	/**
 	 * Based on
 	 */
 	basedOn: string; 
 	/**
 	 * Show published
 	 */
 	showPublished: string; 
 	/**
 	 * Version
 	 */
 	version: string; 
 	/**
 	 * Add User or Group
 	 */
 	addUserOrGroup: string; 
 	/**
 	 * All users will be given view access to this page if no specific access rights are set.
 	 */
 	pageAccessDescription: string; 
 	/**
 	 * Search for user or group...
 	 */
 	principalSearchPlaceholder: string; 
 	/**
 	 * Access Levels
 	 */
 	accessLevels: string; 
 	/**
 	 * Based on widget {0}
 	 */
 	basedOnWidgetX: string; 
 	/**
 	 * Edit Publish Configuration
 	 */
 	editPublishConfiguration: string; 
 	/**
 	 * Please refresh Homepages or try again later, contact your system administrator if the problem persists.
 	 */
 	contactAdminRetry: string; 
 	/**
 	 * The action could not be performed.
 	 */
 	errorGeneric: string; 
 	/**
 	 * The entity could not be found.
 	 */
 	errorNotFound: string; 
 	/**
 	 * The action could not be performed in time.
 	 */
 	errorTimeout: string; 
 	/**
 	 * You are not authorized to perform this action.
 	 */
 	errorUnauthorized: string; 
 	/**
 	 * The service is currently unavailable.
 	 */
 	errorUnavailable: string; 
 	/**
 	 * All
 	 */
 	widgetCategoryAll: string; 
 	/**
 	 * Application
 	 */
 	application: string; 
 	/**
 	 * Default
 	 */
 	defaultSelection: string; 
 	/**
 	 * Reset to Default
 	 */
 	resetToDefault: string; 
 	/**
 	 * Copy Widget
 	 */
 	copyWidget: string; 
 	/**
 	 * Move Left
 	 */
 	moveLeft: string; 
 	/**
 	 * Move Right
 	 */
 	moveRight: string; 
 	/**
 	 * Paste Widget
 	 */
 	pasteWidget: string; 
 	/**
 	 * Previewing {0}
 	 */
 	previewingPage: string; 
 	/**
 	 * Preview Page
 	 */
 	previewPage: string; 
 	/**
 	 * Delete
 	 */
 	delete: string; 
 	/**
 	 * Edit
 	 */
 	edit: string; 
 	/**
 	 * URL
 	 */
 	url: string; 
 	/**
 	 * Unable to save. The data exceeds the maximum allowed size.
 	 */
 	exceedsMaxSize: string; 
 	/**
 	 * Delete Page
 	 */
 	deletePage: string; 
 	/**
 	 * Choose File
 	 */
 	chooseFile: string; 
 	/**
 	 * Confirm Cancel
 	 */
 	confirmCancel: string; 
 	/**
 	 * Each tag must be unique
 	 */
 	duplicateTag: string; 
 	/**
 	 * Translate widget, page title and description
 	 */
 	enableContentTranslation: string; 
 	/**
 	 * Access the Page Catalog
 	 */
 	enablePageCatalog: string; 
 	/**
 	 * Export pages
 	 */
 	enablePageExport: string; 
 	/**
 	 * Import pages
 	 */
 	enablePageImport: string; 
 	/**
 	 * Publish pages to the Page Catalog
 	 */
 	enablePagePublish: string; 
 	/**
 	 * Create private pages
 	 */
 	enablePrivatePages: string; 
 	/**
 	 * Add a page from the Page Catalog
 	 */
 	enablePublicPageAdd: string; 
 	/**
 	 * Duplicate a page from the Page Catalog
 	 */
 	enablePublicPageCopy: string; 
 	/**
 	 * Access the Widget Catalog
 	 */
 	enableWidgetCatalog: string; 
 	/**
 	 * Publish widgets to the Widget Catalog
 	 */
 	enableWidgetPublish: string; 
 	/**
 	 * Homepages currently not available
 	 */
 	homepagesUnavailable: string; 
 	/**
 	 * A tag cannot have more than 32 characters.
 	 */
 	invalidTagMaxLength: string; 
 	/**
 	 * A tag must have at least two characters (excluding #).
 	 */
 	invalidTagMinLength: string; 
 	/**
 	 * Only {0} tags are allowed.
 	 */
 	maxCountTag: string; 
 	/**
 	 * You can have a maximum of {0} pages
 	 */
 	maxUserPages: string; 
 	/**
 	 * Missing Information
 	 */
 	missingInformation: string; 
 	/**
 	 * Title or description is missing.
 	 */
 	noTitleOrDescription: string; 
 	/**
 	 * Search
 	 */
 	search: string; 
 	/**
 	 * A tag can only consist of letters, numbers and underscores and must begin with a "#".
 	 */
 	tagFormatInfo: string; 
 	/**
 	 * Unable to open page settings.
 	 */
 	unableOpenPageSettings: string; 
 	/**
 	 * Cancel without saving changes?
 	 */
 	confirmCancelMessage: string; 
 	/**
 	 * Used by
 	 */
 	usedbyHeader: string; 
 	/**
 	 * Confirm Reset
 	 */
 	confirmReset: string; 
 	/**
 	 * Are you sure that you want to reset the configuration for this widget?
 	 */
 	confirmResetMessage: string; 
 	/**
 	 * There are no pages in the Page Catalog.
 	 */
 	noPages: string; 
 	/**
 	 * No pages were found to match your search.
 	 */
 	noPagesFound: string; 
 	/**
 	 * There are no widgets in the Widget Catalog.
 	 */
 	noWidgets: string; 
 	/**
 	 * No widgets were found to match your search.
 	 */
 	noWidgetsFound: string; 
 	/**
 	 * User Permissions
 	 */
 	userPermissions: string; 
 	/**
 	 * Permissions
 	 */
 	permissions: string; 
 	/**
 	 * Name
 	 */
 	name: string; 
 	/**
 	 * More Homepages
 	 */
 	moreHomepages: string; 
 	/**
 	 * No widgets were found in the selected category.
 	 */
 	noWidgetsCategory: string; 
 	/**
 	 * Page Added
 	 */
 	pageAdded: string; 
 	/**
 	 * '{0}' was added.
 	 */
 	titleAddedMessage: string; 
 	/**
 	 * Widget Added
 	 */
 	widgetAdded: string; 
 	/**
 	 * Unable to Add Widget
 	 */
 	unableToAddWidget: string; 
 	/**
 	 * The page does not exist.
 	 */
 	pageNotExist: string; 
 	/**
 	 * Unable to Save
 	 */
 	unableToSave: string; 
 	/**
 	 * You are not authorized to view this page.
 	 */
 	errorUnauthorizedPage: string; 
 	/**
 	 * Page not found
 	 */
 	pageNotFound: string; 
 	/**
 	 * Your Ming.le Groups
 	 */
 	mingleGroups: string; 
 	/**
 	 * Selection of Homepage
 	 */
 	selectionOfHomepage: string; 
 	/**
 	 * Copy to Clipboard
 	 */
 	copyToClipboard: string; 
 	/**
 	 * Some browsers will block URLs that are not loaded using "HTTPS".
 	 */
 	httpUrlWarning: string; 
 	/**
 	 * The page is not available.
 	 */
 	brokenPage: string; 
 	/**
 	 * You don't have permissions to view this page.
 	 */
 	noPageAccess: string; 
 	/**
 	 * You don't have permissions to view this widget.
 	 */
 	noWidgetAccess: string; 
 	/**
 	 * Text
 	 */
 	text: string; 
 	/**
 	 * View User Permissions
 	 */
 	viewUserPermissions: string; 
 	/**
 	 * Use Widget Catalog title as widget title
 	 */
 	isCatalogWidgetLabel: string; 
 	/**
 	 * Help
 	 */
 	help: string; 
 	/**
 	 * Something went wrong. Please sign out and restart your browser.
 	 */
 	errorSignOut: string; 

}
