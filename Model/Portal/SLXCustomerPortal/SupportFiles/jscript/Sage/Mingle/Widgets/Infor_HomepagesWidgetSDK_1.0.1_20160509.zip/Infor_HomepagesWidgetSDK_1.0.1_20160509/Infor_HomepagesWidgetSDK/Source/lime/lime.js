define(["require", "exports"], function (require, exports) {
    var WidgetState = (function () {
        function WidgetState() {
        }
        WidgetState.running = "running";
        WidgetState.busy = "busy";
        WidgetState.error = "error";
        return WidgetState;
    })();
    exports.WidgetState = WidgetState;
    var WidgetActivationType = (function () {
        function WidgetActivationType() {
        }
        WidgetActivationType.visibility = "visibility";
        WidgetActivationType.close = "close";
        WidgetActivationType.settings = "settings";
        WidgetActivationType.edit = "edit";
        return WidgetActivationType;
    })();
    exports.WidgetActivationType = WidgetActivationType;
    (function (WidgetMessageType) {
        WidgetMessageType[WidgetMessageType["Info"] = 0] = "Info";
        WidgetMessageType[WidgetMessageType["Alert"] = 1] = "Alert";
        WidgetMessageType[WidgetMessageType["Error"] = 2] = "Error";
    })(exports.WidgetMessageType || (exports.WidgetMessageType = {}));
    var WidgetMessageType = exports.WidgetMessageType;
    var WidgetSettingsType = (function () {
        function WidgetSettingsType() {
        }
        WidgetSettingsType.stringType = "string";
        WidgetSettingsType.numberType = "number";
        WidgetSettingsType.booleanType = "boolean";
        WidgetSettingsType.selectorType = "selector";
        WidgetSettingsType.objectType = "object";
        return WidgetSettingsType;
    })();
    exports.WidgetSettingsType = WidgetSettingsType;
    var WidgetConstants = (function () {
        function WidgetConstants() {
        }
        WidgetConstants.widgetInstanceKey = "lmWidgetInstance";
        WidgetConstants.widgetContextKey = "lmWidgetContext";
        WidgetConstants.widgetTitle = "widgetTitle";
        WidgetConstants.widgetDescription = "widgetDescription";
        return WidgetConstants;
    })();
    exports.WidgetConstants = WidgetConstants;
    var ArrayUtil = (function () {
        function ArrayUtil() {
        }
        ArrayUtil.contains = function (array, value) {
            if (array) {
                return $.inArray(value, array) >= 0;
            }
            return false;
        };
        ArrayUtil.indexOf = function (array, value) {
            return $.inArray(value, array);
        };
        ArrayUtil.sortByProperty = function (array, property, options) {
            var ignoreCase = options && options.ignoreCase;
            return array.sort(function (x, y) {
                var xProp = x[property];
                var yProp = y[property];
                var a = ignoreCase ? ("" + xProp).toLocaleLowerCase() : xProp;
                var b = ignoreCase ? ("" + yProp).toLocaleLowerCase() : yProp;
                if (a > b) {
                    return 1;
                }
                else if (a < b) {
                    return -1;
                }
                return 0;
            });
        };
        ArrayUtil.remove = function (array, item) {
            var index = $.inArray(item, array);
            if (index >= 0) {
                array.splice(index, 1);
            }
        };
        ArrayUtil.removeByProperty = function (array, name, value) {
            for (var i = 0; i < array.length; i++) {
                if (array[i][name] === value) {
                    array.splice(i, 1);
                    return true;
                }
            }
            return false;
        };
        ArrayUtil.removeByPredicate = function (array, predicate) {
            for (var i = 0; i < array.length; i++) {
                if (predicate(array[i])) {
                    array.splice(i, 1);
                    return true;
                }
            }
            return false;
        };
        ArrayUtil.indexByProperty = function (array, name, value) {
            if (array) {
                for (var i = 0; i < array.length; i++) {
                    if (array[i][name] === value) {
                        return i;
                    }
                }
            }
            return -1;
        };
        ArrayUtil.itemByProperty = function (array, name, value) {
            var index = this.indexByProperty(array, name, value);
            return index >= 0 ? array[index] : null;
        };
        ArrayUtil.itemByPredicate = function (array, predicate) {
            for (var i = 0; i < array.length; i++) {
                if (predicate(array[i])) {
                    return array[i];
                }
            }
            return null;
        };
        ArrayUtil.containsByProperty = function (array, name, value) {
            return this.indexByProperty(array, name, value) >= 0;
        };
        ArrayUtil.last = function (array) {
            if (array && array.length > 0) {
                return array[array.length - 1];
            }
            return null;
        };
        ArrayUtil.find = function (array, predicate) {
            if (array) {
                for (var _i = 0; _i < array.length; _i++) {
                    var item = array[_i];
                    if (predicate(item)) {
                        return item;
                    }
                }
            }
            return null;
        };
        ArrayUtil.findAll = function (array, predicate) {
            if (array) {
                var arr = [];
                for (var _i = 0; _i < array.length; _i++) {
                    var item = array[_i];
                    if (predicate(item)) {
                        arr.push(item);
                    }
                }
                return arr;
            }
            return null;
        };
        ArrayUtil.array = function (n, defaultValue) {
            var arr = new Array(n);
            for (var j = 0; j < n; j++) {
                arr[j] = defaultValue;
            }
            return arr;
        };
        ArrayUtil.matrix = function (rows, columns, defaultValue) {
            var matrix = new Array(rows);
            for (var i = 0; i < matrix.length; i++) {
                var cols = new Array(columns);
                for (var j = 0; j < columns; j++) {
                    cols[j] = defaultValue;
                }
                matrix[i] = ArrayUtil.array(columns, defaultValue);
            }
            return matrix;
        };
        ArrayUtil.move = function (array, index, newIndex) {
            if (newIndex >= array.length) {
                var k = newIndex - array.length;
                while ((k--) + 1) {
                    array.push(undefined);
                }
            }
            array.splice(newIndex, 0, array.splice(index, 1)[0]);
        };
        return ArrayUtil;
    })();
    exports.ArrayUtil = ArrayUtil;
    var NumUtil = (function () {
        function NumUtil() {
        }
        NumUtil.getLocaleSeparator = function () {
            var n = 1.1;
            var s = n.toLocaleString().substring(1, 2);
            return s;
        };
        NumUtil.getDefaultOptions = function () {
            return NumUtil.defaultOptions;
        };
        NumUtil.setDefaultOptions = function (options) {
            NumUtil.defaultOptions = options;
            if (options.separator) {
                NumUtil.defaultSeparator = options.separator;
            }
        };
        NumUtil.isNumber = function (n) {
            return !isNaN(parseFloat(n)) && isFinite(n);
        };
        NumUtil.getInt = function (s, defaultValue) {
            if (defaultValue === void 0) { defaultValue = 0; }
            if (s) {
                try {
                    return parseInt(s) || defaultValue;
                }
                catch (e) {
                }
            }
            return defaultValue;
        };
        NumUtil.format = function (value, options) {
            var s = value.toString();
            if ("" === s) {
                return s;
            }
            var separator = options ? options.separator : NumUtil.defaultOptions.separator;
            if (!separator) {
                separator = NumUtil.defaultSeparator;
            }
            s = s.replace(".", separator);
            return s;
        };
        NumUtil.pad = function (num, length) {
            var s = num + "";
            while (s.length < length) {
                s = "0" + s;
            }
            return s;
        };
        NumUtil.hasOnlyIntegers = function (s) {
            if (!s) {
                return false;
            }
            var digits = "1234567890";
            for (var i = 0; i < s.length; i++) {
                if (digits.indexOf(s.charAt(i)) === -1) {
                    return false;
                }
            }
            return true;
        };
        NumUtil.tryGetInt = function (input, defaultValue) {
            if (defaultValue === void 0) { defaultValue = 0; }
            if (!input) {
                return defaultValue;
            }
            if (this.isNumber(input)) {
                return input;
            }
            return this.getInt(input.toString(), defaultValue);
        };
        NumUtil.defaultSeparator = NumUtil.getLocaleSeparator();
        NumUtil.defaultOptions = {
            separator: NumUtil.defaultSeparator
        };
        return NumUtil;
    })();
    exports.NumUtil = NumUtil;
    var CommonUtil = (function () {
        function CommonUtil() {
        }
        CommonUtil.getLocaleDateString = function (dateString, options) {
            try {
                var date = new Date(dateString);
                if (!options) {
                    options = { pattern: "yyyy-MM-dd HH:mm" };
                }
                return Locale.formatDate(date, options);
            }
            catch (ex) {
                return dateString;
            }
        };
        CommonUtil.deleteProperty = function (object, property) {
            if (!CommonUtil.isUndefined(object[property])) {
                delete object[property];
            }
        };
        CommonUtil.getBoolean = function (s, defaultValue) {
            if (defaultValue === void 0) { defaultValue = false; }
            if (s && s.length > 0) {
                return s[0].toLowerCase() === "t";
            }
            return defaultValue;
        };
        CommonUtil.getUuid = function (prefix) {
            return prefix + (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1) + (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
        };
        CommonUtil.hasValue = function (anyObject) {
            if (typeof anyObject != "undefined") {
                return anyObject != null;
            }
            return false;
        };
        CommonUtil.isUndefined = function (anyObject) {
            return typeof anyObject === "undefined";
        };
        CommonUtil.random = function (stringLength) {
            if (stringLength === void 0) { stringLength = 16; }
            var chars = CommonUtil.chars;
            var randomstring = "";
            for (var i = 0; i < stringLength; i++) {
                var rnum = Math.floor(Math.random() * chars.length);
                randomstring += chars.substring(rnum, rnum + 1);
            }
            return randomstring;
        };
        CommonUtil.isIframe = function () {
            try {
                return window.self !== window.top;
            }
            catch (e) {
                return true;
            }
        };
        CommonUtil.getClientDate = function () {
            var addZero = function (dateNr) {
                var dateString;
                if (dateNr < 10) {
                    dateString = dateNr.toString();
                    dateString = "0" + dateString;
                }
                else {
                    dateString = dateNr.toString();
                }
                return dateString;
            };
            var date = new Date(Date.now());
            var year = date.getFullYear();
            var month = addZero(date.getMonth() + 1);
            var day = addZero(date.getDate());
            var hours = addZero(date.getHours());
            var min = addZero(date.getMinutes());
            return year + "-" + month + "-" + day + "T" + hours + ":" + min;
        };
        CommonUtil.detectBrowser = function () {
            if (!!navigator.userAgent.match(/Trident/)) {
                $('html').addClass('ie');
            }
            if (navigator.appVersion.indexOf('MSIE 9.0') > -1) {
                $('html').addClass('ie9');
            }
            if (navigator.appVersion.indexOf('MSIE 10.0') > -1) {
                $('html').addClass('ie10');
            }
            if (!!navigator.userAgent.match(/Trident\/7\./)) {
                $('html').addClass('ie11');
            }
        };
        CommonUtil.chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        return CommonUtil;
    })();
    exports.CommonUtil = CommonUtil;
    var StringUtil = (function () {
        function StringUtil() {
        }
        StringUtil.isNullOrWhitespace = function (value) {
            return !value || !value.trim();
        };
        StringUtil.startsWith = function (value, prefix) {
            return value ? value.indexOf(prefix) === 0 : false;
        };
        StringUtil.replaceParameters = function (template, resolveFunction) {
            template = template.replace(/{(.*?)}/g, function (substring, key) {
                var value = resolveFunction(key);
                return (typeof value != "undefined" ? value : "");
            });
            return template;
        };
        StringUtil.endsWith = function (value, suffix) {
            if (!value) {
                return false;
            }
            return value.indexOf(suffix, value.length - suffix.length) !== -1;
        };
        StringUtil.trimEnd = function (value) {
            return value.replace(/\s+$/, "");
        };
        StringUtil.format = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i - 0] = arguments[_i];
            }
            var stringValue = "missing";
            try {
                stringValue = args[0];
                var params = Array.prototype.slice.call(args, 1);
                stringValue = stringValue.replace(/{(\d+)}/g, function () {
                    var value = params[arguments[1]];
                    return (typeof value != 'undefined' ? value : arguments[0]);
                });
            }
            catch (ex) {
            }
            return stringValue;
        };
        return StringUtil;
    })();
    exports.StringUtil = StringUtil;
    var HtmlUtil = (function () {
        function HtmlUtil() {
        }
        HtmlUtil.iframe = function (url, name) {
            var iframe = $("<iframe />").attr("sandbox", "allow-same-origin allow-scripts allow-popups allow-forms").attr("seamless", "seamless").attr("frameborder", "0").addClass("lm-fill-absolute");
            if (url) {
                iframe.attr("src", url);
            }
            if (name) {
                iframe.attr("name", name);
            }
            return iframe;
        };
        return HtmlUtil;
    })();
    exports.HtmlUtil = HtmlUtil;
    var Log = (function () {
        function Log() {
        }
        Log.addAppender = function (appender) {
            Log.appenders.push(appender);
        };
        Log.removeAppender = function (appender) {
            ArrayUtil.remove(Log.appenders, appender);
        };
        Log.getTime = function () {
            var date = new Date();
            var hours = date.getHours();
            var minutes = date.getMinutes();
            var seconds = date.getSeconds();
            var ms = date.getMilliseconds();
            var time = (hours < 10 ? "0" : "") + hours + ":" +
                (minutes < 10 ? "0" : "") + minutes + ":" +
                (seconds < 10 ? "0" : "") + seconds + "," +
                (ms < 10 ? "00" : (ms < 100 ? "0" : "") + ms);
            return time;
        };
        Log.getLogEntry = function (level, text, ex) {
            var logText = "[" + Log.getTime() + "] " + this.prefixes[level] + " " + text;
            if (ex) {
                logText += " " + ex.message;
                if (ex.stack) {
                    logText += " " + ex.stack;
                }
            }
            return logText;
        };
        Log.log = function (currentLevel, level, text, ex) {
            if (level <= currentLevel) {
                if (Log.isConsoleLogEnabled && window.console) {
                    var logText = Log.getLogEntry(level, text, ex);
                    if (level <= 1) {
                        console.error(logText);
                    }
                    else if (level === 2) {
                        console.warn(logText);
                    }
                    else if (level === 3) {
                        console.info(logText);
                    }
                    else {
                        console.log(logText);
                    }
                }
                if (Log.appenders) {
                    for (var i = 0; i < Log.appenders.length; i++) {
                        try {
                            Log.appenders[i](level, text, ex);
                        }
                        catch (e) {
                        }
                    }
                }
            }
        };
        Log.setDefault = function () {
            this.level = this.levelInfo;
        };
        Log.fatal = function (text, ex) {
            this.log(this.level, this.levelFatal, text, ex);
        };
        Log.error = function (text, ex) {
            this.log(this.level, this.levelError, text, ex);
        };
        Log.warning = function (text, ex) {
            this.log(this.level, this.levelWarning, text, ex);
        };
        Log.info = function (text, ex) {
            this.log(this.level, this.levelInfo, text, ex);
        };
        Log.isDebug = function () {
            return this.level >= this.levelDebug;
        };
        Log.setDebug = function () {
            this.level = this.levelDebug;
        };
        Log.debug = function (text, ex) {
            this.log(this.level, this.levelDebug, text, ex);
        };
        Log.isTrace = function () {
            return this.level >= this.levelTrace;
        };
        Log.setTrace = function () {
            this.level = this.levelTrace;
        };
        Log.trace = function (text, ex) {
            this.log(this.level, this.levelTrace, text, ex);
        };
        Log.levelFatal = 0;
        Log.levelError = 1;
        Log.levelWarning = 2;
        Log.levelInfo = 3;
        Log.levelDebug = 4;
        Log.levelTrace = 5;
        Log.level = Log.levelInfo;
        Log.isConsoleLogEnabled = true;
        Log.prefixes = ["[FATAL]", "[ERROR]", "[WARNING]", "[INFO]", "[DEBUG]", "[TRACE]"];
        Log.appenders = [];
        return Log;
    })();
    exports.Log = Log;
    (function (StandardDialogButtons) {
        StandardDialogButtons[StandardDialogButtons["Ok"] = 1] = "Ok";
        StandardDialogButtons[StandardDialogButtons["OkCancel"] = 2] = "OkCancel";
        StandardDialogButtons[StandardDialogButtons["YesNo"] = 3] = "YesNo";
        StandardDialogButtons[StandardDialogButtons["YesNoCancel"] = 4] = "YesNoCancel";
    })(exports.StandardDialogButtons || (exports.StandardDialogButtons = {}));
    var StandardDialogButtons = exports.StandardDialogButtons;
    (function (DialogButtonType) {
        DialogButtonType[DialogButtonType["None"] = 1] = "None";
        DialogButtonType[DialogButtonType["Ok"] = 2] = "Ok";
        DialogButtonType[DialogButtonType["Cancel"] = 3] = "Cancel";
        DialogButtonType[DialogButtonType["Yes"] = 4] = "Yes";
        DialogButtonType[DialogButtonType["No"] = 5] = "No";
        DialogButtonType[DialogButtonType["Custom"] = 6] = "Custom";
    })(exports.DialogButtonType || (exports.DialogButtonType = {}));
    var DialogButtonType = exports.DialogButtonType;
});
//# sourceMappingURL=lime.js.map