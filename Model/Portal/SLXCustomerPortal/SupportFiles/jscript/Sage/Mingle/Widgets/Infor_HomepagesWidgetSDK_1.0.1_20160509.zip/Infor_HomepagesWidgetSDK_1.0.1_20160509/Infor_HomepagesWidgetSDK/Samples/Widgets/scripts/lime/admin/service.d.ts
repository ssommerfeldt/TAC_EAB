import c = require("../core");
import lm = require("../lime");
export declare class AdminOperations {
    static updateRules: string;
    static importData: string;
    static exportData: string;
}
export declare class AdminConstants {
    static openTab: string;
    static settingsTab: string;
    static propertiesTab: string;
    static privatePagesTab: string;
    static publishedPagesTab: string;
    static publishedWidgetsTab: string;
    static standardWidgetsTab: string;
    static errorsTab: string;
    static gridPageSize: number;
    static checkStatusInterval: number;
    static parameterIncludeSettings: string;
    static parameterIncludeUserSettings: string;
    static parameterIncludeSettingsRules: string;
    static parameterIncludeProperties: string;
    static parameterIncludePrivatePages: string;
    static parameterIncludePublishedPages: string;
    static parameterIncludePublishedPageConnections: string;
    static parameterIncludePublishedPageAccess: string;
    static parameterIncludePublishedWidgets: string;
    static parameterIncludePublishedWidgetAccess: string;
    static parameterIncludeRoles: string;
    static parameterUserSettingsFilter: string;
    static parameterPublishedWidgetsFilter: string;
    static parameterPublishedPagesFilter: string;
    static parameterPrivatePagesFilter: string;
}
export declare class SettingValueInfo {
    value: string;
    label: string;
}
export declare class AppInfo {
    name: string;
}
export interface IAdminTool {
    isAdministrator: boolean;
    settings: c.ISetting[];
    translations: SettingTitles[];
    isProvisioner: boolean;
    userName: string;
    userId: string;
    tenantId: string;
}
export interface SettingTitles {
    [id: string]: string;
}
export interface IAdminOperationInfo {
    id: string;
    isRunning: boolean;
    messageList: c.MessageInfo[];
}
export interface IAdminToolResponse extends c.IOperationResponse {
    content: IAdminTool;
}
export interface IAdminOperationResponse extends c.IOperationResponse {
    content: IAdminOperationInfo;
}
export interface IAdminOperationRequest extends c.IOperationRequest {
    parameters: c.IStringMap;
}
export interface IPropertyInfoListResponse extends c.IOperationResponse {
    content: IPropertyInfo[];
}
export interface IPropertyInfoResponse extends c.IOperationResponse {
    content: IPropertyInfo;
}
export interface IPropertyInfo {
    propertyId: string;
    propertyValue: string;
    description?: string;
    area?: string;
}
export interface IWidgetAccess {
    id: string;
    accessLevel: c.WidgetAccessLevel;
    principal: string;
    principalName?: string;
    isUser?: boolean;
    isPublished?: boolean;
    isCatalog?: boolean;
    changedBy?: string;
    changedByName?: string;
    changeDate?: string;
}
export interface IWidgetAccessInfo {
    id: string;
    accessList: IWidgetAccess[];
}
export interface IAdminContext {
    initialize(): ng.IPromise<IAdminToolResponse>;
    get(): IAdminTool;
}
export interface IAdminService {
    invalidateCaches(options: c.IStringToAnyMap): void;
    onCachesInvalidated(): c.IInstanceEvent<c.IStringToAnyMap>;
    publishedPages: c.IPage[];
    allWidgets: c.IWidgetInfo[];
    searchRoles(query: string): ng.IPromise<lm.IAutocompleteEntity[]>;
    getTool(): ng.IPromise<IAdminToolResponse>;
    updateTool(adminTool: IAdminTool): ng.IPromise<c.IOperationResponse>;
    updateSettingRules(setting: c.ISetting): ng.IPromise<c.IOperationResponse>;
    listProperties(reload: boolean): ng.IPromise<IPropertyInfoListResponse>;
    createProperty(property: IPropertyInfo): ng.IPromise<IPropertyInfoResponse>;
    updateProperty(property: IPropertyInfo): ng.IPromise<IPropertyInfoResponse>;
    deleteProperty(propertyId: string): ng.IPromise<c.IOperationResponse>;
    exportProperties(properties?: IPropertyInfo[]): void;
    listPrivatePages(userId: string, reload: boolean): ng.IPromise<c.IPageListResponse>;
    listPublishedPages(reload: boolean): ng.IPromise<c.IPageListResponse>;
    getPageDisplayTitle(value: string, pages?: c.IPage[]): string;
    deletePrivatePages(pages: string[]): ng.IPromise<c.IIntegerResponse>;
    exportPublishedPages(pages?: c.IPage[]): void;
    exportPrivatePages(userId: string, pages?: c.IPage[]): void;
    listStandardWidgets(reload: boolean): ng.IPromise<c.IWidgetListResponse>;
    listPublishedWidgets(reload: boolean): ng.IPromise<c.IWidgetListResponse>;
    exportPublishedWidgets(widgets?: c.IWidgetInfo[]): void;
    getWidgetAccess(options: IWidgetAccessInfo): ng.IPromise<c.IOperationResponse>;
    updateWidgetAccess(options: IWidgetAccessInfo): ng.IPromise<c.IOperationResponse>;
    getPageAccess(pageId: string): ng.IPromise<c.IPageAccessResponse>;
    updatePageAccess(pageAccess: c.IPageAccess): ng.IPromise<c.IPageAccessResponse>;
    openImportFilesDialog(options: c.IImportOptions): ng.IPromise<lm.IDialogResult>;
    getError(): ng.IPromise<c.IOperationResponse>;
    startExportOperation(parameters: c.IStringMap): ng.IPromise<c.IOperationResponse>;
    startImportOperation(parameters: c.IStringMap): ng.IPromise<c.IOperationResponse>;
    cancelOperation(): ng.IPromise<IAdminOperationResponse>;
    getOperationStatus(): ng.IPromise<IAdminOperationResponse>;
    downloadExportFile(): void;
    handleError(response: c.IOperationResponse, message?: string): void;
    setBusy(isBusy: boolean): void;
    isBusy(): boolean;
    showUploadCompleteDialog(title: string, message: string, isError?: boolean): ng.IPromise<lm.IDialogResult>;
    updatePageOwner(pageData: c.IPageData): ng.IPromise<c.IPageDataResponse>;
    openChangeOwnerDialog(title: string, currentOwnerId: string, callback: Function): void;
    clearOrReplaceWidgetAccess(widgets: c.IWidgetInfo[], isReplace: boolean, callback: Function, accessCopy?: IWidgetAccess[]): void;
    openWidgetAccessDialog(widget: c.IWidgetInfo, callback: Function): void;
    applyWidgetAccess(widgets: c.IWidgetInfo[], accessCopy: IWidgetAccess[], callback: Function): void;
    clearOrReplacePageAccess(pages: c.IPage[], isReplace: boolean, callback: Function, accessCopy?: c.IPageAccess): void;
    openPageAccessDialog(page: c.IPage, callback: Function): void;
    applyPageAccess(pages: c.IPage[], accessCopy: c.IPageAccess, callback: Function): void;
    unselectGridItem(item: any, gridApi: any): number;
    getDeletePageOptions(pages: c.IPage[], isPrivate: boolean): lm.IMessageDialogOptions;
}
export declare var init: (m: ng.IModule) => void;
