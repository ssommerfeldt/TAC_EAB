define(["require", "exports", "../lime"], function (require, exports, lm) {
    var CapitalizeFilter = (function () {
        function CapitalizeFilter() {
        }
        CapitalizeFilter.add = function (ngModule) {
            ngModule.filter("capitalize", [function () {
                    return function (value) {
                        return value.charAt(0).toUpperCase() + value.substr(1);
                    };
                }]);
        };
        return CapitalizeFilter;
    })();
    exports.CapitalizeFilter = CapitalizeFilter;
    var LocaleDateFilter = (function () {
        function LocaleDateFilter() {
        }
        LocaleDateFilter.add = function (ngModule) {
            ngModule.filter("lmLocaleDate", [function () {
                    return function (value) {
                        return lm.CommonUtil.getLocaleDateString(value);
                    };
                }]);
        };
        return LocaleDateFilter;
    })();
    exports.LocaleDateFilter = LocaleDateFilter;
    var EllipsisFilter = (function () {
        function EllipsisFilter() {
        }
        EllipsisFilter.add = function (ngModule) {
            ngModule.filter("lmEllipsis", [function () {
                    return function (value, maxLength) {
                        return value && (value.length > maxLength) ? value.substr(0, maxLength - 3) + "..." : value;
                    };
                }]);
        };
        return EllipsisFilter;
    })();
    exports.EllipsisFilter = EllipsisFilter;
    var FallbackIconDirective = (function () {
        function FallbackIconDirective() {
        }
        FallbackIconDirective.add = function (ngModule) {
            ngModule.directive("fallbackIcon", function () {
                return {
                    link: function (scope, element, attrs) {
                        element.bind('error', function () {
                            if (attrs.src !== attrs.fallbackIcon) {
                                attrs.$set('src', attrs.fallbackIcon);
                            }
                        });
                    }
                };
            });
        };
        return FallbackIconDirective;
    })();
    exports.FallbackIconDirective = FallbackIconDirective;
    var TagsDirective = (function () {
        function TagsDirective() {
        }
        TagsDirective.add = function (ngModule) {
            ngModule.directive("lmTags", ["$compile", function ($compile) {
                    return {
                        restrict: "E",
                        replace: true,
                        scope: {
                            tags: "=",
                            callback: "&onTagClickUpdate",
                            disabled: "="
                        },
                        link: function (scope, element) {
                            var tags = scope["tags"].split('#');
                            tags.splice(0, 1);
                            angular.forEach(tags, function (tag) {
                                var hashLink = $("<a/>").addClass("hyperlink");
                                if (scope["disabled"] === true) {
                                    hashLink.attr({ "disabled": "disabled", "aria-disabled": true });
                                }
                                else {
                                    scope.onClick = function (tagName) {
                                        scope.callback({ tag: tagName });
                                    };
                                    hashLink.attr("ng-click", "onClick('#" + tag.toLowerCase() + "')");
                                }
                                hashLink.html("#" + tag);
                                element.append($compile(hashLink)(scope));
                            });
                        },
                        template: "<span/>"
                    };
                }]);
        };
        return TagsDirective;
    })();
    exports.TagsDirective = TagsDirective;
    var BrokenEntityDirective = (function () {
        function BrokenEntityDirective() {
        }
        BrokenEntityDirective.add = function (ngModule) {
            ngModule.directive("lmBrokenEntity", function () {
                return {
                    restrict: "E",
                    replace: true,
                    scope: {
                        message: "="
                    },
                    template: '<div class="broken-entity"><div><p>{{message}}</p></div></div>'
                };
            });
        };
        return BrokenEntityDirective;
    })();
    exports.BrokenEntityDirective = BrokenEntityDirective;
    var RepeatCompletedDirective = (function () {
        function RepeatCompletedDirective() {
        }
        RepeatCompletedDirective.add = function (m) {
            m.directive("lmRepeatCompleted", function () {
                return {
                    link: function (scope, element, attributes) {
                        if (scope["$last"] && attributes["lmRepeatCompleted"]) {
                            var execute = scope.$eval(attributes["lmRepeatCompleted"]);
                            if (!lm.CommonUtil.isUndefined(execute)) {
                                execute();
                            }
                        }
                    }
                };
            });
        };
        return RepeatCompletedDirective;
    })();
    var TagValidationDirective = (function () {
        function TagValidationDirective() {
        }
        TagValidationDirective.add = function (ngModule) {
            ngModule.directive("lmTagValidation", ["lmTagService", function (tagService) {
                    return {
                        require: "?ngModel",
                        restrict: "A",
                        scope: {
                            lmTagValidation: "=",
                            invalidChar: "@"
                        },
                        link: function (scope, element, attrs, ngModel) {
                            if (!ngModel) {
                                return;
                            }
                            element.keypress(function (e) {
                                if (e.which > 32) {
                                    var character = String.fromCharCode(e.which);
                                    if (!/[A-Za-z0-9_# ]/.test(character)) {
                                        e.preventDefault();
                                        return false;
                                    }
                                }
                            });
                            ngModel.$parsers.push(function (value) {
                                var returnValue = value;
                                if (value.indexOf("#") !== -1) {
                                    var newValue = value.replace(/( *)#/g, "#");
                                    if (newValue[newValue.length - 1] === " ") {
                                        newValue = newValue.substring(0, newValue.length - 1);
                                    }
                                    returnValue = newValue;
                                }
                                return returnValue;
                            });
                            var requiredFields;
                            ngModel.$validators.tagValidator = function (modelValue) {
                                var returnValue = false;
                                if (modelValue) {
                                    var response = tagService.areTagsValid(modelValue);
                                    if (response.areValid) {
                                        scope.lmTagValidation = null;
                                        element.removeClass("error");
                                        ngModel.$setValidity("lmTagValidation", true);
                                        returnValue = true;
                                    }
                                    else {
                                        scope.lmTagValidation = response.errorMsg;
                                        element.addClass("error");
                                        ngModel.$setValidity("lmTagValidation", false);
                                    }
                                }
                                else {
                                    if (!scope.invalidChar) {
                                        scope.lmTagValidation = null;
                                        scope.invalidChar = false;
                                    }
                                    ;
                                    element.removeClass("error");
                                    ngModel.$setValidity("lmTagValidation", true);
                                    returnValue = true;
                                }
                                if (lm.CommonUtil.isUndefined(requiredFields)) {
                                    requiredFields = element.closest("form").find("input.required, textarea.required");
                                }
                                if (requiredFields.length > 0) {
                                    var field = $(requiredFields[0]);
                                    var validate = field.data("validate");
                                    validate.setErrorOnParent(field);
                                }
                                return returnValue;
                            };
                        }
                    };
                }]);
        };
        return TagValidationDirective;
    })();
    exports.TagValidationDirective = TagValidationDirective;
    var ConcatStringToCountFilter = (function () {
        function ConcatStringToCountFilter() {
        }
        ConcatStringToCountFilter.add = function (ngModule) {
            ngModule.filter("lmStringToCount", [function () {
                    return function (input) {
                        if (!input) {
                            return 0;
                        }
                        return input.split(",").length;
                    };
                }]);
        };
        return ConcatStringToCountFilter;
    })();
    exports.ConcatStringToCountFilter = ConcatStringToCountFilter;
    var SettingsAreaFilter = (function () {
        function SettingsAreaFilter() {
        }
        SettingsAreaFilter.add = function (ngModule) {
            ngModule.filter("lmSettingsArea", [function () {
                    return function (items, input) {
                        var filterHits = [];
                        if (input || input === 0) {
                            angular.forEach(items, function (item) {
                                if (item.setting.area === input) {
                                    filterHits.push(item);
                                }
                            });
                            return filterHits;
                        }
                        else {
                            return items;
                        }
                    };
                }]);
        };
        return SettingsAreaFilter;
    })();
    exports.SettingsAreaFilter = SettingsAreaFilter;
    var SettingsVisibilityFilter = (function () {
        function SettingsVisibilityFilter() {
        }
        SettingsVisibilityFilter.add = function (ngModule) {
            ngModule.filter("lmSettingsVisibility", [function () {
                    return function (items) {
                        var filterHits = [];
                        angular.forEach(items, function (item) {
                            if (item.setting.isVisible === true) {
                                filterHits.push(item);
                            }
                        });
                        return filterHits;
                    };
                }]);
        };
        return SettingsVisibilityFilter;
    })();
    exports.SettingsVisibilityFilter = SettingsVisibilityFilter;
    exports.init = function (m) {
        CapitalizeFilter.add(m);
        LocaleDateFilter.add(m);
        EllipsisFilter.add(m);
        FallbackIconDirective.add(m);
        TagsDirective.add(m);
        BrokenEntityDirective.add(m);
        RepeatCompletedDirective.add(m);
        TagValidationDirective.add(m);
        ConcatStringToCountFilter.add(m);
        SettingsAreaFilter.add(m);
        SettingsVisibilityFilter.add(m);
    };
});
//# sourceMappingURL=common.js.map