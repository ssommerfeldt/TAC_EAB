export declare class CapitalizeFilter {
    static add(ngModule: ng.IModule): void;
}
export declare class LocaleDateFilter {
    static add(ngModule: ng.IModule): void;
}
export declare class EllipsisFilter {
    static add(ngModule: ng.IModule): void;
}
export declare class FallbackIconDirective {
    static add(ngModule: ng.IModule): void;
}
export declare class TagsDirective {
    static add(ngModule: ng.IModule): void;
}
export declare class BrokenEntityDirective {
    static add(ngModule: ng.IModule): void;
}
export declare class TagValidationDirective {
    static add(ngModule: ng.IModule): void;
}
export declare class ConcatStringToCountFilter {
    static add(ngModule: ng.IModule): void;
}
export declare class SettingsAreaFilter {
    static add(ngModule: ng.IModule): void;
}
export declare class SettingsVisibilityFilter {
    static add(ngModule: ng.IModule): void;
}
export declare var init: (m: ng.IModule) => void;
