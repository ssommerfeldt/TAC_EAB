/// <reference path="../../../typings/angularjs/angular.d.ts" />
export declare class TemplateCacherAdmin {
    static cache(locationService: ng.ILocationService, templateCache: ng.ITemplateCacheService): void;
}
