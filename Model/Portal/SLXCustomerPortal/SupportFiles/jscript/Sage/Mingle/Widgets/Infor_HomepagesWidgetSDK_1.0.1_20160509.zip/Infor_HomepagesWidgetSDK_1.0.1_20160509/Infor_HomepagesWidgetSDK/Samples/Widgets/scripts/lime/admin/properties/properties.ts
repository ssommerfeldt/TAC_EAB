﻿import lm = require("../../lime");
import c = require("../../core");
import s = require("../service");

class AdminPropertiesCtrl extends c.CoreBase {
	public properties: s.IPropertyInfo[] = [];
	public propertiesGridOptions: any;
	public noOfSelected: number;
	public refreshText = "Refresh";

	private newProperty: s.IPropertyInfo;
	private chosenProperty: s.IPropertyInfo;
	private checkboxList: { [index: string]: boolean; } = {};

	static $inject = ["$scope", "lmAdminContext", "lmAdminService", "lmDialogService", "uiGridConstants"];

	constructor(public scope: ng.IScope, private adminContext: s.IAdminContext, private adminService: s.IAdminService, private dialogService: lm.IDialogService,
		private uiGridConstants: any) {
		super("[AdminPropertiesCtrl] ");

		this.initNewProperty();
		this.initGrid();

		const adminConstants = s.AdminConstants;
		// Watch to see if this tab is selected
		const self = this;
		scope.$watch(adminConstants.openTab, (tab) => {
			if (tab === adminConstants.propertiesTab) {
				self.getProperties(false);
			}
		});
	}

	/**
	* Get Properties
	*
	* Get properties from server and initialize grid.
	*
	* @ reload boolean Reload properties or use cached.
	* @ param callback Optional callback function called when response returns.
	*/
	public getProperties(reload: boolean, callback?: Function): void {
		const self = this;
		const adminService = self.adminService;
		adminService.setBusy(true);

		if (reload) {
			this.noOfSelected = 0;
			if (this.scope["gridApi"]) {
				this.scope["gridApi"].selection.clearSelectedRows();
			}
		}

		adminService.listProperties(reload).then((r: s.IPropertyInfoListResponse) => {
			const properties = r.content;
			self.properties = properties;
			self.propertiesGridOptions.data = properties;
			adminService.setBusy(false);
			if (callback) {
				callback();
			}
		}, (r: c.IOperationResponse) => {
			adminService.setBusy(false);
			adminService.handleError(r);

			if (callback) {
				callback();
			}
		});
	}

	/**
	* Export
	*
	* Exports all or selected properties.
	*/
	public exportProperties(selection: string): void {
		const adminService = this.adminService;
		if (selection === "all") {
			// Export all
			adminService.exportProperties();
		} else if (selection === "selected") {
			// Export selected
			const properties = this.getSelectedRows();
			adminService.exportProperties(properties);
		}
	}

	/**
	* Import Properties
	*
	* Opens a dialog that lets the user select a file for upload.
	* After a sucessful upload the properties are loaded from the server.
	*/
	public importProperties(): void {
		const dialogTitle = "Import Properties";
		const options: c.IImportOptions = {
			operation: c.EntityCategory.adHocProperties.toString(),
			title: dialogTitle,
			acceptFileExtension: ".json"
		};

		const self = this;
		this.adminService.openImportFilesDialog(options).then((r: lm.IDialogResult) => {
			const value = r.value;
			if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Success) {
				this.adminService.showUploadCompleteDialog(dialogTitle, value.message).then((result: lm.IDialogResult) => {
					if (result.button === lm.DialogButtonType.Ok) {
						self.getProperties(true);
					}
				});
			} else if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Fail) {
				self.adminService.showUploadCompleteDialog(dialogTitle, value.message, true);
			}
		});
	}

	public deleteProperty(property: s.IPropertyInfo): void {
		var propertyId = property.propertyId;
		const options: lm.IMessageDialogOptions = {
			title: "Remove Property",
			message: "Are you sure that you want to remove the property '" + propertyId + "'?",
			standardButtons: lm.StandardDialogButtons.YesNo
		}
        var self = this;
		var adminService = self.adminService;
		this.dialogService.showMessage(options).then((result: lm.IDialogResult) => {
			if (result.button === lm.DialogButtonType.Yes) {
				adminService.setBusy(true);
				adminService.deleteProperty(propertyId).then((r: c.IOperationResponse) => {
                    lm.ArrayUtil.removeByProperty(self.properties, "propertyId", propertyId);
                    this.adminService.unselectGridItem(property, this.scope["gridApi"]);
					adminService.setBusy(false);
				}, (r: c.IOperationResponse) => {
					adminService.setBusy(false);
					self.logResponse(r);
				});
			}
		});
	}

	public deleteProperties(): void {
		const options: lm.IMessageDialogOptions = {
			title: "Remove Properties",
			message: "Are you sure that you want to remove the selected properties?",
			standardButtons: lm.StandardDialogButtons.YesNo
		}

		const self = this;
		const adminService = self.adminService;
		this.dialogService.showMessage(options).then((result: lm.IDialogResult) => {
			if (result.button === lm.DialogButtonType.Yes) {
				adminService.setBusy(true);
				const properties = this.getSelectedRows();
				let noToUpdate = properties.length;
				this.noOfSelected = 0;
				angular.forEach(properties, (prop: s.IPropertyInfo) => {
					var id = prop.propertyId;
					adminService.deleteProperty(prop.propertyId).then((r: c.IOperationResponse) => {
						lm.ArrayUtil.removeByProperty(self.properties, "propertyId", id);
                        noToUpdate -= 1;
                        if (noToUpdate === 0) {
                            adminService.setBusy(false);
                        }
                        this.adminService.unselectGridItem(prop, this.scope["gridApi"]);
					}, (r: c.IOperationResponse) => {
						self.logResponse(r);
						adminService.setBusy(false);
					});
                });
                if (this.noOfSelected === 0) {
                    this.clearSelection();
                }
			}
		});
    }

    /**
     * Unselects a property and updates count.
     * @param property Property that was been deleted.
     * @param gridApiName Grid API.
     */
    private unselectProperty(property: s.IPropertyInfo, gridApi): void {
        if (lm.ArrayUtil.containsByProperty(gridApi.selection.getSelectedRows(), '$$hashKey', (<any>property).$$hashKey)) {
            gridApi.selection.toggleRowSelection(property);
            gridApi.selection.getSelectedRows();
            this.noOfSelected = gridApi.selection.getSelectedRows().length;
        }
    }

	public openAddEditPropertyConnection(isEdit: boolean, property?: s.IPropertyInfo): void {
		let dialogParam = { isEdit: false, property: this.newProperty };
		let dialogTitle = "Add Property";
		if (isEdit) {
			dialogTitle = "Edit Property";
			dialogParam = { property: property, isEdit: true };
		}

		const options = <lm.IDialogOptions>{
			title: dialogTitle,
			templateUrl: "scripts/lime/admin/templates/add-edit-property.html",
			parameter: dialogParam
		};

		const self = this;
		this.dialogService.show(options).then((r: lm.IDialogResult) => {
			const value = r.value;
			if (r.button === lm.DialogButtonType.Ok && value) {
				if (!isEdit) {
					self.newProperty = value;
					self.addProperty();
				} else {
					const properties = self.properties;
					self.chosenProperty = value;
					self.updateProperty();

					const propIndex = lm.ArrayUtil.indexByProperty(properties, "propertyId", value.propertyId);
					properties[propIndex] = value;
				}
			}
		});
	}

	private initGrid(): void {
		const self = this;
		const gridConstants = this.uiGridConstants;
		const containsFilter = gridConstants.filter.CONTAINS;
		const actionBtnTemplate = '<div class="ui-grid-cell-contents lm-center-text"><button type="button" ng-click="$event.stopPropagation();" class="btn-actions lm-transparent" xi-popupmenu="grid.appScope.ctrl.menuOptions"><span class="audible">Actions</span>' +
			'<svg class="icon" focusable="false" aria-hidden="false"><use xlink:href="#icon-more"/></svg></button>' +
			'<ul class="popupmenu actions top"><li><a ng-click="grid.appScope.ctrl.openAddEditPropertyConnection(true, row.entity)">Edit</a></li><li><a ng-click="grid.appScope.ctrl.deleteProperty(row.entity)">Delete</a></li></ul></div>';

		this.propertiesGridOptions = {
			columnDefs: [{
				field: "propertyId",
				name: "Name",
				sort: { direction: gridConstants.ASC, priority: 1 },
				filter: { condition: containsFilter },
				minWidth: 50,
				maxWidth: 600
			},
				{ field: "description", name: "Description", filter: { condition: containsFilter }, minWidth: 50, maxWidth: 600 },
				{ field: "propertyValue", name: "Value", enableColumnResizing: false },
				{ field: "area", name: "Area", enableColumnResizing: false },
				{ field: "actions", name: "Actions", maxWidth: 110, cellTemplate: actionBtnTemplate, enableFiltering: false, enableSorting: false, enableColumnResizing: false }],
			data: this.properties,
			rowHeight: 48,
			enableFiltering: true,
			enableSorting: true,
			enableColumnMenus: false,
			onRegisterApi: (gridApi) => {
				self.scope["gridApi"] = gridApi;
				self.noOfSelected = 0;
				const gridSelection = gridApi.selection;
				const onSelection = gridSelection.on;
				onSelection.rowSelectionChanged(self.scope, () => {
					self.noOfSelected = gridSelection.getSelectedRows().length;
				});
				onSelection.rowSelectionChangedBatch(self.scope, () => {
					self.noOfSelected = gridSelection.getSelectedRows().length;
				});
			}
		};
	}

	private getSelectedRows(): s.IPropertyInfo[] {
		return this.scope["gridApi"].selection.getSelectedRows();
	}

	private initNewProperty(): void {
		this.newProperty = { propertyId: "", propertyValue: "" };
	}

	private addProperty(): void {
		const self = this;
		const adminService = self.adminService;
		// Don't make request if the property name (id) already exists
		const newProperty = self.newProperty;
		const existingProperty = lm.ArrayUtil.itemByProperty(self.properties, "propertyId", newProperty.propertyId);
		if (!existingProperty) {
			adminService.setBusy(true);
			adminService.createProperty(newProperty).then((r: s.IPropertyInfoResponse) => {
				if (!r.content) {
					self.logResponse(r);
				} else {
					self.initNewProperty();
					self.properties.push(newProperty);
				}
				adminService.setBusy(false);
			}, (r: c.IOperationResponse) => {
				if (r.errorText) {
					adminService.handleError(r, "Could not add property. " + r.errorText + ".");
				} else {
					adminService.handleError(r, "Could not add property.");
				}
				adminService.setBusy(false);
			});
		} else {
			this.dialogService.showMessage({ title: "Could not add property.", message: "A property with that name already exists." });
			this.getProperties(true);
		}
	}

	private updateProperty(): void {
		const self = this;
		const adminService = self.adminService;
		adminService.setBusy(true);
		adminService.updateProperty(this.chosenProperty).then((r: s.IPropertyInfoResponse) => {
			adminService.setBusy(false);
		}, (r: c.IOperationResponse) => {
			adminService.setBusy(false);
			adminService.handleError(r);
		});
    }

    /**
     * Clear selection
     * 
     * Clears the selected pages in the grid.
     */
    private clearSelection(): void {
        this.noOfSelected = 0;
        const grid = this.scope["gridApi"];
        if (grid) {
            grid.selection.clearSelectedRows();
        }
    }

	static add(m: ng.IModule) {
		m.controller("lmAdminPropertiesCtrl", AdminPropertiesCtrl);
	}
}

export var init = (m: ng.IModule) => {
	AdminPropertiesCtrl.add(m);
}