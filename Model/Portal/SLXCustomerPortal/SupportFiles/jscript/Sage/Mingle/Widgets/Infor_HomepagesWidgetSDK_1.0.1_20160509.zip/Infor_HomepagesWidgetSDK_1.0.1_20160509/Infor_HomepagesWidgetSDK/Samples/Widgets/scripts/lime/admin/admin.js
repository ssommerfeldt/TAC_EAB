var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../lime", "../core"], function (require, exports, lm, c) {
    var AdminContainerCtrl = (function (_super) {
        __extends(AdminContainerCtrl, _super);
        function AdminContainerCtrl(rootScope, scope, adminContext, adminService) {
            var _this = this;
            _super.call(this, "[AdminContainerCtrl] ");
            this.rootScope = rootScope;
            this.scope = scope;
            this.adminContext = adminContext;
            this.adminService = adminService;
            Locale.set("en-US");
            adminService.setBusy(true);
            adminContext.initialize().then(function (r) {
                _this.onInitialized(r);
                adminService.setBusy(false);
            }, function (r) {
                adminService.setBusy(false);
                adminService.handleError(r);
            });
        }
        AdminContainerCtrl.prototype.onInitialized = function (r) {
            this.rootScope["lmAdminTool"] = r.content;
        };
        AdminContainerCtrl.$inject = ["$rootScope", "$scope", "lmAdminContext", "lmAdminService"];
        return AdminContainerCtrl;
    })(c.CoreBase);
    var AdminPageContainerDirective = (function () {
        function AdminPageContainerDirective() {
        }
        AdminPageContainerDirective.add = function (m) {
            m.directive("lmAdminContainer", ["$compile", function ($compile) {
                    return {
                        scope: true,
                        restrict: "E",
                        replace: true,
                        controller: AdminContainerCtrl,
                        templateUrl: "scripts/lime/admin/templates/admin.html",
                        link: function (scope, element, attributes, controller, transclude) {
                            lm.CommonUtil.detectBrowser();
                        }
                    };
                }]);
        };
        return AdminPageContainerDirective;
    })();
    exports.init = function (m) {
        AdminPageContainerDirective.add(m);
    };
});
//# sourceMappingURL=admin.js.map