﻿import angular = require("angular");
import service = require("./service");
import admin = require("./admin");
import settings = require("./settings/settings");
import properties = require("./properties/properties");
import privatePages = require("./pages/private-pages");
import publishedPages = require("./pages/published-pages");
import pageAccess = require("./pages/page-access");
import publishedWidgets = require("./widgets/published-widgets");
import standardWidgets = require("./widgets/standard-widgets");
import widgetAccess = require("./widgets/widget-access");
import settingSetValue = require("./settings/setting-set-value");
import settingAddEditRule = require("./settings/setting-add-edit-rule");
import ruleAddConnection = require("./settings/rule-add-connection");
import addEditProperty = require("./properties/add-edit-property");
import saveAndDiscard = require("./settings/setting-save-and-discard");
import errors = require("./errors");
import adminImportExport = require("./import-export");
import tc = require("./templates/template-cache-admin");

var configureModule = (m: ng.IModule): void => {
	m.config([
		"$controllerProvider", "$provide", "$compileProvider", "$locationProvider", ($controllerProvider, $provide, $compileProvider, $locationProvider) => {
			m.controller = $controllerProvider.register;
			m.service = $provide.service;
			m.directive = $compileProvider.directive;
			$locationProvider.html5Mode({
				enabled: true,
				requireBase: false
			});
		}
	]);
};

var configureCaching = (m: ng.IModule): void => {
	m.run([
		"$location", "$templateCache", ($location, $templateCache) => {
			tc.TemplateCacherAdmin.cache($location, $templateCache);
		}
	]);
}

var m = angular.module("lime.admin", ["ui.sortable", "ui.grid", "ui.grid.selection", "ui.grid.pagination", "ui.grid.resizeColumns", "sohoxi", "lime", "lime.internal"]);
configureModule(m);
configureCaching(m);

service.init(m);
admin.init(m);
settings.init(m);
properties.init(m);
settingSetValue.init(m);
settingAddEditRule.init(m);
ruleAddConnection.init(m);
addEditProperty.init(m);
saveAndDiscard.init(m);
privatePages.init(m);
publishedPages.init(m);
publishedWidgets.init(m);
standardWidgets.init(m);
widgetAccess.init(m);
errors.init(m);
pageAccess.init(m);
adminImportExport.init(m);