var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../lime", "../../core", "../service"], function (require, exports, lm, c, s) {
    var AdminPublishedWidgetsCtrl = (function (_super) {
        __extends(AdminPublishedWidgetsCtrl, _super);
        function AdminPublishedWidgetsCtrl(scope, adminService, adminContext, dialogService, widgetService, uiGridConstants) {
            var _this = this;
            _super.call(this, "[AdminPublishedWidgetsCtrl] ");
            this.scope = scope;
            this.adminService = adminService;
            this.adminContext = adminContext;
            this.dialogService = dialogService;
            this.widgetService = widgetService;
            this.uiGridConstants = uiGridConstants;
            this.publishedWidgets = [];
            this.refreshText = "Refresh";
            this.initGrid();
            var adminConstants = s.AdminConstants;
            var self = this;
            scope.$watch(adminConstants.openTab, function (tab) {
                if (tab === adminConstants.publishedWidgetsTab && !_this.isSearchActive) {
                    self.listPublishedWidgets(false);
                }
            });
        }
        AdminPublishedWidgetsCtrl.prototype.onError = function (error) {
            this.adminService.handleError(error);
            this.setBusy(false);
        };
        AdminPublishedWidgetsCtrl.prototype.setBusy = function (isBusy) {
            this.adminService.setBusy(isBusy);
        };
        AdminPublishedWidgetsCtrl.prototype.searchWidget = function (id) {
            if (!lm.StringUtil.isNullOrWhitespace(id)) {
                id = id.trim();
                var result = lm.ArrayUtil.find(this.publishedWidgets, function (item) {
                    return (item.widgetId === id);
                });
                this.scope["widgetsGridApi"].selection.clearSelectedRows();
                this.widgetsGridOptions.data = result ? [result] : [];
                this.isSearchActive = true;
            }
        };
        AdminPublishedWidgetsCtrl.prototype.showGuidSearchDialog = function () {
            var _this = this;
            var options = {
                title: "Search",
                templateUrl: "scripts/lime/admin/templates/guid-search-dialog.html"
            };
            this.dialogService.show(options).then(function (r) {
                if (!lm.CommonUtil.isUndefined(r.value) && r.button === lm.DialogButtonType.Ok) {
                    var query = r.value;
                    if (query) {
                        _this.searchWidget(query);
                    }
                }
            });
        };
        AdminPublishedWidgetsCtrl.prototype.listPublishedWidgets = function (reload, callback) {
            var self = this;
            var adminService = self.adminService;
            self.scope["searchIdString"] = "";
            self.isSearchActive = false;
            if (reload) {
                this.noOfSelected = 0;
                if (this.scope["widgetsGridApi"]) {
                    this.scope["widgetsGridApi"].selection.clearSelectedRows();
                }
            }
            adminService.setBusy(true);
            adminService.listPublishedWidgets(reload).then(function (r) {
                var publishedWidgets = r.content;
                self.publishedWidgets = publishedWidgets;
                self.widgetsGridOptions.data = publishedWidgets;
                adminService.setBusy(false);
                if (callback) {
                    callback();
                }
            }, function (r) {
                adminService.setBusy(false);
                adminService.handleError(r);
                if (callback) {
                    callback();
                }
            });
        };
        AdminPublishedWidgetsCtrl.prototype.import = function () {
            var _this = this;
            var dialogTitle = "Import Published Widgets";
            var adminService = this.adminService;
            var options = {
                title: dialogTitle,
                operation: c.EntityCategory.publishedWidget.toString()
            };
            var self = this;
            adminService.openImportFilesDialog(options).then(function (r) {
                var value = r.value;
                if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Success) {
                    _this.adminService.showUploadCompleteDialog(dialogTitle, value.message).then(function (result) {
                        if (result.button === lm.DialogButtonType.Ok) {
                            self.listPublishedWidgets(true);
                        }
                    });
                }
                else if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Fail) {
                    adminService.showUploadCompleteDialog(dialogTitle, value.message, true);
                }
            });
        };
        AdminPublishedWidgetsCtrl.prototype.export = function () {
            if (this.noOfSelected === this.publishedWidgets.length) {
                this.exportAll();
            }
            else {
                var widgetsToExport = this.getSelectedRows();
                this.adminService.exportPublishedWidgets(widgetsToExport);
            }
        };
        AdminPublishedWidgetsCtrl.prototype.exportAll = function () {
            this.adminService.exportPublishedWidgets();
        };
        AdminPublishedWidgetsCtrl.prototype.delete = function () {
            var widgetsToDelete = this.getSelectedRows();
            var widgetList = widgetsToDelete.map(function (widget) {
                return widget.widgetId;
            });
            this.deletePublished(widgetList);
        };
        AdminPublishedWidgetsCtrl.prototype.openWidgetAccessDialog = function (widget) {
            var _this = this;
            this.adminService.openWidgetAccessDialog(widget, function (resp) {
                if (resp && resp.content) {
                    _this.updateAfterWidgetAccessUpdate(resp.content);
                    _this.setBusy(false);
                }
                else {
                    _this.onError(resp);
                }
            });
        };
        AdminPublishedWidgetsCtrl.prototype.updateAfterWidgetAccessUpdate = function (widgetInfo) {
            var existing = lm.ArrayUtil.find(this.publishedWidgets, function (info) { return info.widgetId === widgetInfo.widgetId; });
            if (existing) {
                existing.hasAccess = widgetInfo.hasAccess;
                existing.hasRestrictions = widgetInfo.hasRestrictions;
            }
        };
        AdminPublishedWidgetsCtrl.prototype.updateOwner = function (existing, updated) {
            existing.owner = updated.owner;
            existing.ownerName = updated.ownerName;
            existing.changedByName = updated.changedByName;
            existing.changeDate = updated.changeDate;
        };
        AdminPublishedWidgetsCtrl.prototype.takeOwnership = function (widget) {
            var self = this;
            this.setBusy(true);
            this.widgetService.updatePublishedOwner(widget.widgetId, null).then(function (response) {
                self.updateOwner(widget, response.content);
                self.setBusy(false);
            }, function (e) {
                self.onError(e);
            });
        };
        AdminPublishedWidgetsCtrl.prototype.changeOwnership = function (widget) {
            var self = this;
            this.adminService.openChangeOwnerDialog(widget.title, widget.owner, function (newOwner) {
                if (widget.owner !== newOwner.value) {
                    self.setBusy(true);
                    self.widgetService.updatePublishedOwner(widget.widgetId, newOwner.value).then(function (response) {
                        self.updateOwner(widget, response.content);
                        self.setBusy(false);
                    }, function (e) {
                        self.onError(e);
                    });
                }
            });
        };
        AdminPublishedWidgetsCtrl.prototype.copyAccess = function (widget) {
            var self = this;
            var widgetId = widget.widgetId;
            var adminService = self.adminService;
            adminService.setBusy(true);
            adminService.getWidgetAccess({ id: widgetId, accessList: [] }).then(function (r) {
                self.accessCopy = r.content.accessList;
                self.accessCopyWidgetId = widgetId;
                adminService.setBusy(false);
            }, function (r) {
                self.adminService.handleError(r);
                adminService.setBusy(false);
            });
        };
        AdminPublishedWidgetsCtrl.prototype.applyAccessCopy = function (widget) {
            var _this = this;
            var widgets = widget ? [widget] : this.getSelectedRows();
            this.adminService.applyWidgetAccess(widgets, this.accessCopy, function () {
                _this.listPublishedWidgets(true);
            });
        };
        AdminPublishedWidgetsCtrl.prototype.clearOrReplaceWithAccessCopy = function (isReplace, widget) {
            var _this = this;
            var widgetsToUpdate = widget ? [widget] : this.getSelectedRows();
            this.adminService.clearOrReplaceWidgetAccess(widgetsToUpdate, isReplace, function () {
                _this.listPublishedWidgets(true);
            }, this.accessCopy);
        };
        AdminPublishedWidgetsCtrl.prototype.initGrid = function () {
            var gridConstants = this.uiGridConstants;
            var adminConstants = s.AdminConstants;
            var widgetActionTemplate = '<div class="ui-grid-cell-contents lm-center-text"><button type="button" ng-click="$event.stopPropagation();" ng-disabled="row.entity.widgetErrorInfo" class="btn-actions lm-transparent" xi-popupmenu="grid.appScope.ctrl.menuOptions"><span class="audible">Actions</span>' +
                '<svg class="icon" focusable="false" aria-hidden="false"><use xlink:href="#icon-more"/></svg></button><ul class="popupmenu actions top"><li><a ng-click="grid.appScope.ctrl.openWidgetAccessDialog(row.entity)">Edit Permissions</a></li>' +
                '<li ng-show="row.entity.hasAccess"><a ng-click="grid.appScope.ctrl.copyAccess(row.entity)">Copy Permissions</a></li><li ng-show="grid.appScope.ctrl.accessCopy && grid.appScope.ctrl.accessCopyWidgetId !== row.entity.widgetId" class="separator"></li>' +
                '<li ng-show="grid.appScope.ctrl.accessCopy && grid.appScope.ctrl.accessCopyWidgetId !== row.entity.widgetId"><a ng-click="grid.appScope.ctrl.applyAccessCopy(row.entity)">Apply Copied Permissions</a></li><li ng-show="grid.appScope.ctrl.accessCopyWidgetId && grid.appScope.ctrl.accessCopyWidgetId !== row.entity.widgetId && row.entity.hasAccess">' +
                '<a ng-click="grid.appScope.ctrl.clearOrReplaceWithAccessCopy(true, row.entity)">Replace Copied Permissions</a></li><li class="separator"></li><li><a ng-click="grid.appScope.ctrl.takeOwnership(row.entity)">Take Ownership</a></li><li><a ng-click="grid.appScope.ctrl.changeOwnership(row.entity)">Change Ownership</a></li><li class="separator"></li>' +
                '<li ng-show="row.entity.hasAccess"><a ng-click="grid.appScope.ctrl.clearOrReplaceWithAccessCopy(false, row.entity)">Clear Permissions</a></li><li><a ng-click="grid.appScope.ctrl.deletePublished(row.entity)">Delete</a></li></ul></div>';
            var rowTemplate = '<div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{\'disabled\': row.entity.widgetErrorInfo && col.colDef.name !== \'selectionRowHeaderCol\' }" ui-grid-cell></div>';
            var self = this;
            this.widgetsGridOptions = {
                paginationPageSizes: [adminConstants.gridPageSize],
                paginationPageSize: adminConstants.gridPageSize,
                columnDefs: [{
                        field: "title", name: "Title",
                        sort: { direction: gridConstants.ASC, priority: 1 },
                        filter: { condition: gridConstants.filter.CONTAINS },
                        minWidth: 50, maxWidth: 600
                    },
                    { field: "description", name: "Description", minWidth: 50, maxWidth: 600 },
                    { field: "ownerName", name: "Owner", minWidth: 50, maxWidth: 600 },
                    { field: "standardWidgetId", name: "BasedOn", displayName: "Based on", minWidth: 50, maxWidth: 600 },
                    {
                        field: "changeDate", name: "ChangeDate", displayName: "Change date",
                        cellTemplate: "<div class='ui-grid-cell-contents'>{{COL_FIELD | lmLocaleDate}}</div>", minWidth: 50, maxWidth: 600
                    },
                    { field: "changedByName", name: "ChangeBy", displayName: "Changed by", minWidth: 50, maxWidth: 600 },
                    {
                        field: "hasRestrictions", name: "Permissions", enableFiltering: false, maxWidth: 140,
                        cellTemplate: "<div class='ui-grid-cell-contents'>{{COL_FIELD ? 'Restricted' : ''}}</div>", enableColumnResizing: false
                    },
                    { field: "actions", name: "Actions", maxWidth: 110, cellTemplate: widgetActionTemplate, enableFiltering: false, enableSorting: false, enableColumnResizing: false }],
                data: [],
                rowHeight: 48,
                rowTemplate: rowTemplate,
                enableFiltering: true,
                enableSorting: true,
                enableColumnMenus: false,
                onRegisterApi: function (gridApi) {
                    self.scope["widgetsGridApi"] = gridApi;
                    self.noOfSelected = 0;
                    var gridSelection = gridApi.selection;
                    var onSelection = gridSelection.on;
                    onSelection.rowSelectionChanged(self.scope, function () {
                        self.noOfSelected = gridSelection.getSelectedRows().length;
                    });
                    onSelection.rowSelectionChangedBatch(self.scope, function () {
                        self.noOfSelected = gridSelection.getSelectedRows().length;
                    });
                }
            };
        };
        AdminPublishedWidgetsCtrl.prototype.getSelectedRows = function () {
            return this.scope["widgetsGridApi"].selection.getSelectedRows();
        };
        AdminPublishedWidgetsCtrl.prototype.deletePublished = function (widgets) {
            var _this = this;
            var isMultiple = Array.isArray(widgets);
            var title = isMultiple ? "Delete Widgets" : "Delete Widget";
            var message = isMultiple ? "Are you sure that you want to remove the selected widgets? They will be removed for all users." :
                "Are you sure that you want to remove the widget '" + widgets.title + "'? It will be removed for all users.";
            var options = {
                title: title,
                message: message,
                standardButtons: lm.StandardDialogButtons.YesNo
            };
            var widgetArray = isMultiple ? widgets : [widgets.widgetId];
            var self = this;
            this.dialogService.showMessage(options).then(function (result) {
                if (result.button === lm.DialogButtonType.Yes) {
                    _this.setBusy(true);
                    self.widgetService.deletePublished(widgetArray).then(function (r) {
                        if (r.content > 0) {
                            for (var _i = 0; _i < widgetArray.length; _i++) {
                                var widgetId = widgetArray[_i];
                                _this.adminService.unselectGridItem(lm.ArrayUtil.itemByProperty(self.publishedWidgets, "widgetId", widgetId), _this.scope["widgetsGridApi"]);
                                lm.ArrayUtil.removeByProperty(self.publishedWidgets, "widgetId", widgetId);
                            }
                        }
                        _this.setBusy(false);
                    }, function (r) {
                        _this.setBusy(false);
                        self.adminService.handleError(r, r.errorText);
                    });
                }
            });
        };
        AdminPublishedWidgetsCtrl.prototype.clearSelection = function () {
            this.noOfSelected = 0;
            var grid = this.scope["widgetsGridApi"];
            if (grid) {
                grid.selection.clearSelectedRows();
            }
        };
        AdminPublishedWidgetsCtrl.add = function (m) {
            m.controller("lmAdminPublishedWidgetsCtrl", AdminPublishedWidgetsCtrl);
        };
        AdminPublishedWidgetsCtrl.$inject = ["$scope", "lmAdminService", "lmAdminContext", "lmDialogService", "lmWidgetService", "uiGridConstants"];
        return AdminPublishedWidgetsCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        AdminPublishedWidgetsCtrl.add(m);
    };
});
//# sourceMappingURL=published-widgets.js.map