﻿import lm = require("../../lime");
import c = require("../../core");
import s = require("../service");

class SettingSetValueCtrl extends c.CoreBase {
	public item: c.ISettingItem;
	public pages: c.IPage[];
	public sortableOptions: any;

	private dialog: lm.IDialog;

	static $inject = ["$scope", "lmAdminService", "lmDialogService"];

	constructor(public scope: ng.IScope, private adminService: s.IAdminService, private dialogService: lm.IDialogService) {
		super("[SettingsSetValueCtrl] ");
		var dialog: lm.IDialog = scope["lmDialog"];
		var dialogParameter = dialog.parameter;
		this.dialog = dialog;
		var settingItem: c.ISettingItem = angular.copy(dialogParameter.setting);
		var settingValue = settingItem.value;
		this.item = settingItem;

		// If the display value is the same as the ID, the page has been deleted
		if (settingItem.displayValue === settingValue && settingItem.type !== "string" && settingItem.type !== "int") {
			settingValue = "";
		}

		var pages: c.IPage[] = angular.copy(dialogParameter.pages);
		this.pages = pages;

		// Make mandatory pages sortable
		if (settingItem.type === c.SettingsNames.mandatoryPages) {
			var mandatories = settingValue ? settingValue.split(",") : [];
			settingValue = [];
			mandatories.forEach((id: string) => {
				pages.forEach((page: c.IPage) => {
					if (id === page.data.id) {
						settingValue.push(page);
					}
				});
			});
			this.sortableOptions = {
				connectWith: ".mandatory-pages-container",
				axis: "y"
			};
		} 
		// Set missing boolean value to false
		if (settingItem.type === "boolean" && !settingValue) {
			settingValue = false;
		}

		// Set value back for bindings
		this.item.value = settingValue;
	}

	public onCancel(): void {
		var result: lm.IDialogResult = {
			button: lm.DialogButtonType.Cancel,
			value: null
		};
		this.dialog.close(result);
	}

	public onOk(): void {
		var item = this.item;
		item.changeDate = lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*";
		item.changedByName = this.dialog.parameter.userName;
		item.setting.isChanged = true;

		// Mandatory has to be handled outside
		if (item.type !== c.SettingsNames.mandatoryPages) {
			item.displayValue = this.getDisplayValue();
		}

		var result: lm.IDialogResult = {
			button: lm.DialogButtonType.Ok,
			value: item
		};
		this.dialog.close(result);
	}

	private getDisplayValue(): string {
		var displayValue;
		var item = this.item;
		var itemValue = item.value;
		var itemType = item.type;
		if (itemType === c.SettingsNames.defaultPage || itemType === c.SettingsNames.startPage) {
			displayValue = this.adminService.getPageDisplayTitle(itemValue);
		} else if (itemType === "selector") {
			var valueObject = lm.ArrayUtil.itemByProperty(item.setting.values, "value", itemValue);
			if (valueObject) {
				displayValue = valueObject.label;
			} else {
				displayValue = itemValue;
			}
		} else {
			displayValue = itemValue;
		}
		return displayValue;
	}

	public static add(m: ng.IModule) {
		m.controller("lmSettingSetValueCtrl", SettingSetValueCtrl);
	}
}

export var init = (m: ng.IModule) => {
	SettingSetValueCtrl.add(m);
}