﻿import lm = require("../../lime");
import c = require("../../core");
import s = require("../service");

class AdminPrivatePagesCtrl extends c.CoreBase {
	public privatePages: c.IPage[] = [];
	public noOfSelected: number;
	public selectedUser: string;
	public selectedUserEmail: string;
	public selectedUserDisplayName: string;
	public pagesGridOptions: any;
	public refreshText = "Refresh";

	private isAutocompleteInitialized: boolean;
	private autocompleteElem: JQuery;

	static $inject = ["$scope", "lmAdminService", "lmDialogService", "lmPageService", "lmCommonDataService", "uiGridConstants"];

	constructor(public scope: ng.IScope, private adminService: s.IAdminService, private dialogService: lm.IDialogService, private pageService: c.IPageService,
		private commonDataService: c.ICommonDataService, private uiGridConstants: any) {
		super("[AdminPrivatePagesCtrl] ");

		this.initGrid();
		const adminConstants = s.AdminConstants;

		// Watch to see if this tab is selected
		const self = this;
		scope.$watch(adminConstants.openTab, (tab) => {
			if (tab === adminConstants.privatePagesTab) {
				if (self.selectedUser) {
					self.listPrivatePages(self.selectedUser, false);
				}
			}
		});

		scope.$on("$destroy", () => {
			this.autocompleteElem.off();
		});
	}

	private setBusy(isBusy: boolean): void {
		this.adminService.setBusy(isBusy);
	}

	private onError(error: any): void {
		this.adminService.handleError(error);
		this.setBusy(false);
	}

	/**
	 * List Private Pages
	 *
	 * Lists private pages from cache or server.
	 *
	 * @param userId ID of user.
	 * @param reload Boolean - True: load from server. False: load from cache.
	 * @param callback Function to call on successful load from cache/server.
	 */
	public listPrivatePages(userId: string, reload: boolean, callback?: Function): void {
		const self = this;
		const adminService = self.adminService;

		if (reload) {
			this.noOfSelected = 0;
			if (this.scope["pagesGridApi"]) {
				this.scope["pagesGridApi"].selection.clearSelectedRows();
			}
		}

		adminService.setBusy(true);
		adminService.listPrivatePages(userId, reload).then((r: c.IPageListResponse) => {
			const privatePages = r.content;
			self.privatePages = privatePages;
			self.pagesGridOptions.data = privatePages;
			adminService.setBusy(false);
			if (callback) {
				callback();
			}
		}, (r: c.IOperationResponse) => {
			adminService.handleError(r);
			adminService.setBusy(false);
			if (callback) {
				callback();
			}
		});
	}

	/**
	 * Import
	 *
	 * Import private pages.
	 */
	public import(): void {
		const dialogTitle = "Import Private Pages";
		const adminService = this.adminService;
		const options: c.IImportOptions = {
			title: dialogTitle,
			operation: c.EntityCategory.privatePage.toString()
		};
		const map: c.IStringMap = {};
		map["userId"] = this.selectedUser;
		options.formFields = map;

		const self = this;
		adminService.openImportFilesDialog(options).then((r: lm.IDialogResult) => {
			const value = r.value;
			if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Success) {
				this.adminService.showUploadCompleteDialog(dialogTitle, value.message).then((result: lm.IDialogResult) => {
					if (result.button === lm.DialogButtonType.Ok) {
						self.listPrivatePages(self.selectedUser, true);
					}
				});
			} else if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Fail) {
				adminService.showUploadCompleteDialog(dialogTitle, value.message, true);
			}
		});
	}

	/**
	 * Export
	 *
	 * Exports selected private pages.
	 */
	public export(): void {
		if (this.noOfSelected === this.privatePages.length) {
			this.exportAll();
		} else {
			const pagesToExport = this.getSelectedRows();
			this.adminService.exportPrivatePages(this.selectedUser, pagesToExport);
		}
	}

	/**
	 * Export All
	 *
	 * Exports all private pages.
	 */
	public exportAll(): void {
		this.adminService.exportPrivatePages(this.selectedUser);
	}

	/**
	 * Delete
	 *
	 * Deletes the provided page or selected pages in the grid.
	 *
	 * @param page Page to delete (if single page).
	 */
	public delete(page?: c.IPage): void {
		const pagesToDelete = page ? [page] : this.getSelectedRows();

        var options = this.adminService.getDeletePageOptions(pagesToDelete, true);
        this.dialogService.showMessage(options).then((result: lm.IDialogResult) => {
            if (result.button === lm.DialogButtonType.Yes) {
                this.deletePrivatePage(pagesToDelete);
            }
        });
    }

	/**
	 * Init Grid
	 *
	 * Initializes the grid and sets up the autocomplete control.
	 */
	private initGrid(): void {
		const gridConstants = this.uiGridConstants;
		const pageActionTemplate = '<div class="ui-grid-cell-contents lm-center-text"><button type="button" ng-click="$event.stopPropagation();" class="btn-actions lm-transparent" xi-popupmenu="grid.appScope.ctrl.menuOptions">' +
			'<span class="audible">Actions</span><svg class="icon" focusable="false" aria-hidden="false"><use xlink:href="#icon-more"/></svg></button><ul class="popupmenu actions top"><li><a ng-click="grid.appScope.ctrl.delete(row.entity)">Delete</a></li></ul></div>';

		const self = this;
		this.pagesGridOptions = {
			columnDefs: [{
				field: "data.title",
				name: "Title",
				sort: { direction: gridConstants.ASC, priority: 1 },
				filter: { condition: gridConstants.filter.CONTAINS },
				minWidth: 50, maxWidth: 600
			},
				{ field: "data.ownerName", name: "Owner", enableFiltering: false, enableColumnResizing: false },
				{
					field: "data.changeDate", name: "ChangeDate", displayName: "Change date", enableColumnResizing: false,
					cellTemplate: "<div class='ui-grid-cell-contents'>{{COL_FIELD | lmLocaleDate}}</div>"
				},
				{ field: "data.changedByName", name: "ChangedBy", displayName: "Changed by", enableColumnResizing: false },
				{ field: "actions", name: "Actions", maxWidth: 110, cellTemplate: pageActionTemplate, enableFiltering: false, enableSorting: false, enableColumnResizing: false }
			],
			data: [],
			rowHeight: 48,
			enableFiltering: true,
			enableSorting: true,
			enableColumnMenus: false,
			onRegisterApi: (gridApi) => {
				self.scope["pagesGridApi"] = gridApi;
				self.noOfSelected = 0;
				const gridSelection = gridApi.selection;
				const onSelection = gridSelection.on;

				onSelection.rowSelectionChanged(self.scope, () => {
					self.noOfSelected = gridSelection.getSelectedRows().length;
				});
				onSelection.rowSelectionChangedBatch(self.scope, () => {
					self.noOfSelected = gridSelection.getSelectedRows().length;
				});
			}
		}

		if (!this.isAutocompleteInitialized) {
			this.scope["autocomplete"] = {
				source: (query, done) => {
					self.commonDataService.searchUsers(query).then((response: c.IUserListResponse) => {
						done(query, lm.ArrayUtil.sortByProperty(c.CoreUtil.getEntityArray(response.content), "label"));
					}, (r: c.IOperationResponse) => {
						self.commonDataService.handleError(r);
					});
				},
				template: c.Templates.autocompleteEntity
			}

			this.autocompleteElem = $("#autocomplete-private-pages");

			this.autocompleteElem.on("selected", (event, target, object: lm.IAutocompleteEntity) => {
				if (lm.CommonUtil.isUndefined(object) || lm.CommonUtil.isUndefined(object.value)) {
					return;
				}

				self.selectedUser = object.value;
				self.selectedUserEmail = object.info;
				self.selectedUserDisplayName = object.label;
				self.listPrivatePages(self.selectedUser, true);
			});
			this.isAutocompleteInitialized = true;
		}
	}

	private getSelectedRows(): c.IPage[] {
		return this.scope["pagesGridApi"].selection.getSelectedRows();
	}

	/**
	 * Delete Private Page
	 *
	 * Calls rest api to delete provided page IDs.
	 *
	 * @param pages IDs of pages to be deleted.
	 */
	private deletePrivatePage(pages): void {
        var self = this;
        var pageList = pages.map((page) => {
            return page.data.id;
        });
		this.setBusy(true);
		this.adminService.deletePrivatePages(pageList).then((r: c.IIntegerResponse) => {
			if (r.content > 0) {
                for (var page of pages) {
                    this.adminService.unselectGridItem(lm.ArrayUtil.itemByPredicate(self.privatePages, (item) => item.data.id === page.data.id), this.scope["pagesGridApi"]);
                    lm.ArrayUtil.removeByPredicate(self.privatePages, (item) => item.data.id === page.data.id);
                }
			}
			self.setBusy(false);
		}, (e) => {
			self.onError(e);
		});
    }

    /**
     * Clear selection
     * 
     * Clears the selected pages in the grid.
     */
    private clearSelection(): void {
        this.noOfSelected = 0;
        const grid = this.scope["pagesGridApi"];
        if (grid) {
            grid.selection.clearSelectedRows();
        }
    }

	static add(m: ng.IModule) {
		m.controller("lmAdminPrivatePagesCtrl", AdminPrivatePagesCtrl);
	}
}

export var init = (m: ng.IModule) => {
	AdminPrivatePagesCtrl.add(m);
}