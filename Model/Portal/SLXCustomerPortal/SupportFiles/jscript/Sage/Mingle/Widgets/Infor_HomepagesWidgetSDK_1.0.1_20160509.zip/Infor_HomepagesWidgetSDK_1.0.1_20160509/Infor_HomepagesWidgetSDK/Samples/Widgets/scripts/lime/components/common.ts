﻿import lm = require("../lime");
import c = require("../core");

export class CapitalizeFilter {
	static add(ngModule: ng.IModule) {
		ngModule.filter("capitalize", [() => {
			return (value: string) => {
				return value.charAt(0).toUpperCase() + value.substr(1);
			};
		}]);
	}
}

/**
* Locale date filter
*
* Use to format date strings to current locale
*/
export class LocaleDateFilter {
	static add(ngModule: ng.IModule) {
		ngModule.filter("lmLocaleDate", [() => {
			return (value: string) => {
				return lm.CommonUtil.getLocaleDateString(value);
			};
		}]);
	}
}

/**
* Ellipsis filter
*
* Use to truncate a string if exceeding the max length property
*/
export class EllipsisFilter {
	static add(ngModule: ng.IModule) {
		ngModule.filter("lmEllipsis", [() => {
			return (value: string, maxLength: number) => {
				return value && (value.length > maxLength) ? value.substr(0, maxLength - 3) + "..." : value;
			};
		}]);
	}
}

/**
* Icon Fallback Directive
*
* Used to add fallback icon in Widget Catalog
*/
export class FallbackIconDirective {
	static add(ngModule: ng.IModule) {
		ngModule.directive("fallbackIcon", () => {
			return {
				link: (scope: any, element, attrs) => {
					element.bind('error', () => {
						if (attrs.src !== attrs.fallbackIcon) {
							attrs.$set('src', attrs.fallbackIcon);
						}
					});
				}
			}
		});
	}
}


/**
* Tags Directive
*
* Used to show widget/page tags in view. Splits tag string into tags array and generates tag elements. 
* Updates searchInput to search on a tag when clicked
*/

export class TagsDirective {
	static add(ngModule: ng.IModule) {
		ngModule.directive("lmTags", ["$compile", ($compile) => {
			return {
				restrict: "E",
				replace: true,
				scope: {
					tags: "=",
					callback: "&onTagClickUpdate",
					disabled: "="
				},
				link: (scope, element) => {
					var tags = scope["tags"].split('#');
					tags.splice(0, 1); // to avoid first empty split contribution
					angular.forEach(tags, (tag) => {
						var hashLink = $("<a/>").addClass("hyperlink");
						if (scope["disabled"] === true) {
							hashLink.attr({ "disabled": "disabled", "aria-disabled": true });
						} else {
							scope.onClick = (tagName) => {
								scope.callback({ tag: tagName });
							};
							hashLink.attr("ng-click", "onClick('#" + tag.toLowerCase() + "')");
						}
						hashLink.html("#" + tag);
						element.append($compile(hashLink)(scope));
					});
				},
				template: "<span/>"
			}
		}]);
	}
}

/**
* Broken Entity Directive
*
* Directive for showing an icon and a message telling the user that a widget or page is broken.
*
* Example:
* <lm-broken-entity></lm-broken-entity>
*/
export class BrokenEntityDirective {
	static add(ngModule: ng.IModule) {
		ngModule.directive("lmBrokenEntity", () => {
			return {
				restrict: "E",
				replace: true,
				scope: {
					message: "="
				},
				template: '<div class="broken-entity"><div><p>{{message}}</p></div></div>'
			}
		});
	}
}

/**
 * Repeat Completed Directive
 * 
 * Directive that triggers an event when an ngRepeat is completed. Useful to reduce scope.$apply calls.
 * 
 * Example:
 * <div ng-repeat="item in items" lm-repeat-completed="onRepeatCompleted"></div>
 * 
 * In controller:
 * scope["onRepeatCompleted"] = () => { this.executeSomething(); };
 */
class RepeatCompletedDirective {
	static add(m: ng.IModule) {
		m.directive("lmRepeatCompleted", () => {
			return {
				link: (scope: ng.IScope, element: ng.IAugmentedJQuery, attributes: ng.IAttributes) => {
					if (scope["$last"] && attributes["lmRepeatCompleted"]) {
						var execute = scope.$eval(attributes["lmRepeatCompleted"]);
						if (!lm.CommonUtil.isUndefined(execute)) {
							execute();
						}
					}
				}
			}
		});
	}
}


/**
* Tag Validation Directive
*
* Handles validation and sanitation of tags.
*
* Example: 
* <input ng-trim="false" ng-model="tags" lm-tag-validation="errorMsg">
* tags = "#alpha #bravo"
* errorMsg = null
* 
* Note: 
* - set ng-trim to false to make the directive react to spaces as input.
*/
export class TagValidationDirective {
	static add(ngModule: ng.IModule) {
		ngModule.directive("lmTagValidation", ["lmTagService", (tagService: c.ITagService) => {
			return {
				require: "?ngModel",
				restrict: "A",
				scope: {
					lmTagValidation: "=",
					invalidChar: "@"
				},
				link: (scope, element: ng.IAugmentedJQuery, attrs: ng.IAttributes, ngModel) => {
					if (!ngModel) { return; }

					// Block invalid characters.
					element.keypress((e) => {
						if (e.which > 32) {
							var character = String.fromCharCode(e.which);
							if (!/[A-Za-z0-9_# ]/.test(character)) {
								e.preventDefault();
								return false;
							}
						}
					});

					// Remove spaces from the model.
					ngModel.$parsers.push((value) => {
						var returnValue = value;

						// Remove spaces from the model. Observe that this does not affect the view model.
						if (value.indexOf("#") !== -1) {
							var newValue = value.replace(/( *)#/g, "#");
							if (newValue[newValue.length - 1] === " ") {
								newValue = newValue.substring(0, newValue.length - 1);
							}
							returnValue = newValue;
						}
						return returnValue;
					});

					var requiredFields;
					//Make validity check and return error message if invalid.
					ngModel.$validators.tagValidator = (modelValue) => {
						var returnValue = false;
						if (modelValue) {
							var response: c.IAreTagsValidResponse = tagService.areTagsValid(modelValue);
							if (response.areValid) {
								scope.lmTagValidation = null;
								element.removeClass("error");
								ngModel.$setValidity("lmTagValidation", true);
								returnValue = true;
							} else {
								scope.lmTagValidation = response.errorMsg;
								element.addClass("error");
								ngModel.$setValidity("lmTagValidation", false);
							}
						} else {
							if (!scope.invalidChar) {
								scope.lmTagValidation = null;
								scope.invalidChar = false;
							};
							element.removeClass("error");
							ngModel.$setValidity("lmTagValidation", true);
							returnValue = true;
						}
						if (lm.CommonUtil.isUndefined(requiredFields)) {
							requiredFields = element.closest("form").find("input.required, textarea.required");
						}
						// Run form validation on other required fields if such exist
						if (requiredFields.length > 0) {
							var field = $(requiredFields[0]);
							var validate: any = field.data("validate");
							validate.setErrorOnParent(field);
						}
						return returnValue;
					}
				}
			}
		}]);
	}
}

export class ConcatStringToCountFilter {
	static add(ngModule: ng.IModule) {
		ngModule.filter("lmStringToCount", [() => {
			return (input: string) => {
				if (!input) {
					return 0;
				}
				return input.split(",").length;
			};
		}]);
	}
}

/**
* Settings Area Filter
* 
* Filters settings by Area.
*/
export class SettingsAreaFilter {
	static add(ngModule: ng.IModule) {
		ngModule.filter("lmSettingsArea", [() => {
			return (items, input) => {
				var filterHits = [];
				if (input || input === 0) {
					angular.forEach(items, (item: c.ISettingItem) => {
						if (item.setting.area === input) {
							filterHits.push(item);
						}
					});
					return filterHits;
				} else {
					return items;
				}
			}
		}]);
	}
}

/**
* Visiblity Filter
* 
* Filters settings by visibility.
*/
export class SettingsVisibilityFilter {
	static add(ngModule: ng.IModule) {
		ngModule.filter("lmSettingsVisibility", [() => {
			return (items) => {
				var filterHits = [];
				angular.forEach(items, (item: c.ISettingItem) => {
					if (item.setting.isVisible === true) {
						filterHits.push(item);
					}
				});
				return filterHits;
			}
		}]);
	}
}

export var init = (m: ng.IModule) => {
	CapitalizeFilter.add(m);
	LocaleDateFilter.add(m);
	EllipsisFilter.add(m);
	FallbackIconDirective.add(m);
	TagsDirective.add(m);
	BrokenEntityDirective.add(m);
	RepeatCompletedDirective.add(m);
	TagValidationDirective.add(m);
	ConcatStringToCountFilter.add(m);
	SettingsAreaFilter.add(m);
	SettingsVisibilityFilter.add(m);
}; 