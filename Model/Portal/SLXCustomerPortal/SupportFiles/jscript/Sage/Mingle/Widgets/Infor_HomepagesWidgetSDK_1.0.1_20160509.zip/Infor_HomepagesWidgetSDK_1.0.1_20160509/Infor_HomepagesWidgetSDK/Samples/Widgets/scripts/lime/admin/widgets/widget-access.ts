﻿import lm = require("../../lime");
import c = require("../../core");
import s = require("../service");

class WidgetAccessCtrl extends c.CoreBase {
	public accessEntities: s.IWidgetAccess[];
	public accessLevels: any[];

	private dialog: lm.IDialog;
	private isAddEditDialogOpen: boolean;

	static $inject = ["$scope", "lmDialogService", "lmCommonDataService"];

	constructor(public scope: ng.IScope, private dialogService: lm.IDialogService, private commonDataService: c.ICommonDataService) {
		super("[WidgetAccessCtrl] ");
		const dialog: lm.IDialog = scope["lmDialog"];
		this.dialog = dialog;
		this.accessEntities = this.getAccess(dialog.parameter.accessList);

		const widgetAccessLevel = c.WidgetAccessLevel;
		this.accessLevels = [
			{ name: "Disabled", value: widgetAccessLevel.Disabled },
			{ name: "View", value: widgetAccessLevel.View },
			{ name: "Configure", value: widgetAccessLevel.Configure }];
	}

	private getAccess(items: s.IWidgetAccess[]): s.IWidgetAccess[] {
		items = angular.copy(items);

		// Add the default implicit Everyone permission if it is missing.
		const principal = c.Constants.groupEveryone;
		let everyoneAccess: s.IWidgetAccess = lm.ArrayUtil.itemByProperty(items, "principal", principal);
		if (!everyoneAccess) {
			everyoneAccess = {
				id: this.dialog.parameter.id,
				principal: principal,
				accessLevel: c.WidgetAccessLevel.Configure,
				isCatalog: true,
				isUser: false
			};
			items.unshift(everyoneAccess);
		}

		// The principal name for Everyone is not returned by the server.
		everyoneAccess.principalName = "Everyone";

		return items;
	}

	public isDisabled(access: s.IWidgetAccess): boolean {
		// Disable removal of the Everyone group
		return !access.isUser && c.Constants.groupEveryone === access.principal;
	}

	public ok(): void {
		const result: lm.IDialogResult = {
			button: lm.DialogButtonType.Ok,
			value: this.accessEntities
		};
		this.dialog.close(result);
	}

	public close(): void {
		this.dialog.close();
	}

	public getDisplayValue(value: number): string {
		return lm.ArrayUtil.itemByProperty(this.accessLevels, "value", value).name;
	}

	public delete(entity: s.IWidgetAccess): void {
		lm.ArrayUtil.remove(this.accessEntities, entity);
	}

	public showAccessDialog(entity: s.IWidgetAccess, isAddUser?: boolean): void {
		if (!this.isAddEditDialogOpen) {
			var self = this;
			var options = <lm.IDialogOptions>{
				title: entity ? "Edit Permissions" : "Add Permissions",
				templateUrl: "scripts/lime/admin/templates/add-edit-widget-access.html",
				parameter: {
					accessEntity: entity || {},
					id: self.dialog.parameter.id,
					existingEntities: this.accessEntities,
					isAddUser: isAddUser
				}
			};
			self.isAddEditDialogOpen = true;
			self.dialogService.show(options).then((r: lm.IDialogResult) => {
				self.isAddEditDialogOpen = false;
				if (r.button === lm.DialogButtonType.Ok && r.value) {
					var item = <s.IWidgetAccess>r.value;
					self.addOrUpdateEntityAccess(item, entity);
				}
			});
		}
	}

	private addOrUpdateEntityAccess(newItem: s.IWidgetAccess, oldItem: s.IWidgetAccess) {
		var accessEntities = this.accessEntities;
		if (!lm.CommonUtil.isUndefined(oldItem) && oldItem !== null) {
			var entityIndex = lm.ArrayUtil.indexByProperty(accessEntities, "principal", oldItem.principal);
			accessEntities[entityIndex] = newItem;
		} else {
			accessEntities.push(newItem);
		}
	}

	static add(m: ng.IModule) {
		m.controller("lmWidgetAccessCtrl", WidgetAccessCtrl);
	}
}

class AddEditWidgetAccessCtrl extends c.CoreBase {
	public accessEntity: s.IWidgetAccess;
	public accessLevels: any[];
	public isEdit: boolean = false;
	public existsMsg: string;
	public isAddUser: boolean;
	public roleInput: string;

	private autocompleteElem: JQuery;
	private autocompleteElemRole: JQuery;
	public autocompleteOptions: xi.IAutoCompleteOptions;
	public autocompleteOptionsRole: xi.IAutoCompleteOptions;
	private dialog: lm.IDialog;

	static $inject = ["$scope", "lmDialogService", "lmCommonDataService", "lmAdminService"];

	constructor(public scope: ng.IScope, private dialogService: lm.IDialogService, private commonDataService: c.ICommonDataService, private adminService: s.IAdminService) {
		super("[AddEditWidgetAccessCtrl] ");
		var dialog: lm.IDialog = scope["lmDialog"];
		this.dialog = dialog;
		var accessEntity: s.IWidgetAccess = angular.copy(dialog.parameter.accessEntity);
		this.accessEntity = accessEntity;
		var widgetAccessLevel = c.WidgetAccessLevel;

		var buttonText = "Ok";
		if (accessEntity.principal) {
			this.isEdit = true;
		} else {
			buttonText = "Add";
			accessEntity.isCatalog = true;
			accessEntity.accessLevel = widgetAccessLevel.View;
			this.isAddUser = dialog.parameter.isAddUser;
			this.init();
		}
		scope["buttonText"] = buttonText;

		this.accessLevels = [
			{ name: "Disabled", value: widgetAccessLevel.Disabled },
			{ name: "View", value: widgetAccessLevel.View },
			{ name: "Configure", value: widgetAccessLevel.Configure }
		];
	}

	public ok(): void {
		const result: lm.IDialogResult = { button: lm.DialogButtonType.Ok };
		const entity = this.accessEntity;
		if (!this.isEdit && !this.isAddUser) {
			const roleName = entity.principalName || this.roleInput;
			if (lm.ArrayUtil.containsByProperty(this.dialog.parameter.existingEntities, "principal", roleName)) {
				this.existsMsg = "Group already added";
				return;
			}
			delete this.existsMsg;
			entity.isUser = false;
			if (!entity.principalName) {
				entity.principal = roleName;
				entity.principalName = roleName;
			}
		}
		result.value = entity;
		this.dialog.close(result);
	}

	public close(): void {
		this.dialog.close();
	}

	public onChangedAccessLevel(): void {
		var accessEntity = this.accessEntity;
		if (accessEntity.accessLevel === c.WidgetAccessLevel.Disabled) {
			accessEntity.isCatalog = false;
		}
	}

	private init(): void {
		var self = this;
		var autocompleteElem;
		if (this.isAddUser) {
			this.autocompleteOptions = {
				source: (query, done) => {
					self.commonDataService.searchUsers(query).then((response: c.IUserListResponse) => {
						done(query, lm.ArrayUtil.sortByProperty(c.CoreUtil.getEntityArray(response.content), "label"));
					}, (r: c.IOperationResponse) => {
						self.commonDataService.handleError(r);
					});
				},
				template: c.Templates.autocompleteEntity
			}

			autocompleteElem = $("#widget-access-principal");
			this.autocompleteElem = autocompleteElem;
		} else {
			this.autocompleteOptionsRole = {
				source: (query, done) => {
					self.adminService.searchRoles(query).then((result: lm.IAutocompleteEntity[]) => {
						done(query, lm.ArrayUtil.sortByProperty(result, "label"));
					});
				},
				template: c.Templates.autocompleteEntity,
				filterMode: "contains"
			}

			autocompleteElem = $("#widget-access-role");
			this.autocompleteElemRole = autocompleteElem;
			this.scope.$watch("ctrl.roleInput", (newValue: string, oldValue: string) => {
				if (newValue !== oldValue) {
					delete self.accessEntity.principalName;
					delete self.existsMsg;
				}
			});
		}
		this.connectAutoComplete(autocompleteElem, this.scope);
		
		this.scope.$on("$destroy", () => {
			autocompleteElem.off();
		});
	}

	private connectAutoComplete(element: JQuery, scope: ng.IScope): void {
		var self = this;
		element.on("selected", (event, target, object: lm.IAutocompleteEntity) => {
			if (lm.CommonUtil.isUndefined(object) || lm.CommonUtil.isUndefined(object.value)) {
				return;
			}

			var value = object.value;
			self.existsMsg = "";
			if (lm.ArrayUtil.containsByProperty(self.dialog.parameter.existingEntities, "principal", value)) {
				self.existsMsg = "Permissions are already configured";
			} else {
				const accessEntity = self.accessEntity;
				accessEntity.principal = value;
				accessEntity.principalName = object.label ? object.label : value;
				accessEntity.isUser = true;
				self.scope.$apply("accessEntity");
			}
			self.scope.$apply("existsMsg");
		});
	}

	static add(m: ng.IModule) {
		m.controller("lmAddEditWidgetAccessCtrl", AddEditWidgetAccessCtrl);
	}
}

export var init = (m: ng.IModule) => {
	WidgetAccessCtrl.add(m);
	AddEditWidgetAccessCtrl.add(m);
}; 