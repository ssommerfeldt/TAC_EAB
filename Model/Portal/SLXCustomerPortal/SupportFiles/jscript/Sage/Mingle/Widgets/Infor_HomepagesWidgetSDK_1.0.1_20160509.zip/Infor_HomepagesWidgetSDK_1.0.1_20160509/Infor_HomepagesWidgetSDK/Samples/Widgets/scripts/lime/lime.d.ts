/// <reference path="../typings/jquery/jquery.d.ts" />
/// <reference path="../typings/angularjs/angular.d.ts" />
/// <reference path="../typings/sohoxi/sohoxi.d.ts" />
export interface IApplication {
    isDefault: boolean;
    version: string;
    productName: string;
    tenantId: string;
    logicalIdPrefix: string;
    logicalId: string;
    hostname: string;
    context: string;
    port: number;
    useHttps: boolean;
}
export interface ILanguage {
    get(id: string): string;
    ok: string;
    cancel: string;
    yes: string;
    no: string;
    refresh: string;
    add: string;
    save: string;
    delete: string;
    name: string;
    url: string;
    edit: string;
}
export interface IWidgetModule {
    widgetFactory(context: IWidgetContext): IWidgetInstance;
}
export declare class WidgetState {
    static running: string;
    static busy: string;
    static error: string;
}
export interface IWidgetActivationArg {
    type: string;
    isNew?: boolean;
}
export interface IWidgetSettingsCloseArg {
    isSave: boolean;
}
export declare class WidgetActivationType {
    static visibility: string;
    static close: string;
    static settings: string;
    static edit: string;
}
export interface IAngularScopeValue {
    name: string;
    value: any;
}
export interface IAngularTemplateInfo {
    key: string;
    value: string;
}
export interface IAngularWidgetConfig {
    template?: string;
    templates?: IAngularTemplateInfo[];
    cachedTemplateUrl?: string;
    relativeTemplateUrl?: string;
    scopeValue?: IAngularScopeValue;
}
export interface IAngularContext {
    module: ng.IModule;
    scope: ng.IScope;
    compile: ng.ICompileService;
    getTemplateUrl(relativeUrl: string): string;
}
export interface IWidgetAction {
    text?: string;
    execute?: Function;
    isEnabled?: boolean;
    isVisible?: boolean;
    isSeparator?: boolean;
    isPrimary?: boolean;
    standardIconName?: string;
    customIconName?: string;
}
export interface IWidgetMessage {
    message: string;
    type: WidgetMessageType;
    onClose?: Function;
}
export declare enum WidgetMessageType {
    Info = 0,
    Alert = 1,
    Error = 2,
}
export interface IWidgetInstance {
    activated?: (arg: IWidgetActivationArg) => void;
    deactivated?: (arg: IWidgetActivationArg) => void;
    settingsOpening?: (arg: IWidgetSettingsArg) => void;
    settingsSaved?: (arg: IWidgetSettingsArg) => void;
    getMetadata?: () => IWidgetSettingMetadata[];
    editing?: () => void;
    edited?: () => void;
    publishing?: () => void;
    angularConfig?: IAngularWidgetConfig;
    widgetSettingsFactory?: (context: IWidgetSettingsContext) => IWidgetSettingsInstance;
    actions?: IWidgetAction[];
}
export interface IWidgetSettingsArg {
    settings: IWidgetSettings;
    data?: any;
    cancel?: boolean;
}
export interface IWidgetSettingMetadata {
    name: string;
    type?: string;
    defaultValue?: string;
    labelId?: string;
    isVisible?: boolean;
    isHidden?: boolean;
    isEnabled?: boolean;
    maxLength?: number;
    values?: IValueItem[];
}
export declare class WidgetSettingsType {
    static stringType: string;
    static numberType: string;
    static booleanType: string;
    static selectorType: string;
    static objectType: string;
}
export interface IAutocompleteEntity {
    label: string;
    value?: any;
    info?: string;
    type?: any;
}
export interface IValueItem {
    textId?: string;
    text?: string;
    value: string;
}
export interface IShowSettingsOptions {
    data?: any;
}
export interface IViewUrlOptions {
    viewId: string;
    logicalId?: string;
    resolve?: boolean;
}
export interface IIonApiOptions {
    refresh?: boolean;
}
export interface IIonApiRequestOptions extends ng.IRequestConfig {
    ionApiRetry?: boolean;
}
export interface IIonApiContext {
    getUrl(): string;
    getToken(): string;
    getHeaderName(): string;
    getHeaderValue(): string;
    getCustomerContext(): string;
}
export interface IWidgetContext {
    getId(): string;
    getSettings(): IWidgetSettings;
    getLanguage(): ILanguage;
    getElement(): JQuery;
    getUrl(path?: string): string;
    getAngularContext(): IAngularContext;
    isActive(): boolean;
    isVisible(): boolean;
    isPublished(): boolean;
    isDev(): boolean;
    save(): void;
    setState(state: string): void;
    getState(): string;
    getTitle(): string;
    getStandardTitle(): string;
    setTitle(title: string): void;
    enableTitleEdit(isEnabled: boolean): void;
    isTitleEditEnabled(): boolean;
    resolve(key: string): string;
    resolveAndReplace(template: string): string;
    getApplication(): IApplication;
    getApplications(): IApplication[];
    getLogicalId(): string;
    setLogicalId(logicalId: string): void;
    getApplicationAsync(logicalId: string): ng.IPromise<IApplication>;
    getApplicationsAsync(logicalId: string): ng.IPromise<IApplication[]>;
    resolveAndReplaceAsync(template: string, logicalId?: string): ng.IPromise<string>;
    getViewUrlAsync(options: IViewUrlOptions): ng.IPromise<string>;
    getIonApiCustomerContext(): string;
    getIonApiContextAsync(options?: IIonApiOptions): ng.IPromise<IIonApiContext>;
    executeIonApiAsync<T>(options: IIonApiRequestOptions): ng.IPromise<ng.IHttpPromiseCallbackArg<T>>;
    getService<T>(name: string): T;
    launch(launchOptions: ILaunchOptions): void;
    showWidgetMessage(message: IWidgetMessage): void;
    removeWidgetMessage(): void;
    getPageId(): string;
    getStandardWidgetId(): string;
    getWidgetInstanceId(): string;
    getContainerUrl(): string;
    isCloud(): boolean;
}
export interface ILaunchOptions {
    url: string;
    resolve?: boolean;
}
export interface IWidgetSettings {
    getValues(): any;
    setValues(values: any): void;
    getMetadata(): IWidgetSettingMetadata[];
    setMetadata(metadata: IWidgetSettingMetadata[]): any;
    get<T>(name: string, defaultValue?: T): T;
    set(name: string, value: any): void;
    getString(name: string, defaultValue?: string): string;
    showSettings(options?: IShowSettingsOptions): void;
    isSettingsEnabled(): boolean;
    isSettingEnabled(name: string): boolean;
    isSettingVisible(name: string): boolean;
    enableSettingsMenu(enabled: boolean): void;
}
export interface IWidgetSettingsInstance {
    closing?: (arg: IWidgetSettingsCloseArg) => void;
    angularConfig?: IAngularWidgetConfig;
}
export interface IWidgetSettingsContext {
    getWidgetContext(): IWidgetContext;
    enableSave(isEnabled: boolean): void;
    isSaveEnabled(): boolean;
    getElement(): JQuery;
    close(isSave?: boolean): void;
}
export declare class WidgetConstants {
    static widgetInstanceKey: string;
    static widgetContextKey: string;
    static widgetTitle: string;
    static widgetDescription: string;
}
export interface ILogAppender {
    (level: number, text: string, ex?: any): any;
}
export interface INumberFormatOptions {
    separator?: string;
}
export interface ISortOptions {
    ignoreCase?: boolean;
}
export declare class ArrayUtil {
    static contains(array: any[], value: any): boolean;
    static indexOf(array: any[], value: any): number;
    static sortByProperty(array: any[], property: string, options?: ISortOptions): any[];
    static remove(array: any[], item: any): void;
    static removeByProperty(array: any[], name: string, value: any): boolean;
    static removeByPredicate<T>(array: T[], predicate: (item: T) => boolean): boolean;
    static indexByProperty(array: any[], name: string, value: any): number;
    static itemByProperty(array: any[], name: string, value: any): any;
    static itemByPredicate<T>(array: T[], predicate: (item: T) => Object): T;
    static containsByProperty(array: any[], name: string, value: any): boolean;
    static last(array: any[]): any;
    static find<T>(array: T[], predicate: (item: T) => boolean): T;
    static findAll<T>(array: T[], predicate: (item: T) => boolean): T[];
    static array<T>(n: number, defaultValue?: T): T[];
    static matrix<T>(rows: number, columns: number, defaultValue?: T): T[][];
    static move(array: any[], index: number, newIndex: number): void;
}
export declare class NumUtil {
    private static getLocaleSeparator();
    private static defaultSeparator;
    private static defaultOptions;
    static getDefaultOptions(): INumberFormatOptions;
    static setDefaultOptions(options: INumberFormatOptions): void;
    static isNumber(n: any): boolean;
    static getInt(s: string, defaultValue?: number): number;
    static format(value: any, options?: INumberFormatOptions): string;
    static pad(num: number, length: number): string;
    static hasOnlyIntegers(s: string): boolean;
    static tryGetInt(input: any, defaultValue?: number): number;
}
export declare class CommonUtil {
    static getLocaleDateString(dateString: string, options?: any): string;
    static deleteProperty(object: any, property: string): void;
    private static chars;
    static getBoolean(s: string, defaultValue?: boolean): boolean;
    static getUuid(prefix: string): string;
    static hasValue(anyObject: any): boolean;
    static isUndefined(anyObject: any): boolean;
    static random(stringLength?: number): string;
    static isIframe(): boolean;
    static getClientDate(): string;
    static detectBrowser(): void;
}
export declare class StringUtil {
    static isNullOrWhitespace(value: string): boolean;
    static startsWith(value: string, prefix: string): boolean;
    static replaceParameters(template: string, resolveFunction: Function): string;
    static endsWith(value: string, suffix: string): boolean;
    static trimEnd(value: string): string;
    static format(...args: any[]): string;
}
export declare class HtmlUtil {
    static iframe(url?: string, name?: string): JQuery;
}
export declare class Log {
    static levelFatal: number;
    static levelError: number;
    static levelWarning: number;
    static levelInfo: number;
    static levelDebug: number;
    static levelTrace: number;
    static level: number;
    static isConsoleLogEnabled: boolean;
    private static prefixes;
    private static appenders;
    static addAppender(appender: ILogAppender): void;
    static removeAppender(appender: ILogAppender): void;
    private static getTime();
    static getLogEntry(level: number, text: string, ex?: any): string;
    private static log(currentLevel, level, text, ex?);
    static setDefault(): void;
    static fatal(text: string, ex?: any): void;
    static error(text: string, ex?: any): void;
    static warning(text: string, ex?: any): void;
    static info(text: string, ex?: any): void;
    static isDebug(): boolean;
    static setDebug(): void;
    static debug(text: string, ex?: any): void;
    static isTrace(): boolean;
    static setTrace(): void;
    static trace(text: string, ex?: any): void;
}
export declare enum StandardDialogButtons {
    Ok = 1,
    OkCancel = 2,
    YesNo = 3,
    YesNoCancel = 4,
}
export declare enum DialogButtonType {
    None = 1,
    Ok = 2,
    Cancel = 3,
    Yes = 4,
    No = 5,
    Custom = 6,
}
export interface IDialogResult {
    button?: DialogButtonType;
    value?: any;
}
export interface IMessageDialogOptions {
    title: string;
    message: string;
    buttons?: IDialogButton[];
    standardButtons?: StandardDialogButtons;
    isError?: boolean;
    cssClass?: string;
    hasPrimaryButton?: boolean;
}
export interface IDialogButton {
    text: string;
    type?: any;
    value?: any;
    id?: string;
    isLink?: boolean;
    isDefault?: boolean;
    icon?: string;
    cssClass?: string;
}
export interface IToastOptions {
    title: string;
    message: string;
    position?: string;
    audibleOnly?: boolean;
    progressBar?: boolean;
    timeout?: number;
}
export interface IDialogOptions {
    title: string;
    parameter?: any;
    scope?: ng.IScope;
    template?: string;
    templateUrl?: string;
    buttons?: IDialogButton[];
    style?: string;
    cssClass?: string;
    id?: string;
    actionPanel?: boolean;
}
export interface IDialogEvent {
    dialog: IDialog;
    cancel?: boolean;
}
export interface IDialog {
    close(result?: IDialogResult): void;
    closing: (e: IDialogEvent) => void;
    closed: (e: IDialogEvent) => void;
    opened: (e: IDialogEvent) => void;
    parameter?: any;
    result?: IDialogResult;
}
export interface ICopyToClipboardOptions {
    copyData: string;
    forceDialog?: boolean;
}
export interface IDialogService {
    showContextualActionPanel(template: string, parameter?: any): ng.IPromise<IDialogResult>;
    show(options?: IDialogOptions): ng.IPromise<IDialogResult>;
    showMessage(options: IMessageDialogOptions): ng.IPromise<IDialogResult>;
    showToast(options: IToastOptions): void;
    copyToClipboard(options: ICopyToClipboardOptions, forceDialog?: boolean): void;
}
