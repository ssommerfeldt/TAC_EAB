﻿import lm = require("../../lime");
import c = require("../../core");
import s = require("../service");

class RuleAddConnectionCtrl extends c.CoreBase {
	public autocompleteOptions: xi.IAutoCompleteOptions;
	public autocompleteRoleOptions: xi.IAutoCompleteOptions;
	public existsMsg: string;
	public resultInput: string;

	private dialog: lm.IDialog;
	private userName: string;
	private isUser: boolean;
	private rule: c.ISettingRule;
	private ruleConnectionsString = "ruleConnections";
	private autocompleteElem: JQuery;
	private autocompleteElemRole: JQuery;

	static $inject = ["$scope", "lmAdminService", "lmCommonDataService"];

	constructor(public scope: ng.IScope, private adminService: s.IAdminService, private commonDataService: c.ICommonDataService) {
		super("[RuleAddConnectionCtrl] ");
		var dialog: lm.IDialog = scope["lmDialog"];
		var dialogParameter = dialog.parameter;
		this.dialog = dialog;
		this.rule = angular.copy(dialogParameter.rule);
		this.userName = angular.copy(dialogParameter.userName);
		this.isUser = dialogParameter.isUser;

		scope[this.ruleConnectionsString] = [];


		if (this.isUser) {
			this.autocompleteElem = $("#autocomplete-add-connection");
			// Set source for user autocomplete.
			this.autocompleteOptions = {
				source: (query, done) => {
					commonDataService.searchEntities(query).then((response: c.IEntityListResponse) => {
						done(query, lm.ArrayUtil.sortByProperty(response.content, "label"));
					}, (r: c.IOperationResponse) => {
						commonDataService.handleError(r);
					});
				},
				template: c.Templates.autocompleteEntity
			}
			this.connectAutoComplete(this.autocompleteElem, scope);
		} else {
			// Autocomplete for raw roles
			this.autocompleteRoleOptions = {
				source: (query, done) => {
					adminService.searchRoles(query).then((result: lm.IAutocompleteEntity[]) => {
						done(query, lm.ArrayUtil.sortByProperty(result, "label"));
					}, (r: c.IOperationResponse) => {
						//  Don't use type ahead any more
						// commonDataService.handleError(r);
					});
				},
				template: c.Templates.autocompleteEntity
			}

			this.autocompleteElemRole = $("#autocomplete-add-connection-role");
			this.connectAutoComplete(this.autocompleteElemRole, scope);

		}
	}

	private connectAutoComplete(element: JQuery, scope: ng.IScope): void {
		var self = this;
		// Update connections when a new user/group is selected.
		element.on("selected", (event, target, object: lm.IAutocompleteEntity) => {
			if (lm.CommonUtil.isUndefined(object) || lm.CommonUtil.isUndefined(object.value)) {
				return;
			}
			var value = object.value;
			var entityType = object.type;
			self.existsMsg = "";

			if (lm.ArrayUtil.containsByProperty(self.rule.ruleConnections, "name", value) || lm.ArrayUtil.containsByProperty(self.scope[self.ruleConnectionsString], "name", value)) {
				self.existsMsg = entityType === c.PrincipalType.User ? "User already added" : "Group already added";
			} else {
				var ruleConnection = {
					name: value,
					isUser: entityType === c.PrincipalType.User,
					displayName: object.label ? object.label : value,
					isChanged: true,
					info: object.info || value
				};
				scope[self.ruleConnectionsString].push(ruleConnection);
				self.resultInput = "";
				scope.$apply(self.ruleConnectionsString);
			}
			scope.$apply("existsMsg");
		});

		scope.$on("$destroy", () => {
			element.off();
		});
	}

	public addRole(): void {
		const groupName = angular.copy(this.resultInput);

		if (lm.ArrayUtil.containsByProperty(this.rule.ruleConnections, "name", groupName) || lm.ArrayUtil.containsByProperty(this.scope[this.ruleConnectionsString], "name", groupName)) {
			this.existsMsg = "Role already added";
		} else {
			delete this.resultInput;
			delete this.existsMsg;

			const ruleConnection = {
				name: groupName,
				isUser: false,
				displayName: groupName,
				info: groupName
			};
			this.scope[this.ruleConnectionsString].push(ruleConnection);
		}
	}

	/**
	 * Modal Cancel.
	 *
	 * Close the dialog with no changes to return.
	 */
	public onCancel(): void {
		var result: lm.IDialogResult = {
			button: lm.DialogButtonType.Cancel,
			value: null
		};
		this.dialog.close(result);
	}

	/**
	 * Modal OK.
	 *
	 * If changes has been made to the connections close the dialog with the new values set.
	 * Otherwise call onCancel().
	 */
	public onOk(): void {
		if (this.scope[this.ruleConnectionsString].length > 0) {
			this.addConnections();
			var result: lm.IDialogResult = {
				button: lm.DialogButtonType.Ok,
				value: {
					rule: this.rule,
					displayChangeDate: lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*",
					changedBy: this.userName
				}
			};
			this.dialog.close(result);
		} else {
			this.onCancel();
		}
	}

	/**
	 * Remove user/group.
	 *
	 * Removes a user or group from connections.
	 */
	public remove(connection: any): void {
		var ruleConnections: c.ISettingRuleConnection[] = this.scope[this.ruleConnectionsString];
		var connectionIndex = ruleConnections.indexOf(connection);
		ruleConnections.splice(connectionIndex, 1);
	}

	/**
	 * Add connection.
	 *
	 * Add any new connection(s).
	 */
	private addConnections(): void {
		var self = this;
		angular.forEach(this.scope[this.ruleConnectionsString], (newConnection) => {
			newConnection.displayChangeDate = lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*";
			newConnection.changedByName = self.userName;
			self.rule.ruleConnections.push(newConnection);
		});
	}

	public static add(m: ng.IModule) {
		m.controller("lmRuleAddConnectionCtrl", RuleAddConnectionCtrl);
	}
}

export var init = (m: ng.IModule) => {
	RuleAddConnectionCtrl.add(m);
}