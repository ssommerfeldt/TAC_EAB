define(["require", "exports", "lime"], function (require, exports, lm) {
    var CustomDialogCtrl = (function () {
        function CustomDialogCtrl(scope) {
            this.scope = scope;
            this.dialogResult = "Sample dialog result";
            this.dialog = scope["lmDialog"];
            this.dialogParameter = this.dialog.parameter;
        }
        CustomDialogCtrl.prototype.onOk = function () {
            this.dialog.close({ value: this.dialogResult });
        };
        CustomDialogCtrl.prototype.onCancel = function () {
            this.dialog.close();
        };
        CustomDialogCtrl.$inject = ["$scope"];
        return CustomDialogCtrl;
    })();
    var DialogsCtrl = (function () {
        function DialogsCtrl(scope, dialogService) {
            this.scope = scope;
            this.dialogService = dialogService;
            this.widgetContext = scope[lm.WidgetConstants.widgetContextKey];
            this.instance = scope[lm.WidgetConstants.widgetInstanceKey];
        }
        DialogsCtrl.prototype.showMessage = function () {
            this.dialogService.showMessage({
                title: "A sample title",
                message: "A sample message",
            });
        };
        DialogsCtrl.prototype.showConfirm = function () {
            var _this = this;
            this.dialogService.showMessage({
                title: "Confirm",
                message: "Are you sure?",
                standardButtons: lm.StandardDialogButtons.YesNo
            }).then(function (result) {
                var message, title;
                if (result.button === lm.DialogButtonType.Yes) {
                    title = "Confirmed";
                    message = "You are sure.";
                }
                else {
                    title = "Not confirmed";
                    message = "You are not sure.";
                }
                _this.dialogService.showMessage({
                    title: title,
                    message: message
                });
            });
        };
        DialogsCtrl.prototype.showToast = function () {
            this.dialogService.showToast({
                title: "A sample toast title",
                message: "A sample toast message"
            });
        };
        DialogsCtrl.prototype.showCustom = function () {
            var _this = this;
            var templateUrl = this.widgetContext.getAngularContext().getTemplateUrl("dialog.html");
            this.dialogService.show({
                title: "A custom dialog title",
                parameter: "A sample custom dialog parameter",
                templateUrl: templateUrl
            }).then(function (result) {
                var message = result.value || "Dialog cancelled";
                _this.dialogService.showMessage({
                    title: "Result",
                    message: message
                });
            });
        };
        DialogsCtrl.$inject = ["$scope", "lmDialogService"];
        return DialogsCtrl;
    })();
    exports.widgetFactory = function (context) {
        var m = context.getAngularContext().module;
        // Register the controller
        m.controller("sample.DialogsCtrl", DialogsCtrl);
        m.controller("sample.CustomDialogCtrl", CustomDialogCtrl);
        // Return the angular configuration the widget.html will contain a controller
        return {
            angularConfig: {
                relativeTemplateUrl: "widget.html"
            }
        };
    };
});
//# sourceMappingURL=widget.js.map