var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../lime", "../../core"], function (require, exports, lm, c) {
    var SettingSaveAndDiscardCtrl = (function (_super) {
        __extends(SettingSaveAndDiscardCtrl, _super);
        function SettingSaveAndDiscardCtrl(scope) {
            _super.call(this, "[SettingSaveAndDiscardCtrl] ");
            this.scope = scope;
            this.dialog = scope["lmDialog"];
        }
        SettingSaveAndDiscardCtrl.prototype.onCancel = function () {
            this.dialog.close({ button: lm.DialogButtonType.Cancel });
        };
        SettingSaveAndDiscardCtrl.prototype.onOk = function () {
            this.dialog.close({ button: lm.DialogButtonType.Ok });
        };
        SettingSaveAndDiscardCtrl.add = function (m) {
            m.controller("lmSettingSaveAndDiscardCtrl", SettingSaveAndDiscardCtrl);
        };
        SettingSaveAndDiscardCtrl.$inject = ["$scope"];
        return SettingSaveAndDiscardCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        SettingSaveAndDiscardCtrl.add(m);
    };
});
//# sourceMappingURL=setting-save-and-discard.js.map