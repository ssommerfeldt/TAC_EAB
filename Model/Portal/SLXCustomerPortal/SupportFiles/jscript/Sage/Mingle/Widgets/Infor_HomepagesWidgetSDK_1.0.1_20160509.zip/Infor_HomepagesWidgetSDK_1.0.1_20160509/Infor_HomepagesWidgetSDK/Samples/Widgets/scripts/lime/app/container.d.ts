import c = require("../core");
export interface IContainerService {
    loadContainer(loadStartPage?: boolean): ng.IPromise<c.IPageContainer>;
    getContainer(): c.IPageContainer;
}
export declare var init: (m: ng.IModule) => void;
