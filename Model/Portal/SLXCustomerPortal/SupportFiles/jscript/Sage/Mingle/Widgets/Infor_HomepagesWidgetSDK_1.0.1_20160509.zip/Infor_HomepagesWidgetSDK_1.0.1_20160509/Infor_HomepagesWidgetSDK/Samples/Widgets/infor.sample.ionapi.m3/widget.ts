﻿/// <reference path="../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../scripts/typings/lime/lime.d.ts" />

import lm = require("lime");

// Prerequisites
// =============
// The following steps are required before testing this sample widget.
// - Aquire the server and port number for the ION API server to test with.
// - Configure and start a localhost proxy with the ION API server and port number.
// - Example: node proxy.js 8083 "mingledev01-ionapi.mingledev.infor.com" 443
// - Example: \Samples\StartIonApiProxy.cmd
//
// - Set the ionApiUrl property in the configuration.json file to the URL of the localhost proxy.
// - The configuration.json file is located in the root of the Widgets sample project by default.
// - The URL should include the tenant to test with.
// - Example: "ionApiUrl": "http://localhost:8083/ACME_TST"
//
// - Acquire an OAuth token string.
// - Log on to Ming.le.
// - Example: https://mingledev01-portal.mingledev.infor.com/ACME_TST/
// - Open a new tab in the same browser and navigate to the Grid SAML Session Provider OAuth resource
// - The Grid must be version 2.0 or later with a SAML Session Provider configured for the same IFS as Ming.le.
// - Example: https://mingledev01-grid-hp.mingledev.infor.com/grid/rest/security/sessions/oauth
// - Copy the the OAuth token string from the browser window.
//
// - If there are issues you can verify if your user has access to the grid by navigating to the Grid user page.
// - Note that you must be logged on to Ming.le before doing this.
// - Example: https://mingledev01-grid-hp.mingledev.infor.com:9544/grid/user
//
// - Set the ionApiToken property in the configuration.json file to the OAuth token string.
// - Example: "ionApiToken": "V9k5niTDR1kq6RuYlEq3N3HxGq8u"
//
// - Set the dev-configuration attribute on the lm-page-container to the name of the configuration.json file
// - Example: <lm-page-container dev-widget="infor.sample.ionapi.m3" dev-configuration="configuration.json"></lm-page-container>
//
//
// Developing and debugging
// ========================
// A widget using the ION API can be developed and debugged like any other widget.
// Just remember to start the proxy and configure the configuration.json file.
// The OAuth token will time out and when that happens you must acquire a new token and update the configuration.json file.


interface IMIResponse {
	Program: string;
	Transaction: string;
	MIRecord: IMIRecord[];
}

interface IMIRecord {
	RowIndex: number;
	NameValue: INameValue[];
}

interface INameValue {
	Name: string;
	Value: string;
}

interface IListItem {
	title: string;
	description: string;
}

class IonApiM3Ctrl {
	private widgetContext: lm.IWidgetContext;
	private instance: lm.IWidgetInstance;

	static $inject = ["$scope", "$http"];

	constructor(public scope: ng.IScope, private http: ng.IHttpService) {
		this.widgetContext = scope[lm.WidgetConstants.widgetContextKey];
		this.instance = scope[lm.WidgetConstants.widgetInstanceKey];
		scope["model"] = this;

		const request = this.createRequest();
		this.widgetContext.executeIonApiAsync(request).then((response) => {
			this.showCustomers((<IMIResponse>response.data).MIRecord);
		}, (error) => { this.onRequestError(error); });
	}

	private createRequest(): lm.IIonApiRequestOptions {
		const request: lm.IIonApiRequestOptions = {
			method: "GET",
			url: "/M3/m3api-rest/execute/CRS610MI/LstByName",
			cache: false,
			headers: {
				"Accept": "application/json"
			}
		}
		return request;
	}

	private showCustomers(records: IMIRecord[]): void {
		const items = this.getItems(records, "CUNO", "CUNM");
		this.scope["customers"] = items;
	}

	private getItems(records: IMIRecord[], titleField: string, descriptionField: string): IListItem[] {
		const items: IListItem[] = [];
		for (let i = 0; i < records.length; i++) {
			const nameValues = records[i].NameValue;
			const customer: IListItem = {
				title: this.getValue(nameValues, titleField),
				description: this.getValue(nameValues, descriptionField)
			};
			items.push(customer);
		}
		return items;
	}

	private getValue(nameValues: INameValue[], name: string): string {
		for (let i = 0; i < nameValues.length; i++) {
			const nameValue = nameValues[i];
			if (nameValue.Name === name) {
				return nameValue.Value.trim();
			}
		}
		return null;
	}

	private onRequestError(error: any): void {
		alert("Failed to call ION API: " + error);
	}
}

export var widgetFactory = (context: lm.IWidgetContext): lm.IWidgetInstance => {
	var m = context.getAngularContext().module;
	m.controller("sample.IonApiM3Ctrl", IonApiM3Ctrl);
	return {
		angularConfig: {
			relativeTemplateUrl: "widget.html"
		}
	};
};