﻿import lm = require("../lime");
import c = require("../core");
import p = require("../app/page");

/**
* Interface for unsubscribers.
*/
interface IUnsubScriber {
	/**
	 * Page ID
	 */
	id?: string;

	/**
	 * Unsubscribing function
	 */
	unsubscribe: Function;
}

class PageContainer extends c.CoreBase implements c.IPageContainer {
	private changedEvent = new c.InstanceEvent<c.IPageContainer>();
	private refreshedEvent = new c.InstanceEvent<c.IPageContainer>();
	private addedEvent = new c.InstanceEvent<c.IPageInstance>();
	private selectedEvent = new c.InstanceEvent<c.IPageInstance>();
	pages: c.IPageInstance[] = [];

	/**
	 * The currently selected page or null if no page is selected.
	 */
	public selectedPage: c.IPageInstance = null;

	constructor(public context: c.IContext, public data: c.IPageContainerData, private pageService: c.IPageService, private dialogService: lm.IDialogService,
		private q: ng.IQService, private widgetService: c.IWidgetService, private lang: ILanguageLime, private progressService: c.IProgressService, private editModeService?: c.IEditModeService, loadStartPage?: boolean) {
		super("[PageContainer] ");
		if (data) {
			const pages = data.pages;
			if (pages) {
				for (var i = 0; i < pages.length; i++) {
					this.addLast(pages[i]);
				}
			}
			if (loadStartPage) {
				this.selectStartPage();
			}
		}
	}

	public destroy(): void {
		try {
			var pages = this.pages;
			if (pages) {
				for (var i = 0; i < pages.length; i++) {
					pages[i].destroy();
				}
			}

			this.addedEvent.clear();
			this.changedEvent.clear();
			this.refreshedEvent.clear();
			this.selectedEvent.clear();
		} catch (ex) {
			this.error("Failed to destroy", ex);
		}
	}

	private selectStartPage() {
		const settings = this.context.settings;
		var startPage = settings.getStartPage();
		const selectedPage = this.getPage(startPage); // Check if it exists here or within select?
		if (!startPage || !selectedPage || !settings.isSelectHomepageEnabled()) {
			startPage = (this.pages[0] != null) ? this.pages[0].id : null;
		}
		this.select(startPage);
	}

	public onCancelPublish() {
		this.dialogService.showMessage({ standardButtons: lm.StandardDialogButtons.YesNo, message: this.lang.confirmCancelMessage, title: this.lang.confirmCancel }).then((r: lm.IDialogResult) => {
			if (r.button === lm.DialogButtonType.Yes) {
				this.editModeService.stop({ isSave: false });
			}
		});
	}

	private notifyMingle(): void {
		var client = infor.companyon.client;
		var page = this.selectedPage;
		var name = page.title;
		var description = page.description;

		// Enable bookmarking of this page in Ming.le by sending the setShortcutContext message
		var context: c.IMingleContext = {
			type: "page",
			id: page.id
		};
		var data = {
			name: name,
			description: description,
			absoluteURL: "false",
			shortcutContext: context
		};
		client.sendMessage("setShortcutContext", data);

		// Enable sharing of publishes pages in Ming.le by sending the inforBusinessContext message.
		// An empty entities array is used for private pages since those cannot currently be shared.
		var id = page.id;
		var logicalId = c.ClientConfiguration.getLogicalId();
		var entities;
		if (page.isPublished()) {
			var drillback = "?LogicalId=" + logicalId + "&page=" + id;
			entities = [{
				entityType: "Homepage",
				id1: name, // Set id1 to name to display something readable for the link
				name: name,
				description: description,
				drillbackURL: drillback,
			}];
		} else {
			entities = [];
		}
		var businessContext = {
			screenId: "homepages_Page",
			logicalId: logicalId,
			entities: entities,
			contextId: lm.CommonUtil.random(),
			originatingTime: new Date().getTime()
		};
		client.sendMessage("inforBusinessContext", businessContext);
	}

	select(pageId: string): void {
		if (!pageId) {
			this.selectedPage = null;
			return;
		}

		let selectedPage = this.getPage(pageId);
		if (!selectedPage) {
			// This happens when the currently selected page has been deleted but the users UI hasn't been updated (see LIME-814).
			// In that case we set the selected pages to the first in the array if any pages exist.
			if (this.pages.length > 0) {
				selectedPage = this.pages[0];
			} else {
				return;
			}
		}

		const previousPage = this.selectedPage;
		if (previousPage) {
			previousPage.hide();
		}

		this.selectedPage = selectedPage;
		this.selectedEvent.raise(selectedPage);
		selectedPage.show();

		try {
			this.notifyMingle();
		} catch (ex) {
			this.error("Failed to notify Ming.le", ex);
		}
	}

	private getNextSortOrder(): number {
		var sortOrder = 0;
		try {
			if (this.pages && this.pages.length > 0) {
				var pageInstance: c.IPageInstance = lm.ArrayUtil.last(this.pages);
				var lastSortOrder = pageInstance.data.sortOrder;
				sortOrder = lastSortOrder + 1;
			}
		} catch (ex) {
			lm.Log.error("Failed to get next sort order");
		}
		return sortOrder;
	}

	create(pageData: c.IPageData) {
		pageData.sortOrder = this.getNextSortOrder();

		if (c.ClientConfiguration.isDev()) {
			var dev = c.ClientConfiguration.dev;

			dev.initPage(pageData);
			this.onPageCreated(new c.OperationResponse(pageData));
			dev.container.pages.push({ isEditable: true, data: pageData });
			dev.save();
			return;
		}
		var lang = this.lang;

		// Verify that this page isn't already loaded in that case show an error message
		if (lm.ArrayUtil.containsByProperty(this.pages, "id", pageData.id)) {
			this.dialogService.showMessage({ title: lang.pageExists, message: lang.format(lang.pageExistsMessage, pageData.title), standardButtons: lm.StandardDialogButtons.Ok });
			return;
		}

		var settings = this.context.settings;
		var userPageCount = this.getUserPageCount();
		var maxCount = settings.getMaxUserPageCount();
		if (userPageCount >= maxCount) {
			this.dialogService.showMessage({ title: lang.unableToAddPage, message: lang.format(lang.maxPageCountMessage, maxCount), standardButtons: lm.StandardDialogButtons.Ok });
			return;
		}

		this.context.setBusy(true);
		this.pageService.createPrivate(pageData).then((response: c.IPageDataResponse) => {
			this.onPageCreated(response, true);
			this.context.setBusy(false);
		}, (response: c.IOperationResponse) => {
			this.handleCreatePageError(response);
			this.context.setBusy(false);
		});
	}

	cacheApplicationsAndDefinitions(serverPage: c.IPage): void {
		// Needed when adding a shared or copy.
		var definitions = serverPage.widgetDefinitions;
		if (definitions) {
			for (var i = 0; i < definitions.length; i++) {
				this.widgetService.addDefinitionItem(definitions[i]);
			}
		}

		var applications = serverPage.applications;
		if (applications) {
			// Replacement configuration for a logicalId needs to be added to the container
			var config: c.IConfiguration = this.context.getConfiguration();
			if (config) {
				config.addApplicationMap(applications);
			}
		}
	}

	add(serverPage: c.IPage, showToastConfirmation: boolean): void {
		this.cacheApplicationsAndDefinitions(serverPage);
		var page = this.addLast(serverPage);
		this.addedEvent.raise(page);
		this.select(page.id);
		this.raiseChanged();

		var lang = this.lang;
		if (showToastConfirmation) {
			this.dialogService.showToast({ title: lang.pageAdded, message: lang.format(lang.titleAddedMessage, page.title) });
		}
	}

	getUserPageCount() {
		var count = 0;
		for (var i = 0; i < this.pages.length; i++) {
			var page: c.IPageInstance = this.pages[i];
			if (!page.isMandatory) {
				count++;
			}
		}
		return count;
	}

	reorder(order: string[]): ng.IPromise<c.IOperationResponse> {
		var deferred = this.q.defer();

		this.pageService.reorderConnections(order).then((r: c.IOperationResponse) => {
			if (r.hasError()) {
				this.logResponse(r);
				deferred.reject(r);
			} else {
				r.content = this.pages;
				deferred.resolve(r);
				this.raiseChanged();
			}
		}, (r: c.IOperationResponse) => {
			this.logResponse(r);
			deferred.reject(r);
		});

		return deferred.promise;
	}

	public contains(id: string): boolean {
		return lm.ArrayUtil.containsByProperty(this.pages, "id", id);
	}

	publish(page: c.IPageInstance, isUpdate?: boolean) {
		var pageData = page.createSavePageData();
		var pageRequest = <c.IPage>{
			data: pageData,
			roleAccess: page.roleAccess,
			userAccess: page.userAccess,
			localization: page.localization
		};

		var self = this;
		this.pageService.updatePublished(pageRequest).then((r: c.IPageDataResponse) => {
			this.editModeService.stop({ isSave: true });
			this.refresh();
		}, (r: c.IOperationResponse) => {
			this.pageService.handleError(r);
			this.editModeService.stop({ isSave: false });
		});
	}

	editPageConfiguration(isUpdate?: boolean) {
		var page = this.selectedPage;
		var options = <lm.IDialogOptions>{
			title: this.lang.editPublishConfiguration,
			templateUrl: "scripts/lime/templates/page-customize.html",
			style: "width: 100%; max-width: 650px;",
			parameter: page,
			id: c.Constants.modalPagePublish
		};

		this.dialogService.show(options).then((r: lm.IDialogResult) => {
			var updatedPage = <c.IPage>r.value;
			if (!lm.CommonUtil.isUndefined(updatedPage)) {
				// The data properties are manually copied instead of replacing the entire data object 
				// since that caused issues that must be fixed before this can be done.
				var pageData = page.data;
				var updatedData = updatedPage.data;
				pageData.title = updatedData.title;
				pageData.description = updatedData.description;
				pageData.tags = updatedData.tags;
				page.roleAccess = updatedPage.roleAccess;
				page.userAccess = updatedPage.userAccess;
				page.localization = updatedPage.localization;
			}
		});
	}

	private removeDev(deferred: ng.IDeferred<c.IOperationResponse>, page: c.IPageInstance) {
		this.removeFromPages(page);
		c.ClientConfiguration.dev.save();
		deferred.resolve(new c.OperationResponse(page.id));
	}

	remove(page: c.IPageInstance): ng.IPromise<c.IOperationResponse> {
		var deferred = this.q.defer();

		var lang = this.lang;
		var options: lm.IMessageDialogOptions = {
			title: lang.removePage,
			message: p.PageUtil.isPagePrivate(page.data) ? lang.format(lang.confirmRemovePage, page.title) : lang.format(lang.confirmRemovePublicPage, page.title),
			standardButtons: lm.StandardDialogButtons.YesNo,
			cssClass: "e2e-publRemove"
		}
		this.dialogService.showMessage(options).then((result: lm.IDialogResult) => {
			if (result.button === lm.DialogButtonType.Yes) {
				this.context.setBusy(true);
				if (c.ClientConfiguration.isDev()) {
					this.removeDev(deferred, page);
					return deferred.promise;
				}

				this.pageService.removeConnection(page.id).then((r: c.IOperationResponse) => {
					if (r.hasError()) {
						deferred.reject(r);
					}
					this.removeFromPages(page);
					deferred.resolve(r);
					this.context.setBusy(false);
				}, (r: c.IOperationResponse) => {
					deferred.reject(r);
					this.logResponse(r);
					this.context.setBusy(false);
				});
			}
		});

		return deferred.promise;
	}

	delete(pageId: string, name: string, isShared: boolean): ng.IPromise<c.IOperationResponse> {
		var lang = this.lang;
		var page: c.IPageInstance = this.getPage(pageId);
		var isPageLoaded = lm.CommonUtil.hasValue(page);
		var deferred = this.q.defer();
		var message = isShared ? lang.format(lang.confirmDeletePublicPage, name) :
			lang.format(lang.confirmRemovePage, name);

		var options: lm.IMessageDialogOptions = {
			title: isShared ? this.lang.deletePage : this.lang.removePage,
			message: message,
			standardButtons: lm.StandardDialogButtons.YesNo,
			cssClass: "e2e-privRemove"
		}
		this.dialogService.showMessage(options).then((result: lm.IDialogResult) => {
			if (result.button === lm.DialogButtonType.Yes) {
				this.context.setBusy(true);
				if (c.ClientConfiguration.isDev()) {
					this.removeDev(deferred, page);
					this.context.setBusy(false);
					return deferred.promise;
				}

				this.pageService.delete(page === null ? pageId : page.id).then((r: c.IOperationResponse) => {
					if (r.hasError()) {
						deferred.reject(r);
					}
					if (isPageLoaded) {
						this.removeFromPages(page);
					}
					deferred.resolve(r);
					this.context.setBusy(false);
				}, (r: c.IOperationResponse) => {
					deferred.reject(r);
					this.logResponse(r);
					this.context.setBusy(false);
				});
			}
			return deferred.promise;
		});

		return deferred.promise;
	}

	public removeAllPagesFromClient(): void {
		angular.forEach(this.pages, (page) => {
			this.removeFromPages(page, true);
		});
	}

	private removeFromPages(page: c.IPageInstance, isRefresh?: boolean): void {
		const id = page.id;
		let selectedIndex: number;
		if (!isRefresh && this.selectedPage.id === page.id) {
			selectedIndex = lm.ArrayUtil.indexByProperty(this.pages, "id", id);
		}

		// Remove homepage element from DOM. This must be done before destroying the page and
		// removing the page data, otherwise a memory leak will occur.
		const element = $("#" + id + "").parent(".homepage");
		p.PageUtil.destroyHomepageControl(element);
		element.remove();

		// Destroy page and all its widgets
		page.destroy();

		lm.ArrayUtil.removeByProperty(this.pages, "id", id);
		for (let i = 0; i < this.data.pages.length; i++) {
			if (this.data.pages[i].data.id === id) {
				this.data.pages.splice(i, 1);
				break;
			}
		}

		if (!lm.CommonUtil.isUndefined(selectedIndex)) {
			this.selectOnRemove(selectedIndex);
		}

		if (this.isDebug()) {
			this.debug("Page " + page.data.title + " was removed");
		}
		this.raiseChanged();
	}

	added(): c.InstanceEvent<c.IPageInstance> {
		return this.addedEvent;
	}

	selected(): c.InstanceEvent<c.IPageInstance> {
		return this.selectedEvent;
	}

	changed(): c.InstanceEvent<c.IPageContainer> {
		return this.changedEvent;
	}

	refreshed(): c.InstanceEvent<c.IPageContainer> {
		return this.refreshedEvent;
	}

	showAddPage() {
		if (this.isPageAddPossible()) {
			const options = <lm.IDialogOptions>{
				title: this.lang.newPage,
				templateUrl: "scripts/lime/templates/add-page.html",
				cssClass: "e2e-newPageDialog"
			};

			this.dialogService.show(options).then((r: lm.IDialogResult) => {
				this.debug("Add page dialog closed");
				if (!lm.CommonUtil.isUndefined(r.value) && r.button === lm.DialogButtonType.Ok) {
					const newPage = <c.IPageData>r.value;
					if (newPage.title) {
						this.create(newPage);
					} else {
						this.debug("Page not added since no title was specified");
					}
				}
			});
		}
	}

	public loadPage(id: string): ng.IPromise<c.IPageData> {
		var deferred = this.q.defer();
		var existingPage = <c.IPageInstance>lm.ArrayUtil.itemByProperty(this.pages, "id", id);
		//If page is not mine and ownerName is not set, fetch page
		if (lm.CommonUtil.hasValue(existingPage) && (existingPage.data.ownerId === this.context.getUserId() || !lm.CommonUtil.isUndefined(existingPage.data.ownerName))) {
			deferred.resolve(existingPage);
		} else {
			this.pageService.getPublished(id).then((resp: c.IPageResponse) => {
				if (resp && resp.content) {
					if (lm.CommonUtil.hasValue(existingPage)) {
						//Replace pageData if existing page was fetched again to set userNames
						existingPage.data = resp.content.data;
					}
					deferred.resolve(resp.content);
				} else {
					this.error("loadPage did not return the page. " + JSON.stringify(resp));
					deferred.reject(resp);
				}
			},
				(resp: c.IOperationResponse) => {
					this.error("Failed to load page: " + JSON.stringify(resp));
					deferred.reject(resp);
				});
		}
		return deferred.promise;
	}

	showPageInformation(id: string) {
		if (!id) {
			return;
		}

		// TODO: Do we need this page to update public or is it ok to just fetch it?
		//var page = lm.ArrayUtil.itemByProperty(this.pages, "id", id);
		//var isExisting = lm.CommonUtil.hasValue(page);
		this.context.setBusy(true);
		this.loadPage(id).then((page: c.IPageInstance) => {
			var isPrivate = page.data.viewAccess === c.AccessType.Owner;
			this.context.setBusy(false);
			this.showPageSettings(page);
		}, (error) => {
			this.error("Unable to get Page " + error);
			this.dialogService.showMessage({ title: this.lang.pageSettings, message: this.lang.unableOpenPageSettings, standardButtons: lm.StandardDialogButtons.Ok });
			this.context.setBusy(false);
		});
	}

	public showPageSettings(page: c.IPage) {
		var options = <lm.IDialogOptions>{
			title: this.lang.pageSettings,
			templateUrl: "scripts/lime/templates/page-settings.html",
			parameter: page
		};
		this.dialogService.show(options).then((r: lm.IDialogResult) => {
			if (r.button == lm.DialogButtonType.Ok) {
				page.data.title = page.title;
				page.data.description = page.description;
				page.data.changeDate = page.changeDate;
				this.raiseChangedId(page.data.id);
			}
		});
	}

	public showAboutPage() {
		//TODO Type data
		var about: any = $("#xi-about-dialog-link").data("about");
		var modal: any = about.modal.data("modal");
		modal.open();
	}

	showPageLibrary() {
		var template = "<div class=\"contextual-action-panel modal lm-catalog-dialog\" ng-include=\"'scripts/lime/templates/page-library.html'\"></div>";
		this.dialogService.showContextualActionPanel(template);
	}

	private addLast(serverPage: c.IPage): c.IPageInstance {
		var page = new p.Page(this.context, serverPage, this.widgetService, this.lang, this.progressService);
		this.addEventHandlers(page);
		this.pages.push(page);
		return page;
	}

	private savePage(page: c.IPageInstance, deferred: ng.IDeferred<c.IOperationResponse>) {
		var pageData: c.IPageData = page.createSavePageData();
		this.pageService.update(pageData).then((r: c.IOperationResponse) => {
			this.debug("Page saved: " + pageData.title);
			if (deferred) {
				deferred.resolve(r);
			}
		}, (r: c.IOperationResponse) => {
			this.pageService.handleError(r);
			if (deferred) {
				deferred.reject(r);
			}
		});
	}

	public refresh() {
		this.refreshedEvent.raise(this);
	}

	public saveAndRefreshCurrent(): void {
		if (this.selectedPage) {
			this.saveCurrent().then(() => {
				this.refresh();
			});
		}
	}

	public saveCurrent(): ng.IPromise<c.IOperationResponse> {
		var deferred = this.q.defer();
		var page = this.selectedPage;
		if (page) {
			this.savePage(page, deferred);
		} else {
			deferred.reject();
		}
		return deferred.promise;
	}

	private addEventHandlers(page: c.IPageInstance) {
		page.changed().on((p: c.IPageInstance) => {
			if (p) {
				// Check edit modes where save should be skipped
				var service = this.editModeService;
				if (service.containsMode(c.EditModes.page) || service.containsMode(c.EditModes.widget)) {
					// Don't save anything here when in publish page / widdget mode for now. 
					// The page will be saved if it is published.
					// TODO How to handle user data in publish page mode?
					return;
				}

				if (page.isPublished()) {
					this.saveUserData(page);
				} else {
					this.savePage(p, null);
				}
			}
		});
	}

	private getPage(id: string): c.IPageInstance {
		return <c.IPageInstance>lm.ArrayUtil.itemByProperty(this.pages, "id", id);
	}

	private saveUserData(page: c.IPageInstance) {
		var data = page.getWidgetUserSettings();

		// Save the widget user data in the settings object
		if (page.setWidgetUserSettings(data)) {
			this.pageService.updateConnectionSettings(page.data.id, page.settings).then((response: c.IOperationResponse) => {
				// Nothing to do for now
			}, (r: c.IOperationResponse) => { this.widgetService.handleError(r); });
		}
	}

	/**
	 * Selects the page with this index or one below if index is out of range
	 */
	private selectOnRemove(index: number) {
		if (this.pages.length == 0) {
			this.select(null);
		} else if (0 <= index && index < this.pages.length) {
			this.select(this.pages[index].id);
		} else {
			this.select(this.pages[index - 1].id);
		}
	}

	private onPageCreated(response: c.IPageDataResponse, startEditMode?: boolean) {
		var pageData = response.content;
		var serverPage = { data: pageData, isEditable: true };
		this.add(serverPage, false);
		if (startEditMode) {
			this.editModeService.start({
				mode: c.EditModes.layout, title: this.lang.editingPageLayout
			});
		}
		this.debug("Created page: " + pageData.title);
	}

	private raiseChangedId(id: string) {
		this.debug("Page with id " + id + " changed");
		this.changedEvent.raise();
	}

	private raiseChanged(): void {
		this.changedEvent.raise(this);
	}

	/**
	 * Add Existing Page
	 *
	 * Add an existing published or private page.
	 */
	addExistingPage(page: c.IPage, showToastConfirmation: boolean, isCopy?: boolean, copyTitle?: string, busyCallback?: Function) {
		if (!busyCallback) {
			this.progressService.setBusy(true);
		} else {
			busyCallback();
		}
		var pageToAdd: c.IPageInstance = lm.ArrayUtil.itemByProperty(this.pages, "id", page.data.id);
		if (!pageToAdd || pageToAdd.isPublished()) {
			// Public page.
			// Verify that the page does not exist in My Pages already, in that case show an error message
			var lang = this.lang;
			if (!isCopy && lm.ArrayUtil.containsByProperty(this.pages, "id", page.data.id)) {
				busyCallback ? busyCallback() : this.progressService.setBusy(true);
				this.dialogService.showMessage({ title: lang.pageExists, message: lang.format(lang.pageExistsMessage, page.title), standardButtons: lm.StandardDialogButtons.Ok });
				return;
			}

			// Add page if max pages not reached.
			if (this.isPageAddPossible()) {
				var sortOrder: number = this.getNextSortOrder();
				// Sortorder is set on server
				this.pageService.addConnection(page.data.id, isCopy, sortOrder, copyTitle).then((r: c.IPageResponse) => {
					this.add(r.content, showToastConfirmation);
					busyCallback ? busyCallback() : this.progressService.setBusy(false);
				}, (r: c.IOperationResponse) => {
					this.pageService.handleError(r);
					busyCallback ? busyCallback() : this.progressService.setBusy(false);
				});
			} else {
				busyCallback ? busyCallback() : this.progressService.setBusy(false);
			}
		} else {
			// Private page.
			this.duplicatePrivatePage(pageToAdd.createSavePageData(), copyTitle);
			if (busyCallback) {
				busyCallback();
			}
		}
	}

	/**
	 * Duplicate Private Page
	 *
	 * Duplicates a private page.
	 */
	duplicatePrivatePage(pageData: c.IPageData, copyTitle: string) {
		// Add page if max pages not reached.
		if (this.isPageAddPossible()) {
			// Strip ID and set new title.
			pageData.title = copyTitle;
			pageData.id = null;

			// Set next sort order
			pageData.sortOrder = this.getNextSortOrder();

			// Create new page.
			this.context.setBusy(true);
			this.pageService.createPrivate(pageData).then((response: c.IPageResponse) => {
				this.onPageCreated(response, false);
				this.context.setBusy(false);
			}, (response: c.IOperationResponse) => {
				this.handleCreatePageError(response);
				this.context.setBusy(false);
			});
		}
	}

	/**
	 * Is Page Add Possible
	 *
	 * Returns false if the user has reached the max page count.
	 * @ return boolean Max page count reached?
	 */
	private isPageAddPossible(): boolean {
		var lang = this.lang;
		var settings = this.context.settings;
		var userPageCount = this.getUserPageCount();
		// Fix for preview page since a page is temporarily added in that mode, causing misleading page count
		if (this.editModeService.isMode("preview")) {
			userPageCount--;
		}
		var maxCount = settings.getMaxUserPageCount();
		if (userPageCount >= maxCount) {
			this.dialogService.showMessage({ title: lang.unableToAddPage, message: lang.format(lang.maxPageCountMessage, maxCount), standardButtons: lm.StandardDialogButtons.Ok });
			return false;
		}
		return true;
	}

	copyPage(page: c.IPage, showToastConfirmation: boolean, fromPreview: boolean, busyCallback?: Function) {
		if (this.isPageAddPossible()) {
			var title: string;
			var pageTitle = page.title ? page.title : page.data.title;
			var pageTitleLength = pageTitle.length;
			var self = this;
			// Handle max-length
			var copySuffixLength = this.lang.format(this.lang.pageCopyTitle, pageTitle).length - pageTitleLength;
			if ((pageTitleLength + copySuffixLength) <= c.Constants.pageTitleLength) {
				title = pageTitle;
			} else {
				title = pageTitle.substr(0, (pageTitleLength + (c.Constants.pageTitleLength - pageTitleLength)) - (copySuffixLength + 3));
				title += "...";
			}

			var options = <lm.IDialogOptions>{
				title: this.lang.duplicatePage,
				templateUrl: "scripts/lime/templates/copy-page.html",
				parameter: { title: this.lang.format(this.lang.pageCopyTitle, title) },
				controller: "lmCopyPageCtrl as ctrl",
				cssClass: "e2e-copyPageModal"
			};

			this.dialogService.show(options).then((r: lm.IDialogResult) => {
				self.debug("Copy page dialog closed");
				if (r.value && r.button === lm.DialogButtonType.Ok) {
					var newPage = <c.IPageData>r.value;
					if (fromPreview) {
						// Remove then add to get correct behavior towards the server
						self.removeFromPages(self.getPage(page.data.id));
					}
					self.addExistingPage(page, showToastConfirmation, true, newPage.title, busyCallback);
					if (fromPreview) {
						self.editModeService.stop({ isSave: true });
					}
				}
			});
		}
	}


	openImportPageDialog(): ng.IPromise<lm.IDialogResult> {
		const settings = this.context.settings;
		const userPageCount = this.getUserPageCount();
		const maxCount = settings.getMaxUserPageCount();
		const lang = this.lang;
		if (userPageCount >= maxCount) {
			const messageOptions: lm.IMessageDialogOptions = {
				title: lang.unableToAddPage,
				message: lang.format(lang.maxPageCountMessage, maxCount),
				standardButtons: lm.StandardDialogButtons.Ok
			};

			return this.dialogService.showMessage(messageOptions);
		}

		const importOptions: c.IImportOptions = {
			url: "/user",
			title: this.lang.importPage,
			operation: c.EntityCategory.privatePage.toString(),
			acceptFileExtension: ".json"
		};

		const options: lm.IDialogOptions = {
			title: this.lang.importPage,
			templateUrl: "scripts/lime/templates/import.html",
			style: "width:450px;",
			parameter: importOptions
		};

		return this.dialogService.show(options);
	}

	previewPage(pageId: string, isExternal: boolean): void {
		this.progressService.setBusy(true);
		this.pageService.getPreview(pageId).then((response: c.IPageResponse) => {
			if (response.hasError() || !response.content.data) {
				this.progressService.setBusy(false);
				this.pageService.handleError(response);
				if (!isExternal) {
					// Catalog should not be opened for previews / shared links
					this.showPageLibrary();
				}
				return;
			}
			var page: c.IPage = response.content;

			var isAddEnabled = this.context.settings.isPublicPageAddEnabled();
			var isDuplicateEnabled = this.context.settings.isPublicPageCopyEnabled() && this.context.settings.isPrivatePagesEnabled();

			// Register Applications and definitions so the preview will have enough data
			this.cacheApplicationsAndDefinitions(page);

			var pageTitle: string = page.data.title;

			var isEditable = page.isEditable;
			// Edit is never allowed in preview - but remember to change it back is added
			page.isEditable = false;

			var self = this;
			this.editModeService.start({
				mode: c.EditModes.preview,
				title: this.lang.format(this.lang.previewingPage, "'" + pageTitle + "'"),
				actions: [
					{
						text: this.lang.cancel,
						cssClass: "e2e-previewPageCancel",
						execute: () => {
							self.removeFromPages(self.getPage(page.data.id));
							self.editModeService.stop({ isSave: false });
							if (!isExternal) {
								// Catalog should not be opened for previews / shared links
								this.showPageLibrary();
							}
						}
					},
					{
						text: this.lang.addPage,
						cssClass: "e2e-previewPageAdd",
						execute: () => {
							if (this.isPageAddPossible()) {
								// Remove then add to get correct behavior towards the server
								self.removeFromPages(self.getPage(page.data.id));
								// Set the server value for isEditable
								page.isEditable = isEditable;
								self.addExistingPage(page, false);
								self.editModeService.stop({ isSave: true });
							}

						},
						isEnabled: isAddEnabled
					}
				],
				secondaryActions: [
					{
						text: this.lang.duplicatePage,
						execute: () => {
							self.copyPage(page, false, true);
						},
						isEnabled: isDuplicateEnabled
					}
				]
			});
			this.add(page, false);
			this.progressService.setBusy(false);
		}, (response: c.IOperationResponse) => {
			this.pageService.handleError(response);
			this.context.setBusy(false);
			if (!isExternal) {
				// Catalog should not be opened for previews / shared links
				this.showPageLibrary();
			}
		});
	}

	private handleCreatePageError(response: c.IOperationResponse) {
		var title = this.lang.unableToAddPage;
		var message = this.lang.unableToAddPageMesssage;
		// Check if this is a IOperationResponse or a http error
		if (response.errorList) {
			if (response.errorList[0].code === c.UniqueError.failedToAddMaxUserPagesReached) {
				var maxUserPage = this.context.settings.getMaxUserPageCount();
				message = this.lang.format(this.lang.maxPageCountMessage, maxUserPage);
			}
		}
		this.dialogService.showMessage({ title: title, message: message, standardButtons: lm.StandardDialogButtons.Ok });
		this.logResponse(response);
	}
}

class IonApiContext implements lm.IIonApiContext {
	constructor(private url: string, private token: string, private customerContext: string) {
	}

	public getUrl(): string {
		return this.url;
	}

	public getToken(): string {
		return this.token;
	}

	public setToken(token: string): void {
		this.token = token;
	}

	public getHeaderName(): string {
		return "Authorization";
	}

	public getHeaderValue(): string {
		return "Bearer " + this.token;
	}

	public getCustomerContext(): string {
		return this.customerContext;
	}
}

class Configuration implements c.IConfiguration {
	// A map of application instances keyed by logical ID
	private instanceMap = {};

	// A map of application instance arrays keyed by logical ID prefix
	private prefixMap = {};

	private ionApiContext: IonApiContext;

	/**
	 * Error message: No logical ID specified
	 */
	private errorNoId = "No logical ID specified";

	constructor(private q: ng.IQService, private http: ng.IHttpService, private commonDataService: c.ICommonDataService, applications: c.IStringToIApplicationArrayMap, public properties: c.IStringToStringMap, public ionApiCustomerContext: string, private ionApiUrl: string, private ionApiDevToken: string) {
		this.addApplicationMap(applications);
	}

	public getIonApiContextAsync(options?: lm.IIonApiOptions): ng.IPromise<lm.IIonApiContext> {
		var deferred = this.q.defer<lm.IIonApiContext>();
		const refresh = options && options.refresh === true;

		var context = this.ionApiContext;
		if (!c.ClientConfiguration.isDev()) {
			if (context && !refresh) {
				deferred.resolve(context);
			} else {
				const req = {
					method: "GET",
					url: "/grid/rest/security/sessions/oauth?forceRefresh=true",
					cache: false
				}
				this.http(req).then(response => {
					var token = <string>response.data;
					if (context) {
						// Update the token in the exsting context
						context.setToken(token);
					} else {
						context = new IonApiContext(this.ionApiUrl, token, this.ionApiCustomerContext);
						this.ionApiContext = context;
					}
					deferred.resolve(context);
				}, response => {
					deferred.reject(response);
				});
			}
		} else {
			// Use data from configuration file
			if (lm.CommonUtil.isUndefined(this.ionApiUrl) || lm.CommonUtil.isUndefined(this.ionApiDevToken)) {
				deferred.reject();
			} else {
				context = new IonApiContext(this.ionApiUrl, this.ionApiDevToken, this.ionApiCustomerContext);
				deferred.resolve(context);
			}
		}

		return deferred.promise;
	}

	private executeIonApi<T>(context: lm.IIonApiContext, options: lm.IIonApiRequestOptions, deferred: ng.IDeferred<any>, isRetry: boolean): void {
		const url = options.url;
		if (url && url.indexOf("https://") !== 0) {
			// Prepend the ION API base URL to the relative URL
			options.url = c.HttpUtil.combine(context.getUrl(), url);
		}

		// Add the authorization header for ION API including the OAuth token.
		const headers = options.headers || {};
		headers[context.getHeaderName()] = context.getHeaderValue();
		options.headers = headers;

		this.http(options).then((r) => {
			// Resolve successful request.
			deferred.resolve(r);
		}, (error: ng.IHttpPromiseCallbackArg<any>) => {
			// Check if the failed request should be retried with a new ION API context.
			if (error.status === 401 && !isRetry && options.ionApiRetry !== false) {
				this.getIonApiContextAsync({ refresh: true }).then((retryContext: lm.IIonApiContext) => {
					this.executeIonApi(retryContext, options, deferred, true);
				}, (retryError) => {
					// Reject when a new context cannot be retrieved.
					deferred.reject(retryError);
				});
			} else {
				// Reject failed retry attemtps or when retry is disabled.
				deferred.reject(error);
			}
		});
	}

	public executeIonApiAsync<T>(options: lm.IIonApiRequestOptions): ng.IPromise<ng.IHttpPromiseCallbackArg<T>> {
		const deferred = this.q.defer<T>();
		this.getIonApiContextAsync().then((context: lm.IIonApiContext) => {
			this.executeIonApi(context, options, deferred, false);
		}, (r) => {
			deferred.reject(r);
		});
		return deferred.promise;
	}

	private getApplicationOrDefault(applications: lm.IApplication[], logicalId: string): lm.IApplication {
		if (applications) {
			let defaultApplication: lm.IApplication;
			for (let i = 0; i < applications.length; i++) {
				const application = applications[i];
				if (application.logicalId === logicalId) {
					// Return exact match
					return application;
				}
				if (application.isDefault) {
					defaultApplication = application;
				}
			}
			// Return the application marked as default or the first in the list
			return defaultApplication || applications[0];
		}
		return null;
	}

	public getApplicationCached(logicalId: string): lm.IApplication {
		const application = this.instanceMap[logicalId];
		if (application) {
			return application;
		}
		const applications = this.prefixMap[logicalId];
		return this.getApplicationOrDefault(applications, logicalId);
	}

	public getApplicationsCached(logicalId: string): lm.IApplication[] {
		let logicalIdPrefix: string;
		const application = this.instanceMap[logicalId];
		if (application) {
			logicalIdPrefix = application.logicalIdPrefix;
		} else {
			logicalIdPrefix = logicalId;
		}
		const applications = logicalIdPrefix ? this.prefixMap[logicalIdPrefix] : null;
		return applications || null;
	}

	private add(items: lm.IApplication[]): void {
		for (let i = 0; i < items.length; i++) {
			this.addApplication(items[i]);
		}
	}

	public addApplicationMap(applications: c.IStringToIApplicationArrayMap): void {
		for (let key in applications) {
			this.addApplications(applications[key]);
		}
	}

	public addApplications(applications: lm.IApplication[]): void {
		for (let i = 0; i < applications.length; i++) {
			this.addApplication(applications[i]);
		}
	}

	addApplication(application: lm.IApplication): void {
		const logicalId = application.logicalId;
		const logicalIdPrefix = application.logicalIdPrefix;
		let instances = this.prefixMap[logicalIdPrefix];
		if (!instances) {
			instances = [];
			this.prefixMap[logicalIdPrefix] = instances;
		}

		const index = lm.ArrayUtil.indexByProperty(instances, "logicalId", logicalId);
		if (index >= 0) {
			// Overwrite exsting
			instances[index] = application;
		} else {
			// Add new
			instances.push(application);
		}

		this.instanceMap[logicalId] = application;
	}

	public getApplications(logicalId: string): ng.IPromise<lm.IApplication[]> {
		var deferred = this.q.defer();
		if (logicalId) {
			var applications = this.getApplicationsCached(logicalId);
			if (applications) {
				deferred.resolve(applications);
			} else {
				this.commonDataService.getApplication(logicalId).then((r: c.IApplicationResponse) => {
					if (!r.hasError() && r.content) {
						applications = r.content;
						this.add(applications);
						deferred.resolve(applications);
					} else {
						deferred.reject(r);
					}
				}, (r: c.IOperationResponse) => {
					deferred.reject(r);
				});
			}
		} else {
			deferred.reject(this.errorNoId);
		}
		return deferred.promise;
	}

	public getApplication(logicalId: string): ng.IPromise<lm.IApplication> {
		var deferred = this.q.defer();
		if (logicalId) {
			this.getApplications(logicalId).then((applications: lm.IApplication[]) => {
				var application = this.getApplicationOrDefault(applications, logicalId);
				if (application) {
					deferred.resolve(application);
				} else {
					deferred.reject(null);
				}
			}, (r) => {
				deferred.reject(r);
			});
		} else {
			deferred.reject(this.errorNoId);
		}
		return deferred.promise;
	}
}

class Context implements c.IContext {
	private userId: string;
	private version: string;
	private configuration: c.IConfiguration;
	private language: string;
	private tenantId: string;
	private containerUrl: string;
	private container: c.IPageContainerData;

	settings: c.IServerSettings;
	isAdministrator = false;
	isPageAdmininistrator = false;
	isDev = false;

	constructor(private q: ng.IQService, private http: ng.IHttpService, private progressService: c.IProgressService, private dataservice: c.IDataService, private commonDataService: c.ICommonDataService) {
	}

	public init(container: c.IPageContainerData, containerUrl: string) {
		// TODO Decide if we should keep both or just one. MT vs on-premise.
		this.isAdministrator = container.isAdministrator;
		this.isPageAdmininistrator = container.isPageAdministrator;

		this.container = container;
		this.userId = container.userId;
		this.tenantId = container.tenantId;
		this.version = container.version;
		this.containerUrl = containerUrl;
		this.settings = new ServerSettings(container.userSettings, container.applicationSettings, container.isAdministrator, container.isPageAdministrator, this.q, this.dataservice);
		this.configuration = this.createConfiguration(container.configuration);
	}

	public getTenantId() {
		return this.tenantId;
	}

	public getContainerUrl() {
		return this.containerUrl;
	}

	public isCloud(): boolean {
		return this.container.isCloud;
	}

	public isBusy(): boolean {
		return this.progressService.isBusy();
	}

	public setBusy(isBusy: boolean): void {
		this.progressService.setBusy(isBusy);
	}

	createConfiguration(config: c.IConfigurationData): c.IConfiguration {
		var applications = null, properties = null, ionApiCustomerContext = null, ionApiUrl = null, ionDevToken = null;
		if (config) {
			applications = config.applications;
			properties = config.properties;
			ionApiCustomerContext = config.ionApiCustomerContext;
			ionApiUrl = config.ionApiUrl;
			ionDevToken = config.ionApiToken;
		}
		return new Configuration(this.q, this.http, this.commonDataService, applications || {}, properties || {}, ionApiCustomerContext, ionApiUrl, ionDevToken);
	}

	getConfiguration(): c.IConfiguration {
		return this.configuration;
	}

	getUserId(): string { return this.userId; }

	getVersion(): string { return this.version; }

	isCurrentUser(user: string): boolean {
		return user && user.toLocaleLowerCase() === this.userId;
	}

	// TODO Change all security checks

	public isOperationEnabled(page: c.IPageData, settingValue: boolean): boolean {
		const isAdmin = this.isPageAdmininistrator;
		const isOwner = this.isCurrentUser(page.ownerId);
		const isShared = page.viewAccess !== c.AccessType.Owner;
		const isAllowed = isShared && settingValue;
		return isOwner || isAdmin || isAllowed;
	}

	public getLanguage(): string {
		if (lm.CommonUtil.isUndefined(this.language)) {
			this.language = infor.lime.language || "en-US";
		}
		return this.language;
	}
}

class ServerSettings extends c.CoreBase implements c.IServerSettings {
	private isDirty: boolean = false;
	private user: { [index: string]: c.ISettingInfo; };
	private application: { [index: string]: c.ISettingInfo; }
	private enabledWidgets: string;
	private disabledWidgets: string;

	constructor(private userSettings: c.ISettingInfo[], public applicationSettings: c.ISettingInfo[], private isAdmin: boolean, private isPageAdmin: boolean, private q: ng.IQService, private dataservice: c.IDataService) {
		super("[ServerSettings] ");
		this.user = this.toDictionary(userSettings);
		this.application = this.toDictionary(applicationSettings);
	}

	private toDictionary(source: c.ISettingInfo[]): { [index: string]: c.ISettingInfo; } {
		var dictionary: { [index: string]: c.ISettingInfo; } = {};
		if (source != null) {
			for (var i = 0; i < source.length; i++) {
				var item = source[i];
				dictionary[item.name] = item;
			}
		}
		return dictionary;
	}

	private getString(dictionary: { [index: string]: c.ISettingInfo; }, name: string, defaultValue: string = null): string {
		var setting: c.ISettingInfo = dictionary[name];
		if (setting && setting.value) {
			return setting.value;
		}
		return defaultValue;
	}

	private setString(dictionary: { [index: string]: c.ISettingInfo; }, name: string, value: string) {
		var setting: c.ISettingInfo = dictionary[name];
		if (setting && value) {
			if (setting.value !== value) {
				setting.isChanged = true;
				this.isDirty = true;
			}
			setting.value = value;
		}
	}


	private setStringAllowEmpty(dictionary: { [index: string]: c.ISettingInfo; }, name: string, value: string) {
		var setting: c.ISettingInfo = dictionary[name];
		if (setting && value != null) {
			if (setting.value !== value) {
				setting.isChanged = true;
				this.isDirty = true;
			}
			setting.value = value;
		}
	}

	private getInt(dictionary: { [index: string]: c.ISettingInfo; }, name: string, defaultValue: number = 0): number {
		var setting = dictionary[name];
		if (setting) {
			return lm.NumUtil.getInt(setting.value, defaultValue);
		}
		return defaultValue;
	}

	private getBoolean(dictionary: { [index: string]: c.ISettingInfo; }, name: string, defaultValue: boolean = false): boolean {
		var setting = dictionary[name];
		if (setting) {
			return lm.CommonUtil.getBoolean(setting.value, defaultValue);
		}
		return defaultValue;
	}

	private getJSON(dictionary: { [index: string]: c.ISettingInfo; }, name: string): JSON {
		var setting = dictionary[name];
		if (setting) {
			var value = setting.value;
			try {
				return JSON.parse(setting.value);
			} catch (e) {
				this.error("Failed to parse to JSON " + value);
			}
		}
		return null;
	}

	isAdministrator(): boolean {
		return this.isAdmin;
	}

	isPageAdministrator(): boolean {
		return this.isAdmin || this.isPageAdmin;
	}

	isPrivatePagesEnabled(): boolean {
		return this.getBoolean(this.application, c.SettingsNames.enablePrivatePages, false);
	}

	isSelectHomepageEnabled(): boolean {
		return this.getBoolean(this.application, c.SettingsNames.enableSelectHomepage, false);
	}

	/**
	* Use getCanAddFavoritePage(currentCount).
	*/
	isPublicPageAddEnabled(): boolean {
		return this.getBoolean(this.application, c.SettingsNames.enableAddPublishedPage, false);
	}

	isPublicPageCopyEnabled(): boolean {
		if (!this.isPrivatePagesEnabled) {
			return false;
		}
		return this.getBoolean(this.application, c.SettingsNames.enableDuplicatePublishedPage, false);
	}

	isWidgetPublishEnabled(): boolean {
		return this.getBoolean(this.application, c.SettingsNames.enableWidgetPublish, false);
	}

	isPageCatalogEnabled(): boolean {
		return this.getBoolean(this.application, c.SettingsNames.enablePageCatalog, false);
	}

	isContentTranslationEnabled(): boolean {
		return this.getBoolean(this.application, c.SettingsNames.enableContentTranslation, true);
	}

	public getDefaultLanguage(): string {
		return this.getString(this.application, c.SettingsNames.defaultLanguage, "en-US");
	}

	public getCanAddPrivatePage(pageCount: number = -1): boolean {
		// Only check pageCount if that value has been passed
		if (!this.getCanAddUserPage(pageCount)) {
			return false;
		}
		return this.isPrivatePagesEnabled();
	}

	public getCanAddUserPage(pageCount: number = -1): boolean {
		if (pageCount >= 0) {
			if (pageCount >= this.getMaxUserPageCount()) {
				return false;
			} else {
				return true;
			}
		}
		return false;
	}

	public getCanAddFavoritePage(pageCount: number = -1): boolean {
		if (!this.getCanAddUserPage(pageCount)) {
			return false;
		}
		return this.isPublicPageAddEnabled();
	}

	public getMaxUserPageCount(): number {
		return this.getInt(this.application, c.SettingsNames.maxUserPageCount, 0);
	}

	public getStartPage(): string {
		return this.getString(this.user, c.SettingsNames.startPage, "");
	}

	public setStartPage(value: string) {
		this.setStringAllowEmpty(this.user, c.SettingsNames.startPage, value);
	}

	public getLogLevel(): number {
		return this.getInt(this.user, c.SettingsNames.logLevel, lm.Log.levelInfo);
	}

	public saveUserSettings() {
		var deferred = this.q.defer();
		var array = this.toArray(this.user);
		var request = { content: JSON.stringify(array) };
		this.dataservice.executePost("/user/settings/update", request).then((response: c.IStringResponse) => {
			// TODO if ok then remove isChanged from all user settings?
			deferred.resolve(response);
		}, (response: c.IStringResponse) => {
			deferred.reject(response);
		});
		return deferred.promise;
	}

	private toArray(dictionary: { [index: string]: c.ISettingInfo; }): c.ISettingInfo[] {
		var array: c.ISettingInfo[] = [];
		for (var key in dictionary) {
			if (dictionary.hasOwnProperty(key)) {
				array.push(dictionary[key]);
			}
		};
		return array;
	}

	/**
	 * Gets a valued that indicates if the user is allowed to publish a page (make it public).
	 */
	public isPagePublishEnabled() {
		return this.getBoolean(this.application, "EnablePagePublish");
	}

	public isPageExportEnabled() {
		return this.getBoolean(this.application, "EnablePageExport");
	}

	public isPageImportEnabled() {
		return this.getBoolean(this.application, "EnablePageImport");
	}

	/**
	 * Gets a value that indicates if a specific widget is enabled for the current user.
	 */
	public isWidgetEnabled(type: string) {
		if (type == null) {
			return false;
		}
		if (this.enabledWidgets == null) {
			this.enabledWidgets = this.getString(this.application, "EnabledWidgets", "").trim().toLowerCase();
			this.disabledWidgets = this.getString(this.application, "DisabledWidgets", "").trim().toLowerCase();
		}
		type = type.toLowerCase();
		if (this.disabledWidgets.indexOf(type) >= 0) {
			return false;
		}
		if (this.enabledWidgets.length > 0 && this.enabledWidgets.indexOf(type) < 0) {
			return false;
		}
		return true;
	}
}

// Temporary default settings if container isn't loaded
class DefaultServerSettings implements c.IServerSettings {
	isAdministrator(): boolean {
		return false;
	}

	isPageAdministrator(): boolean {
		return false;
	}

	isPrivatePagesEnabled(): boolean {
		return false;
	}

	isSelectHomepageEnabled(): boolean {
		return false;
	}

	isPublicPageAddEnabled(): boolean {
		return false;
	}

	isPublicPageCopyEnabled(): boolean {
		return false;
	}

	isPageCatalogEnabled(): boolean {
		return false;
	}

	isContentTranslationEnabled(): boolean {
		return true;
	}

	public getCanAddPrivatePage(pageCount: number = -1): boolean {
		return false;
	}

	public getCanAddUserPage(pageCount: number = -1): boolean {
		return false;
	}

	public getCanAddFavoritePage(pageCount: number = -1): boolean {
		return false;
	}

	public getMaxUserPageCount(): number {
		return 0;
	}

	public getStartPage(): string {
		return ""; // TODO?
	}

	public setStartPage(value: string) {
		// TODO?
	}

	public saveUserSettings(): ng.IPromise<c.IStringResponse> {
		// TODO?
		//var deferred = this.q.defer();
		return null;
	}

	public getLogLevel(): number {
		return lm.Log.levelInfo;
	}

	/**
	 * Gets a valued that indicates if the user is allowed to publish a page (make it public).
	 */
	public isPagePublishEnabled() {
		return false;
	}

	public isPageExportEnabled() {
		return false;
	}

	public isPageImportEnabled() {
		return false;
	}
	public isWidgetEnabled(id: string) {
		return true;
	}
	public isWidgetPublishEnabled() {
		return false;
	}

	public getDefaultLanguage(): string {
		return "en-US";
	}
}

/**
 * Controller class for the page navigator.
 */
class PageNavigatorCtrl extends c.CoreBase {
	public pageContainer: c.IPageContainer;
	private currentPage: c.IPageInstance;
	private widgetToAdd: c.IWidgetData = null;
	private filenameExport = "Homepage";
	private extensionExport = ".json";
	private context: c.IContext;

	public isPageDeletable;
	public isPagePrivate;
	public isRepublishEnabled;
	public isSettingsEnabled;
	public isAdvancedEnabled;
	public isPublicPageCopyEnabled;
	public settings: c.IServerSettings;
	private lang: ILanguageLime;
	private adminUrl: string;
	private selectedPageIndex: number = 0;
	private aboutDialogOptions: xi.IAboutOptions;
	private unsubscribers: Array<Function> = [];

	static $inject = ["$scope", "$rootScope", "lmContainerService", "lmDataService", "lmDialogService", "lmWidgetService", "lmContextService", "lmLanguageService", "lmEditModeService", "$location", "lmPageService"];

	constructor(public scope: ng.IScope, private rootScope: ng.IRootScopeService, private containerService: IContainerService, private dataService: c.IDataService,
		private dialogService: lm.IDialogService, private widgetService: c.IWidgetService, private contextService: c.IContextService, languageService: c.ILanguageService, private editModeService: c.IEditModeService, private locationService: ng.ILocationService, private pageService: c.IPageService) {
		super("[PageNavigatorCtrl] ");
		var isDev = c.ClientConfiguration.isDev();
		// TODO Set default settings opbject with everything turned off
		this.settings = new DefaultServerSettings();

		// TODO Check security settings
		this.isSettingsEnabled = !isDev;
		this.isAdvancedEnabled = !isDev;
		this.lang = languageService.getLanguage();
		this.adminUrl = this.calculateAdminUrl();

		var unregister = scope.$watch("lmPageContainer", (pc: c.IPageContainer) => {
			if (pc) {
				this.initialize(pc);
				unregister();
			}
		});

		scope.$watch("lmPageContainer.selectedPage", (page: c.IPageInstance) => {
			if (page) {
				this.selectedPageIndex = this.pageContainer.pages.indexOf(page);
			}
		});

		this.unsubscribers.push(
			editModeService.stopped().on((editMode: c.IEditMode) => {
				if ((editMode.mode === c.EditModes.page || editMode.mode === c.EditModes.widget) && editMode.isSave === false) {
					this.refreshCurrent();
				}
			})
		);

		scope.$on("$destroy", () => {
			angular.forEach(this.unsubscribers, (unsubscribe) => {
				unsubscribe();
			});
		});
	}

	public static add(m: ng.IModule) {
		m.controller("lmPageNavigatorCtrl", PageNavigatorCtrl);
	}

	private showPagesMenu() {
		if (this.pageContainer.pages.length > 1) {
			$("#lmPagesMenuBtn").click();
		}
	}

	private initialize(pageContainer: c.IPageContainer) {
		this.pageContainer = pageContainer;
		this.context = pageContainer.context;
		// Check for settings to make sure nor error occurs if server is unavailable (Lime-659)
		if (this.context.settings) { this.settings = pageContainer.context.settings; }
		this.isPublicPageCopyEnabled = this.settings.isPublicPageCopyEnabled();

		// Select the initial page if there is one
		if (pageContainer.selectedPage) {
			this.onSelected(pageContainer.selectedPage);
		}
		// Subscribe to events from the page container
		this.unsubscribers.push(pageContainer.selected().on((p: c.IPageInstance) => this.onSelected(p)));
      this.unsubscribers.push(pageContainer.refreshed().on(() => this.refreshCurrent()));

		if (pageContainer.data) {
			var name = c.Product.productName;
			this.aboutDialogOptions = {
				appName: name,
				productName: name,
				version: pageContainer.data.version,
				useDefaultCopyright: true,
            content: "<div ng-controller='lmPageAboutCtrl as ctrl' class='lm-padding-md-l'><a class='hyperlink e2e-showUserSettings' ng-click='ctrl.showUserSettings()'>" + this.lang.viewUserPermissions + "</a></div>"
			}
		}
	}

	private addWidget(addWidgetInfo: c.IAddWidgetInfo, busyCallback: Function) {
		var page = this.currentPage;
		var lang = this.lang;
		this.widgetService.preAddWidget(page.getWidgetParentContext(), addWidgetInfo, busyCallback).then((widget: c.IWidget) => {
			page.add(widget);
			this.dialogService.showToast({ title: lang.widgetAdded, message: lang.format(lang.titleAddedMessage, addWidgetInfo.widgetInfo.title) });
		}, (err) => {
			this.dialogService.showMessage({ title: lang.unableToAddWidget, message: lang.brokenWidget, isError: true });
		});
	}

	private pasteWidget() {
		this.context.setBusy(true);
		var widgetCopy = this.rootScope["clipboardWidget"];
		// Add to the current page context
		var context = this.currentPage.getWidgetParentContext();
		var addWidgetInfo = this.widgetService.getAddWidgetInfo(widgetCopy);

		this.widgetService.addWidgetCopyToPage(context, addWidgetInfo).then(() => {
			this.context.setBusy(false);
		});
	}

	private removePage() {
		//Delete if private, remove if public
		if (p.PageUtil.isPagePrivate(this.currentPage.data)) {
			this.pageContainer.delete(this.currentPage.id, this.currentPage.title, false).then((r: c.IOperationResponse) => {
				// For now the selected event from pageContainer handles selection
			}, (r: c.IOperationResponse) => { this.dataService.handleError(r); });
		} else {
			this.pageContainer.remove(this.currentPage).then((r: c.IOperationResponse) => {
				// For now the selected event from pageContainer handles selection
			}, (r: c.IOperationResponse) => { this.dataService.handleError(r); });
		}
	}

	private deletePage() {
		var pageData = this.currentPage.data;
		if (this.currentPage.isEditable) {
			var self = this;
			this.pageContainer.delete(pageData.id, this.currentPage.title, pageData.viewAccess != c.AccessType.Owner).then((r: c.IOperationResponse) => {
				// For now the selected event from pageContainer handles delete
			}, (r: c.IOperationResponse) => { this.dataService.handleError(r); });
		}
	}

	private showWidgetCatalog() {
		var context = this.currentPage.getWidgetParentContext();
		var self = this;
		this.widgetService.showCatalog(context, (w: c.IAddWidgetInfo, c: Function) => { self.addWidget(w, c); }).then(() => {
			// Adding of widget handled by callback
		}, () => {
			lm.Log.error("Could not open Widget Catalog (via menu).");
		});
	}

	private showAddPage() {
		this.pageContainer.showAddPage();
	}

	private showMyPages() {
		this.scope["lmShowMyPages"] = true;
	}

	private showPageSettings() {
		this.pageContainer.showPageInformation(this.pageContainer.selectedPage.id);
	}

	private showRepublishPage() {
		var page = this.pageContainer.selectedPage;
		this.pageService.getPublishedExtended(page.data.id).then((r: c.IPageResponse) => {
			if (r.hasError()) {
				this.logResponse(r);
			} else {
				page.localization = r.content.localization;
				page.userAccess = r.content.userAccess;
				page.roleAccess = r.content.roleAccess;
				this.showPublishPage();
			}
		}, (r: c.IOperationResponse) => {
			this.logResponse(r);
			return;
		});
	}

	private showPublishPage() {
		const lang = this.lang;
		let title;
		let commandText;
		if (this.isPagePrivate) {
			title = lang.publishPage;
			commandText = lang.publish;
		} else {
			title = lang.republishPage;
			commandText = lang.republish;
		}

		this.currentPage.notifyPublishingMode();

		var self = this;
		var cancelClass = "e2e-pubPageCancel";
		var publishClass = "e2e-pubPagePublish";
		var editLayoutClass = "e2e-pubPageEditLayout";
		var editPubConf = "e2e-pubPageEditPubConfig";
		if (!this.isPagePrivate) {
			cancelClass = "e2e-rePubPageCancel";
			publishClass = "e2e-rePubPagePublish";
			editLayoutClass = "e2e-rePubPageEditLayout";
			editPubConf = "e2e-rePubPageEditPubConfig";
		}
		this.editModeService.start({
			mode: c.EditModes.page,
			title: title,
			submode: this.isPagePrivate ? c.EditSubmodes.publish : c.EditSubmodes.republish,
			actions: [
				{ text: this.lang.cancel, cssClass: cancelClass, execute: () => { self.pageContainer.onCancelPublish(); } },
				{ text: commandText, cssClass: publishClass, execute: () => { self.pageContainer.publish(self.pageContainer.selectedPage, self.pageContainer.selectedPage.isPublished()); } }
			],
			secondaryActions: [
				{ text: this.lang.editLayout, cssClass: editLayoutClass, execute: () => { self.showEditPageLayout(); } },
				{ text: this.lang.editPublishConfiguration, cssClass: editPubConf, execute: () => { self.pageContainer.editPageConfiguration(!self.isPagePrivate); } }
			]
		});

		this.pageContainer.editPageConfiguration(!this.isPagePrivate);
	}

	private exportPage() {
		if (!this.settings.isPageExportEnabled()) {
			this.debug("[ExportPage] Click on disabled context menu, should have been prevented by infor control");
			return;
		}
		var page = this.currentPage;
		var id = page.id;
		var name = page.data.title; // TODO: which title to use for export, default or translated?
		if (!name) {
			name = this.filenameExport;
		}
		name = encodeURI(name);
		var query = "?_=" + new Date().getTime(); // Add this to prevent browser caching
		var url = this.dataService.getUrl("page/export/" + id + "/" + name + this.extensionExport) + query;
		this.debug("[exportPage] " + url);
		window.open(url, "_blank");
	}

	private importPage(): void {
		const self = this;
		this.pageContainer.openImportPageDialog().then((r: lm.IDialogResult) => {
			const value = r.value;
			if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Success) {
				const response: c.IPageDataResponse = r.value.message;
				self.refresh(response.content.id);
			} else if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Fail) {
				self.dialogService.showMessage({
					title: self.lang.importPage,
					message: self.lang.errorGeneric,
					isError: true
				});
			}
		}, (r: c.IOperationResponse) => {
			this.pageService.handleError(r);
		});
	}

	private showPageLibrary() {
		this.pageContainer.showPageLibrary();
	}

	private showEditPageLayout() {
		this.editModeService.start({
			mode: c.EditModes.layout,
			title: this.lang.editingPageLayout
		});
	}

	private onClickSelectPage(page: c.IPageInstance) {
		this.pageContainer.select(page.id);
	}

	private onSelected(page: c.IPageInstance) {
		if (page !== this.currentPage) {
			this.currentPage = page;
		}
		this.isPagePrivate = p.PageUtil.isPagePrivate(this.currentPage.data);
		this.isPageDeletable = this.currentPage.isEditable && !this.isPagePrivate;
		this.isRepublishEnabled = this.currentPage.isEditable && !this.isPagePrivate && this.context.settings.isPagePublishEnabled();
	}

	private copyPage() {
		var page = this.currentPage;
		this.pageContainer.copyPage(page, false, false);
	}

	private refreshCurrent() {
		this.pageContainer.removeAllPagesFromClient();
		this.widgetService.invalidateWidgetCache();
		this.pageService.invalidatePageCache();
		var page = this.pageContainer.selectedPage;
		if (page) {
			this.refresh(page.id);
		} else {
			// Case when no pages exist, but still need to fully refresh the container
			this.refresh();
		}
	}

	private refresh(selectPageId?: string) {
		// For case where when container failed to load and "Refresh" button appears, or when user has no pages, full refresh of startpage is needed
		let fullRefresh: boolean;
		if (this.pageContainer.errorMessage || !this.pageContainer.selectedPage) {
			fullRefresh = true;
		} else {
			fullRefresh = false;
		}

		this.scope["lmPageContainer"] = null;
		var unregister = this.scope.$watch("lmPageContainer", (pc: c.IPageContainer) => {
			if (pc) {
				this.initialize(pc);
				if (selectPageId) {
					pc.select(selectPageId);
				}
				unregister();
			}
		});
		this.scope["lmRefresh"](fullRefresh);
	}

	/**
	 * Shows the About Page dialog.
	 */
	private showAboutPage(): void {
		this.pageContainer.showAboutPage();
	}

	/**
	 * Calculate Admin URL
	 *
	 * Returns url to admin tool with or without template cache flag.
	 */
	private calculateAdminUrl(): string {
		var urlParams = this.locationService.search();
		var url = c.ClientConfiguration.isLocal() ? "admin.html" : "admin";
		if (urlParams.templateCache && urlParams.templateCache === "true") {
			url += "?templateCache=true";
		}
		return url;
	}
}

class PageNavigatorDirective {
	static add(m: ng.IModule) {
		m.directive("lmPageNavigator", ["$compile", ($compile) => {
			return {
				scope: false,
				restrict: "E",
				replace: true,
				controller: PageNavigatorCtrl,
				controllerAs: "lmPageNavigatorCtrl",
				templateUrl: "scripts/lime/templates/navigator.html"
			};
		}]);
	}
}

class PageContainerCtrl extends c.CoreBase {
	static $inject = ["$rootScope", "$scope", "$compile", "lmContainerService", "lmWidgetService", "$location", "MingleMessageBroker", "lmDialogService", "lmLanguageService"];
	private pageContainer: c.IPageContainer;
	private isDev = false;
	private isSafeMode = false;
	private isMingleInitialized = false;

	constructor(rootScope: ng.IRootScopeService, public scope: ng.IScope, private compile: ng.ICompileService, private containerService: IContainerService, private widgetService: c.IWidgetService, private location: ng.ILocationService, mingleMessageBroker: any, private dialogService: lm.IDialogService, private languageService: c.ILanguageService) {
		super("[PageContainerCtrl] ");

		mingleMessageBroker.initialize();

		var self = this;
		// Delay initialization until the directive has completed initialization.
		var unregister = scope.$watch("lmContainerMode", (mode) => {
			var urlParams = location.search();
			rootScope[c.Constants.safeMode] = !lm.CommonUtil.isUndefined(urlParams) && !lm.CommonUtil.isUndefined(urlParams[c.Constants.safeMode]) && urlParams[c.Constants.safeMode] === "true";
			self.init(mode, true);
			unregister();
		});
	}

	private init(mode: string, reloadStartPage: boolean) {
		const isDev = mode === "dev";
		if (isDev) {
			this.isDev = true;
			c.ClientConfiguration.initDevConfiguration(this.scope["lmDevData"]);
		}

		this.containerService.loadContainer(reloadStartPage).then((response: c.IPageContainer) => {
			this.onResponse(response);
		}, (r: c.IOperationResponse) => { this.widgetService.handleError(r); });

		this.scope["lmRefresh"] = (fullRefresh: boolean) => { this.refresh(fullRefresh); };
	}

	private refresh(fullRefresh: boolean): void {
		const mode = this.scope["lmContainerMode"];

		// TODO Destroy in both cases or not?
		this.pageContainer.destroy();

		if (fullRefresh) {
			this.init(mode, true);
		} else {
			this.init(mode, false);
		}
	}

	private showPageMissing(): void {
		const language = this.languageService.getLanguage();
		this.dialogService.showMessage({ title: c.Product.productName, message: language.pageNotExist, standardButtons: lm.StandardDialogButtons.Ok });
	}

	private openPage(pageId: string, preview: boolean): boolean {
		const container = this.pageContainer;
		if (container.contains(pageId)) {
			container.select(pageId);

			// Manually apply the scope since the source is from another frame.
			this.scope.$apply();
			return true;
		}

		if (preview) {
			container.previewPage(pageId, true);
			return true;
		}

		return false;
	}

	private onShowPage(pageId: string): void {
		if (pageId && this.openPage(pageId, true)) {
			return;
		}
		this.showPageMissing();
	}

	private onDrillback(data: any): void {
		try {
			if (!data) { return; }
			this.debug("onDrillback: " + JSON.stringify(data));

			// Parse the drillback URL, for example:
			// "?LogicalId=lid://infor.homepages.1&page=asd45as54asd564asd564",

			const url = data.applicationDrillback;
			const pageId = c.HttpUtil.parseQuery(url)["page"];
			this.onShowPage(pageId);
		} catch (ex) {
			this.error("Failed to handle drillback " + JSON.stringify(data), ex);
		}
	}

	private onBookmark(data: any): void {
		try {
			this.debug("onBookmark: " + JSON.stringify(data));
			const context = <c.IMingleContext>JSON.parse(data.favoriteContext);
			this.onShowPage(context.id);
		} catch (ex) {
			this.error("Failed to handle bookmark " + JSON.stringify(data), ex);
		}
	}

	private initMingleCallbacks(): void {
		if (this.isMingleInitialized) {
			return;
		}
		this.isMingleInitialized = true;

		const client = infor.companyon.client;

		var self = this;
		client.registerMessageHandler("showFavoriteContext", (data: any) => {
			self.onBookmark(data);
		});

		client.registerMessageHandler("applicationDrillback", (data: any) => {
			self.onDrillback(data);
		});

		// Use explicit initialization for Homepages
		client.sendMessage("appInitComplete", window.name);
	}

	private onResponse(pageContainer: c.IPageContainer): void {
		this.debug("Received page container");

		this.pageContainer = pageContainer;
		this.scope["lmPageContainer"] = pageContainer;

		this.initMingleCallbacks();
	}

	public static add(m: ng.IModule) {
		m.controller("lmPageContainerCtrl", PageContainerCtrl);
	}
}

class PageContainerDirective {
	static add(m: ng.IModule) {
		m.directive("lmPageContainer", ["$compile", ($compile) => {
			return {
				scope: true,
				restrict: "E",
				replace: true,
				controller: PageContainerCtrl,
				templateUrl: "scripts/lime/templates/page-container.html",
				link: (scope: ng.IScope, element: ng.IAugmentedJQuery, attributes: ng.IAttributes, controller: any, transclude: ng.ITranscludeFunction) => {
					var mode = "default";
					var widgetId = attributes["devWidget"];
					var config = attributes["devConfiguration"];
					var settings = attributes["devSettings"];
					var custom = attributes["devCustom"];
					var devData = new c.DevConfigurationData();
					// devWidget is mandatory and has to be set
					if (widgetId) {
						mode = "dev";
						devData.widgetId = widgetId;
						scope["lmDevData"] = devData;
					}
					if (config) {
						devData.configurationPath = config;
					}
					if (settings) {
						devData.settingsPath = settings;
					}
					if (custom) {
						devData.customDefinitionPath = custom;
					}
					scope["lmContainerMode"] = mode;

					lm.CommonUtil.detectBrowser();
				}
			};
		}]);
	}
}

class PageDirective {
	private page: c.IPageInstance;
	private unsubscribers: Array<Function> = [];

	constructor(private scope: ng.IScope, private element: JQuery, private $compile: ng.ICompileService, private timeout: ng.ITimeoutService, private editModeService: c.IEditModeService) {
		scope.$watch("lmPageContainer.selectedPage", (page) => {
			this.update(page);
		});
		this.unsubscribers.push(
			editModeService.started().on((editMode: c.IEditMode) => {
				if (editMode.mode == c.EditModes.layout && this.page) {
					this.startEditLayout();
					this.page.toggleEditMode(true);
				}
			})
		);

		this.unsubscribers.push(
			editModeService.stopped().on((editMode: c.IEditMode) => {
				if (editMode.mode == c.EditModes.layout && this.page) {
					this.stopEditLayout(editMode);
					this.page.toggleEditMode(false);
				}
			})
		);

		scope.$on("$destroy", () => {
			angular.forEach(this.unsubscribers, (unsubscribe) => {
				unsubscribe();
			});
		});
	}

	private startEditLayout() {
		var content = this.findContent(this.page.data);
		p.PageUtil.updateLayout(this.page.widgets);
		p.PageUtil.destroyHomepageControl(content.parent(".homepage"));
	}

	private stopEditLayout(editMode: c.IEditMode) {
		const page = this.page;
		var content = this.findContent(page.data);
		p.PageUtil.addHomepageControl(content.parent(".homepage"));

		if (!editMode.isSave) {
			setTimeout(() => {
				p.PageUtil.refreshHomepageLayout(content.parent(".homepage"));
			}, 1);
			return;
		}

		page.widgetsAddedCount = 0;
		this.updateContent(page);
		const currentMode = this.editModeService.getCurrent();
		const isPageEditActive = currentMode != null && currentMode.isActive && currentMode.mode === c.EditModes.page;
		page.updateWidgets(<c.IEditableWidget[]>editMode.result, !isPageEditActive);

		if (isPageEditActive) {
			this.timeout(() => {
				page.notifyPublishingMode();
			});
		}
	}

	private remove(widget: c.IWidget) {
		const element = widget.element;
		if (element) {
			try {
				element.remove();
			} catch (e) {
				lm.Log.error("Widget element with id '" + widget.id + "' could not be removed.");
			}
		}
	}

	private addWidget(content: JQuery, widget: c.IWidget) {
		var element = this.createWidget(widget);
		content.append(element);
	}

	private createWidget(widget: c.IWidget): JQuery {
		var elementId = lm.CommonUtil.random();
		widget.elementId = elementId;
		var container = $("<lm-widget-container/>").attr("id", elementId);
		var newScope = this.scope.$new(true);
		widget.element = container;
		newScope["lmWidget"] = widget;

		if (widget.destroyed) {
			const unregisterDestroyed = widget.destroyed().on(() => {
				unregisterDestroyed();
				newScope.$destroy();
				this.remove(widget);
			});
		}

		if (widget.added) {
			const unregisterAdded = widget.added().on(() => {
				unregisterAdded();
				this.onWidgetAdded();
			});
		}

		return this.$compile(container)(newScope);
	}

	private onWidgetAdded() {
		this.page.widgetsAddedCount++;
		if (this.page.widgetsAddedCount === this.page.noOfWidgets()) {
			//Delay needed to place larger widgets correctly
			var self = this;
			setTimeout(() => {
				var content = self.findContent(self.page.data);
				p.PageUtil.refreshHomepageLayout(content.parent(".homepage"));
				content.find(".chart-container").trigger("resize");
			}, 1);
		}
	}

	private addWidgets(content: JQuery, widgets: c.IWidget[]): void {
		this.page.widgetsAddedCount = 0;
		for (var i = 0; i < widgets.length; i++) {
			this.addWidget(content, widgets[i]);
		}
	}

	private createContent(page: c.IPageInstance): JQuery {
		// Attribute data-colums says that the Homepage supports 4 columns, othervise use 3.
		return $("<div/>").addClass("homepage").attr({ "role": "main", "data-columns": "4" }).append($("<div />").addClass("content").attr("id", page.id));
	}

	private updateContent(page: c.IPageInstance): JQuery {
		var content = this.findContent(page);
		if (content.length > 0) {
			content.empty();
		} else {
			content = this.createContent(page);
			this.element.append(content);
		}
		return content;
	}

	private findContent(page: c.IPageData): JQuery {
		return this.element.find("#" + page.id);
	}

	private update(page: c.IPageInstance): void {
		if (!page) {
			if (this.page) {
				// Remove homepage container
				this.element.find(".homepage").remove();
				this.page = null;
			}
			return;
		}

		this.page = page;
		var visibleHomePage = this.element.find(".homepage");
		if (visibleHomePage.length > 0) {
			visibleHomePage.hide();
			p.PageUtil.detachHomepageEvents(visibleHomePage);
		}
		var content = this.findContent(page);
		if (content.length > 0) {
			var hiddenHomepage = content.parent(".homepage");
			hiddenHomepage.show();
			p.PageUtil.attachHomepageEvents(hiddenHomepage, true);
			return;
		}

		this.updateContent(page);
		content = this.findContent(page);
		p.PageUtil.addHomepageControl(content.parent(".homepage"));
		this.unsubscribers.push(
			page.widgetAdded().on((w) => {
				this.addWidget(content, w);
			})
		);
		this.addWidgets(content, page.widgets);
	}

	static add(m: ng.IModule) {
		m.directive("lmPage", ["$compile", "$timeout", "lmEditModeService", ($compile, $timeout, editModeService: c.IEditModeService) => {
			return {
				scope: false,
				replace: true,
				restrict: "E",
				link: (scope: ng.IScope, element: ng.IAugmentedJQuery, attributes: ng.IAttributes, controller: any, transclude: ng.ITranscludeFunction) => {
					var directive = new PageDirective(scope, element, $compile, $timeout, editModeService);
				}
			};
		}]);
	}
}

export interface IContainerService {
	loadContainer(loadStartPage?: boolean): ng.IPromise<c.IPageContainer>;
	getContainer(): c.IPageContainer;
}

class ContainerService extends c.CoreBase implements IContainerService {
	private context: c.IContext;
	private isDev = false;
	private pageContainer: c.IPageContainer;
	private language: ILanguageLime;

	static $inject = ["$location", "$q", "lmContextService", "lmDataService", "lmWidgetService", "lmPageService", "lmDialogService", "lmLanguageService", "lmEditModeService", "lmProgressService", "$http"];

	constructor(private location: ng.ILocationService, private q: ng.IQService, private contextService: c.IContextService, private dataservice: c.IDataService, private widgetService: c.IWidgetService, private pageService: c.IPageService, private dialogService: lm.IDialogService, private languageService: c.ILanguageService, private editModeService: c.IEditModeService, private progressService: c.IProgressService, private http: ng.IHttpService) {
		super("[ContainerService] ");
		this.context = contextService.getContext();
		this.language = languageService.getLanguage();
	}

	public getContainer(): c.IPageContainer {
		return this.pageContainer;
	}

	public loadContainer(loadStartPage?: boolean): ng.IPromise<c.IPageContainer> {
		this.context.setBusy(true);
		var deferred = this.q.defer();

		// Get url parameters from mingle limeLanguage is a global javascript variable
		const language = this.context.getLanguage();
		lm.Log.debug("Parameter " + c.Constants.mingleLanguage + " set to :" + language);

		// Initialize language
		this.dataservice.setLanguage(language);

		if (c.ClientConfiguration.isDev()) {
			// Widget development mode
			this.isDev = true;
			this.initDev(deferred, loadStartPage);
			this.context.setBusy(false);
		} else {
			// Normal mode
			Locale.set(language).then((response: string) => {
				this.info("Locale successfully set to: " + response);

				//Class-based detection for IE
				if (navigator.userAgent.match(/Trident/)) {
					$('html').addClass('ie');
				}
				if (navigator.appVersion.indexOf('MSIE 9.0') > -1) {
					$('html').addClass('ie9');
				}
				if (navigator.appVersion.indexOf('MSIE 10.0') > -1) {
					$('html').addClass('ie10');
				} else {
					if (navigator.userAgent.match(/Trident\/7\./)) {
						$('html').addClass('ie11');
					}
				}

			}, () => {
				this.error("Failed to set Locale.");
			});

			c.ClientConfiguration.initialize(this.location);

			this.dataservice.executePost("/page/container", {}).then((response: IPageContainerResponse) => {
				this.onResponse(response, loadStartPage);
				this.context.setBusy(false);
				deferred.resolve(this.pageContainer);
			}, (response: c.IOperationResponse) => {
				this.context.setBusy(false);
				this.error("Failed to load pages: " + response);
				this.createErrorContainer("Failed to load page container");
				var errorTitle = this.language.errorUnavailable;
				var errorList = response.errorList;
				if (errorList && errorList.length && errorList[0].code === c.ResponseErrorCodes.forbidden) {
					errorTitle = this.language.errorUnauthorizedPage + " (403)";
				}
				var message = this.language.contactAdminRetry;
				if (response.errorHttpCode === c.ResponseErrorCodes.undefined.toString()) {
					message = this.language.errorSignOut;
				}
				this.dialogService.showMessage({ title: errorTitle, message: message });
				deferred.resolve(this.pageContainer);
			});
		}

		return deferred.promise;
	}

	private loadDevContainer(devPath: string, devData: c.DevConfigurationData): IPageContainerResponse {
		// TODO Add support for widget layout and other things that might be required for testing.
		var definition = devData.widgetDefinition;
		var id = definition.widgetId;
		var dev = c.ClientConfiguration.dev;
		var container = dev.load(id);

		var enableSettings = definition.enableSettings !== false;
		var enableTitleEdit = definition.enableTitleEdit !== false;
		definition.enableSettings = enableSettings;
		definition.enableSettingsDef = enableSettings;
		definition.enableTitleEdit = enableTitleEdit;
		definition.enableTitleEditDef = enableTitleEdit;

		dev.definition = definition;

		// Add configuration
		var configuration = devData.configuration;
		if (configuration) {
			container.configuration = devData.configuration;
		}

		(<any>container)["applicationSettings"] = [{ name: c.SettingsNames.enablePrivatePages, value: "true" },
			{ name: c.SettingsNames.maxUserPageCount, value: "5" }];

		// Get the English description for now, consider using client language in dev mode
		var language = definition["localization"]["en-US"];
		var title = language[lm.WidgetConstants.widgetTitle];
		definition.localization = language;

		var page: c.IPageData = null;
		var serverPage: c.IPage = null;
		if (container.pages) {
			// TODO Support more than one page
			serverPage = container.pages[0];
			serverPage.isEditable = true;
			page = serverPage.data;
		}

		if (page) {
			dev.initPage(page);

			var widgets = page.widgets;
			if (!widgets || widgets.length === 0) {
				page.widgets = widgets = [{}];
			}
			var widgetData = widgets[0];
			var customDefinition = devData.customDefinition;
			var useCustom = !!customDefinition;

			if (!widgetData.title) {
				widgetData.title = title;
			}

			widgetData.instanceId = lm.CommonUtil.random();
			if (widgetData.isTitleLocked !== false) {
				widgetData.isTitleLocked = true;
			}

			if (useCustom) {
				definition.isPublished = true;
				definition.standardWidgetId = id;
				id = lm.CommonUtil.random();
				definition.widgetId = id;
				definition.custom = customDefinition.custom;
				if (customDefinition.enableSettings === false) {
					definition.enableSettings = false;
				}
				if (customDefinition.enableTitleEdit === false) {
					definition.enableTitleEdit = false;
				}
			} else {
				// If a settings and data file is configured those should be used instead of the saved values - but only if the widget isn't customized
				if (devData.settings) {
					var devSettings = devData.settings["settings"];
					if (devSettings) {
						this.info("Using settings from " + devData.settingsPath + ". The stored settings in isolated storage will not be used.");
						widgetData.settings = devSettings;
					}
				}
			}

			// Set the widget ID which might have changed
			widgetData.id = id;

			if (!widgetData.layout) {
				widgetData.layout = new c.WidgetLayout(0, 0);
			}
		}

		var finalDefinition: c.IWidgetDefinition = {};
		angular.copy(definition, finalDefinition);

		var item = <c.IWidgetDefinitionItem>{
			definition: finalDefinition, standardTitle: title, catalogTitle: title, localization: language
		};

		finalDefinition.widgetId = id;
		finalDefinition.settings = definition.settings;
		finalDefinition.devPath = devPath;
		finalDefinition.lang = language;
		container.widgetDefinitions = [item];

		page.widgetRefs = [{
			id: id,
			byRef: !!finalDefinition.isPublished
		}];

		var response = <IPageContainerResponse>new c.OperationResponse();
		response.content = container;
		return response;
	}

	private initDev(deferred: ng.IDeferred<c.IPageContainer>, loadStartPage?: boolean) {
		lm.Log.setDebug();

		// TODO Better solution for changing the context root in dev mode?
		c.Constants.restRoot = "";
		var devData = c.ClientConfiguration.dev.devData;

		const promises = [];
		var widgetId = devData.widgetId;
		if (widgetId) {
			const definitionPath = widgetId + "/widget.manifest";
			promises.push(this.downloadFile(definitionPath, devData.propWidgetDefinition, devData));
		}
		if (devData.settingsPath) {
			promises.push(this.downloadFile(devData.settingsPath, devData.propSettings, devData));
		}
		if (devData.customDefinitionPath) {
			promises.push(this.downloadFile(devData.customDefinitionPath, devData.propCustomDefinition, devData));
		}
		if (devData.configurationPath) {
			promises.push(this.downloadFile(devData.configurationPath, devData.propConfiguration, devData));
		}

		const promise = this.q.all(promises);
		promise.then((result: any[]) => {
			this.onResponse(this.loadDevContainer(widgetId, devData), loadStartPage);
			deferred.resolve(this.pageContainer);
		}, (error: any[]) => {
			this.createErrorContainer("Failed to load page container of one of the configured attributes.");
			deferred.resolve(this.pageContainer);
		});
	}

	private downloadFile(path: string, propertyName: string, devObj: c.DevConfigurationData): ng.IPromise<any> {
		var uri = path + "?rid=" + lm.CommonUtil.random();
		var deferred = this.q.defer();
		this.http.get(uri).then(
			(response) => {
				devObj[propertyName] = response.data;
				deferred.resolve();
			},
			() => {
				this.error("Failed to download " + uri);
				deferred.resolve();
			}
		);
		return deferred.promise;
	}

	private createErrorContainer(message: string) {
		this.pageContainer = new PageContainer(this.context, null, this.pageService, this.dialogService, this.q, this.widgetService, this.language, this.progressService);
		this.pageContainer.errorMessage = message;
	}

	private onResponse(response: IPageContainerResponse, loadStartPage?: boolean): void {
		const containerData = response.content;
		if (containerData) {
			if (!this.isDev) {
				lm.Log.level = lm.ArrayUtil.itemByProperty(containerData.userSettings, "name", "LogLevel").value;
			}
			this.info("Loaded page container");

			this.dataservice.startPing(containerData.pingInterval);

			const definitions = containerData.widgetDefinitions;
			if (definitions) {
				for (let definition of definitions) {
					this.widgetService.addDefinitionItem(definition);
				}
			}

			// Set sort order from IPage to IPageData. 
			// This is a temporary change, the sortOrder property should be completely moved to IPage since IPageData is shared for published pages.
			const pages = containerData.pages;
			if (pages) {
				for (let page of pages) {
					const data = page.data;
					if (data) {
						data.sortOrder = page.sortOrder;
					}
				}
			}

			// Initialize context
			this.context.init(containerData, this.getContainerUrl());

			const container = new PageContainer(this.context, containerData, this.pageService, this.dialogService, this.q, this.widgetService, this.language, this.progressService, this.editModeService, loadStartPage);
			container.context.isDev = this.isDev;

			container.changed().on(() => {
				this.onChanged();
			});
			this.pageContainer = container;
		} else {
			const message = "Received empty page container";
			this.createErrorContainer(message);
			this.error(message);
		}
	}

	private getContainerUrl(): string {
		// Check the location for an xfo parameter from Ming.le
		// If that is set return it
		var xfoParameter = this.location.search().xfo;
		if (xfoParameter) {
			this.info("Using ContainerUrl " + xfoParameter);
			return xfoParameter;
		}
		// If no parameter is present use the homepages application
		var homepagesUrl = this.location.protocol() + "://" + this.location.host();
		// Not including port since I don't think that we will use it
		this.info("Using ContainerUrl" + homepagesUrl);
		return homepagesUrl;
	}

	private onChanged() {
		this.debug("Change detected");
	}

	static add(m: ng.IModule) {
		m.service("lmContainerService", ContainerService);
	}
}

interface IPageContainerResponse extends c.OperationResponse {
	content: c.IPageContainerData;
}

class PageService extends c.CoreBase implements c.IPageService {
	static $inject = ["$q", "lmDataService", "lmCacheService"];

	private pageListCache: c.IDataListCache;

	constructor(private q: ng.IQService, private dataService: c.IDataService, private cacheService: c.ICacheService) {
		super("[PageService] ");
		this.pageListCache = this.cacheService.createCache(c.Constants.clientCachePages);
	}

	static add(m: ng.IModule) {
		m.service("lmPageService", PageService);
	}

	createPrivate(page: c.IPageData): ng.IPromise<c.IPageResponse> {
		var request = { content: page };
		return this.dataService.executePost("/page/private/create", request);
	}

	update(page: c.IPageData): ng.IPromise<c.IOperationResponse> {
		if (c.ClientConfiguration.isDev()) {
			c.ClientConfiguration.dev.save();
			this.debug("Saved page in dev mode");
			return this.q.when({ content: "" });
		}

		var request = { content: page };
		return this.dataService.executePost("/page/update", request);
	}

	updateSettings(page: c.IPageData): ng.IPromise<c.IPageDataResponse> {
		var request = { content: page };
		return this.dataService.executePost("/page/settings/update", request);
	}

	delete(id: string): ng.IPromise<c.IOperationResponse> {
		this.pageListCache.isValid = false;
		var request = { content: id };
		return this.dataService.executePost("/page/delete", request);
	}

	getPublished(id: string): ng.IPromise<c.IPageResponse> {
		return this.dataService.executePost("/page/published", { content: id });
	}

	getPublishedExtended(pageId: string): ng.IPromise<c.IPageResponse> {
		return this.dataService.executePost("/page/published/extended", { content: pageId });
	}

	listPublished(reload: boolean): ng.IPromise<c.IPageListResponse> {
		var deferred: ng.IDeferred<c.IPageListResponse> = this.q.defer();
		if (!this.pageListCache.isValid || reload) {
			this.dataService.executePost("/page/published/list", {}).then((response: c.IPageListResponse) => {
				this.cacheService.updateCache(this.pageListCache, response, deferred);
			}, (response: c.IPageListResponse) => {
				this.pageListCache.isValid = false;
				deferred.reject(response);
			});
		} else {
			deferred.resolve(this.pageListCache.cachedResponse);
		}
		return deferred.promise;
	}

	updatePublished(page: c.IPage): ng.IPromise<c.IPageDataResponse> {
		this.pageListCache.isValid = false;
		return this.dataService.executePost("/page/published/update", { content: page });
	}

	deletePublished(pages: string[]): ng.IPromise<c.IIntegerResponse> {
		return this.dataService.executePost("/page/published/delete", { content: pages });
	}

	addConnection(id: string, asTemplate: boolean, sortOrder: number, templateTitle?: string): ng.IPromise<c.IPageResponse> {
		var request = { pageId: id, asTemplate: asTemplate, templateTitle: templateTitle, sortOrder: sortOrder };
		return this.dataService.executePost("/page/connection/add", request);
	}

	reorderConnections(pages: string[]): ng.IPromise<c.IOperationResponse> {
		return this.dataService.executePost("/page/connection/reorder", { content: pages });
	}

	updateConnectionSettings(pageId: string, settings: any): ng.IPromise<c.IOperationResponse> {
		var request = { content: { pageId: pageId, settings: settings } };
		return this.dataService.executePost("/page/connection/settings/update", request);
	}

	removeConnection(id: string): ng.IPromise<c.IOperationResponse> {
		return this.dataService.executePost("/page/connection/remove", { content: id });
	}

	/*
	 * Forwards errors to DataService error handler.
	 */
	handleError(response: c.IOperationResponse, message?: string) {
		this.dataService.handleError(response, message);
	}

	getPreview(pageId: string): ng.IPromise<c.IPageResponse> {
		return this.dataService.executePost("/page/published/preview", { content: pageId });
	}

	/**
	 * Invalidates the Page cache.
	 */
	invalidatePageCache(): void {
		if (this.pageListCache) {
			this.pageListCache.isValid = false;
		}
	}
}

class ContextService implements c.IContextService {
	private context: c.IContext;

	static $inject = ["$q", "$http", "lmProgressService", "lmDataService", "lmCommonDataService"];

	constructor(q: ng.IQService, http: ng.IHttpService, private progressService: c.IProgressService, dataservice: c.IDataService, commonDataService: c.ICommonDataService) {
		this.context = new Context(q, http, progressService, dataservice, commonDataService);
	}

	public getContext(): c.IContext {
		return this.context;
	}

	static add(m: ng.IModule) {
		m.service("lmContextService", ContextService);
	}
}

class EditModeService implements c.IEditModeService {
	private startedEvent = new c.InstanceEvent<c.IEditMode>();
	private stoppedEvent = new c.InstanceEvent<c.IEditMode>();
	private changedEvent = new c.InstanceEvent<c.IEditMode>();

	private modes: c.IEditMode[] = [];

	static $inject = ["$rootScope"];

	constructor(private rootScope: ng.IScope) {
	}

	private updateMode() {
		var mode = this.getCurrent();
		this.rootScope["lmEditMode"] = mode;
	}

	public start(options: c.IEditModeStartOptions): void {
		var mode = <c.IEditMode>options;
		mode.isActive = true;
		this.modes.push(mode);
		this.updateMode();
		this.startedEvent.raise(mode);
		this.changedEvent.raise(mode);
	}

	public isActive(): boolean {
		var current = this.getCurrent();
		return (current && current.isActive) === true;
	}

	public stop(options: c.IEditModeStopOptions): void {
		var mode = this.modes.pop();
		if (mode) {
			mode.isSave = options.isSave;
			mode.result = options.result;
			this.updateMode();
			this.stoppedEvent.raise(mode);
			this.changedEvent.raise(mode);
		}
	}

	public isMode(mode: string): boolean {
		var current = this.getCurrent();
		return (current && current.mode == mode) === true;
	}

	public containsMode(mode: string): boolean {
		// Check if the mode exists anywhere in the mode stack
		var modes = this.modes;
		for (var i = 0; i < modes.length; i++) {
			if (modes[i].mode == mode) {
				return true;
			}
		}
		return false;
	}

	public getCurrent(): c.IEditMode {
		return this.modes.length > 0 ? this.modes[this.modes.length - 1] : null;
	}

	public started(): c.IInstanceEvent<c.IEditMode> {
		return this.startedEvent;
	}

	public stopped(): c.IInstanceEvent<c.IEditMode> {
		return this.stoppedEvent;
	}

	public changed(): c.IInstanceEvent<c.IEditMode> {
		return this.changedEvent;
	}

	static add(m: ng.IModule) {
		m.service("lmEditModeService", EditModeService);
	}
}

class ContentImportCtrl extends c.CoreBase {
	public acceptFileExtension: string;

	private dialog: lm.IDialog = null;
	private options: c.IImportOptions;

	static $inject = ["$scope", "lmDataService"];

	constructor(public scope: any, private dataService: c.IDataService) {
		super("[ContentImportCtrl] ");

		const dialog: lm.IDialog = scope["lmDialog"];
		if (!dialog) {
			this.error("lmDialog is not found in scope when opening admin import dialog");
			return;
		}

		const dialogParam = dialog.parameter;

		this.options = dialogParam;
		this.acceptFileExtension = dialogParam.acceptFileExtension || ".zip";
		this.dialog = dialog;
	}

	public close(): void {
		this.dialog.close({ button: lm.DialogButtonType.Cancel });
	}

	public import(files: any): void {
		if (!files) {
			this.debug("No file was selected");
			return;
		}
		const dialog = this.dialog;

		this.dataService.upload(this.options.url, this.options.operation, files).then((response: c.IOperationResponse) => {
			dialog.close({ button: lm.DialogButtonType.Yes, value: { message: response, responseCode: c.DialogResponseCode.Success } });
		}, (r: c.IOperationResponse) => {
			let errorMsg = "";
			if (r.errorList) {
				angular.forEach(r.errorList, (error) => {
					errorMsg += error.message;
				});
			}
			dialog.close({ button: lm.DialogButtonType.Yes, value: { message: errorMsg, responseCode: c.DialogResponseCode.Fail } });
		});
	}

	static add(m: ng.IModule) {
		m.controller("lmContentImportCtrl", ContentImportCtrl);
	}
}

export var init = (m: ng.IModule) => {
	ContextService.add(m);
	PageService.add(m);
	ContainerService.add(m);
	PageNavigatorCtrl.add(m);
	PageContainerCtrl.add(m);
	PageNavigatorDirective.add(m);
	PageDirective.add(m);
	PageContainerDirective.add(m);
	ContentImportCtrl.add(m);
	EditModeService.add(m);
};