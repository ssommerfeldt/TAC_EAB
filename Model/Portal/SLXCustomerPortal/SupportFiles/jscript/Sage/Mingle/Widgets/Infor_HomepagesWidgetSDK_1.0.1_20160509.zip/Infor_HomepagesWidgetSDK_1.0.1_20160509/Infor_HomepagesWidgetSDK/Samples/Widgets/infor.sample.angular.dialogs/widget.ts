﻿import lm = require("lime");

class CustomDialogCtrl {
	static $inject = ["$scope"];

	private dialog: lm.IDialog;
	private dialogParameter: string;
	private dialogResult: string = "Sample dialog result";


	constructor(public scope: ng.IScope) {
		this.dialog = scope["lmDialog"];
		this.dialogParameter = <string>this.dialog.parameter;
	}

	private onOk(): void {
		this.dialog.close({ value: this.dialogResult });
	}

	private onCancel(): void {
		this.dialog.close();
	}
}

class DialogsCtrl {
	private widgetContext: lm.IWidgetContext;
	private instance: lm.IWidgetInstance;

	static $inject = ["$scope", "lmDialogService"];

    constructor(public scope: ng.IScope, private dialogService: lm.IDialogService) {
		this.widgetContext = scope[lm.WidgetConstants.widgetContextKey];
		this.instance = scope[lm.WidgetConstants.widgetInstanceKey];
	}

	private showMessage(): void {
		this.dialogService.showMessage({
			title: "A sample title",
			message: "A sample message",
		});
	}

	private showConfirm(): void {
		this.dialogService.showMessage({
			title: "Confirm",
			message: "Are you sure?",
			standardButtons: lm.StandardDialogButtons.YesNo
		}).then((result: lm.IDialogResult) => {
			var message, title;
			if (result.button === lm.DialogButtonType.Yes) {
				title = "Confirmed";
				message = "You are sure.";
			} else {
				title = "Not confirmed";
				message = "You are not sure.";
			}
			this.dialogService.showMessage({
				title: title,
				message: message
			});
		});
	}

	private showToast(): void {
		this.dialogService.showToast({
			title: "A sample toast title",
			message: "A sample toast message"
		});
	}

	private showCustom(): void {
		var templateUrl = this.widgetContext.getAngularContext().getTemplateUrl("dialog.html");
		this.dialogService.show({
			title: "A custom dialog title",
			parameter: "A sample custom dialog parameter",
			templateUrl: templateUrl
		}).then((result: lm.IDialogResult) => {
			var message = result.value || "Dialog cancelled";
			this.dialogService.showMessage({
				title: "Result",
				message: message
			});
		});
	}
}

export var widgetFactory = (context: lm.IWidgetContext): lm.IWidgetInstance => {
	var m = context.getAngularContext().module;
	
	// Register the controller
	m.controller("sample.DialogsCtrl", DialogsCtrl);
	m.controller("sample.CustomDialogCtrl", CustomDialogCtrl);

	// Return the angular configuration the widget.html will contain a controller
	return {
		angularConfig: {
			relativeTemplateUrl: "widget.html"
		}
	};
};