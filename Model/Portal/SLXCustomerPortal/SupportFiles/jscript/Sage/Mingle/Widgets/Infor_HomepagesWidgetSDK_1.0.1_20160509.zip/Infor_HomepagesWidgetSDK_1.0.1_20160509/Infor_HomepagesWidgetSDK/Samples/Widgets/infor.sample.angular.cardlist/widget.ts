﻿/// <reference path="../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../scripts/typings/lime/lime.d.ts" />

import lm = require("lime");

export interface ISampleWidgetService {
	test(): string;
}

class CardlistCtrl {
	static $inject = ["$scope"];
	private reverseKey = "reverse";
	private widgetContext: lm.IWidgetContext;
	private instance: lm.IWidgetInstance;
	private logPrefix = "[CardlistCtrl] ";

	public items = [
		{
			isError: true,
			title: "Stock level 31-22",
			description: "Stocklevel has reached 100 items"
		},
		{
			title: "Customer returns",
			description: "Customer returns has increased with 10%"
		},
		{
			title: "Customer approved",
			description: "Customer Hulk Holding has been approved."
		},
		{
			title: "Stock level Chair-3",
			description: "WHLO 200 has 500 items"
		},
		{
			title: "Planned machine maintenance",
			description: "Planned time"
		}
	];

	constructor(public scope: ng.IScope) {
		// Get the widget context from the scope
		this.widgetContext = scope[lm.WidgetConstants.widgetContextKey];
		if (!this.widgetContext) {
			lm.Log.error(this.logPrefix + "No widget context is found");
			return;
		}
		// Get the instance from the scope
		this.instance = scope[lm.WidgetConstants.widgetInstanceKey];
		if (!this.instance) {
			lm.Log.error(this.logPrefix + "No instance is found");
			return;
		}
		var settings = this.widgetContext.getSettings();
		var reverseSetting = settings.getString(this.reverseKey, null);
		if (reverseSetting == null) {
			// Store the default setting
			reverseSetting = "false";
			settings.set(this.reverseKey, reverseSetting);
		}
		var reverse = false;
		if (reverseSetting.toLowerCase() === "true") {
			reverse = true;
		}

		scope[this.reverseKey] = reverse;
		scope["model"] = this;

		this.instance.settingsOpening = (options: lm.IWidgetSettingsArg) => {
			lm.Log.debug(this.logPrefix + "settingsOpening");
		};

		this.instance.getMetadata = () => {
			return this.createMetadata();
		}

		this.instance.settingsSaved = () => {
			// Handle when settings are saved to update internal state
			var reverseSettings = this.widgetContext.getSettings().getString(this.reverseKey, "false");
			scope[this.reverseKey] = reverseSettings === "true";
		}
	}

	createMetadata(): lm.IWidgetSettingMetadata[] {
		// Dynamically create meta data for the metadata controlled settings UI
		var metadata: lm.IWidgetSettingMetadata[] = [];
		var widgetSetting: lm.IWidgetSettingMetadata = { labelId: "order", type: lm.WidgetSettingsType.selectorType, name: this.reverseKey, defaultValue: "false" };
		widgetSetting.values = [{ textId: "ascending", value: "false" }, { textId: "descending", value: "true" }];
		metadata.push(widgetSetting);
		return metadata;
	}

	public static add(m: ng.IModule) {

	}
}

export var widgetFactory = (context: lm.IWidgetContext): lm.IWidgetInstance => {

	var m = context.getAngularContext().module;
	// Register the controller
	m.controller("sample.CardlistCtrl", CardlistCtrl);

	// Return the angular configuration the widget.html will contain a controller
	return {
		angularConfig: {
			relativeTemplateUrl: "widget.html"
		}
	};
};