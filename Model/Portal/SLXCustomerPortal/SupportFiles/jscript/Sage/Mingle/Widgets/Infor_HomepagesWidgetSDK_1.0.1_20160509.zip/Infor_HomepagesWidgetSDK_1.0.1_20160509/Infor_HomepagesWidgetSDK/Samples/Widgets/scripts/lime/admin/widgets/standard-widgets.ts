﻿import lm = require("../../lime");
import c = require("../../core");
import s = require("../service");

class AdminStandardWidgetsCtrl extends c.CoreBase {
	public standardWidgets: c.IWidgetInfo[] = [];
	public noOfSelected: number;
	public accessCopy: s.IWidgetAccess[];
	public widgetsGridOptions: any;
	public refreshText = "Refresh";

	private accessCopyWidgetId: string;

	static $inject = ["$scope", "lmAdminService", "lmDialogService", "lmWidgetService", "uiGridConstants"];

	constructor(public scope: ng.IScope, private adminService: s.IAdminService, private dialogService: lm.IDialogService, private widgetService: c.IWidgetService,
		private uiGridConstants: any) {
		super("[AdminStandardWidgetsCtrl] ");

		this.initGrid();
		const adminConstants = s.AdminConstants;
		// Watch to see if this tab is selected
		const self = this;
		scope.$watch(adminConstants.openTab, (tab) => {
			if (tab === adminConstants.standardWidgetsTab) {
				self.listStandardWidgets(false);
			}
		});
	}

	/**
	* List Standard Widgets
	*
	* Lists standard widgets from cache or server.
	*
	* @params reload Boolean - True: load from server. False: load from cache.
	* @params callback Function to be called when widgets are loaded from cache/server.
	*/
	public listStandardWidgets(reload: boolean): void {
		const self = this;
		const adminService = self.adminService;

		if (reload) {
			this.noOfSelected = 0;
			if (this.scope["widgetsGridApi"]) {
				this.scope["widgetsGridApi"].selection.clearSelectedRows();
			}
		}

		adminService.setBusy(true);
		adminService.listStandardWidgets(reload).then((r: c.IWidgetListResponse) => {
			const standardWidgets = r.content;
			self.standardWidgets = standardWidgets;
			self.widgetsGridOptions.data = standardWidgets;
			adminService.setBusy(false);
		}, (r: c.IOperationResponse) => {
			adminService.handleError(r);
			adminService.setBusy(false);
		});
	}

	/**
	* Open Widget Access Dialog
	*
	* Opens widget access dialog. Used as an option in grid action menu.
	*/
	public openWidgetAccessDialog(widget: c.IWidgetInfo): void {
		this.adminService.openWidgetAccessDialog(widget, (resp: c.IWidgetInfoResponse) => {
			if (resp && resp.content) {
				this.updateAfterWidgetAccessUpdate(resp.content);
				this.setBusy(false);
			} else {
				this.onError(resp);
			}
		});
	}

	private updateAfterWidgetAccessUpdate(widgetInfo: c.IWidgetInfo): void {
		// Locate and update the widget in the list
		var existing = lm.ArrayUtil.find(this.standardWidgets, (info) => info.widgetId === widgetInfo.widgetId);
		if (existing) {
			existing.hasAccess = widgetInfo.hasAccess;
			existing.hasRestrictions = widgetInfo.hasRestrictions;
		}
	}

	private setBusy(isBusy: boolean): void {
		this.adminService.setBusy(isBusy);
	}

	private onError(error: any): void {
		this.adminService.handleError(error);
		this.setBusy(false);
	}

	/**
	* Copy widget access.
	*
	* Copy access rights of a widget. Used as an option in grid action menu.
	*
	* @params widget Widget to copy access from.
	*/
	public copyAccess(widget: c.IWidgetInfo): void {
		const self = this;
		const adminService = self.adminService;

		adminService.setBusy(true);
		adminService.getWidgetAccess({ id: widget.widgetId, accessList: [] }).then((r: c.IOperationResponse) => {
			self.accessCopy = r.content.accessList;
			self.accessCopyWidgetId = widget.widgetId;
			adminService.setBusy(false);
		}, (r: c.IOperationResponse) => {
			self.adminService.handleError(r);
			adminService.setBusy(false);
		});
	}

	/**
	* Apply Access Copy
	*
	* Apply copied acces rights to selected widget(s).
	*
	* @params widget to edit. Otherwise use selected widgets in grid.
	*/
	public applyAccessCopy(widget?: c.IWidgetInfo): void {
		const widgetsToUpdate = widget ? [widget] : this.getSelectedRows();
		this.adminService.applyWidgetAccess(widgetsToUpdate, this.accessCopy, () => { this.listStandardWidgets(true); });
	}

	/**
	* Clear Or Replace With Access Copy
	*
	* If indicated with "isReplace", replaces access rights.
	* Otherwise clear access rights of selected widgets.
	*
	* @params isReplace Boolean, true: replace, false: clear.
	*/
	public clearOrReplaceWithAccessCopy(isReplace?: boolean, widget?: c.IWidgetInfo): void {
		const widgetsToUpdate = widget ? [widget] : this.getSelectedRows();
		this.adminService.clearOrReplaceWidgetAccess(widgetsToUpdate, isReplace, () => { this.listStandardWidgets(true); }, this.accessCopy);
	}

	/**
	* Init Grid
	*
	* Initialize the grid.
	*/
	private initGrid(): void {
		const gridConstants = this.uiGridConstants;
		const adminConstants = s.AdminConstants;
		const widgetActionTemplate = '<div class="ui-grid-cell-contents lm-center-text"><button type="button" ng-click="$event.stopPropagation();" class="btn-actions lm-transparent" xi-popupmenu="grid.appScope.ctrl.menuOptions"><span class="audible">Actions</span>' +
			'<svg class="icon" focusable="false" aria-hidden="false"><use xlink:href="#icon-more"/></svg></button><ul class="popupmenu actions top"><li><a ng-click="grid.appScope.ctrl.openWidgetAccessDialog(row.entity)">Edit Permissions</a></li>' +
			'<li ng-show="row.entity.hasAccess"><a ng-click="grid.appScope.ctrl.copyAccess(row.entity)">Copy Permissions</a></li><li ng-show="grid.appScope.ctrl.accessCopy && grid.appScope.ctrl.accessCopyWidgetId !== row.entity.widgetId" class="separator"></li>' +
			'<li ng-show="grid.appScope.ctrl.accessCopy && grid.appScope.ctrl.accessCopyWidgetId !== row.entity.widgetId"><a ng-click="grid.appScope.ctrl.applyAccessCopy(row.entity)">Apply Copied Permissions</a></li><li ng-show="grid.appScope.ctrl.accessCopyWidgetId && grid.appScope.ctrl.accessCopyWidgetId !== row.entity.widgetId && row.entity.hasAccess">' +
			'<a ng-click="grid.appScope.ctrl.clearOrReplaceWithAccessCopy(true, row.entity)">Replace Copied Permissions</a></li><li ng-show="row.entity.hasAccess" class="separator"></li>' +
			'<li ng-show="row.entity.hasAccess"><a ng-click="grid.appScope.ctrl.clearOrReplaceWithAccessCopy(false, row.entity)">Clear Permissions</a></li></ul></div>';

		const self = this;
		this.widgetsGridOptions = {
			paginationPageSizes: [adminConstants.gridPageSize],
			paginationPageSize: adminConstants.gridPageSize,
			columnDefs: [{
				field: "title",
				name: "Title",
				sort: { direction: gridConstants.ASC, priority: 1 },
				filter: { condition: gridConstants.filter.CONTAINS },
				minWidth: 50, maxWidth: 600
			},
				{ field: "description", name: "Description", minWidth: 50, maxWidth: 600 },
				{ field: "widgetId", name: "WidgetId", displayName: "Widget id", minWidth: 50, maxWidth: 600 },
				{
					field: "changeDate", name: "ChangeDate", displayName: "Change date",
					cellTemplate: "<div class='ui-grid-cell-contents'>{{COL_FIELD | lmLocaleDate}}</div>", minWidth: 50, maxWidth: 600
				},
				{ field: "changedByName", name: "ChangeBy", displayName: "Changed by", minWidth: 50, maxWidth: 600 },
				{
					field: "hasRestrictions", name: "Permissions", enableFiltering: false, maxWidth: 140,
					cellTemplate: "<div class='ui-grid-cell-contents'>{{COL_FIELD ? 'Restricted' : ''}}</div>",
					enableColumnResizing: false
				},
				{ field: "actions", name: "Actions", maxWidth: 110, cellTemplate: widgetActionTemplate, enableFiltering: false, enableSorting: false, enableColumnResizing: false }],
			data: [],
			rowHeight: 48,
			enableFiltering: true,
			enableSorting: true,
			enableColumnMenus: false,
			onRegisterApi: (gridApi) => {
				self.scope["widgetsGridApi"] = gridApi;
				self.noOfSelected = 0;
				const gridSelection = gridApi.selection;
				const onSelection = gridSelection.on;

				onSelection.rowSelectionChanged(self.scope, () => {
					self.noOfSelected = gridSelection.getSelectedRows().length;
				});
				onSelection.rowSelectionChangedBatch(self.scope, () => {
					self.noOfSelected = gridSelection.getSelectedRows().length;
				});
			}
		}
	}

	private getSelectedRows(): c.IWidgetInfo[] {
		return this.scope["widgetsGridApi"].selection.getSelectedRows();
	}

	static add(m: ng.IModule) {
		m.controller("lmAdminStandardWidgetsCtrl", AdminStandardWidgetsCtrl);
	}
}

export var init = (m: ng.IModule) => {
	AdminStandardWidgetsCtrl.add(m);
}