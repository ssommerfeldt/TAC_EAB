define(["require", "exports", "angular", "./lime", "./core", "./app/container", "./app/container-edit", "./service", "./app/widget", "./app/page", "./components/common", "./page-library/page-library", "./widget-library/widget-library", "./translations/translations", "./role-access/role-access", "./templates/template-cache", "./mingle"], function (require, exports, angular, lm, core, container, containerEdit, service, widget, page, common, pageLibrary, widgetLibrary, translations, roleAccess, tc, mingle) {
    var configureModule = function (m) {
        m.config([
            "$controllerProvider", "$provide", "$compileProvider", "$locationProvider", function ($controllerProvider, $provide, $compileProvider, $locationProvider) {
                m.controller = $controllerProvider.register;
                m.service = $provide.service;
                m.directive = $compileProvider.directive;
                $locationProvider.html5Mode({
                    enabled: true,
                    requireBase: false
                });
            }
        ]);
    };
    var configureCaching = function (m) {
        m.run([
            "$location", "$templateCache", function ($location, $templateCache) {
                tc.TemplateCacher.cache($location, $templateCache);
            }
        ]);
    };
    var externalModule = angular.module("lime", ["ui.sortable", "sohoxi"]);
    configureModule(externalModule);
    var internalModule = angular.module("lime.internal", ["ui.sortable", "sohoxi", "mingle.services", "mingle.factories", "lime"]);
    configureModule(internalModule);
    configureCaching(internalModule);
    mingle.init(internalModule);
    var version = "1.0.1";
    infor.lime.version = version;
    lm.Log.info("[Lime] Framework version " + version);
    core.init(externalModule);
    service.init(externalModule, internalModule);
    widget.init(externalModule, internalModule);
    page.init(internalModule);
    container.init(internalModule);
    containerEdit.init(internalModule);
    common.init(internalModule);
    pageLibrary.init(internalModule);
    widgetLibrary.init(internalModule);
    translations.init(internalModule);
    roleAccess.init(internalModule);
    return internalModule;
});
//# sourceMappingURL=module.js.map