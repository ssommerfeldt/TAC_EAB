﻿import lm = require("../../lime");
import c = require("../../core");
import s = require("../service");

class AddEditPropertyCtrl extends c.CoreBase {
	private property: s.IPropertyInfo;
	private maskOptions: xi.IMaskOptions;
	private isEdit: boolean;
	private addEditBtnLabel: string;
	private dialog: lm.IDialog;
	private invalidNames: string[];

	static $inject = ["$scope", "lmDialogService"];

	constructor(public scope: ng.IScope, private dialogService: lm.IDialogService) {
		super("[AddEditPropertyCtrl] ");
		var dialog = scope["lmDialog"];
		var dialogParameter = dialog.parameter;
		this.dialog = dialog;
		this.property = angular.copy(dialogParameter.property);
		this.isEdit = angular.copy(dialogParameter.isEdit);
		this.addEditBtnLabel = this.isEdit ? "Save" : "Add";

		this.invalidNames = ["productname", "version", "logicalid", "hostname", "context", "port", "usehttps", "tenantid"];
		this.maskOptions = {
			definitions: {
				'i': /[a-z0-9\.\_]/
			},
			pattern: "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii" // max-length 64. 
		}
	}

	private onCancel(): void {
		var result: lm.IDialogResult = {
			button: lm.DialogButtonType.Cancel,
			value: null
		};
		this.dialog.close(result);
	}

	private onOk(): void {
		if (this.isNameValid()) {
			var result: lm.IDialogResult = {
				button: lm.DialogButtonType.Ok,
				value: this.property
			};
			this.dialog.close(result);
		} else {
			this.showInvalidDialog();
		}
	}

	private isNameValid(): boolean {
		if (lm.ArrayUtil.contains(this.invalidNames, this.property.propertyId.toLowerCase())) {
			return false;
		} else {
			return true;
		}
	}

	private showInvalidDialog(): void {
		var options: lm.IMessageDialogOptions = {
			title: "Invalid name",
			message: "The property name '" + this.property.propertyId + "' is not valid.",
			isError: true
		};
		this.dialogService.showMessage(options);
	}

	public static add(m: ng.IModule) {
		m.controller("lmAddEditPropertyCtrl", AddEditPropertyCtrl);
	}
}

export var init = (m: ng.IModule) => {
	AddEditPropertyCtrl.add(m);
}