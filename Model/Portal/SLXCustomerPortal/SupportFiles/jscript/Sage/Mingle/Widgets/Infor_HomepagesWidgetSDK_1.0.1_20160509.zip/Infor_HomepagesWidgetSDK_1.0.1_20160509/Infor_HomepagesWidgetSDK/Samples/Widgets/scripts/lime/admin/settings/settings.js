var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../lime", "../../core", "../service"], function (require, exports, lm, c, s) {
    var AdminSettingsCtrl = (function (_super) {
        __extends(AdminSettingsCtrl, _super);
        function AdminSettingsCtrl(rootScope, scope, q, filter, adminContext, adminService, dialogService, progressService, uiGridConstants) {
            _super.call(this, "[AdminSettingsCtrl] ");
            this.rootScope = rootScope;
            this.scope = scope;
            this.q = q;
            this.filter = filter;
            this.adminContext = adminContext;
            this.adminService = adminService;
            this.dialogService = dialogService;
            this.progressService = progressService;
            this.uiGridConstants = uiGridConstants;
            this.settingIsChanged = false;
            this.ruleIsChanged = false;
            this.refreshText = "Refresh";
            this.chosenSetting = null;
            this.chosenRule = null;
            this.settingsWithChangedRules = [];
            this.changeRuleErrorOccurred = false;
            this.initGrids();
            var constants = c.Constants;
            var areas = [
                { name: "All", value: constants.allArea },
                { name: "Common", value: constants.commonArea },
                { name: "Page", value: constants.pageArea },
                { name: "Widget", value: constants.widgetArea }
            ];
            this.selectedArea = areas[0];
            this.areas = areas;
            this.selectArea();
            var self = this;
            var unsubscribeTool = rootScope.$watch("lmAdminTool", function (tool) {
                if (tool) {
                    self.init(tool);
                    unsubscribeTool();
                }
            });
            var adminConstants = s.AdminConstants;
            var unsubscribe = adminService.onCachesInvalidated().on(function (e) {
                var unsubscribeTab = scope.$watch(adminConstants.openTab, function (tab) {
                    if (tab === adminConstants.settingsTab && e[adminConstants.parameterIncludeSettings] === true) {
                        self.reload();
                        unsubscribeTab();
                    }
                });
            });
            scope.$on("$destroy", function () {
                unsubscribe();
            });
        }
        AdminSettingsCtrl.prototype.reload = function () {
            var _this = this;
            var adminService = this.adminService;
            adminService.setBusy(true);
            this.adminContext.initialize().then(function (r) {
                _this.settingIsChanged = false;
                _this.ruleIsChanged = false;
                _this.settingsWithChangedRules = [];
                _this.init(r.content);
                adminService.setBusy(false);
            }, function (r) {
                adminService.setBusy(false);
                adminService.handleError(r);
            });
        };
        AdminSettingsCtrl.prototype.selectArea = function (selectedArea) {
            var filter = this.filter;
            var items = this.items;
            if (selectedArea) {
                this.selectedArea = selectedArea;
            }
            var area = this.selectedArea["value"];
            if (area === c.Constants.allArea) {
                this.settingsGridOptions.data = filter("lmSettingsVisibility")(filter("lmSettingsArea")(items, null));
            }
            else {
                this.settingsGridOptions.data = filter("lmSettingsVisibility")(filter("lmSettingsArea")(items, area));
            }
        };
        AdminSettingsCtrl.prototype.save = function () {
            var _this = this;
            var options = {
                title: "Save",
                templateUrl: "scripts/lime/admin/templates/setting-save.html",
                cssClass: "e2e-saveSettingDialog"
            };
            var self = this;
            this.dialogService.show(options).then(function (r) {
                if (r.button === lm.DialogButtonType.Ok) {
                    self.setBusy(true);
                    self.reconstructSettings();
                    if (self.ruleIsChanged) {
                        var settingsWithChangedRules = self.settingsWithChangedRules;
                        var nrOfSettingsWithChangedRules = settingsWithChangedRules.length;
                        angular.forEach(settingsWithChangedRules, function (itemId) {
                            var item = _this.itemByProp(self.items, "settingName", itemId);
                            item.setting.rules = item.rules;
                            self.adminService.updateSettingRules(item.setting).then(function (result) {
                                var savedSetting = result.content;
                                var settingToUpdate = _this.itemByProp(self.adminTool.settings, "settingName", savedSetting.settingName);
                                settingToUpdate.rules = savedSetting.rules;
                                nrOfSettingsWithChangedRules -= 1;
                                if (nrOfSettingsWithChangedRules === 0) {
                                    settingsWithChangedRules = [];
                                    self.ruleIsChanged = false;
                                    if (!self.settingIsChanged) {
                                        self.init(self.adminTool);
                                        self.setBusy(false);
                                    }
                                    else {
                                        _this.updateSettings();
                                    }
                                }
                            }, function (result) {
                                self.showErrorMessage(result);
                            });
                        });
                        self.settingsWithChangedRules = [];
                    }
                    if (self.settingIsChanged && !self.ruleIsChanged) {
                        _this.updateSettings();
                    }
                }
            });
        };
        AdminSettingsCtrl.prototype.discard = function () {
            var options = {
                title: "Discard",
                templateUrl: "scripts/lime/admin/templates/setting-discard.html"
            };
            var self = this;
            this.dialogService.show(options).then(function (r) {
                if (r.button === lm.DialogButtonType.Ok) {
                    self.settingIsChanged = false;
                    self.ruleIsChanged = false;
                    self.settingsWithChangedRules = [];
                    self.init(self.adminTool);
                }
            });
        };
        AdminSettingsCtrl.prototype.addOrEditRule = function (rule) {
            var _this = this;
            var chosenSetting = this.chosenSetting;
            var settingName = chosenSetting.setting.settingName;
            var settingNames = c.SettingsNames;
            var dialogParam = {
                setting: chosenSetting,
                rule: undefined,
                userName: this.adminTool.userName,
                pages: null,
            };
            var dialogTitle = "Add Rule";
            if (!lm.CommonUtil.isUndefined(rule)) {
                dialogParam.rule = rule;
                dialogTitle = "Edit Rule";
            }
            var options = {
                title: dialogTitle,
                templateUrl: "scripts/lime/admin/templates/setting-add-edit-rule.html",
                parameter: dialogParam,
                style: "width: 750px; min-height: 400px;"
            };
            if (settingName === settingNames.defaultPage ||
                settingName === settingNames.mandatoryPages ||
                settingName === settingNames.startPage) {
                this.getPages().then(function (r) {
                    options.parameter.pages = r;
                    _this.openAddEditRuleDialog(options);
                });
            }
            else {
                this.openAddEditRuleDialog(options);
            }
        };
        AdminSettingsCtrl.prototype.openAddRuleConnection = function (isUser) {
            var _this = this;
            var dialogParam = {
                rule: this.chosenRule,
                userName: this.adminTool.userName,
                isUser: isUser
            };
            var options = {
                title: isUser ? "Add User" : "Add Role",
                templateUrl: "scripts/lime/admin/templates/rule-add-connection.html",
                parameter: dialogParam,
                style: "min-height: 400px;"
            };
            var self = this;
            this.dialogService.show(options).then(function (r) {
                if (r.button === lm.DialogButtonType.Ok && r.value) {
                    var updateItem = _this.itemByProp(self.items, "settingName", self.chosenSetting.settingName);
                    var updateItemRules = updateItem.rules;
                    var updateRuleIndex = _this.indexByProp(updateItemRules, "sortOrder", r.value.rule.sortOrder);
                    updateItemRules[updateRuleIndex] = r.value.rule;
                    if (self.settingsWithChangedRules.indexOf(updateItem.settingName) === -1) {
                        self.settingsWithChangedRules.push(updateItem.settingName);
                    }
                    self.ruleIsChanged = true;
                    _this.listConnections(updateItemRules[updateRuleIndex]);
                }
            });
        };
        AdminSettingsCtrl.prototype.deleteConnections = function () {
            var _this = this;
            var connections = this.scope["connectionsGridApi"].selection.getSelectedRows();
            var chosenSettingName = this.chosenSetting.settingName;
            var updateItem = this.itemByProp(this.items, "settingName", chosenSettingName);
            var updateItemRules = updateItem.rules;
            var updateRuleIndex = this.indexByProp(updateItemRules, "sortOrder", this.chosenRule.sortOrder);
            angular.forEach(connections, function (connection) {
                var connectionIndex = _this.indexByProp(updateItemRules[updateRuleIndex].ruleConnections, "name", connection.name);
                updateItemRules[updateRuleIndex].ruleConnections.splice(connectionIndex, 1);
            });
            if (this.settingsWithChangedRules.indexOf(chosenSettingName) === -1) {
                this.settingsWithChangedRules.push(chosenSettingName);
            }
            this.ruleIsChanged = true;
            this.listConnections(updateItemRules[updateRuleIndex]);
        };
        AdminSettingsCtrl.prototype.deleteRules = function (singleRule) {
            var _this = this;
            var rules = singleRule ? [singleRule] : this.scope["rulesGridApi"].selection.getSelectedRows();
            var chosenSetting = this.chosenSetting;
            var chosenSettingRules = chosenSetting.rules;
            var self = this;
            angular.forEach(rules, function (rule) {
                var ruleIndex = self.indexByProp(chosenSettingRules, "sortOrder", rule.sortOrder);
                chosenSettingRules.splice(ruleIndex, 1);
            });
            chosenSettingRules = lm.ArrayUtil.sortByProperty(chosenSettingRules, "sortOrder");
            chosenSettingRules.forEach(function (rule, index) {
                if (rule.sortOrder !== index + 1) {
                    rule.isChanged = true;
                    rule.displayChangeDate = _this.getLocalChangeDate();
                    rule.changedByName = _this.adminTool.userName;
                }
                rule.sortOrder = index + 1;
            });
            if (this.settingsWithChangedRules.indexOf(chosenSetting.settingName) === -1) {
                this.settingsWithChangedRules.push(chosenSetting.settingName);
            }
            chosenSetting.noOfRules = chosenSettingRules.length;
            this.listRules();
            this.ruleIsChanged = true;
        };
        AdminSettingsCtrl.prototype.initGrids = function () {
            var settingNameTemplate = '<div class= "ui-grid-cell-contents"><a class="hyperlink e2e-{{row.entity.settingName}}-drilldown" ng-click="grid.appScope.ctrl.listRules(row.entity)">{{COL_FIELD}}</a></div>';
            var settingValueTemplate = '<div class="ui-grid-cell-contents e2e-{{row.entity.settingName}}-value">{{COL_FIELD}}</div>';
            var settingActionBtnTemplate = '<div class="ui-grid-cell-contents lm-center-text"><button type="button" ng-click="grid.appScope.ctrl.chosenSetting = row.entity; $event.stopPropagation();" class="btn-actions lm-transparent e2e-{{row.entity.settingName}}-actions" xi-popupmenu="grid.appScope.ctrl.menuOptions"="grid.appScope.ctrl.menuOptions"="grid.appScope.ctrl.menuOptions"><span class="audible">Actions</span>' +
                '<svg class="icon" focusable="false" aria-hidden="false"><use xlink:href="#icon-more"/></svg></button>' +
                '<ul class="popupmenu actions top"><li class="e2e-{{row.entity.settingName}}-actions-edit"><a ng-click="grid.appScope.ctrl.setSettingsValue()">Edit</a></li><li class="e2e-{{row.entity.settingName}}-actions-add"><a ng-click="grid.appScope.ctrl.addOrEditRule()">Add Rule</a></li></ul></div>';
            var settingRuleCountTemplate = '<div class= "ui-grid-cell-contents e2e-{{row.entity.settingName}}-ruleCount">{{COL_FIELD}}</div>';
            var gridConstants = this.uiGridConstants;
            this.settingsGridOptions = {
                columnDefs: [
                    {
                        field: "setting.label",
                        name: "SettingName",
                        displayName: "Setting name",
                        sort: { direction: gridConstants.ASC, priority: 1 },
                        filter: { condition: gridConstants.filter.CONTAINS },
                        cellTemplate: settingNameTemplate,
                        width: 325
                    },
                    { field: "displayValue", name: "Value", enableFiltering: false, cellTemplate: settingValueTemplate },
                    { field: "changeDate", name: "ChangeDate", displayName: "Change date" },
                    { field: "changedByName", name: "ChangedBy", displayName: "Changed by" },
                    { field: "noOfRules", name: "Rules", maxWidth: 100, cellTemplate: settingRuleCountTemplate },
                    { field: "actions", name: "Actions", maxWidth: 110, cellTemplate: settingActionBtnTemplate, enableFiltering: false, enableSorting: false }],
                data: [],
                rowHeight: 48,
                enableColumnMenus: false,
                enableFiltering: true,
                enableSorting: true,
                enableRowHeaderSelection: false
            };
            var ruleNameTemplate = '<div ng-if="row.entity.sortOrder" class="ui-grid-cell-contents"><a class="hyperlink" data-e2e="{{row.entity.name}}-name" ng-click="grid.appScope.ctrl.listConnections(row.entity)">{{COL_FIELD}}</a></div>' +
                '<div ng-if="!row.entity.sortOrder" class="ui-grid-cell-contents">{{COL_FIELD}}</div>';
            var ruleValueTemplate = '<div class="ui-grid-cell-contents" data-e2e="{{row.entity.name}}-value">{{COL_FIELD}}</div>';
            var ruleAffectedTemplate = '<div class="ui-grid-cell-contents" data-e2e="{{row.entity.name}}-affected">{{COL_FIELD}}</div>';
            var ruleDateTemplate = '<div class="ui-grid-cell-contents" data-e2e="{{row.entity.name}}-date"">{{COL_FIELD}}</div>';
            var ruleChangedByTemplate = '<div class="ui-grid-cell-contents" data-e2e="{{row.entity.name}}-changedBy">{{COL_FIELD}}</div>';
            var rulePrioTemplate = '<div class="ui-grid-cell-contents" data-e2e="{{row.entity.name}}-prio">{{COL_FIELD}}</div>';
            var ruleActionBtnTemplate = '<div class="ui-grid-cell-contents lm-center-text"><button ng-hide="!row.entity.sortOrder" data-e2e="{{row.entity.name}}-actions" type="button" ng-click="grid.appScope.ctrl.chosenRule = row.entity; $event.stopPropagation();" class="btn-actions lm-transparent" xi-popupmenu="grid.appScope.ctrl.menuOptions"><span class="audible">Actions</span>' +
                '<svg class="icon" focusable="false" aria-hidden="false"><use xlink:href="#icon-more"/></svg></button>' +
                '<ul class="popupmenu actions top"><li><a ng-click="grid.appScope.ctrl.addOrEditRule(grid.appScope.ctrl.chosenRule)" data-e2e="{{row.entity.name}}-edit">Edit</a></li><li><a ng-click="grid.appScope.ctrl.deleteRules(row.entity)" data-e2e="{{row.entity.name}}-delete">Delete</a></li><li ng-show="grid.appScope.ctrl.chosenSetting.rules.length > 1" class="separator"></li>' +
                '<li ng-show="grid.appScope.ctrl.chosenRule.sortOrder !== 1"><a ng-click="grid.appScope.ctrl.moveRule(\'up\')" data-e2e="{{row.entity.name}}-moveUp">Move Up</a></li><li ng-show="grid.appScope.ctrl.chosenRule.sortOrder < grid.appScope.ctrl.chosenSetting.rules.length"><a ng-click="grid.appScope.ctrl.moveRule(\'down\')" data-e2e="{{row.entity.name}}-moveDown">Move Down</a></li></ul></div>';
            var rowTemplate = '<div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{\'disabled\': !row.entity.sortOrder }" ui-grid-cell></div>';
            var self = this;
            this.rulesGridOptions = {
                columnDefs: [
                    { field: "name", name: "RuleName", displayName: "Rule name", cellTemplate: ruleNameTemplate, minWidth: 50, maxWidth: 600 },
                    { field: "displayValue", name: "Value", cellTemplate: ruleValueTemplate, enableColumnResizing: false },
                    { field: "affectedUsers", name: "AffectedUsers", displayName: "Affected users/groups", cellTemplate: ruleAffectedTemplate, enableColumnResizing: false },
                    { field: "displayChangeDate", name: "ChangeDate", displayName: "Change date", maxWidth: 160, cellTemplate: ruleDateTemplate, enableColumnResizing: false },
                    { field: "changedByName", name: "ChangedBy", displayName: "Changed by", cellTemplate: ruleChangedByTemplate, enableColumnResizing: false },
                    {
                        field: "sortOrder", name: "Priority",
                        sort: { direction: gridConstants.ASC, priority: 1 },
                        visible: true,
                        maxWidth: 110,
                        cellTemplate: rulePrioTemplate,
                        enableColumnResizing: false
                    },
                    { field: "actions", name: "Actions", maxWidth: 110, cellTemplate: ruleActionBtnTemplate, enableColumnResizing: false }
                ],
                data: [],
                rowHeight: 48,
                rowTemplate: rowTemplate,
                enableColumnMenus: false,
                enableFiltering: false,
                enableSorting: false,
                onRegisterApi: function (gridApi) {
                    self.scope["rulesGridApi"] = gridApi;
                    self.noOfSelected = 0;
                    var gridSelection = gridApi.selection;
                    var onSelection = gridSelection.on;
                    onSelection.rowSelectionChanged(self.scope, function () {
                        self.noOfSelected = gridSelection.getSelectedRows().length;
                    });
                    onSelection.rowSelectionChangedBatch(self.scope, function () {
                        self.noOfSelected = gridSelection.getSelectedRows().length;
                    });
                },
                isRowSelectable: function (row) {
                    if (row.entity.sortOrder) {
                        return true;
                    }
                    return false;
                }
            };
            this.connectionsGridOptions = {
                columnDefs: [
                    {
                        field: "displayName", name: "UserGroupName", displayName: "User/group name",
                        sort: { direction: gridConstants.ASC, priority: 1 },
                        filter: { condition: gridConstants.filter.CONTAINS }
                    },
                    { field: "displayChangeDate", name: "ChangeDate", displayName: "Change date" },
                    { field: "changedByName", name: "ChangedBy", displayName: "Changed by" }
                ],
                data: [],
                rowHeight: 48,
                enableColumnMenus: false,
                enableSorting: true,
                enableFiltering: true,
                onRegisterApi: function (gridApi) {
                    self.scope["connectionsGridApi"] = gridApi;
                    self.noOfSelected = 0;
                    var gridSelection = gridApi.selection;
                    var onSelection = gridSelection.on;
                    onSelection.rowSelectionChanged(self.scope, function () {
                        self.noOfSelected = gridSelection.getSelectedRows().length;
                    });
                    onSelection.rowSelectionChangedBatch(self.scope, function () {
                        self.noOfSelected = gridSelection.getSelectedRows().length;
                    });
                }
            };
        };
        AdminSettingsCtrl.prototype.init = function (adminTool) {
            adminTool ? this.adminTool = adminTool : this.adminTool = this.rootScope["lmAdminTool"];
            var items = [];
            var settings = adminTool.settings;
            var settingsNames = c.SettingsNames;
            var adminService = this.adminService;
            var filter = this.filter;
            for (var i = 0; i < settings.length; i++) {
                var setting = settings[i];
                var settingName = setting.settingName;
                var value = angular.copy(setting.value);
                var rules = setting.rules ? angular.copy(setting.rules) : [];
                var displayValue = value;
                var itemType;
                var values = [];
                var changeDate = setting.changeDate ? filter("lmLocaleDate")(angular.copy(setting.changeDate)) : "";
                if (setting.values) {
                    itemType = "selector";
                    var valueObject = this.itemByProp(setting.values, "value", value);
                    if (valueObject) {
                        displayValue = valueObject.label;
                    }
                }
                else if (setting.dataType === "boolean") {
                    value = value === "true";
                    itemType = "boolean";
                }
                else if (setting.dataType === "int") {
                    itemType = "int";
                }
                else if (settingName === settingsNames.defaultPage) {
                    itemType = settingsNames.defaultPage;
                    displayValue = adminService.getPageDisplayTitle(value);
                }
                else if (settingName === settingsNames.mandatoryPages) {
                    itemType = settingsNames.mandatoryPages;
                    displayValue = adminService.getPageDisplayTitle(value);
                }
                else if (settingName === settingsNames.startPage) {
                    itemType = settingsNames.startPage;
                    displayValue = adminService.getPageDisplayTitle(value);
                }
                else {
                    itemType = "string";
                }
                for (var j = 0; j < rules.length; j++) {
                    if (itemType === "selector") {
                        valueObject = this.itemByProp(setting.values, "value", rules[j].value);
                        if (valueObject) {
                            rules[j].displayValue = valueObject.label;
                        }
                    }
                    else if (itemType === settingsNames.defaultPage || itemType === settingsNames.mandatoryPages || itemType === settingsNames.startPage) {
                        rules[j].displayValue = adminService.getPageDisplayTitle(rules[j].value);
                    }
                    else {
                        rules[j].displayValue = rules[j].value;
                    }
                    if (itemType === "boolean") {
                        rules[j].value = rules[j].value === "true";
                    }
                    rules[j].displayChangeDate = filter("lmLocaleDate")(rules[j].changeDate);
                    rules[j].affectedUsers = rules[j].ruleConnections ? rules[j].ruleConnections.length : 0;
                    rules[j].ruleConnections = rules[j].ruleConnections || [];
                    for (var k = 0; k < rules[j].ruleConnections.length; k++) {
                        rules[j].ruleConnections[k].displayChangeDate = filter("lmLocaleDate")(rules[j].ruleConnections[k].changeDate);
                    }
                }
                var item = {
                    setting: setting,
                    value: value,
                    values: values,
                    displayValue: displayValue,
                    rules: rules,
                    type: itemType,
                    changeDate: changeDate,
                    changedByName: angular.copy(setting.changedByName),
                    settingName: settingName,
                    noOfRules: rules.length
                };
                items.push(item);
            }
            this.items = items;
            this.filteredItems = items;
            var chosenSetting = this.chosenSetting;
            var chosenRule = this.chosenRule;
            if (!this.navState || this.navState === "settings") {
                this.listSettings();
            }
            else if (this.navState === "rules") {
                chosenSetting = this.itemByProp(items, "settingName", chosenSetting.settingName);
                this.listRules(chosenSetting);
            }
            else if (this.navState === "connections") {
                chosenSetting = this.itemByProp(items, "settingName", chosenSetting.settingName);
                chosenRule = this.itemByProp(chosenSetting.rules, "sortOrder", chosenRule.sortOrder);
                if (chosenRule) {
                    this.chosenSetting = chosenSetting;
                    this.listConnections(chosenRule);
                }
                else {
                    this.listRules(chosenSetting);
                }
            }
        };
        AdminSettingsCtrl.prototype.updateSettings = function () {
            var _this = this;
            var settings = this.adminTool.settings;
            var editedSettings = angular.copy(this.adminTool);
            editedSettings.settings = [];
            angular.forEach(settings, function (item) {
                if (item.isChanged) {
                    editedSettings.settings.push(item);
                }
            });
            this.adminService.updateTool(editedSettings).then(function (response) {
                angular.forEach(response.content, function (setting) {
                    var settingToUpdate = _this.itemByProp(settings, "settingName", setting.settingName);
                    var settingIndex = settings.indexOf(settingToUpdate);
                    settings[settingIndex] = setting;
                    settings[settingIndex].isChanged = false;
                });
                _this.init(_this.adminTool);
                _this.settingIsChanged = false;
                _this.setBusy(false);
            }, function (r) {
                _this.showErrorMessage(r);
            });
        };
        AdminSettingsCtrl.prototype.reconstructSettings = function () {
            var settings = this.adminTool.settings;
            for (var i = 0; i < settings.length; i++) {
                var setting = settings[i];
                var item = this.items[i];
                if (item.setting.isChanged) {
                    var value = void 0;
                    if (item.type === "boolean") {
                        value = item.value ? "true" : "false";
                    }
                    else {
                        value = item.value;
                    }
                    setting.value = value;
                    setting.isChanged = true;
                }
            }
        };
        AdminSettingsCtrl.prototype.getPages = function () {
            var _this = this;
            var adminService = this.adminService;
            var defer = this.q.defer();
            this.setBusy(true);
            adminService.listPublishedPages(false).then(function (r) {
                var publishedPages = r.content;
                adminService.publishedPages = publishedPages;
                defer.resolve(publishedPages);
                _this.setBusy(false);
            }, function (r) {
                if (r.hasMessage()) {
                    lm.Log.error(r.toErrorLog());
                }
                _this.setBusy(false);
                _this.dialogService.showMessage({
                    title: "Could not load pages",
                    message: "The pages could not be loaded and therefore no value can be set."
                });
                defer.reject();
            });
            return defer.promise;
        };
        AdminSettingsCtrl.prototype.setSettingsValue = function () {
            var _this = this;
            var chosenSetting = this.chosenSetting;
            var settingName = chosenSetting.setting.settingName;
            var settingNames = c.SettingsNames;
            var options = {
                title: "Edit Setting",
                templateUrl: "scripts/lime/admin/templates/setting-set-value.html",
                style: settingName === "MandatoryPages" ? "min-height: 400px;" : "",
                parameter: {
                    setting: chosenSetting,
                    userName: this.adminTool.userName,
                    pages: null,
                    widgets: null
                }
            };
            if (settingName === settingNames.defaultPage ||
                settingName === settingNames.mandatoryPages ||
                settingName === settingNames.startPage) {
                this.getPages().then(function (r) {
                    options.parameter.pages = r;
                    _this.openSetSettingDialog(options);
                });
            }
            else {
                this.openSetSettingDialog(options);
            }
        };
        AdminSettingsCtrl.prototype.openSetSettingDialog = function (options) {
            var updateItemIndex;
            var self = this;
            this.dialogService.show(options).then(function (r) {
                if (r.button === lm.DialogButtonType.Ok && r.value) {
                    var setting = angular.copy(r.value);
                    if (setting.type === c.SettingsNames.mandatoryPages) {
                        setting.value = setting.value.map(function (page) {
                            return page.data.id;
                        }).join(",");
                        setting.displayValue = self.adminService.getPageDisplayTitle(setting.value);
                    }
                    updateItemIndex = self.indexByProp(self.items, "settingName", self.chosenSetting.settingName);
                    self.items[updateItemIndex] = setting;
                    var gridOptionsData = self.settingsGridOptions.data;
                    updateItemIndex = self.indexByProp(gridOptionsData, "settingName", self.chosenSetting.settingName);
                    gridOptionsData[updateItemIndex] = setting;
                    self.settingIsChanged = true;
                }
            });
        };
        AdminSettingsCtrl.prototype.openAddEditRuleDialog = function (options) {
            var _this = this;
            var self = this;
            this.dialogService.show(options).then(function (r) {
                if (r.button === lm.DialogButtonType.Ok && r.value) {
                    var updateItem = _this.itemByProp(self.items, "settingName", self.chosenSetting.settingName);
                    updateItem.rules = r.value.rules;
                    updateItem.noOfRules = r.value.rules.length;
                    if (self.settingsWithChangedRules.indexOf(updateItem.settingName) === -1) {
                        self.settingsWithChangedRules.push(updateItem.settingName);
                    }
                    if (self.navState === "rules") {
                        self.listRules();
                    }
                    self.ruleIsChanged = true;
                }
            });
        };
        AdminSettingsCtrl.prototype.listSettings = function () {
            this.navState = "settings";
            this.chosenSetting = null;
            this.chosenRule = null;
            this.selectArea();
        };
        AdminSettingsCtrl.prototype.listRules = function (setting) {
            this.navState = "rules";
            this.scope["rulesGridApi"].selection.clearSelectedRows();
            if (!lm.CommonUtil.isUndefined(setting)) {
                this.chosenSetting = setting;
            }
            var chosenSetting = this.chosenSetting;
            this.rulesGridOptions.data = angular.copy(chosenSetting.rules);
            this.rulesGridOptions.data.push({
                name: chosenSetting.setting.label,
                displayValue: chosenSetting.displayValue,
                affectedUsers: "All",
                displayChangeDate: chosenSetting.changeDate,
                changedByName: chosenSetting.setting.changedByName
            });
            this.noOfSelected = 0;
        };
        AdminSettingsCtrl.prototype.listConnections = function (rule) {
            this.navState = "connections";
            this.scope["connectionsGridApi"].selection.clearSelectedRows();
            this.chosenRule = rule;
            rule.affectedUsers = rule.ruleConnections.length;
            this.connectionsGridOptions.data = angular.copy(rule.ruleConnections);
            this.noOfSelected = 0;
        };
        AdminSettingsCtrl.prototype.moveRule = function (direction) {
            var ruleToMoveUp;
            var ruleToMoveDown;
            var chosenSetting = this.chosenSetting;
            var chosenSettingRules = chosenSetting.rules;
            var chosenRuleSortOrder = this.chosenRule.sortOrder;
            if (direction === "up") {
                ruleToMoveUp = this.itemByProp(chosenSettingRules, "sortOrder", chosenRuleSortOrder);
                ruleToMoveDown = this.itemByProp(chosenSettingRules, "sortOrder", chosenRuleSortOrder - 1);
            }
            else if (direction === "down") {
                ruleToMoveDown = this.itemByProp(chosenSettingRules, "sortOrder", chosenRuleSortOrder);
                ruleToMoveUp = this.itemByProp(chosenSettingRules, "sortOrder", chosenRuleSortOrder + 1);
            }
            else {
                return;
            }
            ruleToMoveUp.sortOrder -= 1;
            ruleToMoveUp.isChanged = true;
            ruleToMoveUp.displayChangeDate = this.getLocalChangeDate();
            ruleToMoveUp.changedByName = this.adminTool.userName;
            ruleToMoveDown.sortOrder += 1;
            ruleToMoveDown.isChanged = true;
            ruleToMoveDown.displayChangeDate = this.getLocalChangeDate();
            ruleToMoveDown.changedByName = this.adminTool.userName;
            if (this.settingsWithChangedRules.indexOf(chosenSetting.settingName) === -1) {
                this.settingsWithChangedRules.push(chosenSetting.settingName);
            }
            this.ruleIsChanged = true;
            this.listRules();
        };
        AdminSettingsCtrl.prototype.setBusy = function (isBusy) {
            this.progressService.setBusy(isBusy);
        };
        AdminSettingsCtrl.prototype.itemByProp = function (array, name, value) {
            return lm.ArrayUtil.itemByProperty(array, name, value);
        };
        AdminSettingsCtrl.prototype.indexByProp = function (array, name, value) {
            return lm.ArrayUtil.indexByProperty(array, name, value);
        };
        AdminSettingsCtrl.prototype.getLocalChangeDate = function () {
            return lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*";
        };
        AdminSettingsCtrl.prototype.showErrorMessage = function (r) {
            var options = {
                title: "Could not update settings",
                message: "An error occured while updating the settings.",
                standardButtons: lm.StandardDialogButtons.Ok
            };
            this.dialogService.showMessage(options);
            this.setBusy(false);
            if (r.hasMessage()) {
                lm.Log.error("[Admin Settings] " + r.toErrorLog());
            }
        };
        AdminSettingsCtrl.add = function (m) {
            m.controller("lmAdminSettingsCtrl", AdminSettingsCtrl);
        };
        AdminSettingsCtrl.$inject = ["$rootScope", "$scope", "$q", "$filter", "lmAdminContext", "lmAdminService", "lmDialogService", "lmProgressService", "uiGridConstants"];
        return AdminSettingsCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        AdminSettingsCtrl.add(m);
    };
});
//# sourceMappingURL=settings.js.map