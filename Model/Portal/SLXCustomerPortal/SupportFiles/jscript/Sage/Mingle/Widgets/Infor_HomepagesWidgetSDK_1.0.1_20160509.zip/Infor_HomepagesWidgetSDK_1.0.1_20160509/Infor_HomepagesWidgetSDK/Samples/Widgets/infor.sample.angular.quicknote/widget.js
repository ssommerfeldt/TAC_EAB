/// <reference path="../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../scripts/typings/lime/lime.d.ts" />
define(["require", "exports", "lime"], function (require, exports, lm) {
    var QuicknoteCtrl = (function () {
        function QuicknoteCtrl(scope) {
            var _this = this;
            this.scope = scope;
            this.logPrefix = "[QuicknoteCtrl] ";
            this.settingsKeyItems = "items";
            this.items = [];
            this.widgetContext = scope[lm.WidgetConstants.widgetContextKey];
            this.instance = scope[lm.WidgetConstants.widgetInstanceKey];
            this.lang = this.widgetContext.getLanguage();
            var settings = this.widgetContext.getSettings();
            // Set custom title
            this.widgetContext.setTitle("QuickNote");
            var savedItems = settings.get(this.settingsKeyItems);
            if (savedItems) {
                this.items = savedItems;
            }
            else {
                settings.set(this.settingsKeyItems, this.items);
            }
            // Add custom widget action to widget instance
            var clearAction = {
                execute: function () { _this.clear(); },
                isEnabled: this.items.length ? true : false,
                text: this.lang.get("clear")
            };
            angular.extend(this.instance.actions[0], clearAction);
        }
        QuicknoteCtrl.prototype.addNote = function (value) {
            if (value) {
                if (lm.ArrayUtil.contains(this.items, value)) {
                    lm.ArrayUtil.remove(this.items, value);
                }
                this.items.unshift(value);
                this.instance.actions[0].isEnabled = true;
                this.widgetContext.save();
            }
            this.text = null;
        };
        QuicknoteCtrl.prototype.clear = function () {
            this.items.length = 0;
            this.instance.actions[0].isEnabled = false;
            this.widgetContext.save();
        };
        QuicknoteCtrl.$inject = ["$scope"];
        return QuicknoteCtrl;
    })();
    exports.widgetFactory = function (context) {
        var m = context.getAngularContext().module;
        m.controller("sample.QuicknoteCtrl", QuicknoteCtrl);
        return {
            angularConfig: {
                relativeTemplateUrl: "widget.html"
            },
            actions: [{ isPrimary: true, standardIconName: "#icon-delete" }]
        };
    };
});
//# sourceMappingURL=widget.js.map