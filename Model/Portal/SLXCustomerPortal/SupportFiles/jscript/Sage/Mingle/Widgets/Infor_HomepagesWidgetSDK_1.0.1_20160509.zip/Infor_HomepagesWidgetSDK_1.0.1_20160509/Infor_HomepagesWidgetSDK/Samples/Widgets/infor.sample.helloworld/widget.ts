﻿/// <reference path="../scripts/typings/jquery/jquery.d.ts" />
/// <reference path="../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../scripts/typings/lime/lime.d.ts" />

import lm = require("lime");

class HelloWorld implements lm.IWidgetInstance {

	private messageElement: JQuery;

	constructor(private widgetContext: lm.IWidgetContext) {
		// Add content to the widget element
		this.addContent();

		// Initial update of the message text
		this.updateMessage();
	}

	public settingsSaved() {
		this.updateMessage();
	}

	private addContent() {
		var div = $("<div/>");
		var h1 = $("<h1/>").css({ "margin-top": "20px", "text-align": "center" });
		div.append(h1);

		this.widgetContext.getElement().append(div);
		this.messageElement = h1;
	}

	private updateMessage() {
		var message = this.widgetContext.getSettings().get<string>("Message");
		this.messageElement.text(message);
	}
}

// Widget factory function
export var widgetFactory = (context: lm.IWidgetContext): lm.IWidgetInstance => {
	// Create and return the widget instance
	return new HelloWorld(context);
};