﻿import lm = require("../../lime");
import c = require("../../core");

/**
 * Setting Save And Discard Controller
 *
 * Controller that handles the save and discard modals.
 */
class SettingSaveAndDiscardCtrl extends c.CoreBase {
	private dialog: lm.IDialog;

	static $inject = ["$scope"];

	constructor(public scope: ng.IScope) {
		super("[SettingSaveAndDiscardCtrl] ");
		this.dialog = scope["lmDialog"];
	}

	public onCancel(): void {
		this.dialog.close({ button: lm.DialogButtonType.Cancel });
	}

	public onOk(): void {
		this.dialog.close({ button: lm.DialogButtonType.Ok });
	}

	public static add(m: ng.IModule) {
		m.controller("lmSettingSaveAndDiscardCtrl", SettingSaveAndDiscardCtrl);
	}
}

export var init = (m: ng.IModule) => {
	SettingSaveAndDiscardCtrl.add(m);
}