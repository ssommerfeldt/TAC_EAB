var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../lime", "../../core", "../service"], function (require, exports, lm, c, s) {
    var AdminPropertiesCtrl = (function (_super) {
        __extends(AdminPropertiesCtrl, _super);
        function AdminPropertiesCtrl(scope, adminContext, adminService, dialogService, uiGridConstants) {
            _super.call(this, "[AdminPropertiesCtrl] ");
            this.scope = scope;
            this.adminContext = adminContext;
            this.adminService = adminService;
            this.dialogService = dialogService;
            this.uiGridConstants = uiGridConstants;
            this.properties = [];
            this.refreshText = "Refresh";
            this.checkboxList = {};
            this.initNewProperty();
            this.initGrid();
            var adminConstants = s.AdminConstants;
            var self = this;
            scope.$watch(adminConstants.openTab, function (tab) {
                if (tab === adminConstants.propertiesTab) {
                    self.getProperties(false);
                }
            });
        }
        AdminPropertiesCtrl.prototype.getProperties = function (reload, callback) {
            var self = this;
            var adminService = self.adminService;
            adminService.setBusy(true);
            if (reload) {
                this.noOfSelected = 0;
                if (this.scope["gridApi"]) {
                    this.scope["gridApi"].selection.clearSelectedRows();
                }
            }
            adminService.listProperties(reload).then(function (r) {
                var properties = r.content;
                self.properties = properties;
                self.propertiesGridOptions.data = properties;
                adminService.setBusy(false);
                if (callback) {
                    callback();
                }
            }, function (r) {
                adminService.setBusy(false);
                adminService.handleError(r);
                if (callback) {
                    callback();
                }
            });
        };
        AdminPropertiesCtrl.prototype.exportProperties = function (selection) {
            var adminService = this.adminService;
            if (selection === "all") {
                adminService.exportProperties();
            }
            else if (selection === "selected") {
                var properties = this.getSelectedRows();
                adminService.exportProperties(properties);
            }
        };
        AdminPropertiesCtrl.prototype.importProperties = function () {
            var _this = this;
            var dialogTitle = "Import Properties";
            var options = {
                operation: c.EntityCategory.adHocProperties.toString(),
                title: dialogTitle,
                acceptFileExtension: ".json"
            };
            var self = this;
            this.adminService.openImportFilesDialog(options).then(function (r) {
                var value = r.value;
                if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Success) {
                    _this.adminService.showUploadCompleteDialog(dialogTitle, value.message).then(function (result) {
                        if (result.button === lm.DialogButtonType.Ok) {
                            self.getProperties(true);
                        }
                    });
                }
                else if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Fail) {
                    self.adminService.showUploadCompleteDialog(dialogTitle, value.message, true);
                }
            });
        };
        AdminPropertiesCtrl.prototype.deleteProperty = function (property) {
            var _this = this;
            var propertyId = property.propertyId;
            var options = {
                title: "Remove Property",
                message: "Are you sure that you want to remove the property '" + propertyId + "'?",
                standardButtons: lm.StandardDialogButtons.YesNo
            };
            var self = this;
            var adminService = self.adminService;
            this.dialogService.showMessage(options).then(function (result) {
                if (result.button === lm.DialogButtonType.Yes) {
                    adminService.setBusy(true);
                    adminService.deleteProperty(propertyId).then(function (r) {
                        lm.ArrayUtil.removeByProperty(self.properties, "propertyId", propertyId);
                        _this.adminService.unselectGridItem(property, _this.scope["gridApi"]);
                        adminService.setBusy(false);
                    }, function (r) {
                        adminService.setBusy(false);
                        self.logResponse(r);
                    });
                }
            });
        };
        AdminPropertiesCtrl.prototype.deleteProperties = function () {
            var _this = this;
            var options = {
                title: "Remove Properties",
                message: "Are you sure that you want to remove the selected properties?",
                standardButtons: lm.StandardDialogButtons.YesNo
            };
            var self = this;
            var adminService = self.adminService;
            this.dialogService.showMessage(options).then(function (result) {
                if (result.button === lm.DialogButtonType.Yes) {
                    adminService.setBusy(true);
                    var properties = _this.getSelectedRows();
                    var noToUpdate = properties.length;
                    _this.noOfSelected = 0;
                    angular.forEach(properties, function (prop) {
                        var id = prop.propertyId;
                        adminService.deleteProperty(prop.propertyId).then(function (r) {
                            lm.ArrayUtil.removeByProperty(self.properties, "propertyId", id);
                            noToUpdate -= 1;
                            if (noToUpdate === 0) {
                                adminService.setBusy(false);
                            }
                            _this.adminService.unselectGridItem(prop, _this.scope["gridApi"]);
                        }, function (r) {
                            self.logResponse(r);
                            adminService.setBusy(false);
                        });
                    });
                    if (_this.noOfSelected === 0) {
                        _this.clearSelection();
                    }
                }
            });
        };
        AdminPropertiesCtrl.prototype.unselectProperty = function (property, gridApi) {
            if (lm.ArrayUtil.containsByProperty(gridApi.selection.getSelectedRows(), '$$hashKey', property.$$hashKey)) {
                gridApi.selection.toggleRowSelection(property);
                gridApi.selection.getSelectedRows();
                this.noOfSelected = gridApi.selection.getSelectedRows().length;
            }
        };
        AdminPropertiesCtrl.prototype.openAddEditPropertyConnection = function (isEdit, property) {
            var dialogParam = { isEdit: false, property: this.newProperty };
            var dialogTitle = "Add Property";
            if (isEdit) {
                dialogTitle = "Edit Property";
                dialogParam = { property: property, isEdit: true };
            }
            var options = {
                title: dialogTitle,
                templateUrl: "scripts/lime/admin/templates/add-edit-property.html",
                parameter: dialogParam
            };
            var self = this;
            this.dialogService.show(options).then(function (r) {
                var value = r.value;
                if (r.button === lm.DialogButtonType.Ok && value) {
                    if (!isEdit) {
                        self.newProperty = value;
                        self.addProperty();
                    }
                    else {
                        var properties = self.properties;
                        self.chosenProperty = value;
                        self.updateProperty();
                        var propIndex = lm.ArrayUtil.indexByProperty(properties, "propertyId", value.propertyId);
                        properties[propIndex] = value;
                    }
                }
            });
        };
        AdminPropertiesCtrl.prototype.initGrid = function () {
            var self = this;
            var gridConstants = this.uiGridConstants;
            var containsFilter = gridConstants.filter.CONTAINS;
            var actionBtnTemplate = '<div class="ui-grid-cell-contents lm-center-text"><button type="button" ng-click="$event.stopPropagation();" class="btn-actions lm-transparent" xi-popupmenu="grid.appScope.ctrl.menuOptions"><span class="audible">Actions</span>' +
                '<svg class="icon" focusable="false" aria-hidden="false"><use xlink:href="#icon-more"/></svg></button>' +
                '<ul class="popupmenu actions top"><li><a ng-click="grid.appScope.ctrl.openAddEditPropertyConnection(true, row.entity)">Edit</a></li><li><a ng-click="grid.appScope.ctrl.deleteProperty(row.entity)">Delete</a></li></ul></div>';
            this.propertiesGridOptions = {
                columnDefs: [{
                        field: "propertyId",
                        name: "Name",
                        sort: { direction: gridConstants.ASC, priority: 1 },
                        filter: { condition: containsFilter },
                        minWidth: 50,
                        maxWidth: 600
                    },
                    { field: "description", name: "Description", filter: { condition: containsFilter }, minWidth: 50, maxWidth: 600 },
                    { field: "propertyValue", name: "Value", enableColumnResizing: false },
                    { field: "area", name: "Area", enableColumnResizing: false },
                    { field: "actions", name: "Actions", maxWidth: 110, cellTemplate: actionBtnTemplate, enableFiltering: false, enableSorting: false, enableColumnResizing: false }],
                data: this.properties,
                rowHeight: 48,
                enableFiltering: true,
                enableSorting: true,
                enableColumnMenus: false,
                onRegisterApi: function (gridApi) {
                    self.scope["gridApi"] = gridApi;
                    self.noOfSelected = 0;
                    var gridSelection = gridApi.selection;
                    var onSelection = gridSelection.on;
                    onSelection.rowSelectionChanged(self.scope, function () {
                        self.noOfSelected = gridSelection.getSelectedRows().length;
                    });
                    onSelection.rowSelectionChangedBatch(self.scope, function () {
                        self.noOfSelected = gridSelection.getSelectedRows().length;
                    });
                }
            };
        };
        AdminPropertiesCtrl.prototype.getSelectedRows = function () {
            return this.scope["gridApi"].selection.getSelectedRows();
        };
        AdminPropertiesCtrl.prototype.initNewProperty = function () {
            this.newProperty = { propertyId: "", propertyValue: "" };
        };
        AdminPropertiesCtrl.prototype.addProperty = function () {
            var self = this;
            var adminService = self.adminService;
            var newProperty = self.newProperty;
            var existingProperty = lm.ArrayUtil.itemByProperty(self.properties, "propertyId", newProperty.propertyId);
            if (!existingProperty) {
                adminService.setBusy(true);
                adminService.createProperty(newProperty).then(function (r) {
                    if (!r.content) {
                        self.logResponse(r);
                    }
                    else {
                        self.initNewProperty();
                        self.properties.push(newProperty);
                    }
                    adminService.setBusy(false);
                }, function (r) {
                    if (r.errorText) {
                        adminService.handleError(r, "Could not add property. " + r.errorText + ".");
                    }
                    else {
                        adminService.handleError(r, "Could not add property.");
                    }
                    adminService.setBusy(false);
                });
            }
            else {
                this.dialogService.showMessage({ title: "Could not add property.", message: "A property with that name already exists." });
                this.getProperties(true);
            }
        };
        AdminPropertiesCtrl.prototype.updateProperty = function () {
            var self = this;
            var adminService = self.adminService;
            adminService.setBusy(true);
            adminService.updateProperty(this.chosenProperty).then(function (r) {
                adminService.setBusy(false);
            }, function (r) {
                adminService.setBusy(false);
                adminService.handleError(r);
            });
        };
        AdminPropertiesCtrl.prototype.clearSelection = function () {
            this.noOfSelected = 0;
            var grid = this.scope["gridApi"];
            if (grid) {
                grid.selection.clearSelectedRows();
            }
        };
        AdminPropertiesCtrl.add = function (m) {
            m.controller("lmAdminPropertiesCtrl", AdminPropertiesCtrl);
        };
        AdminPropertiesCtrl.$inject = ["$scope", "lmAdminContext", "lmAdminService", "lmDialogService", "uiGridConstants"];
        return AdminPropertiesCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        AdminPropertiesCtrl.add(m);
    };
});
//# sourceMappingURL=properties.js.map