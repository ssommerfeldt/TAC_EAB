export declare var init: (m: ng.IModule) => void;
