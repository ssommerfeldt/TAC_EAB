﻿import lm = require("../../lime");
import c = require("../../core");
import s = require("../service");

class SettingAddEditRuleCtrl extends c.CoreBase {
   public item: c.ISettingItem;
   public pages: c.IPage[];
   public value: any;
   public mandatoryValues: c.IPage[];
   public ruleName: string;
   public autocompleteOptions: xi.IAutoCompleteOptions;
	public autocompleteOptionsRole: xi.IAutoCompleteOptions;
   public sortableOptions: any;
   public existsMsg: string;
   public existsRoleMsg: string;
   public confirmButtonTitle: string;
   public roleInput: string;

   private dialog: lm.IDialog;
   private rule: c.ISettingRule;
   private isEdit: boolean;
   private userName: string;
   private ruleConnectionsString: string = "ruleConnections";
	private autocompleteElem: JQuery;
	private autocompleteElemRole: JQuery;

   static $inject = ["$scope", "lmCommonDataService", "lmAdminService"];

   constructor(public scope: ng.IScope, private commonDataService: c.ICommonDataService, private adminService: s.IAdminService) {
      super("[SettingAddEditRuleCtrl] ");
      var dialog: lm.IDialog = scope["lmDialog"];
      var dialogParam = dialog.parameter;
      this.dialog = dialog;
      this.userName = dialogParam.userName;
      this.item = angular.copy(dialogParam.setting);
      var rule = angular.copy(dialogParam.rule);
      this.rule = rule;
      this.pages = angular.copy(dialogParam.pages);

      scope[this.ruleConnectionsString] = [];
      this.confirmButtonTitle = "Save"; // Was Add but now it looks strange when we have add to manually add a role

      if (!lm.CommonUtil.isUndefined(rule)) {
         this.value = rule.value;
         this.ruleName = rule.name;
         scope[this.ruleConnectionsString] = rule.ruleConnections || [];
         this.isEdit = true;
         this.confirmButtonTitle = "Ok";
      } else {
         // Client Log Level should never be null (LIME-829)
         if (this.item.settingName === c.SettingsNames.logLevel) {
            this.value = this.item.value;
         }
      }

      var self = this;
      // Make mandatory pages sortable 
      if (this.item.type === c.SettingsNames.mandatoryPages) {
         var mandatories = this.value ? this.value.split(",") : [];
         var mandatoryValues = [];
         this.mandatoryValues = mandatoryValues;
         mandatories.forEach((id: string) => {
            self.pages.forEach((page: c.IPage) => {
               if (id === page.data.id) {
                  mandatoryValues.push(page);
               }
            });
         });
         this.sortableOptions = {
            connectWith: ".mandatory-pages-rules-container",
            axis: "y"
         };
      }

      if (this.item.type === "boolean" && !this.isEdit) {
         this.value = false;
      }

      // Set source of autocomplete
      this.autocompleteOptions = {
         source: (query, done) => {
            self.commonDataService.searchUsers(query).then((response: c.IUserListResponse) => {
               const items = c.CoreUtil.getEntityArray(response.content);
               done(query, lm.ArrayUtil.sortByProperty(items, "label"));
            });
         },
         template: c.Templates.autocompleteEntity
      }
		this.autocompleteOptionsRole = {
         source: (query, done) => {
            adminService.searchRoles(query).then((result: lm.IAutocompleteEntity[]) => {
					done(query, lm.ArrayUtil.sortByProperty(result, "label"));
            });
         },
         template: c.Templates.autocompleteEntity,
			filterMode: "contains"
      }

		const autocompleteUsers = $("#autocomplete-rules");
		const autocompleteRoles = $("#autocomplete-role");
		
		this.connectAutoComplete(autocompleteUsers, scope);
		this.connectAutoComplete(autocompleteRoles, scope);

	   this.autocompleteElem = autocompleteUsers;
	   this.autocompleteElemRole = autocompleteRoles;

      scope.$on("$destroy", () => {
         this.autocompleteElem.off();
			this.autocompleteElemRole.off();
      });
   }

	private connectAutoComplete(element: JQuery, scope: ng.IScope): void {
		var self = this;
		element.on("selected", (event, target, object: lm.IAutocompleteEntity) => {
         if (lm.CommonUtil.isUndefined(object) || lm.CommonUtil.isUndefined(object.value)) {
            return;
         }
         self.addEntity(object.value, object.type, object.label, object.info, true);
      });
	}

	private addEntity(name: string, principalType: number, label: string, info: string, applyScope: boolean): void {
      this.existsMsg = "";
      this.existsRoleMsg = "";
      var connections: any[] = this.scope[this.ruleConnectionsString];
      if (lm.ArrayUtil.containsByProperty(connections, "name", name)) {
         if (principalType === c.PrincipalType.User) {
            this.existsMsg = "User already added";
         } else {
            this.existsRoleMsg = "Role already added";
         }
	      if (applyScope) {
		      this.scope.$apply();
	      }
      } else {
         const ruleConnection = {
            name: name,
            isUser: principalType === c.PrincipalType.User,
            displayName: label ? label : name,
            info: info || name
         };

         connections.push(ruleConnection);
	      if (!ruleConnection.isUser) {
				this.roleInput = "";
			}
	      if (applyScope) {
				this.scope.$apply(this.ruleConnectionsString);
			}
      }
   }

   public addRole(): void {
      const name = this.roleInput;
      if (!name) {
         return;
      }
      this.addEntity(name, c.PrincipalType.Role, null, null, false);
   }

   public onCancel(): void {
      var result: lm.IDialogResult = {
         button: lm.DialogButtonType.Cancel,
         value: null
      };
      this.dialog.close(result);
   }

   public onOk(): void {
      if (this.ruleName) {
         var item = this.item;
         if (item.type === c.SettingsNames.mandatoryPages) {
            this.value = this.mandatoryValues.map((page: c.IPage) => {
               return page.data.id;
            }).join(",");
         }

         if (this.isEdit) {
            this.editRule();
         } else {
            this.addRule();
         }

         var result: lm.IDialogResult = {
            button: lm.DialogButtonType.Ok,
            value: item
         };
         this.dialog.close(result);
      }
   }

	/**
	* Remove user/group.
	*
	* Removes a user or group from connections.
	*/
   public remove(connection: c.ISettingRuleConnection): void {
      var ruleConnections: c.ISettingRuleConnection[] = this.scope[this.ruleConnectionsString];
      var connectionIndex = ruleConnections.indexOf(connection);
      ruleConnections.splice(connectionIndex, 1);
   }

   private addRule(): void {
      // Set change date and by for each new connection
      var self = this;
      var userName = this.userName;
      var ruleConnections: c.ISettingRuleConnection[] = self.scope[self.ruleConnectionsString];
      angular.forEach(ruleConnections, (connection: c.ISettingRuleConnection) => {
         connection.displayChangeDate = lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*";
         connection.changedByName = userName;
      });

      var ruleDisplayValue = this.getDisplayValue();
      var settingItem = this.item;

      var rule = {
         name: this.ruleName,
         sortOrder: 1,
         affectedUsers: ruleConnections.length,
         value: this.value,
         displayValue: ruleDisplayValue,
         isChanged: true,
         ruleConnections: ruleConnections,
         displayChangeDate: lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*",
         changedByName: userName,
         changeDate: null,
         changedBy: null,
         mode: null,
         module: null,
         readOnly: null,
         ruleSettingId: null,
         settingName: settingItem.setting.settingName
      }

      angular.forEach(settingItem.rules, (ruleItem: c.ISettingRule) => {
         ruleItem.sortOrder++;
         ruleItem.isChanged = true;
         ruleItem.changedByName = userName;
         ruleItem.displayChangeDate = lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*";
      });

      settingItem.rules.push(rule);
   }

   private editRule(): void {
      var self = this;
      var rule = self.rule;
      var ruleConnections: c.ISettingRuleConnection[] = this.scope[this.ruleConnectionsString];
      var userName = this.userName;
      // Set changedate and changedby for each new connection
      angular.forEach(ruleConnections, (connection: c.ISettingRuleConnection) => {
         connection.displayChangeDate = lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*";
         connection.changedByName = userName;
      });

      var ruleIndex = lm.ArrayUtil.indexByProperty(this.item.rules, "sortOrder", rule.sortOrder);
      var ruleDisplayValue = this.getDisplayValue();

      rule.name = this.ruleName;
      rule.value = this.value;
      rule.displayValue = ruleDisplayValue,
      rule.affectedUsers = ruleConnections.length,
      rule.isChanged = true;
      rule.ruleConnections = ruleConnections;
      rule.displayChangeDate = lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*";
      rule.changedByName = userName;

      if (ruleIndex !== -1) {
         this.item.rules[ruleIndex] = rule;
      }
   }

	/**
	* Get Display Value
	*
	* Returns a display value depending on the item type.
	*/
   private getDisplayValue(): string {
      var item = this.item;
      var settingType = item.type;
      var value = this.value;
      var displayValue;
      if (settingType === c.SettingsNames.defaultPage || settingType === c.SettingsNames.mandatoryPages ||
         settingType === c.SettingsNames.startPage) {
         displayValue = this.adminService.getPageDisplayTitle(value);
      } else if (settingType === "selector") {
         var valueObject = lm.ArrayUtil.itemByProperty(item.setting.values, "value", value);
         if (valueObject) {
            displayValue = valueObject.label;
         } else {
            displayValue = value;
         }
      } else {
         displayValue = value;
      }
      return displayValue;
   }

   public static add(m: ng.IModule) {
      m.controller("lmSettingAddEditRuleCtrl", SettingAddEditRuleCtrl);
   }
}

export var init = (m: ng.IModule) => {
   SettingAddEditRuleCtrl.add(m);
}