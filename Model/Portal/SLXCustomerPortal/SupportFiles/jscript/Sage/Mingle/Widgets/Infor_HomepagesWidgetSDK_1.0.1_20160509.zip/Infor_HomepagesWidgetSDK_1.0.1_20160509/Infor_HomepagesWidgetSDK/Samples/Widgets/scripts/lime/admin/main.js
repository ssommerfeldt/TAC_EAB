require.config({
    waitSeconds: 180,
    baseUrl: "",
    urlArgs: "",
    paths: {
        "angular": "scripts/vendor/angular.min",
        "sortable": "scripts/vendor/sortable",
        "ui.grid": "scripts/vendor/ui-grid.min",
        "sohoxi": "scripts/xi/sohoxi-angular"
    },
    shim: {
        "angular": { exports: "angular" },
        "sortable": ["angular"],
        "ui.grid": ["angular"],
        "sohoxi": ["angular"]
    },
    map: {
        '*': {
            "lime": "scripts/lime/lime"
        }
    }
});
require(["angular", "sortable", "ui.grid", "sohoxi", "scripts/lime/module", "scripts/lime/admin/module"], function (angular) {
    $(function () {
        angular.bootstrap(document, ["sohoxi", "lime", "lime.internal", "lime.admin"]);
    });
});
//# sourceMappingURL=main.js.map