﻿/// <reference path="../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../scripts/typings/lime/lime.d.ts" />

import lm = require("lime");

class QuicknoteCtrl {
	static $inject = ["$scope"];
	private widgetContext: lm.IWidgetContext;
	private instance: lm.IWidgetInstance;
	private logPrefix = "[QuicknoteCtrl] ";
	private settingsKeyItems = "items";
	private lang: lm.ILanguage;
	private items: string[] = [];
	private text: string;

	constructor(public scope: ng.IScope) {
		this.widgetContext = scope[lm.WidgetConstants.widgetContextKey];
		this.instance = scope[lm.WidgetConstants.widgetInstanceKey];
		this.lang = this.widgetContext.getLanguage();

		var settings = this.widgetContext.getSettings();
		
		// Set custom title
		this.widgetContext.setTitle("QuickNote");
		var savedItems = settings.get(this.settingsKeyItems);
		if (savedItems) {
			this.items = <any>savedItems;
		} else {
			settings.set(this.settingsKeyItems, this.items);
		}

		// Add custom widget action to widget instance
		var clearAction: lm.IWidgetAction = {
			execute: () => { this.clear(); },
			isEnabled: this.items.length ? true : false,
			text: this.lang.get("clear")
		}

		angular.extend(this.instance.actions[0], clearAction);
	}

	private addNote(value: string): void {
		if (value) {
			if (lm.ArrayUtil.contains(this.items, value)) {
				lm.ArrayUtil.remove(this.items, value);
			}
			this.items.unshift(value);
			this.instance.actions[0].isEnabled = true;
			this.widgetContext.save();
		}
		this.text = null;
	}

	private clear(): void {
		this.items.length = 0;
		this.instance.actions[0].isEnabled = false;
		this.widgetContext.save();
	}
}

export var widgetFactory = (context: lm.IWidgetContext): lm.IWidgetInstance => {
	var m = context.getAngularContext().module;
	m.controller("sample.QuicknoteCtrl", QuicknoteCtrl);

	return {
		angularConfig: {
			relativeTemplateUrl: "widget.html"
		},
		actions: <lm.IWidgetAction[]>[{ isPrimary: true, standardIconName: "#icon-delete" }]
	};
};