var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../lime", "../../core", "../service"], function (require, exports, lm, c, s) {
    var AdminPublishedPagesCtrl = (function (_super) {
        __extends(AdminPublishedPagesCtrl, _super);
        function AdminPublishedPagesCtrl(scope, adminService, adminContext, dialogService, pageService, commonDataService, uiGridConstants) {
            var _this = this;
            _super.call(this, "[AdminPublishedPagesCtrl] ");
            this.scope = scope;
            this.adminService = adminService;
            this.adminContext = adminContext;
            this.dialogService = dialogService;
            this.pageService = pageService;
            this.commonDataService = commonDataService;
            this.uiGridConstants = uiGridConstants;
            this.publishedPages = [];
            this.refreshText = "Refresh";
            this.initGrid();
            var adminConstants = s.AdminConstants;
            var self = this;
            scope.$watch(adminConstants.openTab, function (tab) {
                if (tab === adminConstants.publishedPagesTab && !_this.isSearchActive) {
                    self.listPublishedPages(false);
                }
            });
        }
        AdminPublishedPagesCtrl.prototype.searchPage = function (id) {
            if (!lm.StringUtil.isNullOrWhitespace(id)) {
                id = id.trim();
                var result = lm.ArrayUtil.find(this.publishedPages, function (item) {
                    var data = item.data;
                    return (data.id === id);
                });
                this.clearSelection();
                this.pagesGridOptions.data = result ? [result] : [];
                this.isSearchActive = true;
            }
        };
        AdminPublishedPagesCtrl.prototype.showGuidSearchDialog = function () {
            var _this = this;
            var options = {
                title: "Search",
                templateUrl: "scripts/lime/admin/templates/guid-search-dialog.html"
            };
            this.dialogService.show(options).then(function (r) {
                if (!lm.CommonUtil.isUndefined(r.value) && r.button === lm.DialogButtonType.Ok) {
                    var query = r.value;
                    if (query) {
                        _this.searchPage(query);
                    }
                }
            });
        };
        AdminPublishedPagesCtrl.prototype.getSelectedRows = function () {
            return this.scope["pagesGridApi"].selection.getSelectedRows();
        };
        AdminPublishedPagesCtrl.prototype.clearSelection = function () {
            this.noOfSelected = 0;
            var grid = this.scope["pagesGridApi"];
            if (grid) {
                grid.selection.clearSelectedRows();
            }
        };
        AdminPublishedPagesCtrl.prototype.listPublishedPages = function (reload, callback) {
            var self = this;
            var adminService = self.adminService;
            this.scope["searchIdString"] = "";
            this.isSearchActive = false;
            if (reload) {
                this.clearSelection();
            }
            adminService.setBusy(true);
            adminService.listPublishedPages(reload).then(function (r) {
                var publishedPages = r.content;
                self.publishedPages = publishedPages;
                self.pagesGridOptions.data = publishedPages;
                adminService.setBusy(false);
                if (callback) {
                    callback();
                }
            }, function (r) {
                adminService.setBusy(false);
                adminService.handleError(r);
                if (callback) {
                    callback();
                }
            });
        };
        AdminPublishedPagesCtrl.prototype.import = function () {
            var _this = this;
            var dialogTitle = "Import Published Pages";
            var adminService = this.adminService;
            var options = {
                title: dialogTitle,
                operation: c.EntityCategory.publishedPage.toString()
            };
            var self = this;
            adminService.openImportFilesDialog(options).then(function (r) {
                var value = r.value;
                if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Success) {
                    _this.adminService.showUploadCompleteDialog(dialogTitle, value.message).then(function (result) {
                        if (result.button === lm.DialogButtonType.Ok) {
                            self.listPublishedPages(true);
                        }
                    });
                }
                else if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Fail) {
                    adminService.showUploadCompleteDialog(dialogTitle, value.message, true);
                }
            });
        };
        AdminPublishedPagesCtrl.prototype.export = function () {
            if (this.noOfSelected === this.publishedPages.length) {
                this.exportAll();
            }
            else {
                var pagesToExport = this.getSelectedRows();
                this.adminService.exportPublishedPages(pagesToExport);
            }
        };
        AdminPublishedPagesCtrl.prototype.exportAll = function () {
            this.adminService.exportPublishedPages();
        };
        AdminPublishedPagesCtrl.prototype.delete = function (page) {
            var _this = this;
            var pagesToDelete = page ? [page] : this.getSelectedRows();
            var options = this.adminService.getDeletePageOptions(pagesToDelete, false);
            this.dialogService.showMessage(options).then(function (result) {
                if (result.button === lm.DialogButtonType.Yes) {
                    _this.deletePublishedPage(pagesToDelete);
                }
            });
        };
        AdminPublishedPagesCtrl.prototype.setBusy = function (isBusy) {
            this.adminService.setBusy(isBusy);
        };
        AdminPublishedPagesCtrl.prototype.onError = function (error) {
            this.adminService.handleError(error);
            this.setBusy(false);
        };
        AdminPublishedPagesCtrl.prototype.updateOwner = function (existing, updated) {
            existing.ownerId = updated.ownerId;
            existing.ownerName = updated.ownerName;
            existing.changedByName = updated.changedByName;
            existing.changeDate = updated.changeDate;
        };
        AdminPublishedPagesCtrl.prototype.takeOwnership = function (page) {
            var self = this;
            this.setBusy(true);
            this.adminService.updatePageOwner({ id: page.data.id }).then(function (response) {
                self.updateOwner(page.data, response.content);
                self.setBusy(false);
            }, function (e) {
                self.onError(e);
            });
        };
        AdminPublishedPagesCtrl.prototype.changeOwnership = function (page) {
            var self = this;
            this.adminService.openChangeOwnerDialog(page.data.title, page.data.ownerId, function (newOwner) {
                if (page.data.ownerId !== newOwner.value) {
                    self.setBusy(true);
                    self.adminService.updatePageOwner({ id: page.data.id, ownerId: newOwner.value }).then(function (response) {
                        self.updateOwner(page.data, response.content);
                        self.setBusy(false);
                    }, function (e) {
                        self.onError(e);
                    });
                }
            });
        };
        AdminPublishedPagesCtrl.prototype.editPageAccess = function (page) {
            var _this = this;
            this.adminService.openPageAccessDialog(page, function () {
                _this.listPublishedPages(true);
            });
        };
        AdminPublishedPagesCtrl.prototype.copyAccess = function (page) {
            var self = this;
            var adminService = self.adminService;
            adminService.setBusy(true);
            adminService.getPageAccess(page.data.id).then(function (r) {
                self.accessCopy = r.content;
                self.accessCopyPageId = page.data.id;
                adminService.setBusy(false);
            }, function (r) {
                adminService.handleError(r);
                adminService.setBusy(false);
            });
        };
        AdminPublishedPagesCtrl.prototype.applyAccessCopy = function (page) {
            var _this = this;
            var pagesToUpdate = page ? [page] : this.getSelectedRows();
            this.adminService.applyPageAccess(pagesToUpdate, this.accessCopy, function () {
                _this.listPublishedPages(true);
            });
        };
        AdminPublishedPagesCtrl.prototype.clearOrReplaceWithAccessCopy = function (isReplace, page) {
            var _this = this;
            var pagesToUpdate = page ? [page] : this.getSelectedRows();
            this.adminService.clearOrReplacePageAccess(pagesToUpdate, isReplace, function () {
                _this.listPublishedPages(true);
            }, this.accessCopy);
        };
        AdminPublishedPagesCtrl.prototype.initGrid = function () {
            var _this = this;
            var gridConstants = this.uiGridConstants;
            var adminConstants = s.AdminConstants;
            var pageActionTemplate = '<div class="ui-grid-cell-contents lm-center-text"><button type="button" ng-click="$event.stopPropagation();" class="btn-actions lm-transparent" xi-popupmenu="grid.appScope.ctrl.menuOptions">' +
                '<span class="audible">Actions</span><svg class="icon" focusable="false" aria-hidden="false"><use xlink:href="#icon-more"/></svg></button><ul class="popupmenu actions top"><li><a ng-click="grid.appScope.ctrl.editPageAccess(row.entity)">Edit Permissions</a></li>' +
                '<li ng-show="row.entity.data.hasAccess"><a ng-click="grid.appScope.ctrl.copyAccess(row.entity)">Copy Permissions</a></li><li ng-show="grid.appScope.ctrl.accessCopy && grid.appScope.ctrl.accessCopyPageId !== row.entity.data.id" class="separator"></li>' +
                '<li ng-show="grid.appScope.ctrl.accessCopy && grid.appScope.ctrl.accessCopyPageId !== row.entity.data.id"><a ng-click="grid.appScope.ctrl.applyAccessCopy(row.entity)">Apply Copied Permissions</a></li><li ng-show="grid.appScope.ctrl.accessCopy && grid.appScope.ctrl.accessCopyPageId !== row.entity.data.id && row.entity.data.hasAccess">' +
                '<a ng-click="grid.appScope.ctrl.clearOrReplaceWithAccessCopy(true, row.entity)">Replace Copied Permissions</a></li><li class="separator"></li><li><a ng-click="grid.appScope.ctrl.takeOwnership(row.entity)">Take Ownership</a></li><li><a ng-click="grid.appScope.ctrl.changeOwnership(row.entity)">Change Ownership</a></li><li class="separator"></li>' +
                '<li ng-show="row.entity.data.hasAccess"><a ng-click="grid.appScope.ctrl.clearOrReplaceWithAccessCopy(false, row.entity)">Clear Permissions</a></li><li><a ng-click="grid.appScope.ctrl.delete(row.entity)">Delete</a></li></ul></div>';
            var self = this;
            this.pagesGridOptions = {
                paginationPageSizes: [adminConstants.gridPageSize],
                paginationPageSize: adminConstants.gridPageSize,
                columnDefs: [
                    {
                        field: "data.title",
                        name: "Title",
                        sort: { direction: gridConstants.ASC, priority: 1 },
                        filter: { condition: gridConstants.filter.CONTAINS },
                        minWidth: 50, maxWidth: 600
                    },
                    { field: "data.description", name: "Description", minWidth: 50, maxWidth: 600 },
                    { field: "data.tags", name: "Tags", minWidth: 50, maxWidth: 600 },
                    { field: "data.ownerName", name: "Owner", minWidth: 50, maxWidth: 600 },
                    {
                        field: "data.changeDate",
                        name: "ChangeDate",
                        displayName: "Change date",
                        cellTemplate: "<div class='ui-grid-cell-contents'>{{COL_FIELD | lmLocaleDate}}</div>",
                        minWidth: 50,
                        maxWidth: 600
                    },
                    { field: "data.changedByName", name: "ChangedBy", displayName: "Changed by", minWidth: 50, maxWidth: 600 },
                    { field: "data.popularity", name: "UsedBy", displayName: "Used by", enableColumnResizing: false, maxWidth: 110 },
                    {
                        field: "data.hasAccess",
                        name: "Permissions",
                        enableFiltering: false,
                        enableColumnResizing: false,
                        maxWidth: 140,
                        cellTemplate: "<div class='ui-grid-cell-contents'>{{COL_FIELD ? 'Restricted' : ''}}</div>"
                    },
                    { field: "actions", name: "Actions", maxWidth: 110, cellTemplate: pageActionTemplate, enableFiltering: false, enableSorting: false, enableColumnResizing: false }
                ],
                data: [],
                rowHeight: 48,
                enableFiltering: true,
                enableSorting: true,
                enableColumnMenus: false,
                onRegisterApi: function (gridApi) {
                    self.scope["pagesGridApi"] = gridApi;
                    self.noOfSelected = 0;
                    var gridSelection = gridApi.selection;
                    var onSelection = gridSelection.on;
                    onSelection.rowSelectionChanged(_this.scope, function () {
                        self.noOfSelected = gridSelection.getSelectedRows().length;
                    });
                    onSelection.rowSelectionChangedBatch(_this.scope, function () {
                        self.noOfSelected = gridSelection.getSelectedRows().length;
                    });
                }
            };
        };
        AdminPublishedPagesCtrl.prototype.deletePublishedPage = function (pages) {
            var _this = this;
            var adminService = this.adminService;
            adminService.setBusy(true);
            var self = this;
            var pageList = pages.map(function (page) {
                return page.data.id;
            });
            this.pageService.deletePublished(pageList).then(function (r) {
                if (r.content > 0) {
                    for (var _i = 0; _i < pages.length; _i++) {
                        var page = pages[_i];
                        _this.adminService.unselectGridItem(lm.ArrayUtil.itemByPredicate(self.publishedPages, function (item) { return item.data.id === page.data.id; }), _this.scope["pagesGridApi"]);
                        lm.ArrayUtil.removeByPredicate(self.publishedPages, function (item) { return item.data.id === page.data.id; });
                    }
                }
                adminService.setBusy(false);
            }, function (r) {
                adminService.setBusy(false);
                adminService.handleError(r, r.errorText);
            });
        };
        AdminPublishedPagesCtrl.add = function (m) {
            m.controller("lmAdminPublishedPagesCtrl", AdminPublishedPagesCtrl);
        };
        AdminPublishedPagesCtrl.$inject = ["$scope", "lmAdminService", "lmAdminContext", "lmDialogService", "lmPageService", "lmCommonDataService", "uiGridConstants"];
        return AdminPublishedPagesCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        AdminPublishedPagesCtrl.add(m);
    };
});
//# sourceMappingURL=published-pages.js.map