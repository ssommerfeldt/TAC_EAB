import lm = require("./lime");
export interface IErrorState {
    error?: any;
    errorMessage?: string;
    errorCode?: string;
    hasError(): boolean;
}
export interface IUser {
    userName: string;
    firstName?: string;
    lastName?: string;
    profilePhoto?: number;
    displayName: string;
}
export interface IBookmark {
    isFolder?: boolean;
    url?: string;
    name: string;
    items?: IBookmark[];
}
export interface IMingleContext {
    type: string;
    id: string;
}
export declare class CoreBase implements IErrorState {
    logPrefix: string;
    constructor(logPrefix: string);
    hasError(): boolean;
    isDebug(): boolean;
    error(message: string, ex?: any): void;
    warning(message: string): void;
    info(message: string): void;
    debug(message: string): void;
    logResponse(response: IOperationResponse): void;
}
export interface IInstanceEvent<T> {
    on(handler: {
        (data?: T): void;
    }): Function;
    off(handler: {
        (data?: T): void;
    }): any;
}
export declare class InstanceEvent<T> implements IInstanceEvent<T> {
    private handlers;
    on(handler: {
        (data?: T): void;
    }): Function;
    off(handler: {
        (data?: T): void;
    }): void;
    raise(data?: T): void;
    clear(): void;
}
export interface IOperationResponse {
    id: string;
    content: any;
    errorList?: ErrorInfo[];
    messageList?: MessageInfo[];
    errorHttpCode?: string;
    hasError(): boolean;
    hasMessage(): boolean;
    showErrorMessages(): any;
    toErrorLog(): string;
    errorText?: string;
}
export declare class DialogResponseCode {
    static Success: number;
    static Fail: number;
}
export interface IImportOptions {
    operation: string;
    url?: string;
    title?: string;
    formFields?: IStringMap;
    buttonText?: string;
    acceptFileExtension?: string;
}
export declare class OperationResponse implements IOperationResponse {
    id: string;
    content: any;
    errorList: ErrorInfo[];
    messageList: MessageInfo[];
    errorHttpCode: string;
    constructor(content?: any);
    hasError(): boolean;
    hasMessage(): boolean;
    showErrorMessages(): void;
    toErrorLog(): string;
}
export declare class ResponseErrorCodes {
    static undefined: number;
    static unauthorized: number;
    static forbidden: number;
    static notFound: number;
    static timeout: number;
    static unavailable: number;
    static exceedsMaxSize: number;
    static tenantContextNotAvailable: number;
}
export declare class Product {
    static productName: string;
}
export declare class ErrorConstants {
    static generic: string;
    static unauthorized: string;
    static notFound: string;
    static timeout: string;
    static unavailable: string;
    static signout: string;
    static exceedsMaxSize: string;
}
export declare class MessageInfo {
    code: number;
    message: string;
    isTranslated: boolean;
}
export declare class ErrorInfo {
    code: number;
    severity: number;
    message: string;
    isTranslated: boolean;
    error: string;
}
export declare enum SettingType {
    User = 0,
    Application = 1,
}
export interface ISetting {
    changeDate: string;
    changedBy: string;
    changedByName: string;
    dataType: string;
    index: number;
    isChanged: boolean;
    label: string;
    module: string;
    readOnly: boolean;
    settingName: string;
    type: SettingType;
    value: string;
    values?: Object[];
    rules?: ISettingRule[];
    area: string;
    isVisible: boolean;
}
export interface ISettingItem {
    setting: ISetting;
    value: any;
    values?: any[];
    displayValue: any;
    rules: ISettingRule[];
    type: any;
    changeDate: string;
    changedByName: string;
    settingName: string;
    noOfRules: number;
}
export interface ISettingRule {
    affectedUsers?: number;
    changeDate: string;
    changedBy: string;
    changedByName: string;
    displayChangeDate?: string;
    isChanged: boolean;
    mode: any;
    module: string;
    name: string;
    readOnly: boolean;
    ruleConnections: ISettingRuleConnection[];
    ruleSettingId: string;
    settingName: string;
    sortOrder: number;
    value: any;
    displayValue?: any;
}
export interface ISettingRuleConnection {
    changeDate: string;
    displayChangeDate?: string;
    changedBy: string;
    changedByName: string;
    isChanged: boolean;
    isUser: boolean;
    module: string;
    name: string;
    ruleSettingId: string;
}
export interface ISettingInfo {
    dataType?: string;
    defaultValue?: any;
    isChanged?: boolean;
    isReadOnly?: boolean;
    name: string;
    type?: SettingType;
    value: any;
}
export declare enum AccessType {
    Owner = 0,
    Role = 100,
    Everyone = 200,
}
export declare enum AccessLevel {
    View = 0,
    Edit = 100,
}
export interface IEntityAccess {
    accessLevel: AccessLevel;
    principal: string;
    principalName: string;
    info: string;
    type?: PrincipalType;
}
export interface IPageAccess {
    userAccess: IStringToIEntityAccessMap;
    roleAccess: IEntityAccess[];
    pageId: string;
}
export interface IStringToIEntityAccessMap {
    [key: string]: IEntityAccess;
}
export interface IWidgetLayout {
    column: number;
    row: number;
    columnSpan: number;
    rowSpan: number;
}
export declare class WidgetLayout implements IWidgetLayout {
    column: number;
    row: number;
    columnSpan: number;
    rowSpan: number;
    constructor(column: number, row: number, columnSpan?: number, rowSpan?: number);
    static isSameCell(a: IWidgetLayout, b: IWidgetLayout): boolean;
    static isAfter(a: IWidgetLayout, b: IWidgetLayout): boolean;
    static isBefore(a: IWidgetLayout, b: IWidgetLayout): boolean;
}
export declare class WidgetType {
    static Inline: string;
    static External: string;
}
export interface IWidgetModule {
    name?: string;
    isShared?: boolean;
}
export interface IWidgetInfo {
    widgetId?: string;
    type?: string;
    version?: string;
    category?: string;
    tags?: string;
    vendor?: string;
    standardIconName?: string;
    iconFile?: string;
    title?: string;
    description?: string;
    owner?: string;
    ownerName?: string;
    standardWidgetId?: string;
    changedByName?: string;
    changeDate?: string;
    canCopy?: boolean;
    isLink?: boolean;
    displayCategory?: string;
    displayIcon?: string;
    hasRestrictions?: boolean;
    hasAccess?: boolean;
}
export interface IAddWidgetInfo {
    widgetInfo: IWidgetInfo;
    byRef: boolean;
    customWidget?: ICustomWidget;
}
export interface ICustomWidget {
    settings?: IStringToAnyMap;
    metadata?: lm.IWidgetSettingMetadata[];
    title?: string;
    titleApi?: string;
    isCatalogTitle?: boolean;
    isTitleLocked?: boolean;
    logicalId?: string;
}
export interface ISharedModule {
    name: string;
    path?: string;
}
export interface IWidgetDefinition {
    widgetId?: string;
    standardWidgetId?: string;
    type?: string;
    version?: string;
    moduleName?: string;
    url?: string;
    helpUrl?: string;
    settings?: lm.IWidgetSettingMetadata[];
    category?: string;
    enableSettings?: boolean;
    enableSettingsDef?: boolean;
    enableTitleEdit?: boolean;
    enableTitleEditDef?: boolean;
    applicationLogicalId?: string;
    applicationVersion?: string;
    sharedModules?: ISharedModule[];
    iconFile?: string;
    owner?: string;
    ownerName?: string;
    title?: string;
    description?: string;
    isPublished?: boolean;
    custom?: ICustomWidget;
    isByRef?: boolean;
    tags?: string;
    standardTitle?: string;
    lang?: any;
    localization?: any;
    modules?: IWidgetModule[];
    angularConfig?: lm.IAngularWidgetConfig;
    devPath?: string;
    accessLevel?: WidgetAccessLevel;
    standardAccessLevel?: WidgetAccessLevel;
    isCatalog?: boolean;
    original?: IWidgetDefinition;
    customMetadata?: lm.IWidgetSettingMetadata[];
    isCatalogTitle?: boolean;
}
export interface IWidgetDefinitionItem {
    definition: IWidgetDefinition;
    localization: IStringToStringMap;
    standardTitle: string;
    catalogTitle: string;
    accessLevel: WidgetAccessLevel;
    standardAccessLevel: WidgetAccessLevel;
    isCatalog: boolean;
    applications?: lm.IApplication[];
}
export interface IPublishedWidgetItem {
    definition: IWidgetDefinition;
    localization?: IStringToEntityLocalizationMap;
}
export interface IPublishWidgetOptions {
    item: IPublishedWidgetItem;
    definition?: IWidgetDefinition;
}
export interface IWidgetPublishInfo {
    publishedItem: IPublishedWidgetItem;
    isLocalizationChanged?: boolean;
    isPublish?: boolean;
}
export interface IWidgetData {
    instanceId?: string;
    id?: string;
    type?: string;
    title?: string;
    isTitleLocked?: boolean;
    titleApi?: string;
    background?: string;
    layout?: WidgetLayout;
    isEditable?: boolean;
    isBroken?: boolean;
    brokenMessage?: string;
    settings?: IStringToAnyMap;
    custom?: IPublishedWidgetItem;
    logicalId?: string;
}
export interface IWidgetParentContext {
    id?: string;
    isPublished?: boolean;
    userSettings?: IStringToAnyMap;
    addWidget(widget: IWidget): void;
}
export interface IWidget {
    id: string;
    data: IWidgetData;
    parentContext: IWidgetParentContext;
    widgetModule: any;
    definition: IWidgetDefinition;
    byRef: boolean;
    elementId: string;
    element: JQuery;
    state: string;
    isVisible: boolean;
    isEdit: boolean;
    isSettings: boolean;
    isTitleEditEnabled: boolean;
    titleApi: string;
    title: string;
    setTitleInternal(title: string): void;
    isDev: boolean;
    externalUrl: string;
    context: lm.IWidgetContext;
    widgetType: string;
    accessLevel: WidgetAccessLevel;
    instance: lm.IWidgetInstance;
    isPublished(): boolean;
    isSettingsEnabled(): boolean;
    isCatalogTitle(): boolean;
    isSettingsMenuEnabled(): boolean;
    setSettingsMenuEnabled(enabled: boolean): void;
    copyFrom(source: IWidget): void;
    enableSettingsTemporary(enable: boolean): void;
    setDefinition(definition: IWidgetDefinition, addWidgetInfo: IAddWidgetInfo): any;
    calculateTitle(isTitleLocked: boolean): string;
    updateTitle(): void;
    getDefaultTitle(): string;
    updateSettings(triggerChanged?: boolean): any;
    changed(): IInstanceEvent<IWidget>;
    raiseChanged(): void;
    remove(): void;
    removed(): IInstanceEvent<IWidget>;
    restore(): void;
    restored(): IInstanceEvent<IWidget>;
    added(): IInstanceEvent<IWidget>;
    raiseAdded(): any;
    destroyed(): IInstanceEvent<IWidget>;
    destroy(): void;
    updated(): IInstanceEvent<IWidget>;
    getUserData(): any;
    hasVisibleActions(): boolean;
    addWidgetInfo: IAddWidgetInfo;
    message?: lm.IWidgetMessage;
}
export interface IWidgetListResponse extends IOperationResponse {
    content: IWidgetInfo[];
}
export interface IWidgetInfoResponse extends IOperationResponse {
    content: IWidgetInfo;
}
export interface IGroupInfoListResponse extends IOperationResponse {
    content: IGroupInfo[];
}
export declare enum WidgetAccessLevel {
    Disabled = 0,
    View = 100,
    Configure = 200,
}
export interface IPageData {
    id?: string;
    viewAccess?: AccessType;
    editAccess?: AccessType;
    ownerId?: string;
    title?: string;
    description?: string;
    createdBy?: string;
    changedBy?: string;
    changedByName?: string;
    ownerName?: string;
    changeDate?: string;
    popularity?: number;
    widgetRefs?: IWidgetHandle[];
    tags?: string;
    sortOrder?: number;
    widgets?: IWidgetData[];
    userSettings?: any;
}
export interface IGroup {
    id: string;
    name: string;
}
export interface IGroupInfo {
    id: string;
    name: string;
}
export interface IWidgetHandle {
    id: string;
    byRef?: boolean;
}
export interface ILocalizationParameter {
    defaultLocalization: IEntityLocalization;
    localizationMap: IStringToEntityLocalizationMap;
    isWidget?: boolean;
}
export interface IEntityLocalization {
    title: string;
    description: string;
}
export interface IStringMap {
    [key: string]: string;
}
export interface IStringToAnyMap {
    [key: string]: any;
}
export interface IStringToWidgetSettingMetadata {
    [key: string]: lm.IWidgetSettingMetadata;
}
export interface IStringToEntityLocalizationMap {
    [key: string]: IEntityLocalization;
}
export interface IPage {
    title?: string;
    description?: string;
    data: IPageData;
    isMandatory?: boolean;
    isEditable?: boolean;
    isViewable?: boolean;
    userAccess?: IStringToIEntityAccessMap;
    roleAccess?: IEntityAccess[];
    widgetDefinitions?: IWidgetDefinitionItem[];
    applications?: IStringToIApplicationArrayMap;
    localization?: IStringToEntityLocalizationMap;
    settings?: IStringToAnyMap;
    changeDate?: string;
    sortOrder?: number;
}
export interface IPageInstance extends IPage {
    id: string;
    widgets: IWidget[];
    noOfWidgets(): number;
    add(widget: IWidget): void;
    afterPublishedStandard(widget: IWidget, definition: IWidgetDefinition): void;
    remove(widget: IWidget): void;
    removed(): IInstanceEvent<IPageInstance>;
    changed(): IInstanceEvent<IPageInstance>;
    widgetAdded(): IInstanceEvent<IWidget>;
    widgetsAddedCount: number;
    show(): void;
    hide(): void;
    destroy(): void;
    isPublishEnabled(): boolean;
    isPublished(): boolean;
    toggleEditMode(isEdit: boolean): void;
    notifyPublishingMode(): void;
    updateWidgets(editedWidgets: IEditableWidget[], isSave: boolean): void;
    getWidgetParentContext(widget?: IWidgetData): any;
    getWidgetByInstanceId(instanceId: string): IWidget;
    getWidgetUserSettings(): any;
    setWidgetUserSettings(data: any): boolean;
    createSavePageData(): IPageData;
}
export interface IEditModeStartOptions {
    mode: string;
    title?: string;
    submode?: string;
    parameter?: any;
    actions?: ICommandBarAction[];
    secondaryActions?: ICommandBarAction[];
    commandText?: string;
}
export interface IEditModeStopOptions {
    isSave: boolean;
    result?: any;
}
export declare class EditModes {
    static none: string;
    static layout: string;
    static widget: string;
    static page: string;
    static preview: string;
}
export declare class EditSubmodes {
    static publish: string;
    static republish: string;
    static publishCopy: string;
}
export interface IEditModeService {
    start(options: IEditModeStartOptions): void;
    stop(options: IEditModeStopOptions): void;
    isActive(): boolean;
    containsMode(mode: string): boolean;
    isMode(mode: string): boolean;
    getCurrent(): IEditMode;
    started(): IInstanceEvent<IEditMode>;
    stopped(): IInstanceEvent<IEditMode>;
    changed(): IInstanceEvent<IEditMode>;
}
export interface IEditMode extends IEditModeStartOptions, IEditModeStopOptions {
    isActive: boolean;
}
export interface IEditableWidgetStyle {
    left: string;
    top: string;
}
export interface IEditableWidget {
    id?: string;
    title?: string;
    layout: IWidgetLayout;
    style?: IEditableWidgetStyle;
    isPlaceholder?: boolean;
    elementId?: string;
    widget?: IWidget;
}
export interface IPageContainerData {
    tenantId?: string;
    userId?: string;
    userName?: string;
    isAdministrator?: boolean;
    isPageAdministrator?: boolean;
    isCloud?: boolean;
    pingInterval?: number;
    version?: string;
    selectedId?: string;
    pages?: IPage[];
    userSettings?: ISettingInfo[];
    applicationSettings?: ISettingInfo[];
    widgetDefinitions?: IWidgetDefinitionItem[];
    configuration?: IConfigurationData;
}
export interface IContextService {
    getContext(): IContext;
}
export interface IPageContainer extends IErrorState {
    context: IContext;
    data: IPageContainerData;
    pages: IPageInstance[];
    selectedPage: IPageInstance;
    add(pageData: IPageData, showToastConfirmation: boolean, definitions?: IWidgetDefinition[], applicationConfig?: IStringToIApplicationArrayMap): any;
    remove(page: IPageInstance): ng.IPromise<IOperationResponse>;
    removeAllPagesFromClient(): void;
    reorder(order: string[]): ng.IPromise<IOperationResponse>;
    delete(pageId: string, name: string, isShared: boolean): ng.IPromise<IOperationResponse>;
    publish(page: IPage, isUpdate?: boolean): any;
    contains(id: string): boolean;
    editPageConfiguration(isUpdate?: boolean): any;
    refresh(): any;
    saveCurrent(): ng.IPromise<IOperationResponse>;
    saveAndRefreshCurrent(): void;
    onCancelPublish(): any;
    create(pageData: IPageData): any;
    selected(): IInstanceEvent<IPageInstance>;
    added(): IInstanceEvent<IPageInstance>;
    changed(): InstanceEvent<IPageContainer>;
    refreshed(): InstanceEvent<IPageContainer>;
    select(pageId: string): void;
    showAddPage(): void;
    showPageInformation(id: string): any;
    showPageLibrary(): any;
    addExistingPage(page: IPage, showToastConfirmation: boolean, isCopy?: boolean, copyTitle?: string, busyCallback?: Function): void;
    copyPage(page: IPage, showToastConfirmation: boolean, fromPreview: boolean, busyCallback?: Function): void;
    openImportPageDialog(): ng.IPromise<lm.IDialogResult>;
    showAboutPage(): void;
    previewPage(pageId: string, external: boolean): void;
    destroy(): void;
}
export interface IContext {
    init(container: IPageContainerData, containerUrl: string): any;
    isBusy(): boolean;
    setBusy(isBusy: boolean): void;
    isCloud(): boolean;
    getUserId(): string;
    getTenantId(): string;
    getVersion(): string;
    isAdministrator: boolean;
    isPageAdmininistrator: boolean;
    isCurrentUser(user: string): boolean;
    isDev: boolean;
    settings: IServerSettings;
    getConfiguration(): IConfiguration;
    isOperationEnabled(page: IPageData, settingValue: boolean): any;
    getLanguage(): string;
    getContainerUrl(): string;
}
export interface IPageService {
    createPrivate(page: IPageData): ng.IPromise<IPageResponse>;
    update(page: IPageData): ng.IPromise<IOperationResponse>;
    updateSettings(page: IPageData): ng.IPromise<IPageDataResponse>;
    delete(id: string): ng.IPromise<IOperationResponse>;
    getPublished(id: string): ng.IPromise<IPageResponse>;
    getPublishedExtended(pageId: string): ng.IPromise<IPageResponse>;
    listPublished(reload: boolean): ng.IPromise<IPageListResponse>;
    updatePublished(page: IPage): ng.IPromise<IPageDataResponse>;
    deletePublished(pages: string[]): ng.IPromise<IIntegerResponse>;
    addConnection(id: string, asTemplate: boolean, sortOrder: number, templateTitle?: string): ng.IPromise<IPageResponse>;
    reorderConnections(pages: string[]): ng.IPromise<IOperationResponse>;
    updateConnectionSettings(pageId: string, settings: any): ng.IPromise<IOperationResponse>;
    removeConnection(id: string): ng.IPromise<IOperationResponse>;
    handleError(response: IOperationResponse, message?: string): any;
    getPreview(pageId: string): ng.IPromise<IPageResponse>;
    invalidatePageCache(): void;
}
export interface IPageResponse extends IOperationResponse {
    content: IPage;
}
export interface IPageDataResponse extends IOperationResponse {
    content: IPageData;
}
export interface IPageListResponse extends IOperationResponse {
    content: IPage[];
}
export interface IStringResponse extends IOperationResponse {
    content: string;
}
export interface IGroupListResponse extends IOperationResponse {
    content: IGroup[];
}
export interface IBookmarkResponse extends IOperationResponse {
    content: IBookmark[];
}
export interface IUserListResponse extends IOperationResponse {
    content: IUser[];
}
export interface IEntityListResponse extends IOperationResponse {
    content: lm.IAutocompleteEntity[];
}
export interface ILanguagueResponse extends IOperationResponse {
    content: IStringMap;
}
export interface IApplicationResponse extends IOperationResponse {
    content: lm.IApplication[];
}
export interface IEntityLocalizationResponse {
    content: IStringToEntityLocalizationMap;
}
export interface IIntegerResponse extends IOperationResponse {
    content: number;
}
export interface IPageAccessResponse extends IOperationResponse {
    content: IPageAccess;
}
export interface IServerSettings {
    isAdministrator(): boolean;
    isPageAdministrator(): boolean;
    isWidgetEnabled(type: string): any;
    isPrivatePagesEnabled(): boolean;
    isSelectHomepageEnabled(): boolean;
    getMaxUserPageCount(): number;
    isPagePublishEnabled(): boolean;
    getLogLevel(): number;
    isPublicPageAddEnabled(): boolean;
    isPublicPageCopyEnabled(): boolean;
    isWidgetPublishEnabled(): boolean;
    isPageCatalogEnabled(): boolean;
    getCanAddPrivatePage(userPageCount: number): boolean;
    getCanAddFavoritePage(userPageCount: number): boolean;
    isPageExportEnabled(): boolean;
    isPageImportEnabled(): boolean;
    getStartPage(): string;
    setStartPage(value: string): any;
    saveUserSettings(): ng.IPromise<IStringResponse>;
    isContentTranslationEnabled(): boolean;
    getDefaultLanguage(): string;
    applicationSettings?: Array<IApplicationSetting>;
}
export interface IApplicationSetting {
    name: string;
    value: any;
}
export interface IInteractionHandler {
    showError(message: string, header?: string): any;
    isBusy(): boolean;
    setBusy(value: boolean): any;
}
export interface IDevConfiguration {
    devData: DevConfigurationData;
    id?: string;
    definition?: IWidgetDefinition;
    container?: IPageContainerData;
    initPage(page: IPageData): void;
    load(id: string): IPageContainerData;
    save(): any;
    clear(): any;
}
export declare class DevConfiguration extends CoreBase implements IDevConfiguration {
    devData: DevConfigurationData;
    id: string;
    definition: IWidgetDefinition;
    container: IPageContainerData;
    private isPersistent;
    private storagePrefix;
    constructor();
    initPage(page: IPageData): void;
    private getKey();
    load(id: string): IPageContainerData;
    clear(): void;
    save(): void;
}
export declare class DevConfigurationData {
    widgetId: string;
    settingsPath: string;
    settings: any;
    propSettings: string;
    configurationPath: string;
    configuration: IConfigurationData;
    propConfiguration: string;
    widgetDefinition: IWidgetDefinition;
    propWidgetDefinition: string;
    customDefinitionPath: string;
    customDefinition: IWidgetDefinition;
    propCustomDefinition: string;
}
export declare class ClientConfiguration {
    private static url;
    private static local;
    private static logicalId;
    static dev: IDevConfiguration;
    static overrideUrl(url: string): void;
    static initialize(location: ng.ILocationService): void;
    static getLogicalId(): string;
    static isLocal(): boolean;
    static initDevConfiguration(devData: DevConfigurationData): void;
    static getUrl(): string;
    static isDev(): boolean;
}
export declare class SettingsNames {
    static defaultPage: string;
    static defaultLanguage: string;
    static enablePageCatalog: string;
    static mandatoryPages: string;
    static enablePagePublish: string;
    static enablePrivatePages: string;
    static maxUserPageCount: string;
    static enableAddPublishedPage: string;
    static enableDuplicatePublishedPage: string;
    static enableSelectHomepage: string;
    static enablePageExport: string;
    static enablePageImport: string;
    static enableWidgetPublish: string;
    static enableContentTranslation: string;
    static startPage: string;
    static logLevel: string;
}
export declare class Constants {
    static applicationName: string;
    static restRoot: string;
    static webRoot: string;
    static mingleLocale: string;
    static mingleLanguage: string;
    static mingleTimeZone: string;
    static mingleThemeName: string;
    static useHttps: string;
    static scheme: string;
    static tenantId: string;
    static userid: string;
    static language: string;
    static safeMode: string;
    static groupEveryone: string;
    static configurationSettings: string;
    static configurationProperties: string;
    static configurationApplication: string;
    static configurationApplicationPrefix: string;
    static configurationFrameworkPrefix: string;
    static configurationLocalizationPrefix: string;
    static configurationPropertyPrefix: string;
    static configurationViewPrefix: string;
    static configurationWidgetPrefix: string;
    static configurationPrefixes: string[];
    static widgetTitleLength: number;
    static widgetDescriptionLength: number;
    static pageTitleLength: number;
    static pageDescriptionLength: number;
    static pageArea: number;
    static widgetArea: number;
    static commonArea: number;
    static allArea: number;
    static modalPageAbout: string;
    static modalPagePublish: string;
    static modalWidgetCustomize: string;
    static contextualActionPanelId: string;
    static adminCacheStandardWidgets: string;
    static adminCachePublishedWidgets: string;
    static adminCachePublishedPages: string;
    static adminCacheProperties: string;
    static adminCachePrivatePages: string;
    static adminCacheRoles: string;
    static clientCacheWidgets: string;
    static clientCachePages: string;
    static cacheLifetime: number;
    static widgetModuleDefaultName: string;
    static sharedLimeLanguageConstants: string[];
    static tagsMaxCount: number;
    static mingleWebWidgetID: string;
    static settingsNameWidgetTitle: string;
}
export interface ICacheService {
    createCache(name: string): IDataListCache;
    updateCache(cache: IDataListCache, response: IOperationResponse, deferred?: ng.IDeferred<any>): any;
}
export declare class Templates {
    static autocompleteEntity: string;
}
export declare class WidgetCategory {
    static BusinessProcess: string;
    static Application: string;
    static Social: string;
    static Utilities: string;
    static BusinessIntelligence: string;
    static All: string;
}
export interface IProgressService {
    isBusy(): boolean;
    setBusy(isBusy: boolean): void;
}
export interface IDataService {
    startPing(pingInterval: number): void;
    setLanguage(language: string): void;
    executeGet(resource: string, parameters?: any): ng.IPromise<IOperationResponse>;
    executePost(resource: string, request?: any, parameters?: any): ng.IPromise<IOperationResponse>;
    getUrl(path?: string): string;
    upload(operationUrl: string, operation: string, files: any[], formFields?: IStringMap): ng.IPromise<IOperationResponse>;
    handleError(response: IOperationResponse, message?: string): void;
}
export interface ICommonDataService {
    getApplication(logicalIdPrefix: string): ng.IPromise<IApplicationResponse>;
    handleError(response: IOperationResponse, message?: string): any;
    listBookmarks(): ng.IPromise<IBookmarkResponse>;
    listGroups(): ng.IPromise<IGroupListResponse>;
    listLanguages(): ng.IPromise<ILanguagueResponse>;
    searchUsers(query: string): ng.IPromise<IUserListResponse>;
    searchGroups(query: string): ng.IPromise<IGroupListResponse>;
    searchEntities(query: string): ng.IPromise<IEntityListResponse>;
}
export interface IOperationRequest {
    id: string;
}
export interface IWidgetService {
    loadWidget(widget: IWidgetData): ng.IPromise<IWidget>;
    listWidgets(reload: boolean): ng.IPromise<IWidgetListResponse>;
    getCachedDefinition(id: string): IWidgetDefinition;
    getDefinition(id: string): ng.IPromise<IWidgetDefinition>;
    addDefinitions(list: IWidgetDefinition[]): any;
    addDefinitionItem(item: IWidgetDefinitionItem): IWidgetDefinition;
    removeDefinition(widgetId: string): any;
    addWidgetCopyToPage(context: IWidgetParentContext, addWidgetInfo: IAddWidgetInfo): ng.IPromise<IWidget>;
    preAddWidget(context: IWidgetParentContext, addWidgetInfo: IAddWidgetInfo, busyCallback?: Function): ng.IPromise<IWidget>;
    getAddWidgetInfo(widget: IWidget): IAddWidgetInfo;
    showSettings(widget: IWidget, data?: any, isWidgetUnlocked?: boolean): ng.IPromise<lm.IDialogResult>;
    showCatalog(context: IWidgetParentContext, callback?: Function): ng.IPromise<IWidget>;
    getPublished(id: string): ng.IPromise<IPublishedWidgetItem>;
    publish(item: IPublishedWidgetItem): ng.IPromise<IStringResponse>;
    updatePublished(item: IPublishedWidgetItem): ng.IPromise<IStringResponse>;
    deletePublished(widgets: string[]): ng.IPromise<IIntegerResponse>;
    exportWidget(widgetData: IWidgetData): string;
    updatePublishedOwner(widgetId: string, ownerId: string): ng.IPromise<IWidgetInfoResponse>;
    handleError(response: IOperationResponse, message?: string): any;
    createImagePath(widget: IWidgetInfo): string;
    invalidateWidgetCache(): void;
    closeCatalog(dialog: IContextualActionPanel): void;
}
export interface IContextualActionPanel {
    destroy(): void;
}
export interface IStringToStringMap {
    [key: string]: String;
}
export interface IStringtoDefinitionMap {
    [key: string]: IWidgetDefinition;
}
export interface IStringToIApplicationArrayMap {
    [key: string]: lm.IApplication[];
}
export interface IConfigurationData {
    applications?: IStringToIApplicationArrayMap;
    properties: IStringToStringMap;
    ionApiCustomerContext: string;
    ionApiUrl: string;
    ionApiToken: string;
}
export interface IConfiguration {
    applications?: IStringToIApplicationArrayMap;
    properties: IStringToStringMap;
    ionApiCustomerContext: string;
    addApplication(application: lm.IApplication): void;
    addApplications(applications: lm.IApplication[]): void;
    addApplicationMap(applications: IStringToIApplicationArrayMap): void;
    getApplication(logicalId: string): ng.IPromise<lm.IApplication>;
    getApplicationCached(logicalId: string): lm.IApplication;
    getApplications(logicalId: string): ng.IPromise<lm.IApplication[]>;
    getApplicationsCached(logicalId: string): lm.IApplication[];
    getIonApiContextAsync(options: lm.IIonApiOptions): ng.IPromise<lm.IIonApiContext>;
    executeIonApiAsync<T>(options: lm.IIonApiRequestOptions): ng.IPromise<ng.IHttpPromiseCallbackArg<T>>;
}
export interface IApplicationView {
    viewId: string;
    urlTemplate: string;
}
export interface ITagService {
    deleteTag(allTags: string, tagToDelete: string): string;
    isTagValid(tag: string): IIsTagValidResponse;
    addTag(allTags: string, tag: string): any;
    areTagsValid(tags: string): any;
}
export interface IIsTagValidResponse {
    isValid: boolean;
    errorMsg?: string;
}
export interface IAreTagsValidResponse {
    areValid: boolean;
    errorMsg?: string;
}
export interface IAddTagResponse {
    allTags: string;
    hasError: boolean;
    errorMsg?: string;
}
export interface ILanguageService {
    getLanguage(): ILanguageLime;
    get(name: string): string;
}
export declare class UniqueError {
    static failedToAddMaxUserPagesReached: number;
}
export declare class EntityCategory {
    static standardWidget: number;
    static publishedWidget: number;
    static publishedPage: number;
    static privatePage: number;
    static adHocProperties: number;
}
export declare enum PrincipalType {
    MingleGroup = 0,
    User = 1,
    Role = 2,
}
export interface IDataListCache {
    name: string;
    isValid: boolean;
    cachedResponse: IOperationResponse;
    timeoutId: number;
}
export interface ICommandBarAction extends lm.IWidgetAction {
    cssClass?: string;
}
export declare class CoreUtil {
    static getEntityArray(array: any[]): lm.IAutocompleteEntity[];
}
export declare class UIUtil {
    static removePopupMenus(element: JQuery): void;
}
export declare class HttpUtil {
    static parseQuery(query: string): any;
    static combine(url1: string, url2: any): string;
}
export declare var init: (m: ng.IModule) => void;
