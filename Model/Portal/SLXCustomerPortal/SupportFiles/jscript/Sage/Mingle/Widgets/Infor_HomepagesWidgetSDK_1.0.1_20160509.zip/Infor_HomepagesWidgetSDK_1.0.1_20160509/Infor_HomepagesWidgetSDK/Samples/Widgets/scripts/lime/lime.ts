﻿/// <reference path="../typings/jquery/jquery.d.ts" />
/// <reference path="../typings/angularjs/angular.d.ts" />
/// <reference path="../typings/sohoxi/sohoxi.d.ts" />

/**
 * Represents configuration data for an application in Ming.le.
 * 
 * @since 1.0
 */
export interface IApplication {
	/**
	 * Gets a value that indicates if this application instance is the default one.
	 */
	isDefault: boolean;

	/**
	 * Gets the application version.
	 */
	version: string;

	/**
	 * Gets the product name.
	 */
	productName: string;

	/**
	 * Gets the tenant ID.
	 */
	tenantId: string;

	/**
	 * Gets the logical ID prefix.
	 */
	logicalIdPrefix: string;

	/**
	 * Get the logical ID for the application instance.
	 */
	logicalId: string;

	/**
	 * Gets the hostname.
	 */
	hostname: string;

	/**
	 * Get the URL context.
	 */
	context: string;

	/**
	 * Gets the port number.
	 */
	port: number;

	/**
	 * Gets a value that indicates if HTTPS should be used.
	 */
	useHttps: boolean;
}

/**
 * Represents localized language constants.
 * @since 1.0
 */
export interface ILanguage {

	/**
	 * Gets a language constant with the given ID.
	 * @param id The language constant ID.
	 * @return Gets the language constant or null if it does not exist.
	 */
	get(id: string): string;

	/**
	 * Shared lime language constants. 
	 *
	 * The following language constants will always be available to use from the widget.
	 * Constants listed here does not have to be specified & localized in the widget manifest.
	 */

	/**
	 * OK
	 */
	ok: string;
	/**
	 * Cancel
	 */
	cancel: string;
	/**
	 * Yes
	 */
	yes: string;
	/**
	 * No
	 */
	no: string;
	/**
	 * Refresh
	 */
	refresh: string;
	/**
	 * Add
	 */
	add: string;
	/**
	 * Save
	 */
	save: string;
	/**
	 * Delete
	 */
	delete: string;
	/**
	 * Name
	 */
	name: string;
	/**
	 * Url
	 */
	url: string;
	/**
	 * Edit
	 */
	edit: string;
}

/**
 * Represents a widget module.
 * 
 * A widget module must implement a widget factory function called widgetFactory.
 * The funciton signature of the widget factory function is defined in this interface.
 * @since 1.0
 */
export interface IWidgetModule {
	/**
	 * Creates a new widget instance.
	 * 
	 * @param context The widget context.
	 * @returns An object representing the widget instance.
	 */
	widgetFactory(context: IWidgetContext): IWidgetInstance;
}

/**
 * Defines widget states.
 * @since 1.0
 */
export class WidgetState {
	/**
	 * Running state.
	 * 
	 * The running state is the default widget state.
	 */
	public static running = "running";

	/**
	 * Busy state.
	 * 
	 * The busy state can be used to indicate that the widget is busy performing an operation 
	 * such as a server request.
	 */
	public static busy = "busy";

	/**
	 * Error state.
	 * 
	 * The error state indicates that the widget is broken in some way and is not functioning properly.
	 * There could be different reasons for this such as missing settings or that a backend service cannot be reached for example.
	 */
	public static error = "error";
}

/**
 * Represents a widget activation or deactivation.
 * @since 1.0
 */
export interface IWidgetActivationArg {
	/**
	 * Gets the type of activation.
	 * 
	 * Activation types are defined in [[WidgetActivationType]].
	 */
	type: string;

	/**
	 * Gets a value that indicates if the widget is new.
	 * 
	 * A widget is considered to be new if it has been added from the widget library.
	 */
	isNew?: boolean;
}

/**
 * Represents the widget settings close event.
 * @since 1.0
 */
export interface IWidgetSettingsCloseArg {
	/**
	 * Gets a value that indicates if the widget settings was saved.
	 * 
	 * If the value is false the settings were cancelled.
	 */
	isSave: boolean;

}

/**
 * Defines widget activation and deactivation types.
 * 
 * The activation types indicates what caused a widget to be activated or deactivated.
 * Most types can be used for both activation and deactivation but close for example can only be used in deactivation.
 * 
 * @since 1.0
 */
export class WidgetActivationType {
	/**
	 * The widget visibility has been changed.
	 */
	public static visibility = "visibility";

	/**
	 * The widget has been closed.
	 */
	public static close = "close";

	/**
	 * The widget settings dialog has been opened or closed.
	 */
	public static settings = "settings";

	/**
	 * The widget has entered or exited edit mode.
	 */
	public static edit = "edit";
}

/**
 * Angular scope value.
 * 
 * @since 1.0
 */
export interface IAngularScopeValue {
	/**
	 * Name of the scope value.
	 */
	name: string;
	/**
	 * Scope value.
	 */
	value: any;
}

/**
 * Represents a cached AngularJS template.
 * 
 * @since 1.0
 */
export interface IAngularTemplateInfo {
	/**
	 * Gets or sets the template key. 
	 * 
	 * The key is usually a HTML file name including a path.
	 * The key must be unique to avoid conflicts between templates from different widgets. 
	 * The key should in most cases include the widget ID somehow to ensure that is is unique.
	 * The [[IAngularContext]].getTemplateUrl function can be used to get a unique template key.
	 */
	key: string;

	/**
	 * Gets or sets a HTML template string.
	 */
	value: string;
}

/**
 * Represents the configuration for a widget implemented using AngularJS.
 * 
 * When this configuration is used the framework will create the widget UI using a template or a template URL.
 * The widget factory should not modify the parent DOM element directly when IAngularWidgetConfig is used.
 * 
 * Only one of the properties defined in this interface should be set since they are mutually exclusive.
 * If more than one property is set the order of evaluation is template, cachedTemplateUrl, relativeTemplateUrl.
 * 
 * This relativeTemplateUrl property is mainly intended for development purposes. In a production environment
 * the widget code and any HTML templates should be optimized and minimized into a single file. The template, templates and
 * cachedTemplateUrl URL properties should be used when a widget is minimized into a single file.
 *
 * A widget can check if it is running in development mode or not using the [[IWidgetContext]].isDev() function.
 * 
 * @since 1.0
 */
export interface IAngularWidgetConfig {
	/**
	 * Gets or sets an AngularJS HTML template string.
	 * 
	 * This property can be used by a widget that has a single template that is constructed or cached in the widget code.
	 * This property can also be used in combination with the templates property. A widget could set the main template
	 * using the template property and additional templates using the templates property.
	 */
	template?: string;

	/**
	 * Gets or sets an array of AngularJS templates that will be added to the AngularJS template cache.
	 * 
	 * This property can be used by widgets that have more than one template that needs to be cached.
	 * 
	 * All templates in the array will be added to the AngularJS template cache unless they already exists.
	 * A template provided in this array can be used with the cachedTemplateUrl property.
	 */
	templates?: IAngularTemplateInfo[];

	/**
	 * Gets or sets the URL for a cached AngularJS template.
	 * 
	 * The template must exist in the AngularJS template cache when the widget is created. 
	 * A template can be added to the AngularJS template cache using the templates property. The framework will 
	 * ensure that the templates are added to the AngularJS template cache before the cachedTemplateUrl is used
	 * to create the widget.
	 * 
	 * The value for this property should in most cases be created using the The [[IAngularContext]].getTemplateUrl function 
	 * to ensure that the template key is unique.
	 */
	cachedTemplateUrl?: string;

	/**
	 * Gets or sets the relative URL for a AngularJS template file.
	 * 
	 * The URL should be relative to the widget directory. 
	 * The framework will create the correct absolute URL in runtime.
	 */
	relativeTemplateUrl?: string;

	/**
	 * Angular scope value.
	 */
	scopeValue?: IAngularScopeValue;
}

/**
 * Represents the AngularJS context for widgets implemented using AngularJS.
 * 
 * @since 1.0
 */
export interface IAngularContext {

	/**
	 * Gets the AngularJS module.
	 */
	module: ng.IModule;

	/**
	 * Gets the widget scope.
	 */
	scope: ng.IScope;

	/**
	 * Gets the compile service.
	 * 
	 * The compile service can be used when content is added explicitly to the widget DOM element.
	 */
	compile: ng.ICompileService;

	/**
	 * Gets an absolute template URL to a template file in the widget directory.
	 * @param relativeUrl The relative path to the template file.
	 */
	getTemplateUrl(relativeUrl: string): string;
}

/**
 * Represents a custom widget action.
 * 
 * Custom widget action will be displayed in the widget menu.
 * 
 * @since 1.0
 */
export interface IWidgetAction {
	/**
	 * Gets or sets the text to display for the action.
	 */
	text?: string;

	/**
	 * Gets or sets a function that will be called when the action is executed by the user.
	 */
	execute?: Function;

	/**
	 * Gets or sets a value that indicates if the action is enabled or not.
	 * 
	 * The default value is true.
	 */
	isEnabled?: boolean;


	/**
	 * Gets or sets a value that indicates if the action is visible or not.
	 * 
	 * The default value is true.
	 */
	isVisible?: boolean;

	/**
	 * Gets or sets a value that indicates if the action represents a separator or not.
	 * 
	 * The default value is false.
	 */
	isSeparator?: boolean;

	/**
	 * Gets or sets a value that indicates if the action is primary and should be shown in the widget header.
	 * If an action is primary, it has to be set on the widget instance before it's returned from the widget factory	 
	 */
	isPrimary?: boolean;

	/**
	 * Gets or sets a SoHo Xi icon name to use if it is a primary widget header action (ex. "#icon-delete").
	 * 	 
	 */
	standardIconName?: string;

	/**
	 * Gets or sets a custom svg icon name to use if it is a primary widget header action.
	 * 	 
	 */
	customIconName?: string;
}

/**
 * A message type used to display inline widget messages.
 * 
 * @since 1.0
 */
export interface IWidgetMessage {
	/**
	 * The plain text message to display
	 */
	message: string;

	/**
	 * Type defines severity and how the message looks like.
	 */
	type: WidgetMessageType;

	/**
	 * Override logic for the X (Close) button on the message
	 * If used, the message needs to be removed using IWidgetContext.removeWidgetMessage().
	 */
	onClose?: Function;
}

/**
 * Used to define severity in IWidgetMessage.
 * 
 * @since 1.0
 */
export enum WidgetMessageType {
	/**
	 * Information message.
	 */
	Info = 0,

	/**
	 * Alert message.
	 */
	Alert = 1,

	/**
	 * Error message.
	 */
	Error = 2
}

/**
 * Represents a widget instance.
 * 
 * An object of this type should be returned by the widgetFactory function in the widget module.
 * All properties in this interface are optional however so it is OK to return an empty object.
 * 
 * A widget implementation may choose which properties to set depending on what types of callbacks the widget requires.
 * 
 * @since 1.0
 */
export interface IWidgetInstance {

	/**
	 * Optional event function that will be called when the widget is activated.
	 * 
	 * A widget is activated when it is shown, the settings dialog is closed open or the widget is no longer in edit mode.
	 */
	activated?: (arg: IWidgetActivationArg) => void;

	/**
	 * Optional event function that will be called when the widget is deactivated.
	 * 
	 * A widget is deactivated when it is not visible, the settings dialog is open or the widget is in edit mode.
	 */
	deactivated?: (arg: IWidgetActivationArg) => void;

	/**
	 * Optional event function that will be called before the settings dialog for a widget is opened.
	 */
	settingsOpening?: (arg: IWidgetSettingsArg) => void;

	/**
	 * Optional event function that will be called when settings are saved for a widget.
	 */
	settingsSaved?: (arg: IWidgetSettingsArg) => void;

	/**
	 * Optional function that gets settings metadata for a widget with dynamic settings metadata.
	 * 
	 * If this function returns an array with at least one item the existing settings metadata will be overridden.
	 * This function will be called by the framework when settings metadata is required such as when opening the settings dialog
	 * or publishing a widget. A widget that defines settings in the manifest should normally not implement this function.
	 * 
	 * @returns An array with metadata for each setting.
	 */
	getMetadata?: () => IWidgetSettingMetadata[];

	/**
	 * Optional event function that will be called when the widget enters edit mode.
	 */
	editing?: () => void;

	/**
	 * Optional event function that will be called when the widget exits edit mode.
	 */
	edited?: () => void;

	/**
	 * Gets or sets an optional event function that will be called when the widget enters publish widget mode.
	 */
	publishing?: () => void;

	/**
	 * Gets or sets an optional configuration for a widget implemented using AngularJS.
	 * 
	 * This property should not be used if content is added to the element property in IWidgetContext.
	 */
	angularConfig?: IAngularWidgetConfig;

	/**
	 * Gets or sets an optional factory function for creating a custom settings UI.
	 * 
	 * Set this function to create custom conent in the widget settings dialog. 
	 * The custom content should contain everthing except the save and cancel buttons that are are handled by the framework. 
	 * The custom dialog content can be created with AngularJS or with jQuery.
	 * 
	 * To hande the complete dialog use the settingsOpening event and cancel the settings and then open your own dialog.
	 */
	widgetSettingsFactory?: (context: IWidgetSettingsContext) => IWidgetSettingsInstance;

	/**
	 * Gets or sets an optional array of custom widget actions that will be displayed in the widget menu.
	 */
	actions?: IWidgetAction[];
}

/**
 * Represent options for the settingsOpening and settingsSaved event functions defined in [[IWidgetInstance]].
 * 
 * @since 1.0
 */
export interface IWidgetSettingsArg {
	/**
	 * Gets the widget settings.
	 * 
	 * These are the same settings that are available on the [[IWidgetContext]].
	 */
	settings: IWidgetSettings;

	/**
	 * Gets an optional data parameter.
	 * 
	 * This property will only be available if the settings were opened using 
	 * the showSettings function on the [[IWidgetContext]] and a data parameter was set on the [[IShowSettingsOptions]].
	 */
	data?: any;

	/**
	 * Gets a value that indicates that the standard settings dialog should be cancelled.
	 * 
	 * The default value is false.
	 * 
	 * This property can be set to true by widgets that have a completely custom settings UI including dialog management.
	 */
	cancel?: boolean;
}

/**
 * Represents metadata for a widget setting.
 * 
 * @since 1.0
 */
export interface IWidgetSettingMetadata {
	/**
	 * Gets or sets the name of the setting.
	 */
	name: string;

	/*
	 * Gets or sets the settings value type defined in [[WidgetSettingsType]].
	 */
	type?: string;

	/**
	 * Gets or sets the default value for the setting if not changed.
	 */
	defaultValue?: string;

	/**
	 * Gets or sets the ID of a label to translate. If no translation is found the text will be used. Label for settings UI.
	 */
	labelId?: string;

	/**
	 * Gets or sets a value that indicates if the setting should be visible in the widget settings UI. The default value is true.
	 * The value of this property will not have any effect if the isHidden property is set to false.
	 */
	isVisible?: boolean;

	/**
	 * Gets or sets a value that indicates if the setting is hidden. The default value is false. A setting that is hidden will always be hidden and setting the
	 * isVisible property will not have any effect. When a setting is hidden it will not be possible to configure the setting visibility when publishing a
	 * widget. 
	 */
	isHidden?: boolean;

	/**
	 * Gets or sets a value that indicates if the setting is enabled. The default value is true. 
	 * A setting might be disabled for a published widget or a widget on a published page. 
	 * Settings will always be enabled on a private page.
	 */
	isEnabled?: boolean;

	/**
	 * Gets or sets the maximum length for string values.
	 */
	maxLength?: number;

	/**
	 * Gets or sets an array of values for a selector type setting.
	 */
	values?: IValueItem[];
}

/**
 * Represents the different types of widget settings. All except the object type are supported in the metadata settings UI.
 * 
 * @since 1.0
 */
export class WidgetSettingsType {
	static stringType = "string";
	static numberType = "number";
	static booleanType = "boolean";
	static selectorType = "selector";
	static objectType = "object";
}

/**
 * An entity optimized for usage with the autocomplete control.
 * @since 1.0
 */
export interface IAutocompleteEntity {
	/**
	 * The visible text.
	 */
	label: string;

	/**
	 * An optional value of the item.
	 */
	value?: any;

	/**
	 * An optional secondary string.
	 */
	info?: string;

	/**
	 * Additional optional property to separate different types.
	 */
	type?: any;
}

/**
 * Represents an item for a selector setting.
 * 
 * @since 1.0
 */
export interface IValueItem {
	/**
	 * Gets or sets a language constant ID for the item text.
	 * 
	 * Use this property or the text property, not both.
	 */
	textId?: string;

	/**
	 * Gets or sets the item text.
	 * 
	 * Use this property or the textId property, not both.
	 */
	text?: string;

	/**
	 * Gets or sets the value.
	 */
	value: string;
}

/**
 * Represents options for a widget settings dialog.
 * 
 * @since 1.0
 */
export interface IShowSettingsOptions {
	/**
	 * Gets or sets an optional data object.
	 */
	data?: any;
}

/**
 * Represents options for getting an application view URL.
 * 
 * @since 1.0
 */
export interface IViewUrlOptions {
	/**
	 * Gets or sets the view ID.
	 */
	viewId: string;

	/**
	 * Gets or sets an optional application logical ID or logical ID prefix.
	 * 
	 * If no value is specified the default application is used.
	 */
	logicalId?: string;

	/**
	 * Gets or sets a value that indicates if the URL template should be resolved by replacing values.
	 * 
	 * The default value is true. This property can be set to false to get the original URL template without replacing values.
	 */
	resolve?: boolean;
}

/**
 * Represents options used when getting an IonApiContext.
 * 
 * @since 1.0
 */
export interface IIonApiOptions {
	/**
	 * Gets or sets an optional value that indicates if the ION API token should be refreshed or not.
	 * 
	 * The default value is false. This property should only be set to true if the current token is invalid.
	 * An ION API call will return HTTP 401 when the token is invalid.
	 */
	refresh?: boolean;
}

/**
 * Represents options when executing an ION API HTTP request.
 * 
 * This interface is a superset of the ng.IRequestConfig interface for the AngularJS $http service.
 * For documentation of the $http service see: https://docs.angularjs.org/api/ng/service/$http
 * 
 * Note that the url property should be set to a relative URL (absolute URLs are not supported).
 * The ION API base URL will be automatically prepended to the url property to create an absolute URL before the request is executed.
 * 
 * The OAuth authorization header will also be automatically added to the headers map.
 */
export interface IIonApiRequestOptions extends ng.IRequestConfig {
	/**
	 * Gets or sets an optional value that indicates if a request should be retried if the ION API returns a 401 HTTP response code.
	 * 
	 * A 401 response code usually means that the OAuth token has expired and must be renewed. A 401 response code could also mean
	 * that the user cannot be authorized at all.
	 * 
	 * The default value is true.
	 */
	ionApiRetry?: boolean;
}

/**
 * Represents the ION API context which contains values required when making ION API HTTP requests.
 * 
 * To call an ION API a client must construct an absolute URL using the ION API base URL returned by the getUrl function.
 * Each HTTP request to an ION API must include an authorization header with an OAuth 2.0 bearer token. 
 * The authorization header name and value can be retrieved using the getHeaderName and getHeaderValue functions. 
 * It is also possible to get just the OAuth token using the getToken function. 
 * 
 * Refer to the documentation for the API used to make HTTP calls for information about how to add a header to a request.
 * 
 * Authorization header example: "Authorization: Bearer yg06wrbaBoutluM8Rdb9v4YH0ztx"
 * 
 * @since 1.0
 */
export interface IIonApiContext {
	/**
	 * Gets the ION API base URL.
	 * @return a URL
	 */
	getUrl(): string;

	/**
	 * Gets an OAUth token.
	 * 
	 * The OAuth token must be provided in an Authorization header for each ION API call.
	 * @return an OAuth token
	 */
	getToken(): string;

	/**
	 * Gets the name of the HTTP Authorization header (Authorization).
	 * @return the authorization header name
	 */
	getHeaderName(): string;

	/**
	 * Gets the value for the HTTP authorization header including the OAuth token.
	 * 
	 * The returned value is an Authorization Request Header Field for an OAuth 2.0 Bearar Token 
	 * according to https://tools.ietf.org/html/rfc6750#section-2.1
	 * 
	 * Example return value: "Bearer yg06wrbaBoutluM8Rdb9v4YH0ztx"
	 * 
	 * @return the authorization header value
	 */
	getHeaderValue(): string;

	/**
	 * Gets the ION API customer context.
	 *
	 * The ION API customer context must be used in the ION API URL for applications that are not Infor provisioned.
	 * Applications that are provisioned in the cloud and is using the standard ION API suite name should not add the customer context to the ION API URL.
	 * In most other cases such as on-premise and when using a non-standard ION API suite name the customer context must be added to the ION API URL.
	 * There are a few exceptions to this for Infor Tech products that are always Infor provisioned both in cloud and on-premise.
	 *
	 * The default value for the ION API customer context is "CustomerApi" but the value can be configured so it cannot be hardcoded.
	 *
	 * Example (M3 application with standard API suite provisioned in cloud):
	 * https://ionapiserver:54321/ACME_AX1/M3/
	 *
	 * Example (Application with custom API suite in cloud or on-premise):
	 * https://ionapiserver:54321/ACME_AX1/CustomerApi/MyApp/
	 *
	 * @returns The ION API customer context
	 *
	 * @since 1.0.1
	 */
	getCustomerContext(): string;
}

/**
 * Represents the context for a widget in runtime.
 * 
 * The context is received as a parameter to the widgetFactory function in the widget module.
 * 
 * The context provides a widget instance with data, settings, the DOM element etc and 
 * functions that can be used to interact with the framework.
 * 
 * @since 1.0
 */
export interface IWidgetContext {
	/**
	 * Gets the unique ID of the widget.
	 */
	getId(): string;

	/**
	 * Gets the widget settings.
	 * 
	 * If the widget defines settings in the widget manifest the settings will contain default values when a widget is added to a page.
	 * If a widget use ad-hoc settings or do not use settings at all the settings object might be empty.
	 */
	getSettings(): IWidgetSettings;

	/**
	 * Gets the widget language object for the current user language.
	 * @return A language object.
	 */
	getLanguage(): ILanguage;

	/**
	 * Gets the widget DOM element wrapped in a JQuery object.
	 * 
	 * A widget may add content to this element and for widgets not implemented using AngularJS
	 * this is the only option for adding content. 
	 * 
	 * Note that a widget is only allowed to add content as children to this element.
	 * A widget is not allowed to explicitly add elements to other parts of the DOM. The only exceptions
	 * are when elements are added implicitly using modal dialogs, popups etc.
	 * 
	 * AngularJS widgets may add compiled content to this element.
	 * The angularContext property contains the the scope and the compile service required for compiling AngularJS elements.
	 * 
	 * AngularJS widgets that uses one of the template properties defined on the angularContext property ([[IAngularWidgetConfig]]) in [[IWidgetInstance]]
	 * should ignore this property. In this case the framework will add content to the element automatically.
	 */
	getElement(): JQuery;

	/**
	 * Gets a URL to the widget folder or a resource in the wiget directory.
	 * 
	 * A widget must use an API such as this to get the URL to the widget directory since the widget directory location is an implementation
	 * detail that might change in future versions.
	 * 
	 * **Example:**
	 * var iconUrl = widgetContext.getUrl("images/icon.png");
	 * var baseUrl = widgetContext.getUrl();
	 * 
	 * @param path An optional relative path that will be appended to the widget directory URL. If this parameter is omitted or is blank the URL to the widget directory will be returned.
	 * @returns A URL to the widget directory or a resource in the wiget directory.
	 */
	getUrl(path?: string): string;

	/**
	 * Gets the AngularJS context that can be used by widgets implemented using AngularJS.
	 * 
	 * Widgets that do not use AngularJS should ignore this property.
	 */
	getAngularContext(): IAngularContext;

	/**
	 * Gets a value that indicates if the widget is active.
	 * 
	 * A widget is considered to be active if it is visible, the settings dialog is not open and the widget is not in edit mode.
	 * 
	 * @returns True if the widget is active.
	 */
	isActive(): boolean;

	/**
	 * Gets a value that indicates if the widget is visible.
	 * 
	 * A widget is considered to be visible if the widget is part of the current page.
	 * 
	 * @returns True if the widget is visible.
	 */
	isVisible(): boolean;

	/**
	 * Gets a value that indicates if the widget is a published widget or if the widget is on a published page.
	 * 
	 * @returns True is the widget is pubished.
	 */
	isPublished(): boolean;

	/**
	 * Gets a value that indicates if the widget is running in the development environment.
	 */
	isDev(): boolean;

	/**
	 * Notifies the framework that the widget data has been changed and that the widget needs to be saved.
	 * 
	 * This function can be used explicity save widget data or settings. There is no need to call this function
	 * when the widget settings dialog is used since the framework saves automatically in that case.
	 * This function should only be used if the widget modifies data or settings that the framework is not aware of.
	 * 
	 * The widget data is saved as part of the current page and this is asynchronous so there is no guarantee exactly when the data is saved.
	 * There might be a delay and frequent calls to this function might not result in the same number of server calls.
	 */
	save(): void;

	/**
	 * Sets the widget state.
	 * 
	 * See [[WidgetState]]
	 * 
	 * @param state The new widget state.
	 */
	setState(state: string): void;

	/**
	 * Gets the current widget state.
	 * 
	 * See [[WidgetState]]
	 * 
	 * @returns A widget state.
	 */
	getState(): string;

	/**
	 * Gets the current widget title.
	 * 
	 * @returns A widget title.
	 */
	getTitle(): string;

	/**
	 * Gets the standard widget title as defined in the widget manifest.
	 * 
	 * @returns A widget title.
	 */
	getStandardTitle(): string;

	/**
	 * Sets the widget title.
	 * 
	 * This function will override the default title or a title set by the user and 
	 * should only be used by special widgets where the title is dependent on the configuration or the current data for example.
	 * If the widget is configured to have the same title as in the widget catalog calling this method will have no effect.
	 * 
	 * @param title The title to set.
	 */
	setTitle(title: string): void;

	/**
	 * Enables or disables the possibility for the user to edit the widget title.
	 * @param isEnabled True to enable title editing, False to disable.
	 */
	enableTitleEdit(isEnabled: boolean): void;

	/**
	 * Gets a value that indicates if the user is allowed to edit the widget title.
	 * @return True if title editing is enabled.
	 */
	isTitleEditEnabled(): boolean;

	/**
	 * Resolves a key by searching for the key in the following order:
	 * 
	 * <ul>
	 * <li>Widget Settings</li>
	 * <li>Ad-hoc properties</li>
	 * <li>Application configuration in Ming.le.</li>
	 * </ul>
	 * 
	 * A key can contain any of the following reserved prefixes (followed by .) for accessing the key directly intead of using the search order:  widget, property, application.
	 * For example application.hostname to get the hostname from the application's configuration.
	 * 
	 * The key is case sensitive.
	 * 
	 * Ad-hoc properties are defined by an administrator and can be useful if an installation has multiple links to another on-premise system.
	 * 
	 * This is only available if the widget has an application dependency defined in the Manifest by specifying applicationLogicalId and applicationVersion.
	 * 
	 * Note that for this to work with Ming.le configuration when using the Test Container, configuration data needs to be provided by setting dev-configuration. 
	 * See the developers guide or sample for more information.
	 *  
	 * @param Key is the name of the value that should be resolved. It might contain a prefix(e.g. application.xxxx)
	 * @return The value for the key or null if no value is found.
	 */
	resolve(key: string): string;

	/**
	 * Resolves a URL template with replacement variables in curly brachets.
	 * 
	 * For example: http://{application.host}:{application.port}/root/{resource}?view={selectedView}
	 * 
	 * By default all replacement variables will be encoded with the encodeURI function.
	 * 
	 * It is possible to add extra information in the expression to specify the encoding method that should be used and a default value if the value is null or empty.
	 * 
	 * For example: {selectedView|encode:component}
	 * 
	 * The encode takes three different options:
	 * <ul>
	 * <li>none - no encoding {selectedView|encode:none}</li>
	 * <li>uri - encodeURI {selectedView|encode:uri}</li>
	 * <li>component - encodeURIComponent {selectedView|encode:component}</li>
	 * </ul>
	 * 
	 * Another option is to specify a default value, for example: {selectedView|default:standard}. If the selectedView cannot be resolved standard would be the fallback.
	 * 
	 * Note that for this to work with Ming.le configuration when using the Test Container, configuration data needs to be provided by setting dev-configuration. 
	 * See the developers guide or sample for more information.
	 * 
	 * 
	 * @param A template with substitution variables. http://{external.server.test}/info/test/{selected}.
	 * @return The resolved template with all substitution variables replaced (or removed if they can't be resolved).
	 */
	resolveAndReplace(template: string): string;

	/**
	 * Gets the default application instance. 
	 * 
	 * If there are more than one instance of the application the one that is considered
	 * to be default by the framework will be returned.
	 * 
	 * Note that for this to work when using the Test Container, configuration data needs to be provided by setting dev-configuration. 
	 * See the developers guide or sample for more information.
	 * 
	 * @returns The default application instance or null if the widget does not belong to an application.
	 */
	getApplication(): IApplication;

	/**
	 * Gets an array with all application instances.
	 * 
	 * If there is only a single appliction instance the result will be an array with one element.
	 *  
	 * Note that for this to work when using the Test Container, configuration data needs to be provided by setting dev-configuration. 
	 * See the developers guide or sample for more information.
	 * 
	 * @returns An array of application instances or an empty array if the widgets does not belong to an application.
	 */
	getApplications(): IApplication[];

	/**
	 * Gets the logical ID.
	 * @returns The logical ID or null if the widget does not belong to an application.
	 */
	getLogicalId(): string;

	/**
	 * Sets the logical ID. This function can be called by widgets that supports multiple application instances 
	 * to change the default application instance.
	 * 
	 * Calling this function will only have an effect if the widget belongs to an application.
	 * 
	 * @param logicalId The logical ID.
	 */
	setLogicalId(logicalId: string): void;

	/**
	 * Gets the Ming.le application settings for a specified application.
	 * 
	 * If a logical ID is specified it must match exactly with an existing application instance.
	 * If a logical ID prefix is specified the default application instance will be returned.
	 * 
	 * Note that for this to work when using the Test Container, configuration data needs to be provided by setting dev-configuration. 
	 * See the developers guide or sample for more information.
	 * 
	 * @param logicalId The logical ID or logical ID prefix for the application to get.
	 * @returns A promise that will be resolved when the application settings are available.
	 */
	getApplicationAsync(logicalId: string): ng.IPromise<IApplication>;

	/**
	 * Gets the Ming.le application settings for all instances of the specified application.
	 * 
	 * If a logical ID is specified it must match exactly with an existing application instance.
	 * If a logical ID prefix is specified the default application instance will be returned.
	 * 
	 * Note that all instances of an application will be returned even if the logical ID for a specific instance is specified.
	 * 
	 * Note that for this to work when using the Test Container, configuration data needs to be provided by setting dev-configuration. 
	 * See the developers guide or sample for more information.
	 * 
	 * @param logicalId The logical ID or logical ID prefix for the application to get.
	 * @returns A promise that will be resolved when the application settings are available.
	 */
	getApplicationsAsync(logicalId: string): ng.IPromise<IApplication[]>;

	/**
	 * Resolves a URL template with replacement variables in curly brackets using values from a Ming.le application.
	 * 
	 * If a logical ID is specified it must match exactly with an existing application instance.
	 * If a logical ID prefix is not specified the default application instance will be used when resolving values.
	 * 
	 * @param logicalId The logical ID prefix for the application to use when resolving values.
	 * @returns A promise that will be resolved when the template has been resolved.
	 */
	resolveAndReplaceAsync(template: string, logicalId?: string): ng.IPromise<string>;

	/**
	 * Gets an application view URL.
	 * 
	 * The default behavior of this function is to get the view URL template for the current default application,
	 * replace values in the template and return the URL. It is possible to specify another application and to 
	 * prevent variable replacement by using additional properties on the options object.
	 * 
	 * @param options Used to specifiy the view to get and other options.
	 * @returns A promise that will be resolved when the URL is available. The promise will be rejected if the application or the view does not exist or if some other error occurs.
	 */
	getViewUrlAsync(options: IViewUrlOptions): ng.IPromise<string>;

	/**
	 * Gets the ION API customer context.
	 *
	 * The ION API customer context must be used in the ION API URL for applications that are not Infor provisioned.
	 * Applications that are provisioned in the cloud and is using the standard ION API suite name should not add the customer context to the ION API URL.
	 * In most other cases such as on-premise and when using a non-standard ION API suite name the customer context must be added to the ION API URL.
	 * There are a few exceptions to this for Infor Tech products that are always Infor provisioned both in cloud and on-premise.
	 *
	 * The default value for the ION API customer context is "CustomerApi" but the value can be configured so it cannot be hardcoded.
	 *
	 * Example (M3 application with standard API suite provisioned in cloud):
	 * https://ionapiserver:54321/ACME_AX1/M3/
	 *
	 * Example (M3 application with standard API suite on-premise):
	 * https://ionapiserver:54321/ACME_AX1/CustomerApi/M3/
	 *
	 * Example (M3 application with custom API suite in cloud or on-premise):
	 * https://ionapiserver:54321/ACME_AX1/CustomerApi/M3_CUSTOM/
	 * 
	 * @returns The ION API customer context.
	 */
	getIonApiCustomerContext(): string;

	/**
	 * Gets an ION API context required when making ION API HTTP requests.
	 * 
	 * This function is asynchronous since a server request might be required to get the OAuth token for ION API.
	 * 
	 * In most cases an ION API request can be executed using the executeIonApiAsync function that will automatically
	 * get the ION API context and retry requests when the OAuth token has expired. This function can be used when more
	 * control is required when making the request or when the executeIonApiAsync fuction cannot be used for some other reason.
	 * 
	 * The OAuth token has a limited lifetime and will become invalid once it has timed out. 
	 * The OAuth token might be invalid if an ION API HTTP request returns 401.
	 * A client can get a new ION API context with a new OAuth token by setting the refresh property to true on the options parameter.
	 * 
	 * @param options Optional object for specifying options when getting the context.
	 * @return A promise that will be resolved when the ION API context is available.
	 */
	getIonApiContextAsync(options?: IIonApiOptions): ng.IPromise<IIonApiContext>;

	/**
	 * Executes an ION API HTTP request.
	 * 
	 * This function will automatically get the IonApiContext which contains the OAuth token necessary to complete the request.
	 *
	 * If the url parameter is relative (which it should be in most cases) the ION API base URL will be prepended to the URL before the request is executed.
	 * 
	 * If the ION API HTTP request returns a 401 response code this function will perform a single retry. The retry attempt
	 * will get a fresh OAuth token and repeat the same request. If the second request completes without errors it will be 
	 * transparent to the caller. If the second request fails the promise will be rejected.
	 * 
	 * Since this function is a wrapper of the AngularJS $http service refer to the documentation here for more details:
	 * https://docs.angularjs.org/api/ng/service/$http
	 * 
	 * If more control is required when making the request the getIonApiContextAsync function can be used to 
	 * get the OAuth token and ION API base URL. In this case the retry for expired OAuth tokens must be handled manually.
	 * 
	 * @param options An object that describes the request (also see documentation for the $http service).
	 * @returns A promise that will be resolved when the request completes or fails.
	 */
	executeIonApiAsync<T>(options: IIonApiRequestOptions): ng.IPromise<ng.IHttpPromiseCallbackArg<T>>;

	/**
	 * Gets a named framework service.
	 * 
	 * This function can be used to get access to framework services implemented in AngularJS from a widget that
	 * is not implemented in AngularJS. The function can be used from an AngularJS widget as well if the 
	 * normal dependency injection cannot be used for some reason.
	 * 
	 * The names of the available services are documented in the service interface API documentation. 
	 * Note that a widget is only allowed to request services that are part of the public API documentation.
	 * Any other services that might be accessible could be removed or refactored at any time without prior notice.
	 * 
	 * @param name The name of the service to get.
	 * @returns A service instance or null if the service could not be found.
	 */
	getService<T>(name: string): T;

	/**
	 * Launches a URL or a drillback link.
	 * 
	 * This function can be used to launch a link in the browser or send a companyon message to open a drillback link.
	 * The launchOptions will control if replacement variables should be resolved automatically or not. Default is true and any curly brackets would
	 * result in that for example {lid://infor.m3} would be resolved to the for the Homepages default instance id for m3, eg {lid://infor.m3.1}. This is for example
	 * used in the custom menu widget as it makes widget link configuration portable for the default application wihtout having to update logical ids.
	 * 
	 * The link can contain replacement variables for specific applications as well using the syntax with the logicalId prefix.
	 * {lid://infor.homepages:Host}
	 * 
	 * Any url that starts with a slash or http or https would be considered a standard web link and will be handled by the browser opening a new window or tab.
	 * All other url will be handled by Ming.le companyon.
	 * 
	 * Note that for this to work when using the Test Container, configuration data needs to be provided by setting dev-configuration. 
	 * See the developers guide or sample for more information.
	 * 
	 * @param launchOptions The launch options. 
	 */
	launch(launchOptions: ILaunchOptions): void;

	/**
	 * Displays a dismissable inline message in the widget.
	 */
	showWidgetMessage(message: IWidgetMessage): void;

	/**
	 * Removes the inline message in the widget.
	 */
	removeWidgetMessage(): void;

	/**
	 * Returns the pageId of the parent page or null if the widget does not have a parent context at this time.
	 */
	getPageId(): string;

	/**
	 * Returns the ID if the widget is a standard widget or the standard widget id the widget is based on.
	 */
	getStandardWidgetId(): string;

	/**
	 * Returns the runtime instance id for the widget. 
	 */
	getWidgetInstanceId(): string;


	/**
	 * Returns the container (top level) url in the form of schema://host, for example https://mingledev.infor.com if Homepages is running withing Ming.le.
	 * This url should be used when implementing X-Frame-Options for widgets that has IFrames. The replacement variable to use in templates is 'containerUrl'.
	 * If Homepages is running standalone or in dev mode it will return the URL to the Hompages host.
	 */
	getContainerUrl(): string;

	/**
	 * Gets a value that indicates if the Homepages server is running the cloud mode or on-premise mode.
	 *
	 * This function can be used by widgets that needs to have a different behavior in cloud mode compared to on-premise mode.
	 * 
	 * @returns True if the server is running in cloud mode.
	 *
	 * @since 1.0.1
	 */
	isCloud(): boolean;
}

/**
 * Launch options for the IWidgetContext launch method.
 * 
 * @since 1.0
 */
export interface ILaunchOptions {
	/**
	 * An url starting with slash, http, https or a Ming.le drillback link.
	 */
	url: string;

	/**
	 * If values should be automatically resolved using application context information. Either the link must start with a logicalId prefix or logicalId 
	 * or the logical Id should be set on this function.
	 * 
	 * An example of a URL that can be replaces to link to Ming.le posts is:
	 * {lid://infor.social}{Scheme}://{Hostname}:{Port}/{TenantId}/webpart/posts
	 * 
	 * The logicalIdPrefix in the beginning of the link determines that the default social application will be used to resolve the other values. It is also possible to have 
	 * values in the link that is from the widget settings or ad-Hoc properties.
	 * 
	 * Another example to open a M3 program would be:
	 * {lid://infor.m3}?LogicalId={logicalId}&program=MMS001
	 * 
	 */
	resolve?: boolean;
}

/**
 * Represents the widget settings.
 * 
 * Note that all settings values must be possible to serialize to JSON.
 * 
 * @since 1.0
 */
export interface IWidgetSettings {

	/**
	 * Gets the settings value object.
	 * 
	 * This object can be used directly instead of using the get/set functions if necessary.
	 * 
	 * @returns The settings value object.
	 */
	getValues(): any;

	/**
	 * Sets the settings value object.
	 * 
	 * Note that calling this function will overwrite all existing setting values.
	 * 
	 * @param values The settings value object.
	 */
	setValues(values: any): void;

	/**
	 * Gets the settings metadata.
	 * @returns An array of metadata for each setting.
	 */
	getMetadata(): IWidgetSettingMetadata[];

	/**
	 * Sets the settings metadata
	 * 
	 * Note that calling this function will overwrite all existing settings metadata.
	 * 
	 * @parma metadata An array of metadata for each setting.
	 */
	setMetadata(metadata: IWidgetSettingMetadata[]): any;

	/**
	 * Gets a property of type T.
	 * 
	 * @param name The name of the property.
	 * @param defaultValue Optional default value to return if the property is missing.
	 * @returns The property value or the default value.
	 */
	get<T>(name: string, defaultValue?: T): T;

	/**
	 * Sets a settings value.
	 * 
	 * Note that the value must be possible to serialize to JSON.
	 * 
	 * @param name The name of the setting.
	 * @param value The setting value.
	 */
	set(name: string, value: any): void;

	/**
	 * Gets a string property.
	 * 
	 * If the property value is not a string it will be converted to a string by this function.
	 * 
	 * @param name The name of the property.
	 * @param defaultValue Optional default value to return if the property is missing.
	 * @returns The property value or the default value.
	 */
	getString(name: string, defaultValue?: string): string;

	/**
	 * Shows the widget settings dialog.
	 * 
	 * This function can be used to manually show the widget settings dialog.
	 * The widget settings can be opened from the widget title bar menu but some widgets may
	 * have some additional UI element that should also open the widget settings.
	 * 
	 * @param options Optional settings options.
	 */
	showSettings(options?: IShowSettingsOptions): void;

	/**
	 * Gets a value that indicates if settings are currently enabled. The value depends on the following factors: if settings are enabled in the definition, if
	 *  settings are enabled for a published widet, if the widget is in a publish / edit published state in the client. This means that the value might change 
	 * over time when working with a published widget.
	 * @return True if settings are enabled.
	 */
	isSettingsEnabled(): boolean;

	/**
	 * Gets a value that indicates if the specified setting is enabled.
	 * 
	 * A setting might be disabled for a published widget. 
	 * A widget implementation with custom settings management should check if a setting is enabled or not.
	 * 
	 * @param name The name of the setting
	 * @return  True if the setting is enabled or if the setting is not recognized. False if the setting is disabled or if all settings are disabled.
	 */
	isSettingEnabled(name: string): boolean;

	/**
	 * Gets a value that indicates if the specified setting should be visible to the end user.
	 * 
	 * A setting might be hidden for a published widget. 
	 * A widget implementation with custom settings management should check if a setting is hidden or not.
	 * 
	 * @param name The name of the setting
	 * @return  True if the setting is visible or if the setting is not recognized. False if the setting is hidden.
	 */
	isSettingVisible(name: string): boolean;

	/**
	 * Sets if the Configure (Settings Menu) should be visible or not. Default is true if the widget has defined settings.
	 * Intended for widgets that want to use the settings framework but not the standard Configure menu that opens the settings dialog.
	 * @param enabled If configure menu should be visible.
	 */
	enableSettingsMenu(enabled: boolean): void;
}

/**
 * Represents a custom widget settings instance.
 * 
 * An object of this type should be set in IWidgetSettingsobject when settingsOpenings is called.
 * 
 * A widget implementation may choose which properties to set depending on what types of callbacks the widget requires.
 * 
 * @since 1.0
 */
export interface IWidgetSettingsInstance {
	/**
	 * Gets or sets an optional event function that will be called when the Settings dialog is closing.  
	 */
	closing?: (arg: IWidgetSettingsCloseArg) => void;

	/**
	 * Gets or sets an optional angular configration for widgets implementing the settings UI with a template.
	 */
	angularConfig?: IAngularWidgetConfig;
}

/**
 * Represents the context for a custom settings UI implementation.
 * 
 * @since 1.0
 */
export interface IWidgetSettingsContext {

	/**
	 * Gets the widget context.
	 * 
	 * @returns The widget context.
	 */
	getWidgetContext(): IWidgetContext;

	/**
	 * Enables or disables save in the settings dialog.
	 * 
	 * @param isEnabled A value that indicates if save should be enabled.
	 */
	enableSave(isEnabled: boolean): void;

	/**
	 * Gets a value that indicates if save is enabled in the settings dialog.
	 * @retruns True if save is enabled.
	 */
	isSaveEnabled(): boolean;

	/**
	 * Gets the widget settings DOM element wrapped in a JQuery object.
	 * 
	 * A widget may add settings UI content to this element and for widgets not implemented using AngularJS
	 * this is the only option for adding custom settings content. 
	 * 
	 * Note that a widget is only allowed to add content as children to this element.
	 * A widget is not allowed to explicitly add elements to other parts of the DOM. The only exceptions
	 * are when elements are added impicitly using modal dialogs, popups etc.
	 * 
	 * AngularJS widgets may add compiled content to this element.
	 * The angularContext property contains the the scope and the compile service required for compiling AngularJS elements.
	 * 
	 * AngularJS widgets that uses one of the template properties defined on the angularConfig property ([[IAngularWidgetConfig]]) in [[IWidgetSEttingsInstance]]
	 * should ignore this property. In this case the framework will add content to the element automatically.
	 * 
	 * @returns The parent jQuery element.
	 */
	getElement(): JQuery;

	/**
	 * Closes the settings dialog.
	 * @param isSave A value that indicats if the settings should be saved or not. The default value is false. See [[IWidgetSettingsCloseArg]].
	 */
	close(isSave?: boolean): void;
}

/**
 * Defines widget constants.
 * 
 * @since 1.0
 */
export class WidgetConstants {
	static widgetInstanceKey = "lmWidgetInstance";
	static widgetContextKey = "lmWidgetContext";
	static widgetTitle = "widgetTitle";
	static widgetDescription = "widgetDescription";
}

/**
 * Interface for custom log appender callback functions.
 * 
 * A log appender function can be used to get all logs from the Log class for the current log level.
 * 
 * @since 1.0
 */
export interface ILogAppender {
	(level: number, text: string, ex?: any);
}

/**
 * Represents options for number formatting.
 * 
 * @since 1.0
 */
export interface INumberFormatOptions {
	/**
	 * Gets or sets the decimal separator character.
	 */
	separator?: string;
}

/**
 * Represents options for sort functions in the [[ArrayUtil]] class.
 * 
 * @since 1.0
 */
export interface ISortOptions {
	/**
	 * Gets or sets a value that indicates if sorting should ignore case.
	 * The default value is false. If this setting is set to true all values will be converted to strings when sorting.
	 */
	ignoreCase?: boolean;
}

/**
 * Utility class for array operations.
 * 
 * @since 1.0
 */
export class ArrayUtil {

	/**	
	 * Checks if an item exists in an array.
	 * @returns True if an item exists.
	 */
	public static contains(array: any[], value: any): boolean {
		if (array) {
			return $.inArray(value, array) >= 0;
		}
		return false;
	}

	/**	
	 * Gets the index of a value in an array.
	 * @param array Array to get value index from.
	 * @param value Value to get index of.
	 * @returns index of value.
	 */
	public static indexOf(array: any[], value: any): number {
		return $.inArray(value, array);
	}

	/**	
		* Sorts the array in acending order of the given property.
		* @param array Array to sort.
		* @param property Property to sort array by.
		* @param options Optional options for controlling the sorting.
		* @returns The sorted array.
		*/
	public static sortByProperty(array: any[], property: string, options?: ISortOptions): any[] {
		const ignoreCase = options && options.ignoreCase;
		return array.sort((x, y) => {
			const xProp = x[property];
			const yProp = y[property];

			// User concatenation instead of toString to avoid crashes for missing properties
			const a = ignoreCase ? ("" + xProp).toLocaleLowerCase() : xProp;
			const b = ignoreCase ? ("" + yProp).toLocaleLowerCase() : yProp;

			if (a > b) {
				return 1;
			} else if (a < b) {
				return -1;
			}
			return 0;
		});
	}

	/**
	 * Removes an item in an array.
	 */
	public static remove(array: any[], item: any): void {
		const index = $.inArray(item, array);
		if (index >= 0) {
			array.splice(index, 1);
		}
	}

	/**
	 * Removes an item in an array by matching the value of a specific property.
	 */
	public static removeByProperty(array: any[], name: string, value: any): boolean {
		for (let i = 0; i < array.length; i++) {
			if (array[i][name] === value) {
				array.splice(i, 1);
				return true;
			}
		}
		return false;
	}

	public static removeByPredicate<T>(array: T[], predicate: (item: T) => boolean) {
		for (let i = 0; i < array.length; i++) {
			if (predicate(array[i])) {
				array.splice(i, 1);
				return true;
			}
		}
		return false;
	}

	/**
	 * Gets the index of an item in an array by matching the value of a specific property.
	 */
	public static indexByProperty(array: any[], name: string, value: any): number {
		if (array) {
			for (let i = 0; i < array.length; i++) {
				if (array[i][name] === value) {
					return i;
				}
			}
		}
		return -1;
	}

	/**
	 * Gets the item in an array by matching the value of a specific property.
	 */
	public static itemByProperty(array: any[], name: string, value: any): any {
		const index = this.indexByProperty(array, name, value);
		return index >= 0 ? array[index] : null;
	}

	/**
	 * Gets the item matching the predicate.
	 */
	public static itemByPredicate<T>(array: T[], predicate: (item: T) => Object) {
		for (let i = 0; i < array.length; i++) {
			if (predicate(array[i])) {
				return array[i];
			}
		}
		return null;
	}

	/**
	 * Checks if an item exists in an array by matching the value of a specific property.
	 * @ returns True if an item with the property and value exists.
	 */
	public static containsByProperty(array: any[], name: string, value: any): boolean {
		return this.indexByProperty(array, name, value) >= 0;
	}

	/**
	* Gets the last item in an array.
	* @returns The last item or null if the array is null or empty.
	*/
	public static last(array: any[]): any {
		if (array && array.length > 0) {
			return array[array.length - 1];
		}
		return null;
	}

	/**
	 * Finds the first item in the array that matches the conditions defined in the predicate function.
	 * @param array An array of items to search.
	 * @param predicate A predicate function that should return true if the item parameter matches the predicate condition.
	 */
	public static find<T>(array: T[], predicate: (item: T) => boolean) {
		if (array) {
			for (let item of array) {
				if (predicate(item)) {
					return item;
				}
			}
		}
		return null;
	}

	/**
	* Finds all items in the array that matches the conditions defined in the predicate function.
	* @param array An array of items to search.
	* @param predicate A predicate function that should return true if the item parameter matches the predicate condition.
	*/
	public static findAll<T>(array: T[], predicate: (item: T) => boolean): T[] {
		if (array) {
			const arr = [];
			for (let item of array) {
				if (predicate(item)) {
					arr.push(item);
				}
			}
			return arr;
		}
		return null;
	}

	/**
	* Creates an array of n entries with the specified default value.
	* @params n            Number of entries.
	* @params defaultValue The default values of the entries.
	* @returns Array.
	*/
	public static array<T>(n: number, defaultValue?: T): T[] {
		const arr = new Array<T>(n);
		for (let j = 0; j < n; j++) {
			arr[j] = defaultValue;
		}
		return arr;
	}

	/**
	* Creates a matrix (two dimensional array) with specified default values.
	* @param rows     The number of rows in the matrix.
	* @params columns The number of columns in the matrix.
	* @returns matrix.
	*/
	public static matrix<T>(rows: number, columns: number, defaultValue?: T): T[][] {
		const matrix = new Array(rows);
		for (let i = 0; i < matrix.length; i++) {
			const cols = new Array<T>(columns);
			for (let j = 0; j < columns; j++) {
				cols[j] = defaultValue;
			}
			matrix[i] = ArrayUtil.array(columns, defaultValue);
		}
		return matrix;
	}

	/**
	 * Moves a object in an array to another index.
	 */
	public static move(array: any[], index: number, newIndex: number): void {
		if (newIndex >= array.length) {
			let k = newIndex - array.length;
			while ((k--) + 1) {
				array.push(undefined);
			}
		}
		array.splice(newIndex, 0, array.splice(index, 1)[0]);
	}
}

/**
 * Number utility functions.
 * 
 * @since 1.0
 */
export class NumUtil {
	private static getLocaleSeparator(): string {
		const n = 1.1;
		const s = n.toLocaleString().substring(1, 2);
		return s;
	}

	private static defaultSeparator = NumUtil.getLocaleSeparator();

	private static defaultOptions: INumberFormatOptions = {
		separator: NumUtil.defaultSeparator
	};

	/**
	 * Gets the default options used by the functions in the class.
	 * @returns The default options.
	 */
	public static getDefaultOptions(): INumberFormatOptions {
		return NumUtil.defaultOptions;
	}

	/**
	 * Sets the default options used by the functions in the class.
	 * @options The default options.
	 */
	public static setDefaultOptions(options: INumberFormatOptions): void {
		NumUtil.defaultOptions = options;
		if (options.separator) {
			NumUtil.defaultSeparator = options.separator;
		}
	}

	/**
	 * Gets a values that indicates if the parameter is a number.
	 * 
	 * The value is considered to be a number if it can be parsed as a float, it is a number and it is finite.
	 * @param n The value to check.
	 * @returns True if the value is a number.
	 */
	public static isNumber(n: any): boolean {
		return !isNaN(parseFloat(n)) && isFinite(n);
	}

	/**
	 * Gets an integer value from a string.
	 * @param s The string to parse.
	 * @param defaultValue Optional default value to return if the string cannot be parsed. The default is zero.
	 * @returns An integer parsed from the string or the default value.
	 */
	public static getInt(s: string, defaultValue: number = 0) {
		if (s) {
			try {
				return parseInt(s) || defaultValue;
			} catch (e) {
			}
		}
		return defaultValue;
	}

	/**
	 * Formats a number or string using default or specified formatting options.
	 * 
	 * This function currently only supports formatting using a specified decimal separator.
	 * The value to format is expected to be either a number or a string containing a number where any 
	 * decimal separator is dot (.). If the value is a string it may not contain any thousand separators
	 * or other formatting characters.
	 * 
	 * @param value The value to format which can be a number or a number in string format.
	 * @param options Optional formatting options.
	 */
	public static format(value: any, options?: INumberFormatOptions): string {
		let s = value.toString();
		if ("" === s) {
			return s;
		}
		let separator = options ? options.separator : NumUtil.defaultOptions.separator;
		if (!separator) {
			separator = NumUtil.defaultSeparator;
		}
		s = s.replace(".", separator);
		return s;
	}

	/**
	 * Pads a number with leading zeroes up to the specified length.
	 * @param num The number to pad.
	 * @param length The length of the string.
	 */
	public static pad(num: number, length: number): string {
		let s = num + "";
		while (s.length < length) {
			s = "0" + s;
		}
		return s;
	}

	/**
	 * Gets a value that indicates if the string contains only integers (1234567890).
	 * @param s The string value to check.
	 * @returns True if string contains only integers.
	 */
	public static hasOnlyIntegers(s: string): boolean {
		if (!s) { return false; }

		const digits = "1234567890";
		for (let i = 0; i < s.length; i++) {
			if (digits.indexOf(s.charAt(i)) === -1) { return false; }
		}

		return true;
	}

	public static tryGetInt(input: any, defaultValue: number = 0): number {
		if (!input) {
			return defaultValue;
		}
		if (this.isNumber(input)) {
			return input;
		}
		return this.getInt(input.toString(), defaultValue);
	}
}

/**
 * Common Utility functions.
 * 
 * @since 1.0
 */
export class CommonUtil {
	/**
	 * Gets the local date string.
	 * Options can be used to set the formatting, for example: { date: "short" } or { pattern: "yyyy-MM-dd HH:mm" }.
	 * @params dateString Date string.
	 * @params options    Options for fromatting.
	 * @returns string    Formatted date.
	 */
	public static getLocaleDateString(dateString: string, options?: any): string {
		try {
			var date = new Date(dateString);
			if (!options) {
				// TODO Decide default date format
				options = { pattern: "yyyy-MM-dd HH:mm" };
			}

			return Locale.formatDate(date, options);
		} catch (ex) {
			return dateString;
		}
	}

	/**
	 * Delets a property of an object.
	 * @param object   Object of which to delete a property.
	 * @param property Property to delete.
	 */
	public static deleteProperty(object: any, property: string): void {
		if (!CommonUtil.isUndefined(object[property])) {
			delete object[property];
		}
	}

	private static chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

	/**
	 * Converts a boolean from a string.
	 * @param string       String to convert.
	 * @param defaultValue Default return value if string can't be used.
	 */
	public static getBoolean(s: string, defaultValue: boolean = false) {
		if (s && s.length > 0) {
			return s[0].toLowerCase() === "t";
		}
		return defaultValue;
	}

	public static getUuid(prefix: string): string {
		return prefix + (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1) + (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
	}

	public static hasValue(anyObject: any): boolean {
		if (typeof anyObject != "undefined") {
			return anyObject != null;
		}
		return false;
	}

	public static isUndefined(anyObject: any): boolean {
		return typeof anyObject === "undefined";
	}

	/**
	 * Creates a string with random uppercase letters and numbers.
	 * The default length is 16 if the stringLength parameter is omitted.
	 */
	public static random(stringLength: number = 16): string {
		const chars = CommonUtil.chars;
		let randomstring = "";
		for (let i = 0; i < stringLength; i++) {
			const rnum = Math.floor(Math.random() * chars.length);
			randomstring += chars.substring(rnum, rnum + 1);
		}
		return randomstring;
	}

	/**
	 * Gets a value that indicates if the current window is an IFrame or not.
	 */
	public static isIframe(): boolean {
		try {
			return window.self !== window.top;
		} catch (e) {
			return true;
		}
	}

	/**
	 * Returns the client's date as yyyy-mm-ddThh:mm
	 * Ex: 2015-01-20T21:20
	 */
	public static getClientDate(): string {
		const addZero = (dateNr: number) => {
			var dateString: string;
			if (dateNr < 10) {
				dateString = dateNr.toString();
				dateString = "0" + dateString;
			} else {
				dateString = dateNr.toString();
			}
			return dateString;
		};
		const date = new Date(Date.now());
		const year = date.getFullYear();
		const month = addZero(date.getMonth() + 1);
		const day = addZero(date.getDate());
		const hours = addZero(date.getHours());
		const min = addZero(date.getMinutes());
		return year + "-" + month + "-" + day + "T" + hours + ":" + min;
	}

	/**
	 * Detects IE version and sets it as a class on the html element.
	 */
	public static detectBrowser(): void {
		if (!!navigator.userAgent.match(/Trident/)) {
			$('html').addClass('ie');
		}
		if (navigator.appVersion.indexOf('MSIE 9.0') > -1) {
			$('html').addClass('ie9');
		}
		if (navigator.appVersion.indexOf('MSIE 10.0') > -1) {
			$('html').addClass('ie10');
		}
		if (!!navigator.userAgent.match(/Trident\/7\./)) {
			$('html').addClass('ie11');
		}
	}
}

/**
 * String utility functions.
 * 
 * @since 1.0
 */
export class StringUtil {
	/**
	 * Gets a value that indicates if the string is null, undefined, empty or contains only whitespace.
	 * @param value The string to check.
	 * @returns True if the string is null, undefined, empty or contains only whitespace.
	 */
	public static isNullOrWhitespace(value: string): boolean {
		return !value || !value.trim();
	}

	/**
	 * Gets a value that indicates if a string starts with a specified value.
	 * @param value The string value to check.
	 * @param prefix The value that the string should start with.
	 * @returns True if the string starts with the specified prefix value.
	 */
	public static startsWith(value: string, prefix: string): boolean {
		return value ? value.indexOf(prefix) === 0 : false;
	}

	public static replaceParameters(template: string, resolveFunction: Function): string {
		template = template.replace(/{(.*?)}/g, (substring: string, key: string): string => {
			var value = resolveFunction(key);
			return (typeof value != "undefined" ? value : "");
		});
		return template;
	}

	/**
	 * Gets a value that indicates if a string ends with a specified value.
	 * @param value The string value to check.
	 * @param prefix The value that the string should end with.
	 * @returns True if the string ends with the specified suffix value.
	 */
	public static endsWith(value: string, suffix: string): boolean {
		if (!value) {
			return false;
		}
		return value.indexOf(suffix, value.length - suffix.length) !== -1;
	}

	/**
	 * Trims whitespace from the end of a string.
	 * @param value The value to trim.
	 * @returns The trimmed value.
	 */
	public static trimEnd(value: string) {
		return value.replace(/\s+$/, "");
	}

	public static format(...args: any[]): string {
		var stringValue = "missing";
		try {
			stringValue = args[0];
			var params = Array.prototype.slice.call(args, 1);
			stringValue = stringValue.replace(/{(\d+)}/g, function (): any {
				var value = params[arguments[1]];
				return (typeof value != 'undefined' ? value : arguments[0]);
			});
		} catch (ex) {
			// TODO Rename to formatSafe, have both format and formatSafe and throw?
			//Log.error("Failed to format string. Args: " + args);
		}
		return stringValue;
	}
}

/**
 * HTML utility functions for creating and manipulating HTML elements.
 * 
 * @since 1.0
 */
export class HtmlUtil {
	/**
	 * Creates an iframe element without borders and the sandbox attribute set.
	 */
	public static iframe(url?: string, name?: string): JQuery {
		// TODO Change to options parameter...
		const iframe = $("<iframe />").attr("sandbox", "allow-same-origin allow-scripts allow-popups allow-forms").attr("seamless", "seamless").attr("frameborder", "0").addClass("lm-fill-absolute");
		if (url) {
			iframe.attr("src", url);
		}
		if (name) {
			iframe.attr("name", name);
		}
		return iframe;
	}
}

/**
 * Log text messages and exceptions on different log levels to the browser console and optional custom log appenders.
 * 
 * **Example:**
 * 
 * import Log = require("log");
 *	Log.info("Application initialized");
 * 
 * @since 1.0
 */
export class Log {

	/**
	 * Fatal log level. Severe errors that prevents the application from functioning.
	 */
	public static levelFatal: number = 0;

	/**
	 * Error log level.
	 */
	public static levelError: number = 1;

	/**
	 * Warning log level.
	 */
	public static levelWarning: number = 2;

	/**
	 * Information log level.
	 */
	public static levelInfo: number = 3;

	/**
	 * Debug log level. Detailed information for debug purposes.
	 */
	public static levelDebug: number = 4;

	/**
	 * Trace log level. Most detailed information for debug purposes.
	 */
	public static levelTrace: number = 5;

	/**
	 * Gets or sets the current log level. The default log level is information.
	 */
	public static level: number = Log.levelInfo;

	/**
	 * Gets or sets a value that indicates if logging to the browser console is enabled. 
	 * The default value is true.
	 */
	public static isConsoleLogEnabled: boolean = true;

	private static prefixes: string[] = ["[FATAL]", "[ERROR]", "[WARNING]", "[INFO]", "[DEBUG]", "[TRACE]"];
	private static appenders: ILogAppender[] = [];

	/**
	 * Adds a new log appender that will receive log entries for the current log level.
	 * @param A log appender.
	 */
	public static addAppender(appender: ILogAppender) {
		Log.appenders.push(appender);
	}

	/**
	 * Removes an existing log appender.
	 * @param appender An existing appender to remove.
	 */
	public static removeAppender(appender: ILogAppender) {
		ArrayUtil.remove(Log.appenders, appender);
	}

	/**
	 * Gets a military time string with hours, minutes, seconds and milliseconds on the format hh:mm:ss,ttt.
	 * @returns A military time string.
	 */
	private static getTime(): string {
		// TODO Utility function?
		const date = new Date();
		const hours = date.getHours();
		const minutes = date.getMinutes();
		const seconds = date.getSeconds();
		const ms = date.getMilliseconds();

		const time = (hours < 10 ? "0" : "") + hours + ":" +
			(minutes < 10 ? "0" : "") + minutes + ":" +
			(seconds < 10 ? "0" : "") + seconds + "," +
			(ms < 10 ? "00" : (ms < 100 ? "0" : "") + ms);

		return time;
	}

	/**
	 * Gets a formatted log entry.
	 * @param level The log level.
	 * @param ex An optional exception object.
	 */
	public static getLogEntry(level: number, text: string, ex?: any) {
		let logText = "[" + Log.getTime() + "] " + this.prefixes[level] + " " + text;
		if (ex) {
			logText += " " + ex.message;
			if (ex.stack) {
				logText += " " + ex.stack;
			}
		}
		return logText;
	}

	private static log(currentLevel: number, level: number, text: string, ex?: any) {
		if (level <= currentLevel) {

			// Log to the console if it is enabled and exist in the current browser.
			if (Log.isConsoleLogEnabled && window.console) {
				const logText = Log.getLogEntry(level, text, ex);
				if (level <= 1) {
					console.error(logText);
				} else if (level === 2) {
					console.warn(logText);
				} else if (level === 3) {
					console.info(logText);
				} else {
					console.log(logText);
				}
			}

			if (Log.appenders) {
				for (var i = 0; i < Log.appenders.length; i++) {
					try {
						Log.appenders[i](level, text, ex);
					} catch (e) {
					}
				}
			}
		}
	}

	/**
	 * Sets the default log level which is information.
	 */
	public static setDefault() {
		this.level = this.levelInfo;
	}

	/**
	 * Logs a text message and an optional exception on the fatal log level.
	 * @param text A log message.
	 * @param ex An optional exception object.
	 */
	public static fatal(text: string, ex?: any) {
		this.log(this.level, this.levelFatal, text, ex);
	}

	/**
	 * Logs a text message and an optional exception on the error log level.
	 * @param text A log message.
	 * @param ex An optional exception object. 
	 */
	public static error(text: string, ex?: any) {
		this.log(this.level, this.levelError, text, ex);
	}

	/**
	 * Logs a text message and an optional exception on the warning log level.
	 * @param text A log message.
	 * @param ex An optional exception object.
	 */
	public static warning(text: string, ex?: any) {
		this.log(this.level, this.levelWarning, text, ex);
	}

	/**
	 * Logs a text message and an optional exception on the information log level.
	 * @param text A log message.
	 * @param ex An optional exception object.
	 */
	public static info(text: string, ex?: any) {
		this.log(this.level, this.levelInfo, text, ex);
	}

	/**
	 * Gets a value that indicates if the debug log level is enabled. Use this before logging large debug messages.
	 * 
	 * @returns True if the debug log level is enabled
	 */
	public static isDebug() {
		return this.level >= this.levelDebug;
	}

	/**
	 * Sets the current log level to debug.
	 */
	public static setDebug() {
		this.level = this.levelDebug;
	}

	/**
	 * Logs a text message and an optional exception on the debug log level.
	 * @param text A log message.
	 * @param ex An optional exception object.
	 */
	public static debug(text: string, ex?: any) {
		this.log(this.level, this.levelDebug, text, ex);
	}

	/**
	 * Gets a value that indicates if the trace log level is enabled. Use this before logging large trace messages.
	 *
	 * @returns True if the trace log level is enabled
	 */
	public static isTrace() {
		return this.level >= this.levelTrace;
	}

	/**
	 * Sets the current log level to trace.		 
	 */
	public static setTrace() {
		this.level = this.levelTrace;
	}

	/**
	 * Logs a text message and an optional exception on the trace log level.
	 * @param text A log message.
	 * @param ex An optional exception object.
	 */
	public static trace(text: string, ex?: any) {
		this.log(this.level, this.levelTrace, text, ex);
	}
}

/**
 * Defines standard button combinations for a message dialog.
 * 
 * @since 1.0
 */
export enum StandardDialogButtons {
	/**
	 * Shows an OK button (1).
	 */
	Ok = 1,
	/**
	 * Shows an OK button and a Cancel button (2).
	 */
	OkCancel = 2,
	/**
	 * Shows a Yes and a No button (3).
	 */
	YesNo = 3,
	/**
	 * Shows a Yes, No and a Cancel button (4).
	 */
	YesNoCancel = 4,
}

/**
 * Defines the different types of buttons that can be used in dialogs.
 * 
 * @since 1.0
 */
export enum DialogButtonType {
	/**
	 * No button is used or the button is unknown (1).
	 */
	None = 1,
	/**
	 * OK button (2).
	 */
	Ok = 2,
	/**
	 * Cancel button (3).
	 */
	Cancel = 3,
	/**
	 * Yes button (4).
	 */
	Yes = 4,
	/**
	 * No button (5).
	 */
	No = 5,
	/**
	 * Custom button (6).
	 */
	Custom = 6
}

/**
 * Represents the result from a closed dialog.
 * 
 * @since 1.0
 */
export interface IDialogResult {
	/**
	 * Gets or sets the type of button clicked, defined in [[DialogButtonType]].
	 * 
	 * This property might not be set depending on how the dialog was dismissed.
	 */
	button?: DialogButtonType;

	/**
	 * Gets or sets an optional result value.
	 * 
	 * This property can be used for a result value object of any type in custom dialog scenarios.
	 */
	value?: any;
}

/**
 * Represents options for a message dialog.
 * 
 * Use either the buttons or standardButtons property.
 * 
 * Example options for a message with the standrad buttons Yes and No:
 * 
 *		var options: lm.IMessageDialogOptions = {
 *			title: "Confirm Delete",
 *			message: "Are you sure that you want to delete the selected item?",
 *			standardButtons: s.StandardDialogButtons.YesNo 
 *		}
 * 
 * Example options for a message with custom buttons:
 * 
 *		var options: lm.IMessageDialogOptions = {
 *			title: "Remove Widget",
 *			message: "Are you sure that you want to remove the widget?",
 *			buttons: [{
 *				text: "Remove it!",
 *				value: "Yes",
 *				isDefault: true
 *			}, {
 *					text: "Keep it!",
 *					value: "No",
 *					isDefault: false
 *				}]
 *		}
 * 
 * @since 1.0
 */
export interface IMessageDialogOptions {
	/**
	 * Gets or sets the dialog title.
	 */
	title: string;

	/**
	 * Gets or sets the dialog message.
	 */
	message: string;

	/**
	 * Gets or sets an optional array of dialog buttons.
	 * 
	 * Use this property or the standardButtons property.
	 */
	buttons?: IDialogButton[];

	/**
	 * Gets or sets an optional stanard button configuration.
	 * 
	 * Use this property or the buttons property.
	 */
	standardButtons?: StandardDialogButtons;

	/**
	 * Gets or sets an optional value that indicates if this is an error message.
	 * 
	 * If this property is set to true the message dialog title will be shown with the error styling.
	 */
	isError?: boolean;

	/**
	 * Sets css class on modal.
	 */
	cssClass?: string;

	/**
	 * Specifies wether or not to automatically set primary button styling.
	 * 
	 * True is default.
	 */
	hasPrimaryButton?: boolean;
}

/**
 * Represents a dialog button.
 * 
 * @since 1.0
 */
export interface IDialogButton {
	/**
	 * Gets or sets the text to display on the button.
	 */
	text: string;

	/**
	 * Gets or sets the type of button defined in [[DialogButtonType]].
	 */
	type?: any;

	/**
	 * Gets or sets an optional value object that will be returned in the [[IDialogResult]] if set.
	 */
	value?: any;

	/**
	 * Gets or sets an optional ID for the button.
	 */
	id?: string;

	/**
	 * Gets or sets an optional value that indicates if the button is a link.
	 */
	isLink?: boolean;

	/**
	 * Gets or sets an optional value that indicates if the button is the default button.
	 */
	isDefault?: boolean;

	/**
	 * Gets or sets an optional svg icon path for the button
	 */
	icon?: string;

	/**
	 * Gets or sets an optional css class for the dialog button
	 */
	cssClass?: string;
}

/**
 * Represents options for a toast message.
 * 
 * @since 1.0
 */
export interface IToastOptions {
	/**
	 * Gets or sets the toast title.
	 */
	title: string;

	/**
	 * Gets or sets the toast message.
	 */
	message: string;

	/**
	 * Sting that stated where the toast should be displayed
	 * 
	 * Possible values: top right, top left, bottom left, bottom right
	 */
	position?: string;

	/**
	 * States whether the notification should be audible only.
	 */
	audibleOnly?: boolean;

	/**
	 * States whether or not to display a progress bar.
	 */
	progressBar?: boolean;

	/**
	 * States for how long the toast should be visible (milliseconds).
	 */
	timeout?: number;
}

/**
 * Represents options for a dialog.
 * 
 * @since 1.0
 */
export interface IDialogOptions {
	/**
	 * Gets or sets the dialog title.
	 */
	title: string;

	/**
	 * Gets or sets an optional parameter.
	 * 
	 * If this property is set when showing a dialog it will be available on the[[IDialog]] instance.
	 */
	parameter?: any;

	/**
	 * Gets or sets an optional parent scope.
	 */
	scope?: ng.IScope;

	/**
	 * Gets or sets an optional AngularJS template.
	 */
	template?: string;

	/**
	 * Gets or sets an optional AngularJS template URL.
	 */
	templateUrl?: string;

	/**
	 * Gets or sets an optional array of dialog buttons.
	 * 
	 * This property should not be set if custom buttons are added in the dialog template.
	 */
	buttons?: IDialogButton[];

	/**
	 * Gets or sets an optional style string that will be applied to the modal dialog instance.
	 */
	style?: string;

	/**
	 * Gets or sets an optional CSS class that will be applied to the modal dialog instance.
	 */
	cssClass?: string;

	/**
	 * Gets or sets an optional ID of the modal dialog instance.
	 */
	id?: string;

	actionPanel?: boolean;
}

/**
 * Represents a dialog event.
 * 
 * An instance of this type will be a parameter to the closing and closed events on the [[IDialog]].
 * 
 * @since 1.0
 */
export interface IDialogEvent {
	/**
	 * Gets or sets the dialog instance that is the source of the event.
	 */
	dialog: IDialog;

	/**
	 * Gets or sets an optional value that indicates if the event should be cancelled.
	 * 
	 * Note that only the closing event can currently be cancelled.
	 */
	cancel?: boolean;
}

/**
 * Represents a modal dialog instance.
 * 
 * The dialog instance can be retrieved from the scope in a dialog controller using the name "lmDialog".
 * 
 * @since 1.0
 */
export interface IDialog {
	/**
	 * Closes the dialog.
	 * 
	 * @param result Optional dialog result. The result property will be set if a value is provided.
	 */
	close(result?: IDialogResult): void;

	/**
	 * Gets or sets a function that will be called when the dialog is closing.
	 * 
	 * The closing of the dialog can be cancelled by setting the cancel property to true on the event parameter.
	 */
	closing: (e: IDialogEvent) => void;

	/**
	 * Gets or sets a function that will be called when the dialog is closed.
	 */
	closed: (e: IDialogEvent) => void;

	/**
	 * Gets or sets a function that will be called when the dialog is opened.
	 */
	opened: (e: IDialogEvent) => void;

	/**
	 * Gets or sets an optional parameter.
	 * 
	 * This property will have the value set on the [[IDialogOptions]] instance when showing the dialog.
	 */
	parameter?: any;

	/**
	 * Gets or sets the dialog result.
	 */
	result?: IDialogResult;
}

/**
 * Represents options for the copy to clipboard function.
 * 
 * @since 1.0
 */
export interface ICopyToClipboardOptions {
	/**
	 * Data to be copied or displayed in message modal if copying is not possible.
	 */
	copyData: string;

	/**
	 * If true, opens a dialog containing the string to be copied, regardless of direct copying is possible.
	 */
	forceDialog?: boolean;
}

/**
 * Represent the dialog service that can be use to show standard message dialogs or dialogs with custom content.
 * 
 * Service name: "lmDialogService"
 * 
 * @since 1.0
 */
export interface IDialogService {
	showContextualActionPanel(template: string, parameter?: any): ng.IPromise<IDialogResult>;

	/**
	 * Shows a dialog with custom content.
	 * 
	 * @param options The dialog options.
	 * @returns A promise that will be resolved to a [[IDialogResult]] when the dialog is closed.
	 */
	show(options?: IDialogOptions): ng.IPromise<IDialogResult>;

	/**
	 * Shows a message dialog.
	 * 
	 * @param options The message dialog options.
	 * @returns A promise that will be resolved to a [[IDialogResult]] when the dialog is closed.
	 */
	showMessage(options: IMessageDialogOptions): ng.IPromise<IDialogResult>;

	/**
	 * Shows a toast notification in the upper right corner of the screen with the given title and message.
	 * 
	 * @param options The toast message options.
	 */
	showToast(options: IToastOptions): void;

	/**
	 * Copies data to clipboard or opens a dialog with the data to copy if copying is not possible.
	 * @param options The copy to clipboard options.
	 */
	copyToClipboard(options: ICopyToClipboardOptions, forceDialog?: boolean): void;
}
