define(["require", "exports"], function (require, exports) {
    var SoapConstants = (function () {
        function SoapConstants() {
        }
        SoapConstants.xml = '<?xml version="1.0" encoding="UTF-8"?>';
        SoapConstants.xsi = "http://www.w3.org/2001/XMLSchema-instance";
        SoapConstants.xsd = "http://www.w3.org/2001/XMLSchema";
        SoapConstants.soap11 = {
            contentType: "text/xml",
            namespaceUri: "http://schemas.xmlsoap.org/soap/envelope/"
        };
        SoapConstants.soap12 = {
            contentType: "application/soap+xml",
            namespaceUri: "http://www.w3.org/2003/05/soap-envelope"
        };
        SoapConstants.entityMap = {
            "<": "&lt;",
            ">": "&gt;",
            "&": "&amp;",
            "\"": "&quot;",
            "'": "&apos;"
        };
        return SoapConstants;
    })();
    exports.SoapConstants = SoapConstants;
    var SoapElement = (function () {
        function SoapElement(name) {
            this.name = name;
            this.className = "SoapElement";
            this.parent = null;
            this.attributes = {};
            this.namespaces = {};
            this.children = [];
            this.value = undefined;
        }
        SoapElement.prototype.getName = function () {
            return this.name;
        };
        SoapElement.prototype.getValue = function () {
            if (this.getAttribute("xsi:nil") == "true") {
                return null;
            }
            return this.value;
        };
        SoapElement.prototype.setValue = function (value) {
            if (value == null) {
                this.setAttribute("xsi:nil", "true");
            }
            else {
                this.value = value;
            }
            return this;
        };
        SoapElement.prototype.getAttributes = function () {
            return this.attributes;
        };
        SoapElement.prototype.getAttribute = function (name) {
            return this.attributes[name];
        };
        SoapElement.prototype.setAttribute = function (name, value) {
            if (!!value || value === "") {
                this.attributes[name] = value;
            }
        };
        SoapElement.prototype.addNamespace = function (name, url) {
            this.namespaces[name] = url;
        };
        SoapElement.prototype.appendChild = function (child) {
            child.parent = this;
            this.children.push(child);
        };
        SoapElement.prototype.newChild = function (name) {
            var child = new SoapElement(name);
            this.appendChild(child);
            return this;
        };
        SoapElement.prototype.addParameter = function (name, value) {
            var child = new SoapElement(name);
            child.setValue(value);
            this.appendChild(child);
            return this;
        };
        SoapElement.prototype.getChildren = function () {
            return this.children;
        };
        SoapElement.prototype.hasChildren = function () {
            return this.children.length > 0;
        };
        SoapElement.prototype.find = function (name) {
            if (this.name === name) {
                return this;
            }
            var children = this.children;
            for (var i = 0; i < children.length; i++) {
                var result = children[i].find(name);
                if (result) {
                    return result;
                }
            }
            return null;
        };
        SoapElement.prototype.toString = function () {
            var out = [];
            out.push('<' + this.name);
            for (var name in this.namespaces) {
                out.push(' xmlns:' + name + '="' + this.namespaces[name] + '"');
            }
            for (var attr in this.attributes) {
                if (typeof (this.attributes[attr]) === "string") {
                    out.push(' ' + attr + '="' + this.attributes[attr] + '"');
                }
            }
            out.push(">");
            if (this.hasChildren()) {
                for (var cPos in this.children) {
                    var cObj = this.children[cPos];
                    if ((typeof (cObj) === "object") && (cObj.className === this.className)) {
                        out.push(cObj.toString());
                    }
                }
            }
            if (this.value !== undefined) {
                var encodedValue = null;
                var typeOf = typeof (this.value);
                if (typeOf === "string") {
                    encodedValue = this.value.match(/<!\[CDATA\[.*?\]\]>/) ?
                        this.value :
                        this.value.replace(/[<>&"']/g, function (ch) {
                            return SoapConstants.entityMap[ch];
                        });
                }
                else if (typeOf === "number") {
                    encodedValue = this.value.toString();
                }
                if (encodedValue != null) {
                    out.push(encodedValue);
                }
            }
            out.push("</" + this.name + ">");
            return out.join("");
        };
        return SoapElement;
    })();
    exports.SoapElement = SoapElement;
    var SoapEnvelope = (function () {
        function SoapEnvelope(element) {
            this.className = "SoapEnvelope";
            this.prefix = "soap";
            this.soapVersion = null;
            this.attributes = {};
            this.headers = [];
            this.bodies = [];
            var parts = element.getName().split(":");
            if (parts[1] === "Envelope" || parts[1] === "Body") {
                this.prefix = parts[0];
                if (element.getAttribute("xmlns:" + this.prefix) === SoapConstants.soap12.namespaceUri) {
                    this.soapVersion = SoapConstants.soap12;
                }
                else {
                    this.soapVersion = SoapConstants.soap11;
                }
                var envelope = element.find(this.prefix + ":Envelope");
                if (envelope) {
                    var attributes = envelope.getAttributes();
                    if (attributes) {
                        for (var i in attributes) {
                            this.addAttribute(i, attributes[i]);
                        }
                    }
                }
                var children;
                var header = element.find(this.prefix + ":Header");
                if (header) {
                    children = header.getChildren();
                    for (var j = 0; j < children.length; j++) {
                        this.addHeader(children[j]);
                    }
                }
                var body = element.find(this.prefix + ":Body");
                if (body) {
                    children = body.getChildren();
                    for (var k = 0; k < children.length; k++) {
                        this.addBody(children[k]);
                    }
                }
                else {
                    children = element.getChildren();
                    for (var l = 0; l < children.length; l++) {
                        this.addBody(children[l]);
                    }
                }
            }
            else {
                this.addBody(element);
            }
        }
        SoapEnvelope.prototype.addAttribute = function (name, value) {
            this.attributes[name] = value;
        };
        SoapEnvelope.prototype.addNamespace = function (name, uri) {
            this.addAttribute("xmlns:" + name, uri);
        };
        SoapEnvelope.prototype.addHeader = function (element) {
            this.headers.push(element);
        };
        SoapEnvelope.prototype.addBody = function (element) {
            this.bodies.push(element);
        };
        SoapEnvelope.prototype.toString = function () {
            var element = new SoapElement(this.prefix + ":Envelope");
            for (var name in this.attributes) {
                element.setAttribute(name, this.attributes[name]);
            }
            if (this.headers.length > 0) {
                var soapHeader = element.newChild(this.prefix + ":Header");
                for (var i = 0; i < this.headers.length; i++) {
                    soapHeader.appendChild(this.headers[i]);
                }
            }
            if (this.bodies.length > 0) {
                var soapBody = element.newChild(this.prefix + ":Body");
                for (var j = 0; j < this.bodies.length; j++) {
                    soapBody.appendChild(this.bodies[j]);
                }
            }
            if (!element.getAttribute("xmlns:" + this.prefix)) {
                element.addNamespace(this.prefix, this.soapVersion.namespaceUri);
            }
            if (!element.getAttribute("xmlns:xsi")) {
                element.addNamespace("xsi", SoapConstants.xsi);
            }
            if (!element.getAttribute("xmlns:xsd")) {
                element.addNamespace("xsd", SoapConstants.xsd);
            }
            return SoapConstants.xml + element.toString();
        };
        return SoapEnvelope;
    })();
    exports.SoapEnvelope = SoapEnvelope;
});
//# sourceMappingURL=soap.js.map