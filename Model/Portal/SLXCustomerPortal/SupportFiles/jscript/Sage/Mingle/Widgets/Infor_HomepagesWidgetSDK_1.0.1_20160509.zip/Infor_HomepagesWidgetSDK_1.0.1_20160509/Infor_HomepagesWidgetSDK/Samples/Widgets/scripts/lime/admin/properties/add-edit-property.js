var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../lime", "../../core"], function (require, exports, lm, c) {
    var AddEditPropertyCtrl = (function (_super) {
        __extends(AddEditPropertyCtrl, _super);
        function AddEditPropertyCtrl(scope, dialogService) {
            _super.call(this, "[AddEditPropertyCtrl] ");
            this.scope = scope;
            this.dialogService = dialogService;
            var dialog = scope["lmDialog"];
            var dialogParameter = dialog.parameter;
            this.dialog = dialog;
            this.property = angular.copy(dialogParameter.property);
            this.isEdit = angular.copy(dialogParameter.isEdit);
            this.addEditBtnLabel = this.isEdit ? "Save" : "Add";
            this.invalidNames = ["productname", "version", "logicalid", "hostname", "context", "port", "usehttps", "tenantid"];
            this.maskOptions = {
                definitions: {
                    'i': /[a-z0-9\.\_]/
                },
                pattern: "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii"
            };
        }
        AddEditPropertyCtrl.prototype.onCancel = function () {
            var result = {
                button: lm.DialogButtonType.Cancel,
                value: null
            };
            this.dialog.close(result);
        };
        AddEditPropertyCtrl.prototype.onOk = function () {
            if (this.isNameValid()) {
                var result = {
                    button: lm.DialogButtonType.Ok,
                    value: this.property
                };
                this.dialog.close(result);
            }
            else {
                this.showInvalidDialog();
            }
        };
        AddEditPropertyCtrl.prototype.isNameValid = function () {
            if (lm.ArrayUtil.contains(this.invalidNames, this.property.propertyId.toLowerCase())) {
                return false;
            }
            else {
                return true;
            }
        };
        AddEditPropertyCtrl.prototype.showInvalidDialog = function () {
            var options = {
                title: "Invalid name",
                message: "The property name '" + this.property.propertyId + "' is not valid.",
                isError: true
            };
            this.dialogService.showMessage(options);
        };
        AddEditPropertyCtrl.add = function (m) {
            m.controller("lmAddEditPropertyCtrl", AddEditPropertyCtrl);
        };
        AddEditPropertyCtrl.$inject = ["$scope", "lmDialogService"];
        return AddEditPropertyCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        AddEditPropertyCtrl.add(m);
    };
});
//# sourceMappingURL=add-edit-property.js.map