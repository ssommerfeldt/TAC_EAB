define(["require", "exports", "angular", "./service", "./admin", "./settings/settings", "./properties/properties", "./pages/private-pages", "./pages/published-pages", "./pages/page-access", "./widgets/published-widgets", "./widgets/standard-widgets", "./widgets/widget-access", "./settings/setting-set-value", "./settings/setting-add-edit-rule", "./settings/rule-add-connection", "./properties/add-edit-property", "./settings/setting-save-and-discard", "./errors", "./import-export", "./templates/template-cache-admin"], function (require, exports, angular, service, admin, settings, properties, privatePages, publishedPages, pageAccess, publishedWidgets, standardWidgets, widgetAccess, settingSetValue, settingAddEditRule, ruleAddConnection, addEditProperty, saveAndDiscard, errors, adminImportExport, tc) {
    var configureModule = function (m) {
        m.config([
            "$controllerProvider", "$provide", "$compileProvider", "$locationProvider", function ($controllerProvider, $provide, $compileProvider, $locationProvider) {
                m.controller = $controllerProvider.register;
                m.service = $provide.service;
                m.directive = $compileProvider.directive;
                $locationProvider.html5Mode({
                    enabled: true,
                    requireBase: false
                });
            }
        ]);
    };
    var configureCaching = function (m) {
        m.run([
            "$location", "$templateCache", function ($location, $templateCache) {
                tc.TemplateCacherAdmin.cache($location, $templateCache);
            }
        ]);
    };
    var m = angular.module("lime.admin", ["ui.sortable", "ui.grid", "ui.grid.selection", "ui.grid.pagination", "ui.grid.resizeColumns", "sohoxi", "lime", "lime.internal"]);
    configureModule(m);
    configureCaching(m);
    service.init(m);
    admin.init(m);
    settings.init(m);
    properties.init(m);
    settingSetValue.init(m);
    settingAddEditRule.init(m);
    ruleAddConnection.init(m);
    addEditProperty.init(m);
    saveAndDiscard.init(m);
    privatePages.init(m);
    publishedPages.init(m);
    publishedWidgets.init(m);
    standardWidgets.init(m);
    widgetAccess.init(m);
    errors.init(m);
    pageAccess.init(m);
    adminImportExport.init(m);
});
//# sourceMappingURL=module.js.map