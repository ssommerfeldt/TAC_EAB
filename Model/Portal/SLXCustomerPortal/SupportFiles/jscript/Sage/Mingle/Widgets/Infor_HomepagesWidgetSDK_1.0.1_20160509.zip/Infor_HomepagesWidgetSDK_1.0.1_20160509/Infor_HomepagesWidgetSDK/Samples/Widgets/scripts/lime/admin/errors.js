var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../core", "./service"], function (require, exports, c, s) {
    var ErrorCtrl = (function (_super) {
        __extends(ErrorCtrl, _super);
        function ErrorCtrl(scope, adminContext, adminService, dialogService, progressService) {
            _super.call(this, "[ErrorCtrl] ");
            this.scope = scope;
            this.adminContext = adminContext;
            this.adminService = adminService;
            this.dialogService = dialogService;
            this.progressService = progressService;
            this.refreshText = "Refresh";
            var adminConstants = s.AdminConstants;
            var self = this;
            scope.$watch(adminConstants.openTab, function (tab) {
                if (tab === adminConstants.errorsTab) {
                    self.listErrors();
                }
            });
        }
        ErrorCtrl.prototype.listErrors = function () {
            var self = this;
            var adminService = self.adminService;
            adminService.setBusy(true);
            adminService.getError().then(function (r) {
                var content = r.content;
                self.errorList = Object.keys(content).length > 0 ? content : [];
                adminService.setBusy(false);
            }, function (r) {
                adminService.setBusy(false);
                self.dialogService.showToast({ title: "Error", message: r.toErrorLog() });
            });
        };
        ErrorCtrl.add = function (m) {
            m.controller("lmErrorCtrl", ErrorCtrl);
        };
        ErrorCtrl.$inject = ["$scope", "lmAdminContext", "lmAdminService", "lmDialogService", "lmProgressService"];
        return ErrorCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        ErrorCtrl.add(m);
    };
});
//# sourceMappingURL=errors.js.map