﻿/// <reference path="../scripts/typings/jquery/jquery.d.ts" />
/// <reference path="../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../scripts/typings/lime/lime.d.ts" />

import lm = require("lime");

/**
 * Custom settings sample widget.
 * 
 * The widget shows a large SVG icon with a color that can be changed in settings.
 * The widget uses a custom settings UI with a color picker for changing the icon color.
 */
class SettingsSample implements lm.IWidgetInstance, lm.IWidgetSettingsInstance {
	private defaultColor = "#13a7fe";
	private color: string;
	private svg: JQuery;
	private picker: JQuery;
	private language: lm.ILanguage;

	constructor(private widgetContext: lm.IWidgetContext) {
		// Get the language object from the widget context.
		this.language = widgetContext.getLanguage();

		// Create the widget content and add it to the parent element from the widget context.
		this.svg = this.createContent();
		this.widgetContext.getElement().append(this.svg);

		this.updateColor();
	}

	/**
	 * Gets the icon color from settings.
	 * @returns The color from the widget settings or a default color.
	 */
	private getColor(): string {
		var color = this.widgetContext.getSettings().get<string>("color");
		return color || this.defaultColor;
	}

	/**
	 * Updates the color of the SVG icon.
	 */
	private updateColor() {
		this.svg.css("fill", this.getColor());
	}

	/**
	 * Custom settings UI factory function.
	 */
	public widgetSettingsFactory(settingsContext: lm.IWidgetSettingsContext) {
		var element: any = settingsContext.getElement();
		this.picker = this.addSettings(element);
		element.initialize();

		var instance: lm.IWidgetSettingsInstance = {
			closing: (arg: lm.IWidgetSettingsCloseArg) => {
				if (arg.isSave) {
					this.onSettingsSaved();
				}
			}
		};
		return instance;
	}

	/**
	 * Saves the color setting value and updates the content with the new color.
	 */
	private onSettingsSaved(): void {
		var color = this.picker.val();
		this.widgetContext.getSettings().set("color", color);
		this.updateColor();
	}

	/**
	 * Adds the settings content.
	 * @param element The parent settings element.
	 * @returns The color picker element.
	 */
	private addSettings(element: JQuery): JQuery {
		// Get the localized label text
		var labelText = this.language["color"];

		var div = $('<div class="field"></div>');
		div.append($('<label/>').text(labelText));

		var picker: any = $('<input class="colorpicker" type="text" />');
		picker.val(this.getColor());
		div.append(picker);
		element.append(div);

		return picker;
	}

	/**
	 * Creates an SVG element with a large time picker icon.
	 * @returns An SVG JQuery element.
	 */
	private createContent(): JQuery {
		var svg = $("<svg class='icon' focusable='false' aria-hidden='true'><use xlink:href='#icon-clock'></use></svg>");
		svg.css({ margin: "20px", width: "200px", height: "200px" });
		return svg;
	}
}

// Widget factory function
export var widgetFactory = (context: lm.IWidgetContext): lm.IWidgetInstance => {
	// Create and return the widget instance
	return new SettingsSample(context);
};