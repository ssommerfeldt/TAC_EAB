var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../lime", "../../core"], function (require, exports, lm, c) {
    var SettingAddEditRuleCtrl = (function (_super) {
        __extends(SettingAddEditRuleCtrl, _super);
        function SettingAddEditRuleCtrl(scope, commonDataService, adminService) {
            var _this = this;
            _super.call(this, "[SettingAddEditRuleCtrl] ");
            this.scope = scope;
            this.commonDataService = commonDataService;
            this.adminService = adminService;
            this.ruleConnectionsString = "ruleConnections";
            var dialog = scope["lmDialog"];
            var dialogParam = dialog.parameter;
            this.dialog = dialog;
            this.userName = dialogParam.userName;
            this.item = angular.copy(dialogParam.setting);
            var rule = angular.copy(dialogParam.rule);
            this.rule = rule;
            this.pages = angular.copy(dialogParam.pages);
            scope[this.ruleConnectionsString] = [];
            this.confirmButtonTitle = "Save";
            if (!lm.CommonUtil.isUndefined(rule)) {
                this.value = rule.value;
                this.ruleName = rule.name;
                scope[this.ruleConnectionsString] = rule.ruleConnections || [];
                this.isEdit = true;
                this.confirmButtonTitle = "Ok";
            }
            else {
                if (this.item.settingName === c.SettingsNames.logLevel) {
                    this.value = this.item.value;
                }
            }
            var self = this;
            if (this.item.type === c.SettingsNames.mandatoryPages) {
                var mandatories = this.value ? this.value.split(",") : [];
                var mandatoryValues = [];
                this.mandatoryValues = mandatoryValues;
                mandatories.forEach(function (id) {
                    self.pages.forEach(function (page) {
                        if (id === page.data.id) {
                            mandatoryValues.push(page);
                        }
                    });
                });
                this.sortableOptions = {
                    connectWith: ".mandatory-pages-rules-container",
                    axis: "y"
                };
            }
            if (this.item.type === "boolean" && !this.isEdit) {
                this.value = false;
            }
            this.autocompleteOptions = {
                source: function (query, done) {
                    self.commonDataService.searchUsers(query).then(function (response) {
                        var items = c.CoreUtil.getEntityArray(response.content);
                        done(query, lm.ArrayUtil.sortByProperty(items, "label"));
                    });
                },
                template: c.Templates.autocompleteEntity
            };
            this.autocompleteOptionsRole = {
                source: function (query, done) {
                    adminService.searchRoles(query).then(function (result) {
                        done(query, lm.ArrayUtil.sortByProperty(result, "label"));
                    });
                },
                template: c.Templates.autocompleteEntity,
                filterMode: "contains"
            };
            var autocompleteUsers = $("#autocomplete-rules");
            var autocompleteRoles = $("#autocomplete-role");
            this.connectAutoComplete(autocompleteUsers, scope);
            this.connectAutoComplete(autocompleteRoles, scope);
            this.autocompleteElem = autocompleteUsers;
            this.autocompleteElemRole = autocompleteRoles;
            scope.$on("$destroy", function () {
                _this.autocompleteElem.off();
                _this.autocompleteElemRole.off();
            });
        }
        SettingAddEditRuleCtrl.prototype.connectAutoComplete = function (element, scope) {
            var self = this;
            element.on("selected", function (event, target, object) {
                if (lm.CommonUtil.isUndefined(object) || lm.CommonUtil.isUndefined(object.value)) {
                    return;
                }
                self.addEntity(object.value, object.type, object.label, object.info, true);
            });
        };
        SettingAddEditRuleCtrl.prototype.addEntity = function (name, principalType, label, info, applyScope) {
            this.existsMsg = "";
            this.existsRoleMsg = "";
            var connections = this.scope[this.ruleConnectionsString];
            if (lm.ArrayUtil.containsByProperty(connections, "name", name)) {
                if (principalType === c.PrincipalType.User) {
                    this.existsMsg = "User already added";
                }
                else {
                    this.existsRoleMsg = "Role already added";
                }
                if (applyScope) {
                    this.scope.$apply();
                }
            }
            else {
                var ruleConnection = {
                    name: name,
                    isUser: principalType === c.PrincipalType.User,
                    displayName: label ? label : name,
                    info: info || name
                };
                connections.push(ruleConnection);
                if (!ruleConnection.isUser) {
                    this.roleInput = "";
                }
                if (applyScope) {
                    this.scope.$apply(this.ruleConnectionsString);
                }
            }
        };
        SettingAddEditRuleCtrl.prototype.addRole = function () {
            var name = this.roleInput;
            if (!name) {
                return;
            }
            this.addEntity(name, c.PrincipalType.Role, null, null, false);
        };
        SettingAddEditRuleCtrl.prototype.onCancel = function () {
            var result = {
                button: lm.DialogButtonType.Cancel,
                value: null
            };
            this.dialog.close(result);
        };
        SettingAddEditRuleCtrl.prototype.onOk = function () {
            if (this.ruleName) {
                var item = this.item;
                if (item.type === c.SettingsNames.mandatoryPages) {
                    this.value = this.mandatoryValues.map(function (page) {
                        return page.data.id;
                    }).join(",");
                }
                if (this.isEdit) {
                    this.editRule();
                }
                else {
                    this.addRule();
                }
                var result = {
                    button: lm.DialogButtonType.Ok,
                    value: item
                };
                this.dialog.close(result);
            }
        };
        SettingAddEditRuleCtrl.prototype.remove = function (connection) {
            var ruleConnections = this.scope[this.ruleConnectionsString];
            var connectionIndex = ruleConnections.indexOf(connection);
            ruleConnections.splice(connectionIndex, 1);
        };
        SettingAddEditRuleCtrl.prototype.addRule = function () {
            var self = this;
            var userName = this.userName;
            var ruleConnections = self.scope[self.ruleConnectionsString];
            angular.forEach(ruleConnections, function (connection) {
                connection.displayChangeDate = lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*";
                connection.changedByName = userName;
            });
            var ruleDisplayValue = this.getDisplayValue();
            var settingItem = this.item;
            var rule = {
                name: this.ruleName,
                sortOrder: 1,
                affectedUsers: ruleConnections.length,
                value: this.value,
                displayValue: ruleDisplayValue,
                isChanged: true,
                ruleConnections: ruleConnections,
                displayChangeDate: lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*",
                changedByName: userName,
                changeDate: null,
                changedBy: null,
                mode: null,
                module: null,
                readOnly: null,
                ruleSettingId: null,
                settingName: settingItem.setting.settingName
            };
            angular.forEach(settingItem.rules, function (ruleItem) {
                ruleItem.sortOrder++;
                ruleItem.isChanged = true;
                ruleItem.changedByName = userName;
                ruleItem.displayChangeDate = lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*";
            });
            settingItem.rules.push(rule);
        };
        SettingAddEditRuleCtrl.prototype.editRule = function () {
            var self = this;
            var rule = self.rule;
            var ruleConnections = this.scope[this.ruleConnectionsString];
            var userName = this.userName;
            angular.forEach(ruleConnections, function (connection) {
                connection.displayChangeDate = lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*";
                connection.changedByName = userName;
            });
            var ruleIndex = lm.ArrayUtil.indexByProperty(this.item.rules, "sortOrder", rule.sortOrder);
            var ruleDisplayValue = this.getDisplayValue();
            rule.name = this.ruleName;
            rule.value = this.value;
            rule.displayValue = ruleDisplayValue,
                rule.affectedUsers = ruleConnections.length,
                rule.isChanged = true;
            rule.ruleConnections = ruleConnections;
            rule.displayChangeDate = lm.CommonUtil.getLocaleDateString(lm.CommonUtil.getClientDate()) + "*";
            rule.changedByName = userName;
            if (ruleIndex !== -1) {
                this.item.rules[ruleIndex] = rule;
            }
        };
        SettingAddEditRuleCtrl.prototype.getDisplayValue = function () {
            var item = this.item;
            var settingType = item.type;
            var value = this.value;
            var displayValue;
            if (settingType === c.SettingsNames.defaultPage || settingType === c.SettingsNames.mandatoryPages ||
                settingType === c.SettingsNames.startPage) {
                displayValue = this.adminService.getPageDisplayTitle(value);
            }
            else if (settingType === "selector") {
                var valueObject = lm.ArrayUtil.itemByProperty(item.setting.values, "value", value);
                if (valueObject) {
                    displayValue = valueObject.label;
                }
                else {
                    displayValue = value;
                }
            }
            else {
                displayValue = value;
            }
            return displayValue;
        };
        SettingAddEditRuleCtrl.add = function (m) {
            m.controller("lmSettingAddEditRuleCtrl", SettingAddEditRuleCtrl);
        };
        SettingAddEditRuleCtrl.$inject = ["$scope", "lmCommonDataService", "lmAdminService"];
        return SettingAddEditRuleCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        SettingAddEditRuleCtrl.add(m);
    };
});
//# sourceMappingURL=setting-add-edit-rule.js.map