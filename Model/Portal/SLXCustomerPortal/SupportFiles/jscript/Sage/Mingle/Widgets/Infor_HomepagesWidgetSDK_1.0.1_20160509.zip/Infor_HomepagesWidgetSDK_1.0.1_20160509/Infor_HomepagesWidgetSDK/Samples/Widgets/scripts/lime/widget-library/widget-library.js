var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../lime", "../core"], function (require, exports, lm, c) {
    var WidgetLibraryCtrl = (function (_super) {
        __extends(WidgetLibraryCtrl, _super);
        function WidgetLibraryCtrl(scope, timeout, dataService, dialogService, widgetService, contextService, tagService, languageService) {
            var _this = this;
            _super.call(this, "[Widget Library] ");
            this.scope = scope;
            this.timeout = timeout;
            this.dataService = dataService;
            this.dialogService = dialogService;
            this.widgetService = widgetService;
            this.contextService = contextService;
            this.tagService = tagService;
            this.dialog = null;
            this.widgetCategories = {};
            this.filteredWidgetsLength = 0;
            this.visibleWidgets = 20;
            this.widgetIncrement = 20;
            var lang = languageService.getLanguage();
            this.lang = lang;
            scope.lmWlBusy = true;
            var callback = scope["lmCallback"];
            if (callback) {
                this.addCallback = callback;
            }
            var once = scope.$watch("lmDialog", function (dialog) {
                if (!dialog) {
                    return;
                }
                once();
                _this.dialog = dialog.data("contextualactionpanel");
                setTimeout(function () {
                    _this.addScrollEvents();
                    _this.listWidgets();
                    $(".contextual-action-panel .toolbar").data("toolbar")["updated"]();
                }, 5);
            });
            this.widgetCategories[c.WidgetCategory.All] = { name: lang.categoryAll, id: c.WidgetCategory.All, filterHits: 0 };
            this.widgetCategories[c.WidgetCategory.Application] = { name: lang.categoryApplication, id: c.WidgetCategory.Application, filterHits: 0, count: 0 };
            this.widgetCategories[c.WidgetCategory.BusinessIntelligence] = { name: lang.categoryBI, id: c.WidgetCategory.BusinessIntelligence, filterHits: 0, count: 0 };
            this.widgetCategories[c.WidgetCategory.BusinessProcess] = { name: lang.categoryProcess, id: c.WidgetCategory.BusinessProcess, filterHits: 0, count: 0 };
            this.widgetCategories[c.WidgetCategory.Social] = { name: lang.categorySocial, id: c.WidgetCategory.Social, filterHits: 0, count: 0 };
            this.widgetCategories[c.WidgetCategory.Utilities] = { name: lang.categoryUtilities, id: c.WidgetCategory.Utilities, filterHits: 0, count: 0 };
            this.isSearchModeOn = false;
            this.clearSelectionOnUpdate = true;
            this.context = contextService.getContext();
            this.userId = this.context.getUserId();
            this.isUserAdmin = this.context.isAdministrator;
            this.isWidgetPublishEnabled = this.context.settings.isWidgetPublishEnabled();
            this.showPublished = true;
            scope.selectedCategoryName = lang.categoryAll;
            scope.descrCharLimit = 130;
            scope.selectedCategory = c.WidgetCategory.All;
            var self = this;
            var filterTimeout;
            this.unsubscribe = scope.$watch("searchInput", function (newValue) {
                timeout.cancel(filterTimeout);
                if (!newValue) {
                    self.clearSearch();
                }
                else if (!self.nextSearchInstant) {
                    filterTimeout = timeout(function () {
                        self.searchWidgets(newValue);
                    }, 200, true);
                }
                else {
                    self.searchWidgets(newValue);
                    self.nextSearchInstant = false;
                }
            });
        }
        WidgetLibraryCtrl.add = function (m) {
            m.controller("lmWidgetLibraryCtrl", WidgetLibraryCtrl);
        };
        WidgetLibraryCtrl.prototype.close = function () {
            this.unsubscribe();
            this.scrollElement.unbind("scroll");
            this.widgetService.closeCatalog(this.dialog);
        };
        WidgetLibraryCtrl.prototype.isLink = function (widget) {
            return widget.isLink === true;
        };
        WidgetLibraryCtrl.prototype.canDelete = function (widget) {
            var owner = widget.owner;
            return owner && (this.isUserAdmin || owner === this.userId) && this.isWidgetPublishEnabled;
        };
        WidgetLibraryCtrl.prototype.addInternal = function (widget, byRef) {
            var _this = this;
            this.scope.lmWlBusy = true;
            var busyCallback = function () {
                _this.scope.lmWlBusy = false;
            };
            var addWidgetInfo = {
                widgetInfo: widget,
                byRef: byRef
            };
            this.addCallback(addWidgetInfo, busyCallback);
        };
        WidgetLibraryCtrl.prototype.copyWidget = function (widget) {
            this.addInternal(widget, false);
        };
        WidgetLibraryCtrl.prototype.addWidget = function (widget) {
            var byRef = widget.owner ? true : false;
            this.addInternal(widget, byRef);
        };
        WidgetLibraryCtrl.prototype.onTagClick = function (tag) {
            var widget = this.activeWidget;
            if (widget) {
                this.closeWidgetDetails();
            }
            this.nextSearchInstant = true;
            this.scope.searchInput = tag;
        };
        WidgetLibraryCtrl.prototype.setCategorySizes = function (widgets) {
            for (var _i = 0; _i < widgets.length; _i++) {
                var widget = widgets[_i];
                this.widgetCategories[widget.category].count++;
            }
        };
        WidgetLibraryCtrl.prototype.updateWidgets = function (widgets) {
            for (var i = 0; i < widgets.length; i++) {
                var widget = widgets[i];
                widget.displayCategory = this.translateCategory(widget.category);
                widget.displayIcon = this.createImagePath(widget);
                widget.isVisible = true;
                this.widgetCategories[widget.category].filterHits++;
            }
            widgets = lm.ArrayUtil.sortByProperty(widgets, "title", { ignoreCase: true });
            this.scope.widgets = widgets;
            this.filteredWidgetsLength = widgets.length;
            this.searchWidgets("");
        };
        WidgetLibraryCtrl.prototype.addScrollEvents = function () {
            var _this = this;
            var element = $(".contextual-action-panel .modal-body-wrapper");
            var self = this;
            element.scroll(function () {
                var category = self.scope.selectedCategory;
                if (self.visibleWidgets >= (category === c.WidgetCategory.All ? self.filteredWidgetsLength : self.widgetCategories[category].filterHits)) {
                    return;
                }
                var scrollTop = element.scrollTop();
                if (scrollTop + element[0].offsetHeight + 100 >= element[0].scrollHeight) {
                    if (!_this.preventWidgetIncrement) {
                        self.visibleWidgets += self.widgetIncrement;
                        self.preventWidgetIncrement = true;
                        self.scope.$apply("ctrl.visibleWidgets");
                        setTimeout(function () {
                            element.scrollTop(scrollTop);
                            self.preventWidgetIncrement = false;
                        }, 100);
                    }
                }
            });
            this.scrollElement = element;
        };
        WidgetLibraryCtrl.prototype.navigateToStandard = function (widget) {
            var widgets = this.scope.widgets;
            for (var i = 0; i < widgets.length; i++) {
                var w = widgets[i];
                if (w.widgetId === widget.standardWidgetId) {
                    this.showWidgetDetails(w.widgetId, true);
                    break;
                }
            }
        };
        WidgetLibraryCtrl.prototype.getStandardName = function (id) {
            var str = "";
            var widgets = this.scope.widgets;
            if (!lm.CommonUtil.isUndefined(id) && !lm.CommonUtil.isUndefined(widgets) && widgets.length > 0) {
                for (var i = 0; i < widgets.length; i++) {
                    var widget = widgets[i];
                    if (id === widget.widgetId) {
                        str = widget.title;
                        break;
                    }
                }
            }
            return str;
        };
        WidgetLibraryCtrl.prototype.listWidgets = function () {
            var _this = this;
            if (c.ClientConfiguration.isDev()) {
                var definition = c.ClientConfiguration.dev.definition;
                var localization = definition.localization;
                var id = definition.widgetId;
                var info = {
                    widgetId: id,
                    standardWidgetId: id,
                    title: localization[lm.WidgetConstants.widgetTitle],
                    description: localization[lm.WidgetConstants.widgetDescription],
                    category: definition.category,
                    owner: definition.owner,
                    version: definition.version,
                    iconFile: definition.iconFile
                };
                this.updateWidgets([info]);
                this.scope.lmWlBusy = false;
                this.scope.$apply("lmWlBusy");
                return;
            }
            this.scope.lmWlBusy = true;
            this.widgetService.listWidgets(false).then(function (r) {
                _this.debug("Listed widgets");
                if (r.content) {
                    _this.setCategorySizes(r.content);
                    _this.updateWidgets(r.content);
                    _this.scope.lmWlBusy = false;
                }
            }, function (r) {
                _this.dataService.handleError(r);
                _this.scope.lmWlBusy = false;
            });
        };
        WidgetLibraryCtrl.prototype.clearCategoryCount = function () {
            angular.forEach(this.widgetCategories, function (value) {
                value.filterHits = 0;
            });
        };
        WidgetLibraryCtrl.prototype.searchWidgets = function (query) {
            var getLower = function (s) {
                return s ? s.toLocaleLowerCase() + ";" : "";
            };
            this.clearCategoryCount();
            query = query.toLowerCase();
            var visibleWidgets = 0;
            var widgets = this.scope.widgets;
            for (var i = 0; i < widgets.length; i++) {
                var widget = widgets[i];
                if (!widget.searchableText) {
                    var tags = widget.tags;
                    widget.searchableText = getLower(widget.title) + getLower(widget.description) + getLower(widget.ownerName) + getLower(tags);
                }
                var widgetCategory = widget.category;
                var isVisible = (!widget.owner || widget.owner && this.showPublished) && widget.searchableText.indexOf(query) !== -1;
                widget.isVisible = isVisible;
                if (isVisible) {
                    visibleWidgets++;
                    var category = this.widgetCategories[widgetCategory];
                    category.filterHits++;
                }
            }
            this.filteredWidgetsLength = visibleWidgets;
            if (this.clearSelectionOnUpdate) {
                this.clearSelection();
                this.scrollUp();
            }
            else {
                this.clearSelectionOnUpdate = true;
            }
        };
        WidgetLibraryCtrl.prototype.clearSearch = function () {
            if (!this.scope.widgets) {
                return;
            }
            this.searchWidgets("");
        };
        WidgetLibraryCtrl.prototype.showWidgetDetails = function (id, isLink) {
            var widget = this.getWidgetById(id);
            if (!isLink) {
                this.scope.scrollPosBeforeExpand = this.scrollElement.scrollTop();
            }
            else {
                this.previousWidget = angular.copy(this.activeWidget);
            }
            this.activeWidget = angular.copy(widget);
        };
        WidgetLibraryCtrl.prototype.closeWidgetDetails = function () {
            if (lm.CommonUtil.isUndefined(this.previousWidget)) {
                delete this.activeWidget;
                this.scrollElement.animate({
                    scrollTop: this.scope.scrollPosBeforeExpand
                }, 1);
            }
            else {
                this.activeWidget = angular.copy(this.previousWidget);
                delete this.previousWidget;
            }
        };
        WidgetLibraryCtrl.prototype.getWidgetById = function (id) {
            return lm.ArrayUtil.itemByProperty(this.scope.widgets, "widgetId", id);
        };
        WidgetLibraryCtrl.prototype.clearSelection = function () {
            if (!lm.CommonUtil.isUndefined(this.activeWidget)) {
                delete this.activeWidget;
                delete this.previousWidget;
            }
        };
        WidgetLibraryCtrl.prototype.toggleShowPublished = function () {
            this.searchWidgets(this.scope.searchInput || "");
        };
        WidgetLibraryCtrl.prototype.selectCategory = function (category, forceNameChange) {
            var selectedCategory = this.scope.selectedCategory;
            var categoryId = category.id;
            var searchInput = this.scope.searchInput;
            var isCategoryAll = categoryId === c.WidgetCategory.All;
            if (selectedCategory === categoryId || category.count === 0 || !isCategoryAll && searchInput && category.filterHits === 0) {
                if (forceNameChange) {
                    this.scope.selectedCategory = categoryId;
                    if (category.name) {
                        this.scope.selectedCategoryName = category.name;
                    }
                }
                return;
            }
            this.clearSelection();
            this.scope.selectedCategory = categoryId;
            if (category.name) {
                this.scope.selectedCategoryName = category.name;
            }
            if (isCategoryAll) {
                this.resetSort();
            }
            else {
                var categoryWidgets = [];
                var widgets = [];
                var scopeWidgets = this.scope.widgets;
                for (var i = 0; i < scopeWidgets.length; i++) {
                    if (scopeWidgets[i].category === categoryId) {
                        categoryWidgets.push(scopeWidgets[i]);
                    }
                    else {
                        widgets.push(scopeWidgets[i]);
                    }
                }
                this.scope.widgets = categoryWidgets.concat(widgets);
            }
            this.scrollUp();
        };
        WidgetLibraryCtrl.prototype.resetSort = function () {
            var widgets = this.scope.widgets;
            widgets = lm.ArrayUtil.sortByProperty(widgets, "title", { ignoreCase: true });
            this.scope.widgets = widgets;
        };
        WidgetLibraryCtrl.prototype.translateCategory = function (category) {
            var lang = this.lang;
            if (category === c.WidgetCategory.BusinessIntelligence) {
                return lang.widgetCategoryBI;
            }
            else if (category === c.WidgetCategory.BusinessProcess) {
                return lang.widgetCategoryProcess;
            }
            else if (category === c.WidgetCategory.Social) {
                return lang.widgetCategorySocial;
            }
            else if (category === c.WidgetCategory.Utilities) {
                return lang.widgetCategoryUtility;
            }
            return lang.widgetCategoryApplication;
        };
        WidgetLibraryCtrl.prototype.deleteWidget = function (widget) {
            var _this = this;
            var lang = this.lang;
            this.dialogService.showMessage({
                title: lang.deleteWidget,
                message: lang.format(lang.confirmDeleteCustomWidget, widget.title),
                standardButtons: lm.StandardDialogButtons.YesNo
            }).then(function (r) {
                if (r.button === lm.DialogButtonType.Yes) {
                    if (widget.owner) {
                        _this.scope.lmWlBusy = true;
                        _this.debug("Attempting to delete customized widget.");
                        _this.widgetService.deletePublished([widget.widgetId]).then(function (r) {
                            _this.widgetService.removeDefinition(widget.widgetId);
                            lm.ArrayUtil.removeByProperty(_this.scope.widgets, "widgetId", widget.widgetId);
                            var searchText = _this.scope.searchInput;
                            if (searchText && searchText.length) {
                                _this.searchWidgets(searchText);
                            }
                            else {
                                _this.clearSelection();
                            }
                            _this.scrollElement.animate({
                                scrollTop: _this.scope.scrollPosBeforeExpand
                            }, 1);
                            _this.debug("Customized widget deleted.");
                            _this.scope.lmWlBusy = false;
                        }, function (r) {
                            _this.widgetService.handleError(r);
                            _this.scope.lmWlBusy = false;
                        });
                    }
                }
            });
        };
        WidgetLibraryCtrl.prototype.createImagePath = function (widget) {
            return this.widgetService.createImagePath(widget);
        };
        WidgetLibraryCtrl.prototype.scrollUp = function () {
            this.scrollElement.scrollTop(0);
            this.visibleWidgets = this.widgetIncrement;
        };
        WidgetLibraryCtrl.$inject = ["$scope", "$timeout", "lmDataService", "lmDialogService", "lmWidgetService", "lmContextService", "lmTagService", "lmLanguageService"];
        return WidgetLibraryCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        WidgetLibraryCtrl.add(m);
    };
});
//# sourceMappingURL=widget-library.js.map