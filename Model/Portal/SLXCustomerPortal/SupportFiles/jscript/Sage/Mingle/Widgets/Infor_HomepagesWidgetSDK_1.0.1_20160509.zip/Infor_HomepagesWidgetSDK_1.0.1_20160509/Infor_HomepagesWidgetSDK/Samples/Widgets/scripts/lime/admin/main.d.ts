/// <reference path="../../typings/requirejs/require.d.ts" />
/// <reference path="../../typings/angularjs/angular.d.ts" />
