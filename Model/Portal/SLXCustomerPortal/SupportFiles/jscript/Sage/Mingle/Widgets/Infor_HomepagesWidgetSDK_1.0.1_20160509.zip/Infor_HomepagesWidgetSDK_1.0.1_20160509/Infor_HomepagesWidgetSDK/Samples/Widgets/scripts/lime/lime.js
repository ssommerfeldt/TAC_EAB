/// <reference path="../typings/jquery/jquery.d.ts" />
/// <reference path="../typings/angularjs/angular.d.ts" />
/// <reference path="../typings/sohoxi/sohoxi.d.ts" />
define(["require", "exports"], function (require, exports) {
    /**
     * Defines widget states.
     * @since 1.0
     */
    var WidgetState = (function () {
        function WidgetState() {
        }
        /**
         * Running state.
         *
         * The running state is the default widget state.
         */
        WidgetState.running = "running";
        /**
         * Busy state.
         *
         * The busy state can be used to indicate that the widget is busy performing an operation
         * such as a server request.
         */
        WidgetState.busy = "busy";
        /**
         * Error state.
         *
         * The error state indicates that the widget is broken in some way and is not functioning properly.
         * There could be different reasons for this such as missing settings or that a backend service cannot be reached for example.
         */
        WidgetState.error = "error";
        return WidgetState;
    })();
    exports.WidgetState = WidgetState;
    /**
     * Defines widget activation and deactivation types.
     *
     * The activation types indicates what caused a widget to be activated or deactivated.
     * Most types can be used for both activation and deactivation but close for example can only be used in deactivation.
     *
     * @since 1.0
     */
    var WidgetActivationType = (function () {
        function WidgetActivationType() {
        }
        /**
         * The widget visibility has been changed.
         */
        WidgetActivationType.visibility = "visibility";
        /**
         * The widget has been closed.
         */
        WidgetActivationType.close = "close";
        /**
         * The widget settings dialog has been opened or closed.
         */
        WidgetActivationType.settings = "settings";
        /**
         * The widget has entered or exited edit mode.
         */
        WidgetActivationType.edit = "edit";
        return WidgetActivationType;
    })();
    exports.WidgetActivationType = WidgetActivationType;
    /**
     * Used to define severity in IWidgetMessage.
     *
     * @since 1.0
     */
    (function (WidgetMessageType) {
        /**
         * Information message.
         */
        WidgetMessageType[WidgetMessageType["Info"] = 0] = "Info";
        /**
         * Alert message.
         */
        WidgetMessageType[WidgetMessageType["Alert"] = 1] = "Alert";
        /**
         * Error message.
         */
        WidgetMessageType[WidgetMessageType["Error"] = 2] = "Error";
    })(exports.WidgetMessageType || (exports.WidgetMessageType = {}));
    var WidgetMessageType = exports.WidgetMessageType;
    /**
     * Represents the different types of widget settings. All except the object type are supported in the metadata settings UI.
     *
     * @since 1.0
     */
    var WidgetSettingsType = (function () {
        function WidgetSettingsType() {
        }
        WidgetSettingsType.stringType = "string";
        WidgetSettingsType.numberType = "number";
        WidgetSettingsType.booleanType = "boolean";
        WidgetSettingsType.selectorType = "selector";
        WidgetSettingsType.objectType = "object";
        return WidgetSettingsType;
    })();
    exports.WidgetSettingsType = WidgetSettingsType;
    /**
     * Defines widget constants.
     *
     * @since 1.0
     */
    var WidgetConstants = (function () {
        function WidgetConstants() {
        }
        WidgetConstants.widgetInstanceKey = "lmWidgetInstance";
        WidgetConstants.widgetContextKey = "lmWidgetContext";
        WidgetConstants.widgetTitle = "widgetTitle";
        WidgetConstants.widgetDescription = "widgetDescription";
        return WidgetConstants;
    })();
    exports.WidgetConstants = WidgetConstants;
    /**
     * Utility class for array operations.
     *
     * @since 1.0
     */
    var ArrayUtil = (function () {
        function ArrayUtil() {
        }
        /**
         * Checks if an item exists in an array.
         * @returns True if an item exists.
         */
        ArrayUtil.contains = function (array, value) {
            if (array) {
                return $.inArray(value, array) >= 0;
            }
            return false;
        };
        /**
         * Gets the index of a value in an array.
         * @param array Array to get value index from.
         * @param value Value to get index of.
         * @returns index of value.
         */
        ArrayUtil.indexOf = function (array, value) {
            return $.inArray(value, array);
        };
        /**
            * Sorts the array in acending order of the given property.
            * @param array Array to sort.
            * @param property Property to sort array by.
            * @param options Optional options for controlling the sorting.
            * @returns The sorted array.
            */
        ArrayUtil.sortByProperty = function (array, property, options) {
            var ignoreCase = options && options.ignoreCase;
            return array.sort(function (x, y) {
                var xProp = x[property];
                var yProp = y[property];
                // User concatenation instead of toString to avoid crashes for missing properties
                var a = ignoreCase ? ("" + xProp).toLocaleLowerCase() : xProp;
                var b = ignoreCase ? ("" + yProp).toLocaleLowerCase() : yProp;
                if (a > b) {
                    return 1;
                }
                else if (a < b) {
                    return -1;
                }
                return 0;
            });
        };
        /**
         * Removes an item in an array.
         */
        ArrayUtil.remove = function (array, item) {
            var index = $.inArray(item, array);
            if (index >= 0) {
                array.splice(index, 1);
            }
        };
        /**
         * Removes an item in an array by matching the value of a specific property.
         */
        ArrayUtil.removeByProperty = function (array, name, value) {
            for (var i = 0; i < array.length; i++) {
                if (array[i][name] === value) {
                    array.splice(i, 1);
                    return true;
                }
            }
            return false;
        };
        ArrayUtil.removeByPredicate = function (array, predicate) {
            for (var i = 0; i < array.length; i++) {
                if (predicate(array[i])) {
                    array.splice(i, 1);
                    return true;
                }
            }
            return false;
        };
        /**
         * Gets the index of an item in an array by matching the value of a specific property.
         */
        ArrayUtil.indexByProperty = function (array, name, value) {
            if (array) {
                for (var i = 0; i < array.length; i++) {
                    if (array[i][name] === value) {
                        return i;
                    }
                }
            }
            return -1;
        };
        /**
         * Gets the item in an array by matching the value of a specific property.
         */
        ArrayUtil.itemByProperty = function (array, name, value) {
            var index = this.indexByProperty(array, name, value);
            return index >= 0 ? array[index] : null;
        };
        /**
         * Gets the item matching the predicate.
         */
        ArrayUtil.itemByPredicate = function (array, predicate) {
            for (var i = 0; i < array.length; i++) {
                if (predicate(array[i])) {
                    return array[i];
                }
            }
            return null;
        };
        /**
         * Checks if an item exists in an array by matching the value of a specific property.
         * @ returns True if an item with the property and value exists.
         */
        ArrayUtil.containsByProperty = function (array, name, value) {
            return this.indexByProperty(array, name, value) >= 0;
        };
        /**
        * Gets the last item in an array.
        * @returns The last item or null if the array is null or empty.
        */
        ArrayUtil.last = function (array) {
            if (array && array.length > 0) {
                return array[array.length - 1];
            }
            return null;
        };
        /**
         * Finds the first item in the array that matches the conditions defined in the predicate function.
         * @param array An array of items to search.
         * @param predicate A predicate function that should return true if the item parameter matches the predicate condition.
         */
        ArrayUtil.find = function (array, predicate) {
            if (array) {
                for (var _i = 0; _i < array.length; _i++) {
                    var item = array[_i];
                    if (predicate(item)) {
                        return item;
                    }
                }
            }
            return null;
        };
        /**
        * Finds all items in the array that matches the conditions defined in the predicate function.
        * @param array An array of items to search.
        * @param predicate A predicate function that should return true if the item parameter matches the predicate condition.
        */
        ArrayUtil.findAll = function (array, predicate) {
            if (array) {
                var arr = [];
                for (var _i = 0; _i < array.length; _i++) {
                    var item = array[_i];
                    if (predicate(item)) {
                        arr.push(item);
                    }
                }
                return arr;
            }
            return null;
        };
        /**
        * Creates an array of n entries with the specified default value.
        * @params n            Number of entries.
        * @params defaultValue The default values of the entries.
        * @returns Array.
        */
        ArrayUtil.array = function (n, defaultValue) {
            var arr = new Array(n);
            for (var j = 0; j < n; j++) {
                arr[j] = defaultValue;
            }
            return arr;
        };
        /**
        * Creates a matrix (two dimensional array) with specified default values.
        * @param rows     The number of rows in the matrix.
        * @params columns The number of columns in the matrix.
        * @returns matrix.
        */
        ArrayUtil.matrix = function (rows, columns, defaultValue) {
            var matrix = new Array(rows);
            for (var i = 0; i < matrix.length; i++) {
                var cols = new Array(columns);
                for (var j = 0; j < columns; j++) {
                    cols[j] = defaultValue;
                }
                matrix[i] = ArrayUtil.array(columns, defaultValue);
            }
            return matrix;
        };
        /**
         * Moves a object in an array to another index.
         */
        ArrayUtil.move = function (array, index, newIndex) {
            if (newIndex >= array.length) {
                var k = newIndex - array.length;
                while ((k--) + 1) {
                    array.push(undefined);
                }
            }
            array.splice(newIndex, 0, array.splice(index, 1)[0]);
        };
        return ArrayUtil;
    })();
    exports.ArrayUtil = ArrayUtil;
    /**
     * Number utility functions.
     *
     * @since 1.0
     */
    var NumUtil = (function () {
        function NumUtil() {
        }
        NumUtil.getLocaleSeparator = function () {
            var n = 1.1;
            var s = n.toLocaleString().substring(1, 2);
            return s;
        };
        /**
         * Gets the default options used by the functions in the class.
         * @returns The default options.
         */
        NumUtil.getDefaultOptions = function () {
            return NumUtil.defaultOptions;
        };
        /**
         * Sets the default options used by the functions in the class.
         * @options The default options.
         */
        NumUtil.setDefaultOptions = function (options) {
            NumUtil.defaultOptions = options;
            if (options.separator) {
                NumUtil.defaultSeparator = options.separator;
            }
        };
        /**
         * Gets a values that indicates if the parameter is a number.
         *
         * The value is considered to be a number if it can be parsed as a float, it is a number and it is finite.
         * @param n The value to check.
         * @returns True if the value is a number.
         */
        NumUtil.isNumber = function (n) {
            return !isNaN(parseFloat(n)) && isFinite(n);
        };
        /**
         * Gets an integer value from a string.
         * @param s The string to parse.
         * @param defaultValue Optional default value to return if the string cannot be parsed. The default is zero.
         * @returns An integer parsed from the string or the default value.
         */
        NumUtil.getInt = function (s, defaultValue) {
            if (defaultValue === void 0) { defaultValue = 0; }
            if (s) {
                try {
                    return parseInt(s) || defaultValue;
                }
                catch (e) {
                }
            }
            return defaultValue;
        };
        /**
         * Formats a number or string using default or specified formatting options.
         *
         * This function currently only supports formatting using a specified decimal separator.
         * The value to format is expected to be either a number or a string containing a number where any
         * decimal separator is dot (.). If the value is a string it may not contain any thousand separators
         * or other formatting characters.
         *
         * @param value The value to format which can be a number or a number in string format.
         * @param options Optional formatting options.
         */
        NumUtil.format = function (value, options) {
            var s = value.toString();
            if ("" === s) {
                return s;
            }
            var separator = options ? options.separator : NumUtil.defaultOptions.separator;
            if (!separator) {
                separator = NumUtil.defaultSeparator;
            }
            s = s.replace(".", separator);
            return s;
        };
        /**
         * Pads a number with leading zeroes up to the specified length.
         * @param num The number to pad.
         * @param length The length of the string.
         */
        NumUtil.pad = function (num, length) {
            var s = num + "";
            while (s.length < length) {
                s = "0" + s;
            }
            return s;
        };
        /**
         * Gets a value that indicates if the string contains only integers (1234567890).
         * @param s The string value to check.
         * @returns True if string contains only integers.
         */
        NumUtil.hasOnlyIntegers = function (s) {
            if (!s) {
                return false;
            }
            var digits = "1234567890";
            for (var i = 0; i < s.length; i++) {
                if (digits.indexOf(s.charAt(i)) === -1) {
                    return false;
                }
            }
            return true;
        };
        NumUtil.tryGetInt = function (input, defaultValue) {
            if (defaultValue === void 0) { defaultValue = 0; }
            if (!input) {
                return defaultValue;
            }
            if (this.isNumber(input)) {
                return input;
            }
            return this.getInt(input.toString(), defaultValue);
        };
        NumUtil.defaultSeparator = NumUtil.getLocaleSeparator();
        NumUtil.defaultOptions = {
            separator: NumUtil.defaultSeparator
        };
        return NumUtil;
    })();
    exports.NumUtil = NumUtil;
    /**
     * Common Utility functions.
     *
     * @since 1.0
     */
    var CommonUtil = (function () {
        function CommonUtil() {
        }
        /**
         * Gets the local date string.
         * Options can be used to set the formatting, for example: { date: "short" } or { pattern: "yyyy-MM-dd HH:mm" }.
         * @params dateString Date string.
         * @params options    Options for fromatting.
         * @returns string    Formatted date.
         */
        CommonUtil.getLocaleDateString = function (dateString, options) {
            try {
                var date = new Date(dateString);
                if (!options) {
                    // TODO Decide default date format
                    options = { pattern: "yyyy-MM-dd HH:mm" };
                }
                return Locale.formatDate(date, options);
            }
            catch (ex) {
                return dateString;
            }
        };
        /**
         * Delets a property of an object.
         * @param object   Object of which to delete a property.
         * @param property Property to delete.
         */
        CommonUtil.deleteProperty = function (object, property) {
            if (!CommonUtil.isUndefined(object[property])) {
                delete object[property];
            }
        };
        /**
         * Converts a boolean from a string.
         * @param string       String to convert.
         * @param defaultValue Default return value if string can't be used.
         */
        CommonUtil.getBoolean = function (s, defaultValue) {
            if (defaultValue === void 0) { defaultValue = false; }
            if (s && s.length > 0) {
                return s[0].toLowerCase() === "t";
            }
            return defaultValue;
        };
        CommonUtil.getUuid = function (prefix) {
            return prefix + (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1) + (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
        };
        CommonUtil.hasValue = function (anyObject) {
            if (typeof anyObject != "undefined") {
                return anyObject != null;
            }
            return false;
        };
        CommonUtil.isUndefined = function (anyObject) {
            return typeof anyObject === "undefined";
        };
        /**
         * Creates a string with random uppercase letters and numbers.
         * The default length is 16 if the stringLength parameter is omitted.
         */
        CommonUtil.random = function (stringLength) {
            if (stringLength === void 0) { stringLength = 16; }
            var chars = CommonUtil.chars;
            var randomstring = "";
            for (var i = 0; i < stringLength; i++) {
                var rnum = Math.floor(Math.random() * chars.length);
                randomstring += chars.substring(rnum, rnum + 1);
            }
            return randomstring;
        };
        /**
         * Gets a value that indicates if the current window is an IFrame or not.
         */
        CommonUtil.isIframe = function () {
            try {
                return window.self !== window.top;
            }
            catch (e) {
                return true;
            }
        };
        /**
         * Returns the client's date as yyyy-mm-ddThh:mm
         * Ex: 2015-01-20T21:20
         */
        CommonUtil.getClientDate = function () {
            var addZero = function (dateNr) {
                var dateString;
                if (dateNr < 10) {
                    dateString = dateNr.toString();
                    dateString = "0" + dateString;
                }
                else {
                    dateString = dateNr.toString();
                }
                return dateString;
            };
            var date = new Date(Date.now());
            var year = date.getFullYear();
            var month = addZero(date.getMonth() + 1);
            var day = addZero(date.getDate());
            var hours = addZero(date.getHours());
            var min = addZero(date.getMinutes());
            return year + "-" + month + "-" + day + "T" + hours + ":" + min;
        };
        /**
         * Detects IE version and sets it as a class on the html element.
         */
        CommonUtil.detectBrowser = function () {
            if (!!navigator.userAgent.match(/Trident/)) {
                $('html').addClass('ie');
            }
            if (navigator.appVersion.indexOf('MSIE 9.0') > -1) {
                $('html').addClass('ie9');
            }
            if (navigator.appVersion.indexOf('MSIE 10.0') > -1) {
                $('html').addClass('ie10');
            }
            if (!!navigator.userAgent.match(/Trident\/7\./)) {
                $('html').addClass('ie11');
            }
        };
        CommonUtil.chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        return CommonUtil;
    })();
    exports.CommonUtil = CommonUtil;
    /**
     * String utility functions.
     *
     * @since 1.0
     */
    var StringUtil = (function () {
        function StringUtil() {
        }
        /**
         * Gets a value that indicates if the string is null, undefined, empty or contains only whitespace.
         * @param value The string to check.
         * @returns True if the string is null, undefined, empty or contains only whitespace.
         */
        StringUtil.isNullOrWhitespace = function (value) {
            return !value || !value.trim();
        };
        /**
         * Gets a value that indicates if a string starts with a specified value.
         * @param value The string value to check.
         * @param prefix The value that the string should start with.
         * @returns True if the string starts with the specified prefix value.
         */
        StringUtil.startsWith = function (value, prefix) {
            return value ? value.indexOf(prefix) === 0 : false;
        };
        StringUtil.replaceParameters = function (template, resolveFunction) {
            template = template.replace(/{(.*?)}/g, function (substring, key) {
                var value = resolveFunction(key);
                return (typeof value != "undefined" ? value : "");
            });
            return template;
        };
        /**
         * Gets a value that indicates if a string ends with a specified value.
         * @param value The string value to check.
         * @param prefix The value that the string should end with.
         * @returns True if the string ends with the specified suffix value.
         */
        StringUtil.endsWith = function (value, suffix) {
            if (!value) {
                return false;
            }
            return value.indexOf(suffix, value.length - suffix.length) !== -1;
        };
        /**
         * Trims whitespace from the end of a string.
         * @param value The value to trim.
         * @returns The trimmed value.
         */
        StringUtil.trimEnd = function (value) {
            return value.replace(/\s+$/, "");
        };
        StringUtil.format = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i - 0] = arguments[_i];
            }
            var stringValue = "missing";
            try {
                stringValue = args[0];
                var params = Array.prototype.slice.call(args, 1);
                stringValue = stringValue.replace(/{(\d+)}/g, function () {
                    var value = params[arguments[1]];
                    return (typeof value != 'undefined' ? value : arguments[0]);
                });
            }
            catch (ex) {
            }
            return stringValue;
        };
        return StringUtil;
    })();
    exports.StringUtil = StringUtil;
    /**
     * HTML utility functions for creating and manipulating HTML elements.
     *
     * @since 1.0
     */
    var HtmlUtil = (function () {
        function HtmlUtil() {
        }
        /**
         * Creates an iframe element without borders and the sandbox attribute set.
         */
        HtmlUtil.iframe = function (url, name) {
            // TODO Change to options parameter...
            var iframe = $("<iframe />").attr("sandbox", "allow-same-origin allow-scripts allow-popups allow-forms").attr("seamless", "seamless").attr("frameborder", "0").addClass("lm-fill-absolute");
            if (url) {
                iframe.attr("src", url);
            }
            if (name) {
                iframe.attr("name", name);
            }
            return iframe;
        };
        return HtmlUtil;
    })();
    exports.HtmlUtil = HtmlUtil;
    /**
     * Log text messages and exceptions on different log levels to the browser console and optional custom log appenders.
     *
     * **Example:**
     *
     * import Log = require("log");
     *	Log.info("Application initialized");
     *
     * @since 1.0
     */
    var Log = (function () {
        function Log() {
        }
        /**
         * Adds a new log appender that will receive log entries for the current log level.
         * @param A log appender.
         */
        Log.addAppender = function (appender) {
            Log.appenders.push(appender);
        };
        /**
         * Removes an existing log appender.
         * @param appender An existing appender to remove.
         */
        Log.removeAppender = function (appender) {
            ArrayUtil.remove(Log.appenders, appender);
        };
        /**
         * Gets a military time string with hours, minutes, seconds and milliseconds on the format hh:mm:ss,ttt.
         * @returns A military time string.
         */
        Log.getTime = function () {
            // TODO Utility function?
            var date = new Date();
            var hours = date.getHours();
            var minutes = date.getMinutes();
            var seconds = date.getSeconds();
            var ms = date.getMilliseconds();
            var time = (hours < 10 ? "0" : "") + hours + ":" +
                (minutes < 10 ? "0" : "") + minutes + ":" +
                (seconds < 10 ? "0" : "") + seconds + "," +
                (ms < 10 ? "00" : (ms < 100 ? "0" : "") + ms);
            return time;
        };
        /**
         * Gets a formatted log entry.
         * @param level The log level.
         * @param ex An optional exception object.
         */
        Log.getLogEntry = function (level, text, ex) {
            var logText = "[" + Log.getTime() + "] " + this.prefixes[level] + " " + text;
            if (ex) {
                logText += " " + ex.message;
                if (ex.stack) {
                    logText += " " + ex.stack;
                }
            }
            return logText;
        };
        Log.log = function (currentLevel, level, text, ex) {
            if (level <= currentLevel) {
                // Log to the console if it is enabled and exist in the current browser.
                if (Log.isConsoleLogEnabled && window.console) {
                    var logText = Log.getLogEntry(level, text, ex);
                    if (level <= 1) {
                        console.error(logText);
                    }
                    else if (level === 2) {
                        console.warn(logText);
                    }
                    else if (level === 3) {
                        console.info(logText);
                    }
                    else {
                        console.log(logText);
                    }
                }
                if (Log.appenders) {
                    for (var i = 0; i < Log.appenders.length; i++) {
                        try {
                            Log.appenders[i](level, text, ex);
                        }
                        catch (e) {
                        }
                    }
                }
            }
        };
        /**
         * Sets the default log level which is information.
         */
        Log.setDefault = function () {
            this.level = this.levelInfo;
        };
        /**
         * Logs a text message and an optional exception on the fatal log level.
         * @param text A log message.
         * @param ex An optional exception object.
         */
        Log.fatal = function (text, ex) {
            this.log(this.level, this.levelFatal, text, ex);
        };
        /**
         * Logs a text message and an optional exception on the error log level.
         * @param text A log message.
         * @param ex An optional exception object.
         */
        Log.error = function (text, ex) {
            this.log(this.level, this.levelError, text, ex);
        };
        /**
         * Logs a text message and an optional exception on the warning log level.
         * @param text A log message.
         * @param ex An optional exception object.
         */
        Log.warning = function (text, ex) {
            this.log(this.level, this.levelWarning, text, ex);
        };
        /**
         * Logs a text message and an optional exception on the information log level.
         * @param text A log message.
         * @param ex An optional exception object.
         */
        Log.info = function (text, ex) {
            this.log(this.level, this.levelInfo, text, ex);
        };
        /**
         * Gets a value that indicates if the debug log level is enabled. Use this before logging large debug messages.
         *
         * @returns True if the debug log level is enabled
         */
        Log.isDebug = function () {
            return this.level >= this.levelDebug;
        };
        /**
         * Sets the current log level to debug.
         */
        Log.setDebug = function () {
            this.level = this.levelDebug;
        };
        /**
         * Logs a text message and an optional exception on the debug log level.
         * @param text A log message.
         * @param ex An optional exception object.
         */
        Log.debug = function (text, ex) {
            this.log(this.level, this.levelDebug, text, ex);
        };
        /**
         * Gets a value that indicates if the trace log level is enabled. Use this before logging large trace messages.
         *
         * @returns True if the trace log level is enabled
         */
        Log.isTrace = function () {
            return this.level >= this.levelTrace;
        };
        /**
         * Sets the current log level to trace.
         */
        Log.setTrace = function () {
            this.level = this.levelTrace;
        };
        /**
         * Logs a text message and an optional exception on the trace log level.
         * @param text A log message.
         * @param ex An optional exception object.
         */
        Log.trace = function (text, ex) {
            this.log(this.level, this.levelTrace, text, ex);
        };
        /**
         * Fatal log level. Severe errors that prevents the application from functioning.
         */
        Log.levelFatal = 0;
        /**
         * Error log level.
         */
        Log.levelError = 1;
        /**
         * Warning log level.
         */
        Log.levelWarning = 2;
        /**
         * Information log level.
         */
        Log.levelInfo = 3;
        /**
         * Debug log level. Detailed information for debug purposes.
         */
        Log.levelDebug = 4;
        /**
         * Trace log level. Most detailed information for debug purposes.
         */
        Log.levelTrace = 5;
        /**
         * Gets or sets the current log level. The default log level is information.
         */
        Log.level = Log.levelInfo;
        /**
         * Gets or sets a value that indicates if logging to the browser console is enabled.
         * The default value is true.
         */
        Log.isConsoleLogEnabled = true;
        Log.prefixes = ["[FATAL]", "[ERROR]", "[WARNING]", "[INFO]", "[DEBUG]", "[TRACE]"];
        Log.appenders = [];
        return Log;
    })();
    exports.Log = Log;
    /**
     * Defines standard button combinations for a message dialog.
     *
     * @since 1.0
     */
    (function (StandardDialogButtons) {
        /**
         * Shows an OK button (1).
         */
        StandardDialogButtons[StandardDialogButtons["Ok"] = 1] = "Ok";
        /**
         * Shows an OK button and a Cancel button (2).
         */
        StandardDialogButtons[StandardDialogButtons["OkCancel"] = 2] = "OkCancel";
        /**
         * Shows a Yes and a No button (3).
         */
        StandardDialogButtons[StandardDialogButtons["YesNo"] = 3] = "YesNo";
        /**
         * Shows a Yes, No and a Cancel button (4).
         */
        StandardDialogButtons[StandardDialogButtons["YesNoCancel"] = 4] = "YesNoCancel";
    })(exports.StandardDialogButtons || (exports.StandardDialogButtons = {}));
    var StandardDialogButtons = exports.StandardDialogButtons;
    /**
     * Defines the different types of buttons that can be used in dialogs.
     *
     * @since 1.0
     */
    (function (DialogButtonType) {
        /**
         * No button is used or the button is unknown (1).
         */
        DialogButtonType[DialogButtonType["None"] = 1] = "None";
        /**
         * OK button (2).
         */
        DialogButtonType[DialogButtonType["Ok"] = 2] = "Ok";
        /**
         * Cancel button (3).
         */
        DialogButtonType[DialogButtonType["Cancel"] = 3] = "Cancel";
        /**
         * Yes button (4).
         */
        DialogButtonType[DialogButtonType["Yes"] = 4] = "Yes";
        /**
         * No button (5).
         */
        DialogButtonType[DialogButtonType["No"] = 5] = "No";
        /**
         * Custom button (6).
         */
        DialogButtonType[DialogButtonType["Custom"] = 6] = "Custom";
    })(exports.DialogButtonType || (exports.DialogButtonType = {}));
    var DialogButtonType = exports.DialogButtonType;
});
//# sourceMappingURL=lime.js.map