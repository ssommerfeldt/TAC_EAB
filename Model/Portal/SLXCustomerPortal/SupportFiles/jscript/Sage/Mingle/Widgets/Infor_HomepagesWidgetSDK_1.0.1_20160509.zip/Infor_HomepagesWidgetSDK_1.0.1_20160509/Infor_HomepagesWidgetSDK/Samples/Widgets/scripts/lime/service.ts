﻿import lm = require("./lime");
import c = require("./core");

class ProgressService implements c.IProgressService {
	static $inject = ["$rootScope"];

	constructor(private rootScope: ng.IScope) {
	}

	public isBusy(): boolean {
		return this.rootScope["lmBusy"] ? true : false;
	}

	public setBusy(isBusy: boolean): void {
		this.rootScope["lmBusy"] = isBusy;
	}

	static add(m: ng.IModule) {
		m.service("lmProgressService", ProgressService);
	}
}

class DataService extends c.CoreBase implements c.IDataService {
	private _overrideUrl: string;
	private language = "en-US";
	private timestamp: number;
	private pingInterval = -1;
	private isExecuting = false;

	static $inject = ["$http", "$q", "$timeout", "lmProgressService", "lmDialogService", "lmLanguageService"];

	constructor(private http: ng.IHttpService, public q: any, private timeout: ng.ITimeoutService, private progressService: c.IProgressService, private dialogService: lm.IDialogService, private languageService: c.ILanguageService) {
		super("[DataService] ");

		this.timestamp = Date.now();
	}

	private checkPing(): void {
		const diff = Date.now() - this.timestamp;
		if (!this.isExecuting && diff >= this.pingInterval) {
			this.executePost("/common/ping", {}).then(() => {
				this.debug("Pinged server.");
			}, () => {
				this.warning("Failed to ping server.");
			});
		}
	}

	private done(): void {
		// The timestamp is currently updated even if the server do not return a 2xx response to avoid spamming ping requests in error scenarios.
		this.isExecuting = false;
		this.timestamp = Date.now();
	}

	public getUrl(path?: string): string {
		if (path) {
			return this.getBaseUrl() + "/" + c.Constants.restRoot + "/" + path;
		}
		return this.getBaseUrl() + "/" + c.Constants.restRoot + "/";
	}

	public setLanguage(language: string): void {
		this.language = language;
	}

	public startPing(pingInterval: number): void {
		// Start pinging if we got an interval and we are not already started.
		if (pingInterval > 0 && this.pingInterval <= 0) {
			this.pingInterval = pingInterval;
			const checkInterval = Math.round((pingInterval / 4) * 60 * 1000);
			setInterval(() => { this.checkPing(); }, checkInterval);
		}
	}

	public overrideUrl(url: string): void {
		this._overrideUrl = url;
	}

	// Uses the FileServlet for uploading files
	public upload(operationUrl: string, operation: string, files: any[], formFields?: c.IStringMap): ng.IPromise<c.IOperationResponse> {
		var deferred: ng.IDeferred<c.IOperationResponse> = this.q.defer();
		var url = this.getBaseUrl() + "/lime/upload" + operationUrl;
		const formData = new FormData();

		formData.append("operation", operation);
		for (var key in formFields) {
			formData.append(key, formFields[key]);
		}

		for (var i = 0; i < files.length; i++) {
			formData.append("datafile", files[i]);
		}

		var params = {
			withCredentials: true,
			// Let the browser decide Content-Type
			headers: { "Content-Type": undefined },
			transformRequest: angular.identity
		};

		this.http.post(url, formData, params).then((httpResponse) => {
			try {
				const response = new c.OperationResponse();
				// TODO use generic? Parse result to given object?
				angular.copy(httpResponse.data, response);

				if (response.hasError()) {
					this.debug("has errors " + httpResponse.data);
					deferred.reject(response);
				} else {
					this.debug("completed " + httpResponse.data);
					deferred.resolve(response);
				}
			} catch (e) {
				this.error("Failed to parse response for " + url);
				const errorResponse = new c.OperationResponse();
				const errorInfo = new c.ErrorInfo();
				errorInfo.error = e;
				errorInfo.code = httpResponse.status;
				errorResponse.errorList = [errorInfo];
				deferred.reject(errorResponse);
			}
		}, httpResponse => {
			var errorResponse = new c.OperationResponse();
			var errorInfo = new c.ErrorInfo();
			errorInfo.message = "The action could not be performed.";
			errorInfo.code = httpResponse.status;
			errorResponse.errorList = [errorInfo];
			this.error("Failed to call " + url + " Response: " + angular.toJson(httpResponse));
			deferred.reject(errorResponse);
		});

		return deferred.promise;
	}

	/*
	* Handle Error
	*
	* Handles request errors.
	*
	* @param response IOperationResponse
	* @param message? string
	*/
	public handleError(response: c.IOperationResponse, message?: string): void {
		// Create options object for dialog
		const options: lm.IMessageDialogOptions = {
			title: c.Constants.applicationName,
			standardButtons: lm.StandardDialogButtons.Ok,
			message: ""
		};

		// Set HTTP error message, otherwise set given error message, 
		// otherwise set generic error message
		let addAdminMessage = true;
		if (response && response.errorList[0].code) {
			let id;
			const errorConstants = c.ErrorConstants;

			switch (response.errorList[0].code) {
				case c.ResponseErrorCodes.unauthorized: // HTTP 401 error (unauthorized)
					id = errorConstants.unauthorized;
					break;
				case c.ResponseErrorCodes.forbidden: // HTTP 403 error (forbidden)
					id = errorConstants.unauthorized;
					break;
				case c.ResponseErrorCodes.notFound: // HTTP 404 error (not found)
					id = errorConstants.notFound;
					break;
				case c.ResponseErrorCodes.timeout: // HTTP 408 error (request timeout)
					id = errorConstants.timeout;
					break;
				case c.ResponseErrorCodes.unavailable: // HTTP 503 (Service unavailable)
					id = errorConstants.unavailable;
					break;
				case c.ResponseErrorCodes.exceedsMaxSize: // Request exceeds max size
					id = errorConstants.exceedsMaxSize;
					addAdminMessage = false;
					break;
				case c.ResponseErrorCodes.undefined:
					id = c.ErrorConstants.signout;
					break;
				default: // HTTP XXX
					id = errorConstants.generic;
					break;
			}
			if (message) {
				options.message = message;
			} else {
				var genericMessage = this.getMessage(id);
				options.message = addAdminMessage ? genericMessage + " " + this.getMessage("contactAdminRetry") : genericMessage;
			}
		} else if (message) {
			options.message = message;
		} else {
			const isSessionRedirect = response.errorHttpCode === c.ResponseErrorCodes.undefined.toString();
			const constant = isSessionRedirect ? c.ErrorConstants.signout : c.ErrorConstants.generic;
			options.message = this.getMessage(constant);
		}

		// Log error message if it exists
		if (response.hasMessage()) {
			lm.Log.error(response.toErrorLog());
		}
		
		// Show error message in a dialog
		this.dialogService.showMessage(options);
	}

	public executeGet(resource: string, params?: any): ng.IPromise<c.IOperationResponse> {
		return this.execute(resource, "GET", null, params);
	}

	public executePost(resource: string, request: any, params?: any): ng.IPromise<c.IOperationResponse> {
		return this.execute(resource, "POST", request, params);
	}

	private execute(resource: string, type: string, request?: any, params?: any): ng.IPromise<c.IOperationResponse> {
		const deferred: ng.IDeferred<c.IOperationResponse> = this.q.defer();
		const url = this.getBaseUrl() + "/" + c.Constants.restRoot + resource;
		this.debug("Executing url " + url);

		let method = "POST";
		if (type === "GET") {
			method = "GET";
		}

		if (request) {
			request["language"] = this.language;
			request["id"] = lm.CommonUtil.random();
		}

		const requestConfig = { method: method, url: url, data: request, params: params, cache: false };
		this.executeHttp(deferred, requestConfig);

		return deferred.promise;
	}

	private executeHttp(deferred: ng.IDeferred<c.IOperationResponse>, requestConfig: ng.IRequestConfig): void {
		this.isExecuting = true;
		this.http(requestConfig).then(httpResponse => {
			try {
				this.done();

				const response = new c.OperationResponse();
				angular.copy(httpResponse.data, response);

				if (response.hasError()) {
					this.debug("has errors " + httpResponse.data);
					deferred.reject(response);
				} else {
					this.debug("completed " + httpResponse.data);
					deferred.resolve(response);
				}
			} catch (e) {
				const message = "Failed to parse response for " + requestConfig.url;
				this.error(message);
				deferred.reject(this.getErrorResponse(httpResponse, message, e));
			}
		}, httpResponse => {
			this.done();
			this.error("Failed to call " + requestConfig.url + " Response: " + angular.toJson(httpResponse));
			var errorResponse = this.getErrorResponse(httpResponse, "The action could not be performed.", null);
			errorResponse.errorHttpCode = httpResponse.status.toString();
			deferred.reject(errorResponse);
		});
	}

	private getErrorResponse(httpResponse: ng.IHttpPromiseCallbackArg<any>, message: string, ex: any): c.IOperationResponse {
		const errorResponse = new c.OperationResponse();
		const errorInfo = new c.ErrorInfo();
		errorInfo.message = message;
		errorInfo.error = ex;
		errorInfo.code = httpResponse.status;
		errorResponse.errorList = [errorInfo];
		return errorResponse;
	}

	private getMessage(id: string): string {
		var message = this.languageService.get(id);
		return message || id;
	}

	private getBaseUrl(): string {
		return (this._overrideUrl ? this._overrideUrl : c.ClientConfiguration.getUrl());
	}

	static add(ngModule: ng.IModule) {
		ngModule.service("lmDataService", DataService);
	}
}

class CommonDataService extends c.CoreBase implements c.ICommonDataService {
	static $inject = ["lmDataService", "$q"];

	constructor(private dataService: c.IDataService, private q: ng.IQService) {
		super("[CommonDataService] ");
	}

	public searchUsers(query: string): ng.IPromise<c.IUserListResponse> {
		return this.dataService.executePost("/user/search", { content: query });
	}

	public searchGroups(query: string): ng.IPromise<c.IGroupListResponse> {
		return this.dataService.executePost("/group/search", { content: query });
	}

	public searchEntities(query: string): ng.IPromise<c.IEntityListResponse> {
		var deferredUsers: JQueryDeferred<lm.IAutocompleteEntity[]> = jQuery.Deferred<lm.IAutocompleteEntity[]>();
		var deferredGroups: JQueryDeferred<lm.IAutocompleteEntity[]> = jQuery.Deferred<lm.IAutocompleteEntity[]>();
		var deferredEntities: ng.IDeferred<c.IEntityListResponse> = this.q.defer();

		$.when(deferredUsers, deferredGroups).then((users, groups) => {
			if (users && groups) {
				var list = (<any[]>users).concat(groups);
				deferredEntities.resolve(<c.IEntityListResponse>{ content: list });
			}
		}, () => {
			deferredEntities.reject({});
		});
		this.searchUsers(query).then((response: c.IUserListResponse) => {
			deferredUsers.resolve(c.CoreUtil.getEntityArray(response.content));
		});

		this.searchGroups(query).then((response: c.IGroupListResponse) => {
			deferredGroups.resolve(c.CoreUtil.getEntityArray(response.content));
		});

		return deferredEntities.promise;
	}

	public listBookmarks(): ng.IPromise<c.IBookmarkResponse> {
		return this.dataService.executePost("/user/bookmark/list", { content: null });
	}

	public listGroups(): ng.IPromise<c.IGroupListResponse> {
		return this.dataService.executePost("/group/list", { content: null });
	}

	public listLanguages(): ng.IPromise<c.ILanguagueResponse> {
		return this.dataService.executePost("/common/language/list", { content: null });
	}

	public getApplication(logicalIdPrefix: string): ng.IPromise<c.IApplicationResponse> {
		return this.dataService.executePost("/common/application", { content: logicalIdPrefix });
	}

	/*
	* Handle Error
	*
	* Forwards respone and message to the error handler in DataService.
	* @param response IOperationResponse
	* @param message? string
	*/
	public handleError(response: c.IOperationResponse, message?: string): void {
		if (!message) {
			this.dataService.handleError(response);
		} else {
			this.dataService.handleError(response, message);
		}
	}

	static add(ngModule: ng.IModule) {
		ngModule.service("lmCommonDataService", CommonDataService);
	}
}

class Dialog implements lm.IDialog {
	public closing: (e: lm.IDialogEvent) => void;
	public closed: (e: lm.IDialogEvent) => void;
	public opened: (e: lm.IDialogEvent) => void;
	public parameter: any;
	public result: lm.IDialogResult;

	private modal: JQuery;
	private canClose = false;

	constructor(private deferred: ng.IDeferred<any>) {
	}

	private resolve(): void {
		var modal = this.modal;
		if (modal) {
			modal.remove();
			this.modal = null;
		}
		var result = this.result || {};
		this.deferred.resolve(result);
	}

	public init(modal: JQuery): void {
		this.modal = modal;

		modal.one("beforeclose", () => {
			var closing = this.closing;
			if (closing) {
				var e = <lm.IDialogEvent>{ dialog: this };
				closing(e);
				return e.cancel ? false : true;
			} else {
				return this.canClose;
			}
		});

		modal.one("afterclose", () => {
			var closed = this.closed;
			if (closed) {
				var e = <lm.IDialogEvent>{ dialog: this };
				closed(e);
			}
			this.resolve();
		});

		modal.one("open", () => {
			var opened = this.opened;
			if (opened) {
				var e = <lm.IDialogEvent>{ dialog: this };
				opened(e);
			}
		});
	}

	public close(result?: lm.IDialogResult): void {
		this.canClose = true;
		if (result) {
			this.result = result;
		}

		const modal = this.modal;
		if (modal) {
			(<any>modal).modal("close");
		}
	}
}

/**
* @internal
*/
interface IDialogButtonEx extends lm.IDialogButton {
	click: Function;
}

export class DialogService extends c.CoreBase implements lm.IDialogService {
	private language: ILanguageLime;

	static $inject = ["$rootScope", "$compile", "$q", "lmLanguageService"];

	constructor(private rootScope: ng.IScope, private compile: ng.ICompileService, private q: ng.IQService, private languageService: c.ILanguageService) {
		super("[DialogService] ");
		this.language = languageService.getLanguage();
	}

	public showContextualActionPanel(template: string, parameter?: any): ng.IPromise<lm.IDialogResult> {
		const deferred = this.q.defer();

		const container = $("<div class='lm-display-none' id='" + c.Constants.contextualActionPanelId + "'></div>");
		const body = $("body");
		body.append(container);

		const modalScope = this.rootScope.$new(true);
		modalScope["lmLang"] = this.rootScope["lmLang"];
		modalScope["lmCallback"] = parameter;

		const cap = this.compile($(template))(modalScope);
		cap.insertAfter(container);

		var unsubscribe = modalScope.$on('$includeContentLoaded', () => {
			unsubscribe();

			const element = $(".contextual-action-panel");
			container["contextualactionpanel"]({ trigger: "immediate" });
			modalScope["lmDialog"] = container;

			element.one("beforeclose", () => {
				// Remove some heavy DOM elements to reduce leak from CAP pboberg 
				element.find("img, svg, a, span").remove();
			});

			element.one("afterclose", () => {
				modalScope.$destroy();
				container.remove();
				deferred.resolve();
			});
		});
		return deferred.promise;
	}

	public show(options?: lm.IDialogOptions): ng.IPromise<lm.IDialogResult> {
		var deferred = this.q.defer();

		var title = null;
		if (options) {
			title = options.title;
		}
		if (!title) {
			title = "";
		}

		var dialog = new Dialog(deferred);

		var modalScope = (options.scope || this.rootScope).$new();
		if (options && options.parameter) {
			dialog.parameter = options.parameter;
		}
		modalScope["lmDialog"] = dialog;

		var contentTemplate = options.template;
		if (!contentTemplate) {
			var url = options.templateUrl;
			if (!url) {
				throw "One of the template and templateUrl properties must be set";
			}
			contentTemplate = "<div ng-include=\"'" + url + "'\"></div>";
		}

		// TODO Add support for standard buttons
		// TODO Default style

		var style = options.style || "";
		var css = options.cssClass || "";
		var id = options.id || lm.CommonUtil.random(8);
		var template = '<div class="modal lm-scroll-no-y ' + css + '" id="' + id + '" style="' + style + '">' +
			'<div class="modal-content"><div class="modal-header"></div><div class="modal-body">' + contentTemplate + '</div>';

		var element = $(template);

		// Modify the template slightly depending if it's a regular modal or contextual action panel modal
		var headerElement = element.find(".modal-header");
		if (options.actionPanel) {
			element.removeClass().addClass("contextual-action-panel modal " + css);
			headerElement.append($('<div class="toolbar"><div class="title">' + title + '</div></div>'));
		} else {
			headerElement.append($('<h1 class="modal-title">' + title + '<h1>'));
		}

		$("body").append(this.compile(element)(modalScope));

		var buttons: IDialogButtonEx[] = null;
		if (options.buttons) {
			buttons = this.setSpecificButtons(options.buttons, deferred, dialog);
		}

		if (options.template && options.template.indexOf("ng-include") === -1) {
			this.createAndOpenModal(element, dialog, title, buttons, modalScope);
		} else { // If templateUrl, wait for included content
			var unsubscribe = modalScope.$on('$includeContentLoaded', () => {
				this.createAndOpenModal(element, dialog, title, buttons, modalScope);
				unsubscribe();
			});
		}

		return deferred.promise;
	}

	private createAndOpenModal(element: JQuery, dialog: Dialog, title: string, buttons: IDialogButtonEx[], modalScope: ng.IScope): void {
		var modal = (<any>element).modal({
			title: title,
			buttons: buttons
		});
		dialog.init(modal);

		if (!buttons) { // To calculate width of included buttons
			modal.modal("addButtons");
		}

		// Destroy the modal scope when the modal is closing.
		modal.one("beforeclose", () => {
			modalScope.$destroy();
			c.UIUtil.removePopupMenus(element);
		});

		modal.modal("open");
	}

	public showMessage(options: lm.IMessageDialogOptions): ng.IPromise<lm.IDialogResult> {
		var deferred = this.q.defer();
		var element: any = $("body");
		var buttons: IDialogButtonEx[] = null;
		if (!options.buttons && !options.standardButtons) {
			options.standardButtons = lm.StandardDialogButtons.Ok;
		}

		if (options.standardButtons != null) {
			buttons = this.setDefaultButtons(options.standardButtons, deferred, lm.CommonUtil.isUndefined(options.hasPrimaryButton) || options.hasPrimaryButton === true);
		} else if (options.buttons) {
			buttons = this.setSpecificButtons(options.buttons, deferred, null);
		}
		element.message({
			title: options.title,
			message: options.message,
			isError: options.isError === true,
			buttons: buttons,
			cssClass: options.cssClass
		});
		return deferred.promise;
	}

	/**
	* Shows a toast notification with the specified options.
	* 
	* Defaults position to "bottom right" and timeout to 3000 if not set.
	*/
	public showToast(options: lm.IToastOptions): void {
		if (!options.position) {
			options.position = "bottom right";
		}
		if (!options.timeout) {
			options.timeout = 3000;
		}
		$("body")["toast"](options);
	}

	/**
	* Copies data to clipboard or opens a dialog with the data to copy if copying is not possible.
	* @param options The copy to clipboard options
	*/
	public copyToClipboard(options: lm.ICopyToClipboardOptions): void {
		// Create hidden input with the text to be copied and select it.
		const copyElement = document.createElement("textarea");
		copyElement.setAttribute("type", "text");
		copyElement.setAttribute("id", "lm-copy-to-clipboard");
		document.body.appendChild(copyElement);
		$("#lm-copy-to-clipboard").val(options.copyData);
		copyElement.select();
		
		if (options.forceDialog) {
			this.showMessage({ title: this.language.copyToClipboard, message: options.copyData, cssClass: "lm-text" });
		} else {
			// Copy the input text or open a dialog with the text if it fails.
			try {
				document.execCommand("copy");
			} catch (e) {
				this.showMessage({ title: this.language.copyToClipboard, message: options.copyData, cssClass: "lm-text" });
			}	
		}	

		// Remove the hidden input
		$("#lm-copy-to-clipboard").remove();
	}

	private setDefaultButtons(defaults: lm.StandardDialogButtons, deferred: ng.IDeferred<any>, hasPrimaryButton: boolean): IDialogButtonEx[] {
		var language = this.language;
		var buttons: IDialogButtonEx[] = [];
		if (defaults == lm.StandardDialogButtons.OkCancel || defaults == lm.StandardDialogButtons.YesNoCancel) {
			buttons.push({
				text: language.cancel || "Cancel",
				click: function () {
					(<any>$(this)).modal("close");
					deferred.resolve({ button: lm.DialogButtonType.Cancel });
				},
				isDefault: false
			});
		}
		if (defaults == lm.StandardDialogButtons.Ok || defaults == lm.StandardDialogButtons.OkCancel) {
			buttons.push({
				text: language.ok || "OK",
				click: function () {
					(<any>$(this)).modal("close");
					deferred.resolve({ button: lm.DialogButtonType.Ok });
				},
				isDefault: hasPrimaryButton
			});
		} else if (defaults == lm.StandardDialogButtons.YesNo || defaults == lm.StandardDialogButtons.YesNoCancel) {
			buttons.push({
				text: language.no || "No",
				click: function () {
					(<any>$(this)).modal("close");
					deferred.resolve({ button: lm.DialogButtonType.No });
				},
				isDefault: false
			});
			buttons.push({
				text: language.yes || "Yes",
				click: function () {
					(<any>$(this)).modal("close");
					deferred.resolve({ button: lm.DialogButtonType.Yes });
				},
				isDefault: hasPrimaryButton
			});
		}
		return buttons;
	}

	private setSpecificButtons(specificButtons: lm.IDialogButton[], deferred: ng.IDeferred<lm.IDialogResult>, dialog: lm.IDialog): IDialogButtonEx[] {
		var buttons: IDialogButtonEx[] = [];
		specificButtons.forEach((button: IDialogButtonEx, index) => {
			button.click = function () {
				if (dialog) {
					dialog.close();
				} else {
					(<any>$(this)).modal("close");
				}
				var result;
				if (dialog) {
					result = dialog.result || {};
					result.button = button.type;
					deferred.resolve(result);
				} else {
					result = { button: button.type };
				}
				deferred.resolve(result);
			}
			buttons.push(button);
		});
		return buttons;
	}

	static add(ngModule: ng.IModule) {
		ngModule.service("lmDialogService", DialogService);
	}
}

/**
* Tag Service
* 
* Provides methods to add, delete and make validity checks
* of tags.
*/
class TagService {
	private lang: ILanguageLime;

	static $inject = ["lmLanguageService"]

	constructor(private languageService: c.ILanguageService) {
		this.lang = languageService.getLanguage();
	}

	/**
	* Is Tag Valid Method
	* 
	* Checks if a tag is valid based on several different rules.
	* If a tag is invalid, it returns an error message with a  short
	* explanation of what is wrong.
	*
	* @param tag - the tag to validate
	* @return IIsTagValidResponse
	*/
	public isTagValid(tag: string): c.IIsTagValidResponse {
		var response: c.IIsTagValidResponse = {
			isValid: true
		};

		// Make sure that the tag only consist of alphanumeric 
		// characters and "_" and "#"
		if (!/[^A-Za-z0-9_#]/.test(tag)) {
			// Make sure that the first character is a "#"
			if (tag[0] !== "#") {
				response.isValid = false;
				response.errorMsg = this.lang.tagFormatInfo;
				return response;
			} 

			// Make sure it does not have a "#" other than as first char
			if (tag.lastIndexOf("#") !== 0) {
				response.isValid = false;
				response.errorMsg = this.lang.tagFormatInfo;
				return response;
			}

			// Make sure it has at least two chars more than "#"
			if (tag.length < 3) {
				response.isValid = false;
				response.errorMsg = this.lang.invalidTagMinLength;
				return response;
			}

			// Make sure it's not longer than 33 chars
			if (tag.length > 33) {
				response.isValid = false;
				response.errorMsg = this.lang.invalidTagMaxLength;
				return response;
			}
		} else {
			response.isValid = false;
			response.errorMsg = this.lang.tagFormatInfo;
			return response;
		}
		return response;
	}

	/**
	* Are Tags Valid Method
	* 
	* Checks if a string of tags are valid based on several different rules.
	* If a tag is invalid, it returns an error message with a  short
	* explanation of what is wrong.
	*
	* @param tags - the tags to validate
	* @return IAreTagValidResponse
	*/
	public areTagsValid(tags: string): c.IAreTagsValidResponse {
		var response: c.IAreTagsValidResponse = {
			areValid: true
		};

		// Make sure the first character is a "#"
		if (tags[0] === "#") {
			// Make sure there are not more than 5 tags
			if (tags.match(/#/g).length <= 5) {
				var tagsArray = tags.split("#");
				tagsArray.shift();

				// Add the # (which was removed above) to each tag in the array,
				// then check if the tag is valid
				angular.forEach(tagsArray, (value, i) => {
					var valueTagged = "#" + value;
					var validityResponse = this.isTagValid(valueTagged);
					tagsArray[i] = tagsArray[i].toLowerCase();

					if (!validityResponse.isValid) {
						// Invalid tag, return error
						response.areValid = false;
						response.errorMsg = validityResponse.errorMsg;
						return response;
					} else {
						if (tagsArray.indexOf(value.toLowerCase()) != tagsArray.lastIndexOf(value.toLowerCase())) {
							// More than one occurence of tag, not unique!
							response.areValid = false;
							response.errorMsg = this.lang.duplicateTag;
							return response;
						}
					}
				});
			} else {
				response.areValid = false;
				response.errorMsg = this.lang.format(this.lang.maxCountTag, c.Constants.tagsMaxCount);
			}
		} else {
			response.areValid = false;
			response.errorMsg = this.lang.tagFormatInfo;
		}
		return response;
	}

	/**
	* Add Tag Method
	* 
	* Adds a tag. Returns an error if 5 tags are already saved 
	* or the new tag is invalid.
	*
	* @param alltags - the currently saved tags
	* @param tag - the tag to add
	* @return IAddTagResponse
	*/
	public addTag(allTags: string, tag: string): c.IAddTagResponse {
		var response: c.IAddTagResponse = {
			allTags: allTags,
			hasError: true
		};

		if (this.isTagValid(tag).isValid) {
			// Make sure less than 5 tags are already saved
			if ((allTags.match(/#/g) || "").length < 5) {
				response.allTags += tag;
			} else {
				response.hasError = true;
				response.errorMsg = this.lang.format(this.lang.maxCountTag, c.Constants.tagsMaxCount);
			}
		} else {
			response.hasError = true;
			response.errorMsg = this.isTagValid(tag).errorMsg;
		}
		return response;
	}

	static add(ngModule: ng.IModule) {
		ngModule.service("lmTagService", TagService);
	}
}

class CacheService extends c.CoreBase implements c.ICacheService {
	constructor() {
		super("[CacheService] ");
	}

	/**
	 * Creates a list cache.
	 *
	 * @param name The name of the cache name.
	 * @returns Admin list cache object.
	 */
	public createCache(name: string): c.IDataListCache {
		return {
			name: name,
			isValid: false,
			cachedResponse: null,
			timeoutId: null
		};
	}

	/**
	* Update Cache
	*
	* Updates given cache and saves it for 15 minutes or until it's updated.
	*
	* @param cache Cache to update.
	* @param deferred Deferred to return.
	* @param response Response to cache.
	* @returns A resolved promise with the supplied response.
	*/
	public updateCache(cache: c.IDataListCache, response: c.IOperationResponse, deferred?: ng.IDeferred<any>) {
		// Cache response
		cache.cachedResponse = response;
		cache.isValid = true;

		// Clear any existing timeout
		if (cache.timeoutId) {
			window.clearTimeout(cache.timeoutId);
			cache.timeoutId = null;
		}

		// Set cache timeout
		cache.timeoutId = window.setTimeout(() => {
			cache.isValid = false;
			lm.Log.debug(this.logPrefix + cache.name + " cache invalidated.");
		}, c.Constants.cacheLifetime);

		if (deferred) {
			deferred.resolve(response);
		}
	}

	static add(ngModule: ng.IModule) {
		ngModule.service("lmCacheService", CacheService);
	}
}

export var init = (externalModule: ng.IModule, internalModule: ng.IModule) => {
	DialogService.add(externalModule);
	ProgressService.add(internalModule);
	DataService.add(internalModule);
	CommonDataService.add(externalModule);
	TagService.add(internalModule);
	CacheService.add(internalModule);
};