/// <reference path="../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../scripts/typings/lime/lime.d.ts" />
define(["require", "exports", "lime"], function (require, exports, lm) {
    var CardlistCtrl = (function () {
        function CardlistCtrl(scope) {
            var _this = this;
            this.scope = scope;
            this.reverseKey = "reverse";
            this.logPrefix = "[CardlistCtrl] ";
            this.items = [
                {
                    isError: true,
                    title: "Stock level 31-22",
                    description: "Stocklevel has reached 100 items"
                },
                {
                    title: "Customer returns",
                    description: "Customer returns has increased with 10%"
                },
                {
                    title: "Customer approved",
                    description: "Customer Hulk Holding has been approved."
                },
                {
                    title: "Stock level Chair-3",
                    description: "WHLO 200 has 500 items"
                },
                {
                    title: "Planned machine maintenance",
                    description: "Planned time"
                }
            ];
            // Get the widget context from the scope
            this.widgetContext = scope[lm.WidgetConstants.widgetContextKey];
            if (!this.widgetContext) {
                lm.Log.error(this.logPrefix + "No widget context is found");
                return;
            }
            // Get the instance from the scope
            this.instance = scope[lm.WidgetConstants.widgetInstanceKey];
            if (!this.instance) {
                lm.Log.error(this.logPrefix + "No instance is found");
                return;
            }
            var settings = this.widgetContext.getSettings();
            var reverseSetting = settings.getString(this.reverseKey, null);
            if (reverseSetting == null) {
                // Store the default setting
                reverseSetting = "false";
                settings.set(this.reverseKey, reverseSetting);
            }
            var reverse = false;
            if (reverseSetting.toLowerCase() === "true") {
                reverse = true;
            }
            scope[this.reverseKey] = reverse;
            scope["model"] = this;
            this.instance.settingsOpening = function (options) {
                lm.Log.debug(_this.logPrefix + "settingsOpening");
            };
            this.instance.getMetadata = function () {
                return _this.createMetadata();
            };
            this.instance.settingsSaved = function () {
                // Handle when settings are saved to update internal state
                var reverseSettings = _this.widgetContext.getSettings().getString(_this.reverseKey, "false");
                scope[_this.reverseKey] = reverseSettings === "true";
            };
        }
        CardlistCtrl.prototype.createMetadata = function () {
            // Dynamically create meta data for the metadata controlled settings UI
            var metadata = [];
            var widgetSetting = { labelId: "order", type: lm.WidgetSettingsType.selectorType, name: this.reverseKey, defaultValue: "false" };
            widgetSetting.values = [{ textId: "ascending", value: "false" }, { textId: "descending", value: "true" }];
            metadata.push(widgetSetting);
            return metadata;
        };
        CardlistCtrl.add = function (m) {
        };
        CardlistCtrl.$inject = ["$scope"];
        return CardlistCtrl;
    })();
    exports.widgetFactory = function (context) {
        var m = context.getAngularContext().module;
        // Register the controller
        m.controller("sample.CardlistCtrl", CardlistCtrl);
        // Return the angular configuration the widget.html will contain a controller
        return {
            angularConfig: {
                relativeTemplateUrl: "widget.html"
            }
        };
    };
});
//# sourceMappingURL=widget.js.map