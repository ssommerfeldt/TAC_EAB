﻿import lm = require("../../lime");
import c = require("../../core");

class PageAccessCtrl extends c.CoreBase {
	private dialog: lm.IDialog = null;
	private pageAccess: c.IPageAccess;

	static $inject = ["$scope"];

	constructor(public scope: ng.IScope) {
		super("[PageAccessCtrl] ");
		this.dialog = scope["lmDialog"];

		var pageAccess = <c.IPageAccess> this.dialog.parameter;
		this.pageAccess = angular.copy(pageAccess);
		scope["roleAccess"] = pageAccess.roleAccess ? angular.copy(pageAccess.roleAccess) : [];
		scope["userAccess"] = $.isEmptyObject(pageAccess.userAccess) ? {} : angular.copy(pageAccess.userAccess);
	}

	public save(): void {
		var pageAccess = this.pageAccess;
		pageAccess.roleAccess = this.scope["roleAccess"];
		pageAccess.userAccess = this.scope["userAccess"];

		var result: lm.IDialogResult = {
			button: lm.DialogButtonType.Ok,
			value: pageAccess
		};
		this.dialog.close(result);
	}

	public cancel(): void {
		this.dialog.close();
	}

	static add(m: ng.IModule) {
		m.controller("lmPageAccessCtrl", PageAccessCtrl);
	}
}

export var init = (m: ng.IModule) => {
	PageAccessCtrl.add(m);
}; 