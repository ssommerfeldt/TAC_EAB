var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../lime", "../core"], function (require, exports, lm, c) {
    var RoleAccessCtrl = (function (_super) {
        __extends(RoleAccessCtrl, _super);
        function RoleAccessCtrl(scope, dialogService, languageService, commonDataService) {
            var _this = this;
            _super.call(this, "[RoleAccessCtrl] ");
            this.scope = scope;
            this.dialogService = dialogService;
            this.commonDataService = commonDataService;
            this.userType = c.PrincipalType.User;
            this.lang = languageService.getLanguage();
            var userAccess = scope["userAccess"];
            var roleAccess = scope["roleAccess"];
            for (var i = 0; i < roleAccess.length; i++) {
                roleAccess[i].type = c.PrincipalType.MingleGroup;
            }
            this.roleAccess = roleAccess;
            this.entityAccess = angular.copy(roleAccess);
            for (var userName in userAccess) {
                var user = userAccess[userName];
                user.type = c.PrincipalType.User;
                this.entityAccess.push(user);
            }
            this.userAccess = userAccess;
            if (!this.entityAccess) {
                lm.Log.debug("roleAccess is not set on scope");
            }
            this.accessLevels = [
                { name: this.lang.editAccess, value: c.AccessLevel.Edit },
                { name: this.lang.viewAccess, value: c.AccessLevel.View }];
            this.init();
            scope.$on("$destroy", function () {
                _this.autocompleteElem.off();
            });
        }
        RoleAccessCtrl.prototype.init = function () {
            var self = this;
            this.scope["autocomplete"] = {
                source: function (query, done) {
                    self.commonDataService.searchEntities(query).then(function (response) {
                        done(query, lm.ArrayUtil.sortByProperty(response.content, "label"));
                    }, function (r) { self.commonDataService.handleError(r); });
                },
                template: c.Templates.autocompleteEntity
            };
            this.autocompleteElem = $("#autocomplete-page-permissions");
            this.autocompleteElem.on("selected", function (event, target, object) {
                if (lm.CommonUtil.isUndefined(object) || lm.CommonUtil.isUndefined(object.value) ||
                    lm.ArrayUtil.containsByProperty(self.entityAccess, "principal", object.value)) {
                    return;
                }
                var entity = {
                    accessLevel: c.AccessLevel.View,
                    principal: object.value,
                    principalName: object.label ? object.label : object.value,
                    type: object.type,
                    info: object.info
                };
                if (object.type === c.PrincipalType.User) {
                    self.userAccess[entity.principal] = entity;
                }
                else if (object.type === c.PrincipalType.MingleGroup) {
                    self.roleAccess.push(entity);
                }
                else {
                    return;
                }
                self.entityAccess.push(entity);
                self.scope.$apply("entityAccess");
            });
        };
        RoleAccessCtrl.prototype.onChangedAccessLevel = function (entity) {
            if (!lm.CommonUtil.isUndefined(this.userAccess[entity.principal])) {
                this.userAccess[entity.principal].accessLevel = entity.accessLevel;
                return;
            }
            var role = lm.ArrayUtil.itemByProperty(this.roleAccess, "principal", entity.principal);
            if (!lm.CommonUtil.isUndefined(role)) {
                role.accessLevel = entity.accessLevel;
            }
        };
        RoleAccessCtrl.prototype.delete = function (entity) {
            lm.ArrayUtil.remove(this.entityAccess, entity);
            lm.ArrayUtil.removeByProperty(this.roleAccess, "principal", entity.principal);
            delete this.userAccess[entity.principal];
        };
        RoleAccessCtrl.add = function (m) {
            m.controller("lmRoleAccessCtrl", RoleAccessCtrl);
        };
        RoleAccessCtrl.$inject = ["$scope", "lmDialogService", "lmLanguageService", "lmCommonDataService"];
        return RoleAccessCtrl;
    })(c.CoreBase);
    exports.init = function (m) {
        RoleAccessCtrl.add(m);
    };
});
//# sourceMappingURL=role-access.js.map