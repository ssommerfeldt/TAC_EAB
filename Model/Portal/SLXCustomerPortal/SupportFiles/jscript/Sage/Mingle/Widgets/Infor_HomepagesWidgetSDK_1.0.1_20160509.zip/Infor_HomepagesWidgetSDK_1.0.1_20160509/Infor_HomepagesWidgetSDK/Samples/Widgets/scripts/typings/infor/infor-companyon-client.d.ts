﻿// Type definitions for infor.companyon.client.js

declare module infor.companyon.client {

	/**
	 * Send "prepareApplicationDrillback" message to handle the drillback execution
	 */
	var sendPrepareDrillbackMessage: (link: string) => void;

	/**
	 * Send "prepareFavoriteContext" message to handle the shortcut execution
	 */
	var sendPrepareFavoritesMessage: (link: string) => void;

	var sendMessage: (name: string, data: any) => void;

	var registerMessageHandler: (name: string, handler: Function, namespace?: string) => void;

	var unRegisterMessageHandler: (name: string, namespace?: string) => void;
}