﻿import lm = require("../lime");
import c = require("../core");
import container = require("../app/container");
import p = require("../app/page");

interface IPageLibraryScope extends ng.IScope {
	filter: any;
	filterName: string;
	searchInput: string;
	lmPlBusy: boolean;
}

interface ICatalogPage extends c.IPage {
	id: string;
	searchableText: string;
	isVisible: boolean;
	isSelected: boolean;
}

interface IContextualActionPanel {
	destroy(): void;
}

class PageLibraryCtrl extends c.CoreBase {

	private pages: ICatalogPage[] = [];
	private dialog: IContextualActionPanel;
	private filters: Array<Object>;
	private widgetCategories: Array<Object>;
	private isUserAdmin: boolean;
	private userId: string;
	private pageAddEnabled: boolean;
	private pageCopyEnabled: boolean;
	private privatePagesEnabled: boolean;
	private selectedPage: ICatalogPage;
	private context: c.IContext;
	private container: c.IPageContainer;
	private language: ILanguageLime;
	private filteredPagesLength: number = 0;

	private visiblePages = 30;
	private preventPageIncrement: boolean;
	private pageIncrement = 30;
	private scrollElement: JQuery;
	private unsubscribe: Function;

	static $inject = ["$scope", "$timeout", "lmPageService", "lmContextService", "lmContainerService", "lmDialogService", "lmLanguageService"];

	constructor(private scope: IPageLibraryScope, private timeout: ng.ITimeoutService, private pageService: c.IPageService, private contextService: c.IContextService,
		private containerService: container.IContainerService, private dialogService: lm.IDialogService, private languageService: c.ILanguageService) {
		super("[Page Library] ");

		const language = languageService.getLanguage();
		this.language = language;

		scope.lmPlBusy = true;

		var once = scope.$watch("lmDialog", (dialog) => {
			if (!dialog) {
				return;
			}
			once();
			this.dialog = dialog.data("contextualactionpanel");
			this.container = containerService.getContainer();
			
			// Timeout to let the DOM be ready
			setTimeout(() => {
				this.addScrollEvents();
				this.listPages();
				// Fix for missing actions in toolbar more pboberg
				$(".contextual-action-panel .toolbar").data("toolbar")["updated"]();
			}, 5);
		});

		this.filters = [
			{ "filter": "data.title", "name": language.sortTitleAsc },
			{ "filter": "-data.title", "name": language.sortTitleDesc },
			{ "filter": "-data.changeDate", "name": language.sortNewest },
			{ "filter": "data.changeDate", "name": language.sortOldest },
			{ "filter": "data.ownerName", "name": language.owner },
			{ "filter": "-data.popularity", "name": language.usedbyHeader }
		];
		scope.filter = this.filters[0];
		scope.filterName = language.sortTitleAsc;
		this.context = contextService.getContext();
		this.isUserAdmin = this.context.settings.isAdministrator();
		this.userId = this.context.getUserId();
		this.pageAddEnabled = this.context.settings.isPublicPageAddEnabled();
		this.pageCopyEnabled = this.context.settings.isPublicPageCopyEnabled();
		this.privatePagesEnabled = this.context.settings.isPrivatePagesEnabled();

		var self = this;
		var filterTimeout: ng.IPromise<any>;
		this.unsubscribe = scope.$watch("searchInput",(newValue: string, oldValue: string) => {
			timeout.cancel(filterTimeout);
			if (!newValue) {
				// Instant action to clear old filter
				self.clearSearch();
			} else if (newValue !== oldValue) {
				// Delay search to await further input
				filterTimeout = timeout(() => {
					self.searchPages(newValue);
				}, 200, true);
			}
		});
	}

	/**
	 * Lists pages.
	 *
	 * Gets a list of pages (IServerPage) and adds additional data (IPageInfo)
	 * for easier UI handling.
	 */
	private listPages(): void {
		this.scope.lmPlBusy = true;
		this.pageService.listPublished(false).then((r: c.IPageListResponse) => {
			var pages = <ICatalogPage[]>r.content;
			if (!r.hasError() && pages) {
				// The response is IServerPage[] but the items are cast to IPageInfo for additional fields used in the page library.
				for (var i = 0; i < pages.length; i++) {
					var page = pages[i];
					page.title = page.title || page.data.title;
					page.description = page.description || page.data.description;
					page.id = page.id || page.data.id;
					page.isVisible = true;
				}
				this.scope.lmPlBusy = false;
				this.filteredPagesLength = pages.length;
				this.pages = pages;
			}
		},(r: c.IOperationResponse) => {
				this.pageService.handleError(r);
				this.scope.lmPlBusy = false;
			});
	}

	private addScrollEvents(): void {
		var element = $(".contextual-action-panel .modal-body-wrapper");
		element.scroll(() => {
			if (this.visiblePages >= this.filteredPagesLength) {
				return;
			}
			var scrollTop = element.scrollTop();
			if (scrollTop + element[0].offsetHeight + 100 >= element[0].scrollHeight) {
				if (!this.preventPageIncrement) {
					this.visiblePages += this.pageIncrement;
					this.preventPageIncrement = true;
					this.scope.$apply("ctrl.visiblePages");
					setTimeout(() => {
						element.scrollTop(scrollTop);
						this.preventPageIncrement = false;
					}, 100);
				}
			}
		});
		this.scrollElement = element;
	}

	private searchPages(query: string): void {
		query = query.toLowerCase();
		let visiblePages = 0;
		const pages = this.pages;

		for (let i = 0; i < pages.length; i++) {
			const page = pages[i];
			const data = page.data;
			if (!page.searchableText) {
				const tags = data.tags;
				page.searchableText = page.title.toLowerCase() + ";" + page.description.toLowerCase() + ";" + data.ownerName.toLowerCase() + ";" + (tags ? tags.toLowerCase() : "");
			}
			const isVisible = page.searchableText.indexOf(query) !== -1;
			page.isVisible = isVisible;
			if (isVisible) {
				visiblePages++;
			}
		}
		this.filteredPagesLength = visiblePages;
		this.scrollToTop();
	}

	private clearSearch(): void {
		const pages = this.pages;
		const pagesCount = pages.length;
		for (let i = 0; i < pagesCount; i++) {
			const page = pages[i];
			page.isVisible = true;
			this.filteredPagesLength = pagesCount;
		}
		this.scrollToTop();
	}

	private scrollToTop(): void {
		const element = this.scrollElement;
		if (element) {
			this.visiblePages = this.pageIncrement;
			element.scrollTop(0);
		}
	}

	private close(): void {
		const page = this.selectedPage;
		if (page) {
			// To deselect the selected page
			this.toggleSelected(page);
		}
		this.unsubscribe();
		this.scrollElement.unbind("scroll");
		this.dialog.destroy();
	}

	private deletePage(page: c.IPage): void {
		this.container.delete(page.data.id, page.title, true).then((r: c.IOperationResponse) => {
			if (r.hasError()) {
				this.logResponse(r);
				return;
			}
			lm.ArrayUtil.remove(this.pages, page);
			delete this.selectedPage;
		},(r: c.IOperationResponse) => { this.pageService.handleError(r); });
	}

	private previewPage(page: c.IPage): void {
		const lang = this.language;
		const id = page.data.id;
		// Only allow preview if page isn't already added.
		if (this.container.contains(id)) {
			this.dialogService.showMessage({ title: lang.pageExists, message: lang.format(lang.pageExistsMessage, page.title), standardButtons: lm.StandardDialogButtons.Ok });
			return;
		}
		this.container.previewPage(id, false);
		this.dialog.destroy();
	}

	private addPage(page: ICatalogPage): void {
		this.scope.lmPlBusy = false;
		var busyCallback = () => {
			this.scope.lmPlBusy = !this.scope.lmPlBusy;
		}
		this.container.addExistingPage(page, true, false, null, busyCallback);
	}

	private copyPage(page: ICatalogPage): void {
		this.scope.lmPlBusy = false;
		var busyCallback = () => {
			this.scope.lmPlBusy = !this.scope.lmPlBusy;
		}
		this.container.copyPage(page, true, false, busyCallback);
	}

	private toggleSelected(page: ICatalogPage): void {
		var selectedPage = this.selectedPage;
		if (!selectedPage) {
			page.isSelected = true;
			this.selectedPage = page;
		} else {
			page.isSelected = true;
			selectedPage.isSelected = false;
			if (page.id === selectedPage.id) {
				delete this.selectedPage;
			} else {
				this.selectedPage = page;
			}
		}
	}

	/**
	 * Sets the page filter.
	 *
	 * Sets the filter used to sort the pages.
	 * Available filters are stored in this.filters.
	 */
	private setFilter(filter: any): void {
		if (!filter["filter"]) {
			return;
		}
		this.scope.filter = filter;
		this.scope.filterName = filter["name"];
		this.scrollToTop();
	}

	/**
	 * Checks if the user can edit the given page.
	 * @param page
	 * @returns boolean
	 */
	private canUserEditPage(page: c.IPage): boolean {
		let isPagePrivate = p.PageUtil.isPagePrivate(page.data);
		return page.isEditable && !isPagePrivate;
	}

	static add(m: ng.IModule): void {
		m.controller("lmPageLibraryCtrl", PageLibraryCtrl);
	}
}

export var init = (m: ng.IModule) => {
	PageLibraryCtrl.add(m);
};