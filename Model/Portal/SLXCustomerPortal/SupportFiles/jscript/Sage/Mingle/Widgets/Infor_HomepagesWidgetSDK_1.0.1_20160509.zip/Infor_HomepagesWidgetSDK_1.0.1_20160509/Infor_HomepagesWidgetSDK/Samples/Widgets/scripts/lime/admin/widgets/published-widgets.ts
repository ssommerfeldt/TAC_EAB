﻿import lm = require("../../lime");
import c = require("../../core");
import s = require("../service");

class AdminPublishedWidgetsCtrl extends c.CoreBase {
	public publishedWidgets: c.IWidgetInfo[] = [];
	public accessCopy: s.IWidgetAccess[];
	public noOfSelected: number;
	public widgetsGridOptions: any;
	public refreshText = "Refresh";
	public isSearchActive: boolean;

	private accessCopyWidgetId: string;

	static $inject = ["$scope", "lmAdminService", "lmAdminContext", "lmDialogService", "lmWidgetService", "uiGridConstants"];

	constructor(public scope: ng.IScope, private adminService: s.IAdminService, private adminContext: s.IAdminContext, private dialogService: lm.IDialogService,
		private widgetService: c.IWidgetService, private uiGridConstants: any) {
		super("[AdminPublishedWidgetsCtrl] ");

		this.initGrid();

		const adminConstants = s.AdminConstants;
		// Watch to see if this tab is selected
		const self = this;
		scope.$watch(adminConstants.openTab, (tab) => {
			if (tab === adminConstants.publishedWidgetsTab && !this.isSearchActive) {
				self.listPublishedWidgets(false);
			}
		});
	}

	private onError(error: any): void {
		this.adminService.handleError(error);
		this.setBusy(false);
	}

	private setBusy(isBusy: boolean): void {
		this.adminService.setBusy(isBusy);
	}

	public searchWidget(id: string): void {
		if (!lm.StringUtil.isNullOrWhitespace(id)) {
			id = id.trim();
			const result = lm.ArrayUtil.find(this.publishedWidgets, (item: c.IWidgetInfo) => {
				return (item.widgetId === id);
			});

			this.scope["widgetsGridApi"].selection.clearSelectedRows();
			this.widgetsGridOptions.data = result ? [result] : [];
			this.isSearchActive = true;
		}
	}

	public showGuidSearchDialog(): void {
		const options = <lm.IDialogOptions>{
			title: "Search",
			templateUrl: "scripts/lime/admin/templates/guid-search-dialog.html"
		};

		this.dialogService.show(options).then((r: lm.IDialogResult) => {
			if (!lm.CommonUtil.isUndefined(r.value) && r.button === lm.DialogButtonType.Ok) {
				const query = <string>r.value;
				if (query) {
					this.searchWidget(query);
				}
			}
		});
	}

	/**
	* List Published Widgets
	*
	* Lists published widgets from cache or server.
	*
	* @params reload Boolean - True: load from server. False: load from cache.
	* @params callback Function to be called when widgets are loaded from cache/server.
	*/
	public listPublishedWidgets(reload: boolean, callback?: Function): void {
		const self = this;
		const adminService = self.adminService;
		self.scope["searchIdString"] = "";
		self.isSearchActive = false;

		if (reload) {
			this.noOfSelected = 0;
			if (this.scope["widgetsGridApi"]) {
				this.scope["widgetsGridApi"].selection.clearSelectedRows();
			}
		}

		adminService.setBusy(true);
		adminService.listPublishedWidgets(reload).then((r: c.IWidgetListResponse) => {
			const publishedWidgets = r.content;
			self.publishedWidgets = publishedWidgets;
			self.widgetsGridOptions.data = publishedWidgets;
			adminService.setBusy(false);
			if (callback) {
				callback();
			}
		}, (r: c.IOperationResponse) => {
			adminService.setBusy(false);
			adminService.handleError(r);
			if (callback) {
				callback();
			}
		});
	}

	public import(): void {
		const dialogTitle = "Import Published Widgets";
		const adminService = this.adminService;
		const options: c.IImportOptions = {
			title: dialogTitle,
			operation: c.EntityCategory.publishedWidget.toString()
		};

		const self = this;
		adminService.openImportFilesDialog(options).then((r: lm.IDialogResult) => {
			const value = r.value;
			if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Success) {
				this.adminService.showUploadCompleteDialog(dialogTitle, value.message).then((result: lm.IDialogResult) => {
					if (result.button === lm.DialogButtonType.Ok) {
						self.listPublishedWidgets(true);
					}
				});
			} else if (r.button === lm.DialogButtonType.Yes && value.responseCode === c.DialogResponseCode.Fail) {
				adminService.showUploadCompleteDialog(dialogTitle, value.message, true);
			}
		});
	}

	/**
	* Export
	*
	* Export selected published widgets.
	*/
	public export(): void {
		if (this.noOfSelected === this.publishedWidgets.length) {
			this.exportAll();
		} else {
			const widgetsToExport = this.getSelectedRows();
			this.adminService.exportPublishedWidgets(widgetsToExport);
		}
	}

	/**
	* Export
	*
	* Export all published widgets.
	*/
	public exportAll(): void {
		this.adminService.exportPublishedWidgets();
	}

	/**
	* Delete
	*
	* Creates list of selected widget IDs in grid and calls delete.
	*/
	public delete(): void {
		const widgetsToDelete = this.getSelectedRows();
		const widgetList = widgetsToDelete.map((widget) => {
			return widget.widgetId;
		});
		this.deletePublished(widgetList);
	}

	/**
	* Open Widget Permissions Dialog
	*
	* Opens widget Permissions dialog. Used as an option in grid action menu.
	*/
	public openWidgetAccessDialog(widget: c.IWidgetInfo): void {
		this.adminService.openWidgetAccessDialog(widget, (resp: c.IWidgetInfoResponse) => {
			if (resp && resp.content) {
				this.updateAfterWidgetAccessUpdate(resp.content);
				this.setBusy(false);
			} else {
				this.onError(resp);
			}
		});
	}

	private updateAfterWidgetAccessUpdate(widgetInfo: c.IWidgetInfo): void {
		// Locate and update the widget in the list
		var existing = lm.ArrayUtil.find(this.publishedWidgets, (info) => info.widgetId === widgetInfo.widgetId);
		if (existing) {
			existing.hasAccess = widgetInfo.hasAccess;
			existing.hasRestrictions = widgetInfo.hasRestrictions;
		}
	}

	private updateOwner(existing: c.IWidgetInfo, updated: c.IWidgetInfo): void {
		existing.owner = updated.owner;
		existing.ownerName = updated.ownerName;
		existing.changedByName = updated.changedByName;
		existing.changeDate = updated.changeDate;
	}

	public takeOwnership(widget: c.IWidgetInfo): void {
		var self = this;
		this.setBusy(true);
		this.widgetService.updatePublishedOwner(widget.widgetId, null).then((response) => {
			self.updateOwner(widget, response.content);
			self.setBusy(false);
		}, (e) => {
			self.onError(e);
		});
	}

	public changeOwnership(widget: c.IWidgetInfo): void {
		var self = this;
		this.adminService.openChangeOwnerDialog(widget.title, widget.owner, (newOwner: lm.IAutocompleteEntity) => {
			if (widget.owner !== newOwner.value) {
				self.setBusy(true);
				self.widgetService.updatePublishedOwner(widget.widgetId, newOwner.value).then((response) => {
					self.updateOwner(widget, response.content);
					self.setBusy(false);
				}, (e) => {
					self.onError(e);
				});
			}
		});
	}
	
	/**
	* Copy widget Permissions.
	*
	* Copy access rights of a widget. Used as an option in grid action menu.
	*
	* @params widget to copy permissions from.
	*/
	public copyAccess(widget: c.IWidgetInfo): void {
		const self = this;
		const widgetId = widget.widgetId;
		const adminService = self.adminService;

		adminService.setBusy(true);
		adminService.getWidgetAccess({ id: widgetId, accessList: [] }).then((r: c.IOperationResponse) => {
			self.accessCopy = r.content.accessList;
			self.accessCopyWidgetId = widgetId;
			adminService.setBusy(false);
		}, (r: c.IOperationResponse) => {
			self.adminService.handleError(r);
			adminService.setBusy(false);
		});
	}

	/**
	* Apply Access Copy
	*
	* Apply copied acces rights to selected widget(s).
	*
	* @params widget Widget to edit. Otherwise use selected widgets in grid.
	*/
	public applyAccessCopy(widget?: c.IWidgetInfo): void {
		const widgets = widget ? [widget] : this.getSelectedRows();
		this.adminService.applyWidgetAccess(widgets, this.accessCopy, () => {
			this.listPublishedWidgets(true);
		});
	}

	/**
	* Clear Or Replace With Access Copy
	*
	* If indicated with "isReplace", replaces access rights.
	* Otherwise clear access rights of selected widgets.
	*
	* @params isReplace Boolean, true: replace, false: clear.
	*/
	public clearOrReplaceWithAccessCopy(isReplace?: boolean, widget?: c.IWidgetInfo): void {
		const widgetsToUpdate = widget ? [widget] : this.getSelectedRows();
		this.adminService.clearOrReplaceWidgetAccess(widgetsToUpdate, isReplace, () => {
			this.listPublishedWidgets(true);
		}, this.accessCopy);
	}

	/**
	* Init Grid
	*
	* Initialize the grid.
	*/
	private initGrid(): void {
		const gridConstants = this.uiGridConstants;
		const adminConstants = s.AdminConstants;
		const widgetActionTemplate = '<div class="ui-grid-cell-contents lm-center-text"><button type="button" ng-click="$event.stopPropagation();" ng-disabled="row.entity.widgetErrorInfo" class="btn-actions lm-transparent" xi-popupmenu="grid.appScope.ctrl.menuOptions"><span class="audible">Actions</span>' +
			'<svg class="icon" focusable="false" aria-hidden="false"><use xlink:href="#icon-more"/></svg></button><ul class="popupmenu actions top"><li><a ng-click="grid.appScope.ctrl.openWidgetAccessDialog(row.entity)">Edit Permissions</a></li>' +
			'<li ng-show="row.entity.hasAccess"><a ng-click="grid.appScope.ctrl.copyAccess(row.entity)">Copy Permissions</a></li><li ng-show="grid.appScope.ctrl.accessCopy && grid.appScope.ctrl.accessCopyWidgetId !== row.entity.widgetId" class="separator"></li>' +
			'<li ng-show="grid.appScope.ctrl.accessCopy && grid.appScope.ctrl.accessCopyWidgetId !== row.entity.widgetId"><a ng-click="grid.appScope.ctrl.applyAccessCopy(row.entity)">Apply Copied Permissions</a></li><li ng-show="grid.appScope.ctrl.accessCopyWidgetId && grid.appScope.ctrl.accessCopyWidgetId !== row.entity.widgetId && row.entity.hasAccess">' +
			'<a ng-click="grid.appScope.ctrl.clearOrReplaceWithAccessCopy(true, row.entity)">Replace Copied Permissions</a></li><li class="separator"></li><li><a ng-click="grid.appScope.ctrl.takeOwnership(row.entity)">Take Ownership</a></li><li><a ng-click="grid.appScope.ctrl.changeOwnership(row.entity)">Change Ownership</a></li><li class="separator"></li>' +
			'<li ng-show="row.entity.hasAccess"><a ng-click="grid.appScope.ctrl.clearOrReplaceWithAccessCopy(false, row.entity)">Clear Permissions</a></li><li><a ng-click="grid.appScope.ctrl.deletePublished(row.entity)">Delete</a></li></ul></div>';

		const rowTemplate = '<div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{\'disabled\': row.entity.widgetErrorInfo && col.colDef.name !== \'selectionRowHeaderCol\' }" ui-grid-cell></div>';

		const self = this;
		this.widgetsGridOptions = {
			paginationPageSizes: [adminConstants.gridPageSize],
			paginationPageSize: adminConstants.gridPageSize,
			columnDefs: [{
				field: "title", name: "Title",
				sort: { direction: gridConstants.ASC, priority: 1 },
				filter: { condition: gridConstants.filter.CONTAINS },
				minWidth: 50, maxWidth: 600
			},
				{ field: "description", name: "Description", minWidth: 50, maxWidth: 600 },
				{ field: "ownerName", name: "Owner", minWidth: 50, maxWidth: 600 },
				{ field: "standardWidgetId", name: "BasedOn", displayName: "Based on", minWidth: 50, maxWidth: 600 },
				{
					field: "changeDate", name: "ChangeDate", displayName: "Change date",
					cellTemplate: "<div class='ui-grid-cell-contents'>{{COL_FIELD | lmLocaleDate}}</div>", minWidth: 50, maxWidth: 600
				},
				{ field: "changedByName", name: "ChangeBy", displayName: "Changed by", minWidth: 50, maxWidth: 600 },
				{
					field: "hasRestrictions", name: "Permissions", enableFiltering: false, maxWidth: 140,
					cellTemplate: "<div class='ui-grid-cell-contents'>{{COL_FIELD ? 'Restricted' : ''}}</div>", enableColumnResizing: false
				},
				{ field: "actions", name: "Actions", maxWidth: 110, cellTemplate: widgetActionTemplate, enableFiltering: false, enableSorting: false, enableColumnResizing: false }],
			data: [],
			rowHeight: 48,
			rowTemplate: rowTemplate,
			enableFiltering: true,
			enableSorting: true,
			enableColumnMenus: false,
			onRegisterApi: (gridApi) => {
				self.scope["widgetsGridApi"] = gridApi;
				self.noOfSelected = 0;
				const gridSelection = gridApi.selection;
				const onSelection = gridSelection.on;

				onSelection.rowSelectionChanged(self.scope, () => {
					self.noOfSelected = gridSelection.getSelectedRows().length;
				});
				onSelection.rowSelectionChangedBatch(self.scope, () => {
					self.noOfSelected = gridSelection.getSelectedRows().length;
				});
			}
		}
	}

	private getSelectedRows(): c.IWidgetInfo[] {
		return this.scope["widgetsGridApi"].selection.getSelectedRows();
	}

	/**
	* Delete Published
	*
	* Displays confirmation message to the user and deletes provided widgets on confirm.
	*
	* @params widgets List of widget IDs to delete, or single WidgetInfo of widget to delete.
	*/
	private deletePublished(widgets: any): void {
		const isMultiple = Array.isArray(widgets);
		const title = isMultiple ? "Delete Widgets" : "Delete Widget";
		const message = isMultiple ? "Are you sure that you want to remove the selected widgets? They will be removed for all users." :
			"Are you sure that you want to remove the widget '" + widgets.title + "'? It will be removed for all users.";
		const options = {
			title: title,
			message: message,
			standardButtons: lm.StandardDialogButtons.YesNo
		};

		const widgetArray = isMultiple ? widgets : [widgets.widgetId];
		const self = this;
		this.dialogService.showMessage(options).then((result: lm.IDialogResult) => {
			if (result.button === lm.DialogButtonType.Yes) {
				this.setBusy(true);

				self.widgetService.deletePublished(widgetArray).then((r: c.IIntegerResponse) => {
					if (r.content > 0) {
                        for (let widgetId of widgetArray) {
                            this.adminService.unselectGridItem(lm.ArrayUtil.itemByProperty(self.publishedWidgets, "widgetId", widgetId), this.scope["widgetsGridApi"]);
                            lm.ArrayUtil.removeByProperty(self.publishedWidgets, "widgetId", widgetId);
                        }    
					}
					this.setBusy(false);
				}, (r: c.IOperationResponse) => {
					this.setBusy(false);
					self.adminService.handleError(r, r.errorText);
				});
			}
		});
    }

    /**
     * Clear selection
     * 
     * Clears the selected widgets in the grid.
     */
    private clearSelection(): void {
        this.noOfSelected = 0;
        const grid = this.scope["widgetsGridApi"];
        if (grid) {
            grid.selection.clearSelectedRows();
        }
    }

	static add(m: ng.IModule) {
		m.controller("lmAdminPublishedWidgetsCtrl", AdminPublishedWidgetsCtrl);
	}
}

export var init = (m: ng.IModule) => {
	AdminPublishedWidgetsCtrl.add(m);
}